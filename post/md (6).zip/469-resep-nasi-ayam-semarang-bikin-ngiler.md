---
description: "Resep Nasi Ayam Semarang, Bikin Ngiler"
title: "Resep Nasi Ayam Semarang, Bikin Ngiler"
slug: 469-resep-nasi-ayam-semarang-bikin-ngiler
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-07T09:07:19.741Z 
thumbnail: https://img-global.cpcdn.com/recipes/790ad311040aead5/682x484cq65/nasi-ayam-semarang-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/790ad311040aead5/682x484cq65/nasi-ayam-semarang-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/790ad311040aead5/682x484cq65/nasi-ayam-semarang-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/790ad311040aead5/682x484cq65/nasi-ayam-semarang-foto-resep-utama.webp
author: Virginia Gray
ratingvalue: 3.6
reviewcount: 7
recipeingredient:
- "Nasi liwet "
- "beras 1 cup"
- "daun salam 1 lembar"
- "sereh ambil bagian putihnya geprek 1 batang"
- "santan encer 1,5 cup"
- "garam 1/2 sdt"
- "Telur pindang "
- "telur 2 butir"
- "lebar daun salam 1"
- "sereh 1 batang"
- "teh celup 1 kantong"
- "bawang merah jangan di kupas 2 siung"
- "garam 1 sdt"
- "Air untuk merebus "
- "Opor ayam "
- "ayam kampung 1/2 ekor"
- "bawang putih 2 siung"
- "bawang merah 4 siung"
- "ketumbar 1 sdt"
- "kemiri 2 butir"
- "jahe 1 ruas"
- "lengkuas 1 ruas"
- "daun salam 2 lembar"
- "daun jeruk 2 lembar"
- "sereh 1 batang"
- "santan encer 2 gelas"
- "santan kental 1 gelas"
- "minyak goreng 2 sdm"
- "Garam dan gula "
- "Bawang goreng untuk taburan "
- "Sambel goreng labu siam "
- "labu siam saya 200 gr 1 buah"
- "cabe merah keriting 4 buah"
- "bawang merah 4 siung"
- "bawang putih 2 siung"
- "kemiri 1 butir"
- "minyak goreng 2 sdm"
- "santan encer 1 gelas"
- "santan kental 1/2 gelas"
- "Gula dan garam "
recipeinstructions:
- "Saya masak nasi seperti biasa dlm magicom kecil, air diganti santan encer ditambah sereh salam dan garam."
- "Rebus telur bersama salam, sereh, bawang merah dan teh celup selama 10 menit. Angkat telur, kupas. Kembalikan lagi ke air rebusan dan rebus kembali sekitar 15 menit, hingga permukaan nya jadi coklat. Angkat, sisihkan."
- "Uleg bumbu opor: bawang merah, bawang putih, ketumbar, dan kemiri. Geprek jahe, lengkuas, sereh. Remas sedikit salam dan daun jeruk."
- "Panaskan minyak goreng. Tumis bumbu halus sampai matang, harum, tambahkan jahe, lengkuas, sereh, salam dan daun jeruk. Aduk rata. Tambahkan ayam. Aduk sampai ayam berubah warna."
- "Tuang santan encer. Tambahkan garam dan gula. Kecilkan api, tutup wajan. Biarkan sampai ayam empuk dan santan susut."
- "Tambahkan santan kental. Aduk terus supaya santan tidak pecah. Setelah mendidih dan santan susut sedikit, matikan kompor, pindahkan opor ke mangkok. Taburi bawang goreng jika suka."
- "Uleg cabe, bawang merah, bawang putih dan kemiri. Iris korek api labu siam dan siapkan bumbu geprek: sereh, salam, lengkuas, daun jeruk dan rawit pedas biarkan utuh."
- "Panaskan minyak goreng. Tumis bumbu hingga matang dan harum. Tambahkan lengkuas, salam, sereh daun jeruk dan cabe rawit pedas. Aduk rata. Masukan labu Siam, aduk rata"
- "Tambahkan santan encer, garam dan gula. Aduk sampai labu Siam matang (warna jadi transparant). Tambahkan santan kental. Aduk jangan sampai santan pecah. Setelah mendidih matikan kompor. Pindahkan ke mangkok."
- "Sajikan. Tata di piring saji: nasi liwet, sambel goreng labu siam, telur pindang dan opor ayam. Ayam bisa di suwir, siram dengan kuah opor. Wah buka puasa yg nikmat banget."
categories:
- Resep
tags:
- nasi
- ayam
- semarang

katakunci: nasi ayam semarang 
nutrition: 113 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT54M"
recipeyield: "3"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Ayam Semarang](https://img-global.cpcdn.com/recipes/790ad311040aead5/682x484cq65/nasi-ayam-semarang-foto-resep-utama.webp)

Resep Nasi Ayam Semarang  enak dengan 10 langkahmudah yang harus kamu coba dirumah

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Dalam Menyiapkan Nasi Ayam Semarang:

1. Nasi liwet 
1. beras 1 cup
1. daun salam 1 lembar
1. sereh ambil bagian putihnya geprek 1 batang
1. santan encer 1,5 cup
1. garam 1/2 sdt
1. Telur pindang 
1. telur 2 butir
1. lebar daun salam 1
1. sereh 1 batang
1. teh celup 1 kantong
1. bawang merah jangan di kupas 2 siung
1. garam 1 sdt
1. Air untuk merebus 
1. Opor ayam 
1. ayam kampung 1/2 ekor
1. bawang putih 2 siung
1. bawang merah 4 siung
1. ketumbar 1 sdt
1. kemiri 2 butir
1. jahe 1 ruas
1. lengkuas 1 ruas
1. daun salam 2 lembar
1. daun jeruk 2 lembar
1. sereh 1 batang
1. santan encer 2 gelas
1. santan kental 1 gelas
1. minyak goreng 2 sdm
1. Garam dan gula 
1. Bawang goreng untuk taburan 
1. Sambel goreng labu siam 
1. labu siam saya 200 gr 1 buah
1. cabe merah keriting 4 buah
1. bawang merah 4 siung
1. bawang putih 2 siung
1. kemiri 1 butir
1. minyak goreng 2 sdm
1. santan encer 1 gelas
1. santan kental 1/2 gelas
1. Gula dan garam 



<!--inarticleads2-->

## Cara Membuat Nasi Ayam Semarang:

1. Saya masak nasi seperti biasa dlm magicom kecil, air diganti santan encer ditambah sereh salam dan garam.
1. Rebus telur bersama salam, sereh, bawang merah dan teh celup selama 10 menit. Angkat telur, kupas. Kembalikan lagi ke air rebusan dan rebus kembali sekitar 15 menit, hingga permukaan nya jadi coklat. Angkat, sisihkan.
1. Uleg bumbu opor: bawang merah, bawang putih, ketumbar, dan kemiri. Geprek jahe, lengkuas, sereh. Remas sedikit salam dan daun jeruk.
1. Panaskan minyak goreng. Tumis bumbu halus sampai matang, harum, tambahkan jahe, lengkuas, sereh, salam dan daun jeruk. Aduk rata. Tambahkan ayam. Aduk sampai ayam berubah warna.
1. Tuang santan encer. Tambahkan garam dan gula. Kecilkan api, tutup wajan. Biarkan sampai ayam empuk dan santan susut.
1. Tambahkan santan kental. Aduk terus supaya santan tidak pecah. Setelah mendidih dan santan susut sedikit, matikan kompor, pindahkan opor ke mangkok. Taburi bawang goreng jika suka.
1. Uleg cabe, bawang merah, bawang putih dan kemiri. Iris korek api labu siam dan siapkan bumbu geprek: sereh, salam, lengkuas, daun jeruk dan rawit pedas biarkan utuh.
1. Panaskan minyak goreng. Tumis bumbu hingga matang dan harum. Tambahkan lengkuas, salam, sereh daun jeruk dan cabe rawit pedas. Aduk rata. Masukan labu Siam, aduk rata
1. Tambahkan santan encer, garam dan gula. Aduk sampai labu Siam matang (warna jadi transparant). Tambahkan santan kental. Aduk jangan sampai santan pecah. Setelah mendidih matikan kompor. Pindahkan ke mangkok.
1. Sajikan. Tata di piring saji: nasi liwet, sambel goreng labu siam, telur pindang dan opor ayam. Ayam bisa di suwir, siram dengan kuah opor. Wah buka puasa yg nikmat banget.




Demikian informasi  resep Nasi Ayam Semarang   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
