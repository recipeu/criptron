---
description: "Cara Gampang Membuat Nasi Uduk Ungu (Kembang Teleng) Anti Gagal"
title: "Cara Gampang Membuat Nasi Uduk Ungu (Kembang Teleng) Anti Gagal"
slug: 126-cara-gampang-membuat-nasi-uduk-ungu-kembang-teleng-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-19T16:52:05.071Z 
thumbnail: https://img-global.cpcdn.com/recipes/b297870bc04b3607/682x484cq65/nasi-uduk-ungu-kembang-teleng-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/b297870bc04b3607/682x484cq65/nasi-uduk-ungu-kembang-teleng-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/b297870bc04b3607/682x484cq65/nasi-uduk-ungu-kembang-teleng-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/b297870bc04b3607/682x484cq65/nasi-uduk-ungu-kembang-teleng-foto-resep-utama.webp
author: Mae Brooks
ratingvalue: 4.8
reviewcount: 4
recipeingredient:
- "beras 6 cup"
- "santan kara 65ml 1 bungkus"
- "kembang teleng 40 buah"
- "air disesuaikan kondisi berasnya 12 cup"
- "garam 2 sdt"
- "gula pasir 1/4"
- "bawang merah 1 siung"
- "bawang putih 1 siung"
- "daun salam 3 lmbr"
- "sereh 3 btg"
- "lengkuas iris tipi 3 ruas"
- "jahe geprek 1 ruas"
- "Topping "
- "Bawang goreng "
- "Lauk pauk disesuaikan selera "
recipeinstructions:
- "Siapkan semua bahan, cuci bersih beras dan rempah-rempah"
- "Tuang air, santan, kembang teleng dan semua bumbu aduk sampai merata. Nyalahkan kompor masak sampai mendidih matikan"
- "Saring santan, lalu masukkan kembali rempah-rempah kecuali kembang teleng. Lalu masukkan beras masak sampai santan menyusut."
- "Siapkan panci kukusan, jika sudah mendidih masukkan beras aron masak kurleb 30 menit."
- "Nasi uduk ungu siap disajikan. Selamat mencoba"
categories:
- Resep
tags:
- nasi
- uduk
- ungu

katakunci: nasi uduk ungu 
nutrition: 198 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT33M"
recipeyield: "2"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Ungu (Kembang Teleng)](https://img-global.cpcdn.com/recipes/b297870bc04b3607/682x484cq65/nasi-uduk-ungu-kembang-teleng-foto-resep-utama.webp)

Resep dan cara memasak  Nasi Uduk Ungu (Kembang Teleng) yang musti ibu coba segera

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Dalam Pembuatan Nasi Uduk Ungu (Kembang Teleng):

1. beras 6 cup
1. santan kara 65ml 1 bungkus
1. kembang teleng 40 buah
1. air disesuaikan kondisi berasnya 12 cup
1. garam 2 sdt
1. gula pasir 1/4
1. bawang merah 1 siung
1. bawang putih 1 siung
1. daun salam 3 lmbr
1. sereh 3 btg
1. lengkuas iris tipi 3 ruas
1. jahe geprek 1 ruas
1. Topping 
1. Bawang goreng 
1. Lauk pauk disesuaikan selera 



<!--inarticleads2-->

## Cara Mudah Membuat Nasi Uduk Ungu (Kembang Teleng):

1. Siapkan semua bahan, cuci bersih beras dan rempah-rempah
1. Tuang air, santan, kembang teleng dan semua bumbu aduk sampai merata. Nyalahkan kompor masak sampai mendidih matikan
1. Saring santan, lalu masukkan kembali rempah-rempah kecuali kembang teleng. Lalu masukkan beras masak sampai santan menyusut.
1. Siapkan panci kukusan, jika sudah mendidih masukkan beras aron masak kurleb 30 menit.
1. Nasi uduk ungu siap disajikan. Selamat mencoba




Terima kasih telah menggunakan resep yang tim kami tampilkan di halaman ini. Semoga bermanfaat dan selamat mencoba!
