---
description: "Resep Nasi bakar ikan tuna, Menggugah Selera"
title: "Resep Nasi bakar ikan tuna, Menggugah Selera"
slug: 366-resep-nasi-bakar-ikan-tuna-menggugah-selera
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-27T09:02:03.331Z 
thumbnail: https://img-global.cpcdn.com/recipes/c34ce90b820bc5fe/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/c34ce90b820bc5fe/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/c34ce90b820bc5fe/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/c34ce90b820bc5fe/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp
author: Ralph Carroll
ratingvalue: 3.8
reviewcount: 5
recipeingredient:
- "resep nasi "
- "beras putih cuci 450 gram"
- "daun salam 3 lbr"
- "serai 1 batang"
- "laos 2 cm"
- "garam 2 sdt"
- "santan instan 65 ml"
- "air bisa diganti santan asli ±500 ml"
- "resep ikan tuna "
- "ikan tuna cuci bersih beri perasan jeruk nipis 200 gram"
- "bawang merah 4 siung"
- "bawang putih 4 siung"
- "lombok merah buang biji bila suka pedas tambahkan lombok rawit sesuai selera 1 buah"
- "kunyit 1 cm"
- "garam 1 1/2 sdt"
- "gula pasir 1/2 sdt"
- "bahan pelengkap "
- "daun kemangi 4 batang"
- "daun pisang utk membungkus "
recipeinstructions:
- "Masak beras dgn daun salam, serai,  laos, santan dan garam. Masak sambil diaduk hingga set. Matikan api. Panaskan dandang, kukus ±30 menit."
- "Sambil menunggu nasi matang, goreng ikan tuna setengah matang. Haluskan bawang merah, bawang putih, lombok dan kunyit. Suwir ikan tuna, sisihkan. Panaskan minyak sedikit utk menumis bumbu, masukan garam dan gula lalu ikan tuna ditumis beri air sedikit dan aduk terus hingga ikan benar2 masak. Matikan api."
- "Setelah nasi masak, siapkan daun pisang jgn lupa bakar daun hingga sedikit layu agar tdk sobek saat menggulung nasi. Ambil nasi letakan diatas daun pisang beri isian ikan tuna 2 sendok makan tambahkan kemangi beri lg nasi diatas ikan tuna. Gulung daun pisang dan semat kedua ujung daun dgn lidi. Lakukan hingga habis."
- "Bakar nasi dgn menggunakan teflon, bolak balik ±10 menit. Nasi bakar siap disajikan..."
- "Gurih dan nikmat..."
categories:
- Resep
tags:
- nasi
- bakar
- ikan

katakunci: nasi bakar ikan 
nutrition: 158 calories
recipecuisine: Indonesian
preptime: "PT38M"
cooktime: "PT60M"
recipeyield: "2"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi bakar ikan tuna](https://img-global.cpcdn.com/recipes/c34ce90b820bc5fe/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp)

5 langkah mudah dan cepat membuat  Nasi bakar ikan tuna yang wajib bunda coba segera

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Dalam Menyiapkan Nasi bakar ikan tuna:

1. resep nasi 
1. beras putih cuci 450 gram
1. daun salam 3 lbr
1. serai 1 batang
1. laos 2 cm
1. garam 2 sdt
1. santan instan 65 ml
1. air bisa diganti santan asli ±500 ml
1. resep ikan tuna 
1. ikan tuna cuci bersih beri perasan jeruk nipis 200 gram
1. bawang merah 4 siung
1. bawang putih 4 siung
1. lombok merah buang biji bila suka pedas tambahkan lombok rawit sesuai selera 1 buah
1. kunyit 1 cm
1. garam 1 1/2 sdt
1. gula pasir 1/2 sdt
1. bahan pelengkap 
1. daun kemangi 4 batang
1. daun pisang utk membungkus 

Angkat nasi dan Nasi Bakar Ikan Tuna Serai Kemangi siap dihidangkan. Jika suka, boleh juga hidangkan dengan sambal dan lalapan. Ada resep nasi bakar jamur merang, resep nasi bakar tuna dan resep nasi bakar ayam kemangi. Rasanya yang lezat membuat ikan tuna sering diolah menjadi berbagai macam olahan makanan seperti bakso tuna, steak tuna, pepes tuna maupun nasi bakar tuna. 

<!--inarticleads2-->

## Cara Membuat Nasi bakar ikan tuna:

1. Masak beras dgn daun salam, serai,  laos, santan dan garam. Masak sambil diaduk hingga set. Matikan api. Panaskan dandang, kukus ±30 menit.
1. Sambil menunggu nasi matang, goreng ikan tuna setengah matang. Haluskan bawang merah, bawang putih, lombok dan kunyit. Suwir ikan tuna, sisihkan. Panaskan minyak sedikit utk menumis bumbu, masukan garam dan gula lalu ikan tuna ditumis beri air sedikit dan aduk terus hingga ikan benar2 masak. Matikan api.
1. Setelah nasi masak, siapkan daun pisang jgn lupa bakar daun hingga sedikit layu agar tdk sobek saat menggulung nasi. Ambil nasi letakan diatas daun pisang beri isian ikan tuna 2 sendok makan tambahkan kemangi beri lg nasi diatas ikan tuna. Gulung daun pisang dan semat kedua ujung daun dgn lidi. Lakukan hingga habis.
1. Bakar nasi dgn menggunakan teflon, bolak balik ±10 menit. Nasi bakar siap disajikan...
1. Gurih dan nikmat...


Nasi Bakar Tuna &amp; Jamur Tiram Sea food bakar udang bakar madu udang bakar simple cumi bakar teflon kepiting bakar kecap pedas bandeng bakar kecap bawal bakar &amp; tips. Bawang putih ketumbar jahe garam resep olahan ikan tuna. Masukkan ikan tuna ke dalam wajan yang sudah berisi bumbu, lalu aduk hingga setengah matang. Masukkan satu serai, daun salam dan daun kemangi. 

Demikian informasi  resep Nasi bakar ikan tuna   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
