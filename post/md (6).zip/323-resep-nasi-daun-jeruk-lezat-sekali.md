---
description: "Resep Nasi Daun Jeruk, Lezat Sekali"
title: "Resep Nasi Daun Jeruk, Lezat Sekali"
slug: 323-resep-nasi-daun-jeruk-lezat-sekali
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-23T23:28:30.712Z 
thumbnail: https://img-global.cpcdn.com/recipes/d4db30ad83d2e66c/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/d4db30ad83d2e66c/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/d4db30ad83d2e66c/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/d4db30ad83d2e66c/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
author: Jeffrey Powers
ratingvalue: 3
reviewcount: 10
recipeingredient:
- "beras 2 cup"
- "bawang putih 3 siung"
- "daun jeruk 10 lembar"
- "Garam "
- "Minyak untuk menumis "
recipeinstructions:
- "Siapkan beras, masak dengan rice cooker"
- "Cincang bawang putih"
- "Buang tulang daun jeruk lalu iris tipis"
- "Panaskan minyak, tumis bawang putih hingga harum"
- "Masukkan irisan daun jeruk kemudian masukkan garam secukupnya"
- "Setelah nasi mulai matang masukkan tumisan bawang dan daun jeruk. Aduk rata"
- "Tunggu nasi matang sempurna"
- "Siap disajikan"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 182 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT54M"
recipeyield: "4"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk](https://img-global.cpcdn.com/recipes/d4db30ad83d2e66c/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp)

Resep rahasia dan cara mengolah  Nasi Daun Jeruk cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Untuk Pembuatan Nasi Daun Jeruk:

1. beras 2 cup
1. bawang putih 3 siung
1. daun jeruk 10 lembar
1. Garam 
1. Minyak untuk menumis 

Nasi daun jeruk siap dihidangkan dengan. Nasi daun jeruk ini memang sedang tren di kalangan masyarakat Indonesia, banyak sekali kaum muda mudi yang berlomba-lomba membuat makanan nasi putih spesial ini. Nasi daun jeruk ala geprek bensu rekomended buat di coba. Geprek bensu nasi daun jeruk anti mainst. 

<!--inarticleads2-->

## Cara Mudah Menyiapkan Nasi Daun Jeruk:

1. Siapkan beras, masak dengan rice cooker
1. Cincang bawang putih
1. Buang tulang daun jeruk lalu iris tipis
1. Panaskan minyak, tumis bawang putih hingga harum
1. Masukkan irisan daun jeruk kemudian masukkan garam secukupnya
1. Setelah nasi mulai matang masukkan tumisan bawang dan daun jeruk. Aduk rata
1. Tunggu nasi matang sempurna
1. Siap disajikan


Gurih dan wangi dari daun jeruk menambah kelezatan nasi daun jeruk. Nasi dengan campuran daun jeruk yang wangi sedang tren. Hai selamat pagi sahabat CWS, pagi ini saya share resep Nasi Daun Jeruk. Praktis banget karena saya gunakan rice cooker. Rasanya mirip nasi uduk tapi wangiiii. 

Demikian informasi  resep Nasi Daun Jeruk   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
