---
description: "Langkah Mudah untuk Membuat Nasi Daun Jeruk Rice Cooker yang Lezat Sekali"
title: "Langkah Mudah untuk Membuat Nasi Daun Jeruk Rice Cooker yang Lezat Sekali"
slug: 269-langkah-mudah-untuk-membuat-nasi-daun-jeruk-rice-cooker-yang-lezat-sekali
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-13T06:23:38.994Z 
thumbnail: https://img-global.cpcdn.com/recipes/8d499bed3a2f34c6/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/8d499bed3a2f34c6/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/8d499bed3a2f34c6/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/8d499bed3a2f34c6/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
author: Jane Alvarado
ratingvalue: 4.6
reviewcount: 9
recipeingredient:
- "daun pandan 3"
- "daun jeruk 10"
- "beras 1.5 cup"
- "Blue Band 1 sdm"
- "bawang putih goreng 1 sdm"
- "royco garam secukupnya"
- "air scukupnya untuk memasak nasi dalam rice cooker "
recipeinstructions:
- "Blender Daun Pandan dengan 100ml Air, saring, ambil airnya, tambahkan 10 daun jeruk yang sudah dibuang tengahnya, Blender sampai halus, Boleh saja di iris tipis."
- "Cuci bersih beras, buang air cucian beras tambahkan air pandan + daun jeruk + garam, royco + 1 sdm blue band + bwg putih goreng, aduk merata. + air secukupnya, Takaran air sesuai beras yang dimasak masak didalam rice cooker"
- "Nasi Daun jeruk sudah siap dihidangkan dengan Ayam grg / Ay. Bakar"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 158 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT52M"
recipeyield: "4"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk Rice Cooker](https://img-global.cpcdn.com/recipes/8d499bed3a2f34c6/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp)

3 langkah cepat dan mudah memasak  Nasi Daun Jeruk Rice Cooker yang wajib kamu coba dirumah

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Untuk Menyiapkan Nasi Daun Jeruk Rice Cooker:

1. daun pandan 3
1. daun jeruk 10
1. beras 1.5 cup
1. Blue Band 1 sdm
1. bawang putih goreng 1 sdm
1. royco garam secukupnya
1. air scukupnya untuk memasak nasi dalam rice cooker 



<!--inarticleads2-->

## Cara Menyiapkan Nasi Daun Jeruk Rice Cooker:

1. Blender Daun Pandan dengan 100ml Air, saring, ambil airnya, tambahkan 10 daun jeruk yang sudah dibuang tengahnya, Blender sampai halus, Boleh saja di iris tipis.
1. Cuci bersih beras, buang air cucian beras tambahkan air pandan + daun jeruk + garam, royco + 1 sdm blue band + bwg putih goreng, aduk merata. + air secukupnya, Takaran air sesuai beras yang dimasak masak didalam rice cooker
1. Nasi Daun jeruk sudah siap dihidangkan dengan Ayam grg / Ay. Bakar




Salah satu masakan yang cukup praktis dalam pembuatannya adalah  Nasi Daun Jeruk Rice Cooker. Selain itu  Nasi Daun Jeruk Rice Cooker  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu lakukan 3 langkah, dan  Nasi Daun Jeruk Rice Cooker  pun siap di hidangkan. selamat mencoba !
