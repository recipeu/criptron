---
description: "Resep Nasi daun jeruk tanpa santan yang Menggugah Selera"
title: "Resep Nasi daun jeruk tanpa santan yang Menggugah Selera"
slug: 293-resep-nasi-daun-jeruk-tanpa-santan-yang-menggugah-selera
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-30T16:40:15.918Z 
thumbnail: https://img-global.cpcdn.com/recipes/d23d60fb514de32a/682x484cq65/nasi-daun-jeruk-tanpa-santan-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/d23d60fb514de32a/682x484cq65/nasi-daun-jeruk-tanpa-santan-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/d23d60fb514de32a/682x484cq65/nasi-daun-jeruk-tanpa-santan-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/d23d60fb514de32a/682x484cq65/nasi-daun-jeruk-tanpa-santan-foto-resep-utama.webp
author: Catherine Tyler
ratingvalue: 4.4
reviewcount: 11
recipeingredient:
- "daun jeruk 5-6 lbr"
- "beras 2-3 cup"
- "bawang putih 3 siung"
- "daun sereh 1 batang"
- "daun salam 2-3 lbr"
- "garam 1 sdt"
- "lada 1/2 sdt"
- "kaldu ayamjamur 1/2 sdm"
- "Margarine 1-2 sdm"
recipeinstructions:
- "Siapkan bahan-bahan yang akan ditumis. Iris daun jeruk tipis-tipis dan halus. Iris bawang putih dan cincang kasar."
- "Siapkan wajan untuk menumis. Panaskan margarine (1- 1 setengah sdm) tuang bawang putih tumis sebentar sampai layu. Lalu masukan irisan daun jeruk tumis kembali dan beri 1/2sdt lada."
- "Cuci bersih beras yang sudah disiapkan dan beri air sesuai takaran. Masukan tumisan tadi ke dalam wadah magicom. Beri sedikit garam,1/2sdm kaldu ayam/jamur (untuk takaran penyedap tambahkan sesuai banyaknya jumlah nasi yang dimasak). Masukan daun salam dan batang sereh yang sudah di geprek aduk sebentar,lalu masak nasi dan tunggu hingga matang."
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 147 calories
recipecuisine: Indonesian
preptime: "PT15M"
cooktime: "PT41M"
recipeyield: "3"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi daun jeruk tanpa santan](https://img-global.cpcdn.com/recipes/d23d60fb514de32a/682x484cq65/nasi-daun-jeruk-tanpa-santan-foto-resep-utama.webp)

3 langkah cepat dan mudah mengolah  Nasi daun jeruk tanpa santan yang bisa ibu coba segera

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Dalam Pembuatan Nasi daun jeruk tanpa santan:

1. daun jeruk 5-6 lbr
1. beras 2-3 cup
1. bawang putih 3 siung
1. daun sereh 1 batang
1. daun salam 2-3 lbr
1. garam 1 sdt
1. lada 1/2 sdt
1. kaldu ayamjamur 1/2 sdm
1. Margarine 1-2 sdm

Nasi daun jeruk kini menjadi salah satu makanan hits yang digemari banyak orang. Selain lezat, aromanya juga mampu menggugah selera. Jika kamu tertarik dengan resep nasi jeruk tanpa santan, berikut adalah bahan-bahan masakan yang perlu kamu lengkapi. Nasi kuning sayur goresan tulungagung adventure. 

<!--inarticleads2-->

## Tata Cara Membuat Nasi daun jeruk tanpa santan:

1. Siapkan bahan-bahan yang akan ditumis. Iris daun jeruk tipis-tipis dan halus. Iris bawang putih dan cincang kasar.
1. Siapkan wajan untuk menumis. Panaskan margarine (1- 1 setengah sdm) tuang bawang putih tumis sebentar sampai layu. Lalu masukan irisan daun jeruk tumis kembali dan beri 1/2sdt lada.
1. Cuci bersih beras yang sudah disiapkan dan beri air sesuai takaran. Masukan tumisan tadi ke dalam wadah magicom. Beri sedikit garam,1/2sdm kaldu ayam/jamur (untuk takaran penyedap tambahkan sesuai banyaknya jumlah nasi yang dimasak). Masukan daun salam dan batang sereh yang sudah di geprek aduk sebentar,lalu masak nasi dan tunggu hingga matang.


Meskipun tanpa santan, nasi kuning buatanku rasanya tetep gurih lho, dan nggak enek sama sekali.! Nasi daun jeruk ini memang sedang tren di kalangan masyarakat Indonesia, banyak sekali kaum muda mudi Oke deh, tanpa berlama-lama lagi yuk kita buat Nasi Daun Jeruk yang enak dirumah aja. Disini topwisata memilih untuk menggunakan rice cooker ya moms. Dengan santan dan tanpa santan perbedaannya hanyalah rasa gurihnya saja yang berbeda. Namun keduanya tetap renyah saat disantap. 

Demikian informasi  resep Nasi daun jeruk tanpa santan   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
