---
description: "Langkah Mudah untuk Membuat Nasi daun jeruk rice cooker, Enak Banget"
title: "Langkah Mudah untuk Membuat Nasi daun jeruk rice cooker, Enak Banget"
slug: 275-langkah-mudah-untuk-membuat-nasi-daun-jeruk-rice-cooker-enak-banget
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-09T17:18:07.718Z 
thumbnail: https://img-global.cpcdn.com/recipes/53b8d9d50ce4c8a0/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/53b8d9d50ce4c8a0/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/53b8d9d50ce4c8a0/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/53b8d9d50ce4c8a0/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
author: Trevor Gregory
ratingvalue: 3.4
reviewcount: 13
recipeingredient:
- "beras 2 cup"
- "bawang putih dan 1 siung bawang merah 2 siung"
- "serepotong 2 1 btg"
- "daun salam 2 lembar"
- "daun jerukiris tipisbuang tulang daunnya 10 lembar"
- "kaldu jamur 1 sdt"
- "garam Sejumput"
- "air Secukupnya"
recipeinstructions:
- "Cuci bersih semuanya,lalu cincang kasar bawang,kemudian tumis"
- "Stlh beras dicuci, tambahkan air,masukkan tumisan bawang tadi,sere,daun salam,irisan daun jeruk,kaldu jamur,dan garam,aduk rata"
- "Masak nasi spti biasa,dan tunggu sampe matang,selesai."
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 141 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT55M"
recipeyield: "2"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi daun jeruk rice cooker](https://img-global.cpcdn.com/recipes/53b8d9d50ce4c8a0/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp)

Resep rahasia dan cara mengolah  Nasi daun jeruk rice cooker yang harus bunda coba segera

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Untuk Menyiapkan Nasi daun jeruk rice cooker:

1. beras 2 cup
1. bawang putih dan 1 siung bawang merah 2 siung
1. serepotong 2 1 btg
1. daun salam 2 lembar
1. daun jerukiris tipisbuang tulang daunnya 10 lembar
1. kaldu jamur 1 sdt
1. garam Sejumput
1. air Secukupnya

Hai selamat pagi sahabat CWS, pagi ini saya share resep Nasi Daun Jeruk. Praktis banget karena saya gunakan rice cooker. Rasanya mirip nasi uduk tapi wangiiii. Yukkk mari dipantengin dan dipraktekin yah. 

<!--inarticleads2-->

## Tata Cara Membuat Nasi daun jeruk rice cooker:

1. Cuci bersih semuanya,lalu cincang kasar bawang,kemudian tumis
1. Stlh beras dicuci, tambahkan air,masukkan tumisan bawang tadi,sere,daun salam,irisan daun jeruk,kaldu jamur,dan garam,aduk rata
1. Masak nasi spti biasa,dan tunggu sampe matang,selesai.


Berikut nih tips dari saya supaya nasi nya matang. Gurih dan wangi dari daun jeruk menambah kelezatan nasi daun jeruk. Setelah tombol menyatakan matang, masukkan daun jeruk. Jangan buka rice cooker sampai uap hilang. Sajikan nasi bersama lauk pelengkap seperti dadar rawis atau bakwan jagung. 

Demikian informasi  resep Nasi daun jeruk rice cooker   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
