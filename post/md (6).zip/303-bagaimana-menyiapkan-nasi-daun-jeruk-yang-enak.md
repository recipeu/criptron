---
description: "Bagaimana Menyiapkan Nasi Daun Jeruk yang Enak"
title: "Bagaimana Menyiapkan Nasi Daun Jeruk yang Enak"
slug: 303-bagaimana-menyiapkan-nasi-daun-jeruk-yang-enak
future: true
lang: id
language: id
languageCode: id
publishDate: 2022-01-04T15:04:41.304Z 
thumbnail: https://img-global.cpcdn.com/recipes/e008f568dd52f51a/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/e008f568dd52f51a/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/e008f568dd52f51a/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/e008f568dd52f51a/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
author: Winifred Lawson
ratingvalue: 3.2
reviewcount: 3
recipeingredient:
- "beras atau 500 gram beras 2 1/2 cup"
- "santan instan isi 65 mL 1 sachet"
- "daun jeruk buang tulang 15 lembar"
- "bawang merah 3 siung"
- "bawang putih 2 siung"
- "sereh digeprek 2 buah"
- "daun salam 3 lembar"
- "garam 2 sdt"
- "kaldu bubuk 1/2 sdt"
- "margarin 1 sdm"
- "air air dicampur santan banyaknya air dan santan sebanyak takaran air masak nasi biasa Secukupnya"
recipeinstructions:
- "Cuci beras. Tambahkan santan dan air. Tumis bawang merah dan bawang putih hingga harum dan layu, masukkan ke campuran beras"
- "Tambahkan daun jeruk, sereh, daun salam, garam dan kaldu bubuk. Masak di rice cooker hingga matang"
- "Jika sudah matang, aduk merata. Tambahkan 1 sdm margarin lalu aduk merata. Nasi jeruk siap disantap"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 193 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT56M"
recipeyield: "3"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk](https://img-global.cpcdn.com/recipes/e008f568dd52f51a/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp)

3 langkah cepat membuat  Nasi Daun Jeruk yang bisa ibu coba dirumah

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Untuk Pembuatan Nasi Daun Jeruk:

1. beras atau 500 gram beras 2 1/2 cup
1. santan instan isi 65 mL 1 sachet
1. daun jeruk buang tulang 15 lembar
1. bawang merah 3 siung
1. bawang putih 2 siung
1. sereh digeprek 2 buah
1. daun salam 3 lembar
1. garam 2 sdt
1. kaldu bubuk 1/2 sdt
1. margarin 1 sdm
1. air air dicampur santan banyaknya air dan santan sebanyak takaran air masak nasi biasa Secukupnya



<!--inarticleads2-->

## Tata Cara Membuat Nasi Daun Jeruk:

1. Cuci beras. Tambahkan santan dan air. Tumis bawang merah dan bawang putih hingga harum dan layu, masukkan ke campuran beras
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/e8ee2e9cbae042c4/160x128cq70/nasi-daun-jeruk-langkah-memasak-1-foto.webp" alt="Nasi Daun Jeruk" width="340" height="340">
>1. Tambahkan daun jeruk, sereh, daun salam, garam dan kaldu bubuk. Masak di rice cooker hingga matang
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/00ced531c5bb93ae/160x128cq70/nasi-daun-jeruk-langkah-memasak-2-foto.webp" alt="Nasi Daun Jeruk" width="340" height="340">
>1. Jika sudah matang, aduk merata. Tambahkan 1 sdm margarin lalu aduk merata. Nasi jeruk siap disantap
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/1ac77c30e553cce0/160x128cq70/nasi-daun-jeruk-langkah-memasak-3-foto.webp" alt="Nasi Daun Jeruk" width="340" height="340">
><img class="lazyload" data-src="https://img-global.cpcdn.com/steps/3ab8efe7e44412de/160x128cq70/nasi-daun-jeruk-langkah-memasak-3-foto.webp" alt="Nasi Daun Jeruk" width="340" height="340">
><img class="lazyload" data-src="https://img-global.cpcdn.com/steps/635152f4cffa1954/160x128cq70/nasi-daun-jeruk-langkah-memasak-3-foto.webp" alt="Nasi Daun Jeruk" width="340" height="340">
>



Demikian informasi  resep Nasi Daun Jeruk   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
