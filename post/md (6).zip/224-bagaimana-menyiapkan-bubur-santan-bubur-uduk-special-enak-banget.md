---
description: "Bagaimana Menyiapkan Bubur Santan / Bubur Uduk Special 👍, Enak Banget"
title: "Bagaimana Menyiapkan Bubur Santan / Bubur Uduk Special 👍, Enak Banget"
slug: 224-bagaimana-menyiapkan-bubur-santan-bubur-uduk-special-enak-banget
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-25T14:31:49.375Z 
thumbnail: https://img-global.cpcdn.com/recipes/c93f8655f053c4ae/682x484cq65/bubur-santan-bubur-uduk-special-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/c93f8655f053c4ae/682x484cq65/bubur-santan-bubur-uduk-special-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/c93f8655f053c4ae/682x484cq65/bubur-santan-bubur-uduk-special-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/c93f8655f053c4ae/682x484cq65/bubur-santan-bubur-uduk-special-foto-resep-utama.webp
author: Shane Hodges
ratingvalue: 4.3
reviewcount: 14
recipeingredient:
- "Nasi Matang 5 centong nasi"
- "Santan Kara 65 ml 1/2 bks kecil"
- "Garam Sesuai selera 1 sdt"
- "Daun Salam 2 lembar"
- "Daun pandan 1 lembar"
- "lengkuas 2 cm"
- "air 1,5 liter"
recipeinstructions:
- "Siapkan panci berisi air masukan daun salam,daun pandan dan lengkuas sampe hampir mendidih masukan nasi aduk2 sampai nasi nya tidak mengumpal...lalu masak sampai air menyusut dgn api sedang."
- "Aduk sesekali agar bubur tidak gosong. Setelah nasi setengah menjadi bubur, masukkan garam dan santan. Aduk-aduk jangan sampai santan pecah. Tes rasa."
- "Masak sambil diaduk-aduk sampai santan matang dan nasi menjadi bubur dengan tekstur sesuai selera. Kalo saya buburnya agak kental hasilnya, tidak terlalu lembut."
- "Siapkan bubur dimangkok saji..tambahkan pelengkap...saya tambahkan telur rebus dan bayam rebus yg dibumbui minyak bawang putih dan garam..           (lihat resep)"
categories:
- Resep
tags:
- bubur
- santan
- 

katakunci: bubur santan  
nutrition: 259 calories
recipecuisine: Indonesian
preptime: "PT12M"
cooktime: "PT45M"
recipeyield: "3"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Bubur Santan / Bubur Uduk Special 👍](https://img-global.cpcdn.com/recipes/c93f8655f053c4ae/682x484cq65/bubur-santan-bubur-uduk-special-foto-resep-utama.webp)

Resep rahasia Bubur Santan / Bubur Uduk Special 👍  enak dengan 4 langkahcepat yang wajib kamu coba segera

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Dalam Pembuatan Bubur Santan / Bubur Uduk Special 👍:

1. Nasi Matang 5 centong nasi
1. Santan Kara 65 ml 1/2 bks kecil
1. Garam Sesuai selera 1 sdt
1. Daun Salam 2 lembar
1. Daun pandan 1 lembar
1. lengkuas 2 cm
1. air 1,5 liter



<!--inarticleads2-->

## Cara Mudah Menyiapkan Bubur Santan / Bubur Uduk Special 👍:

1. Siapkan panci berisi air masukan daun salam,daun pandan dan lengkuas sampe hampir mendidih masukan nasi aduk2 sampai nasi nya tidak mengumpal...lalu masak sampai air menyusut dgn api sedang.
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/5fc7a0f4439621f6/160x128cq70/bubur-santan-bubur-uduk-special-langkah-memasak-1-foto.webp" alt="Bubur Santan / Bubur Uduk Special 👍" width="340" height="340">
>1. Aduk sesekali agar bubur tidak gosong. - Setelah nasi setengah menjadi bubur, masukkan garam dan santan. Aduk-aduk jangan sampai santan pecah. Tes rasa.
1. Masak sambil diaduk-aduk sampai santan matang dan nasi menjadi bubur dengan tekstur sesuai selera. Kalo saya buburnya agak kental hasilnya, tidak terlalu lembut.
1. Siapkan bubur dimangkok saji..tambahkan pelengkap...saya tambahkan telur rebus dan bayam rebus yg dibumbui minyak bawang putih dan garam.. -           (lihat resep)




Daripada bunda beli  Bubur Santan / Bubur Uduk Special 👍  diluar terus, ibu  bisa membuatnya sendiri dirumah. Resep  Bubur Santan / Bubur Uduk Special 👍  sederhana ini cukup praktis pembuatannya, cukup menggunakan bumbu-bumbu sederhana yang ada di dapur  Bubur Santan / Bubur Uduk Special 👍  yang enak, kamu nikmati di rumah.
