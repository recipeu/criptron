---
description: "Langkah Mudah untuk Membuat Sei Sapi Dengan Nasi Daun Jeruk Anti Gagal"
title: "Langkah Mudah untuk Membuat Sei Sapi Dengan Nasi Daun Jeruk Anti Gagal"
slug: 283-langkah-mudah-untuk-membuat-sei-sapi-dengan-nasi-daun-jeruk-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-29T12:10:20.625Z 
thumbnail: https://img-global.cpcdn.com/recipes/5c8fc9dfb830729e/682x484cq65/sei-sapi-dengan-nasi-daun-jeruk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/5c8fc9dfb830729e/682x484cq65/sei-sapi-dengan-nasi-daun-jeruk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/5c8fc9dfb830729e/682x484cq65/sei-sapi-dengan-nasi-daun-jeruk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/5c8fc9dfb830729e/682x484cq65/sei-sapi-dengan-nasi-daun-jeruk-foto-resep-utama.webp
author: Elnora Reyes
ratingvalue: 3.4
reviewcount: 8
recipeingredient:
- "daging sapi 300 gram"
- "daun singkong 1 ikat"
- "beras 50 gram"
- "gula palem 15 gram"
- "daun pandan 3 lembar"
- "beras 500 gram"
- "Kemangi iris 1 genggam"
- "bahan pengasapan  "
- "gula 1 sdt"
- "Air disesuaikan 650 ml"
- "Tomat 1 buah"
- "kecap Inggris 1 sdm"
- "daun salam 2 lembar"
- "serai geprek 1 batang"
- "lengkuas geprek 2 cm"
- "Daun serai geprek 1"
- "Bahan Tumis Sei Sapi  "
- "Daun salam 2 lembar"
- "Daun serai geprek 1 lembar"
- "Daun salam 2 lembar"
- "Lengkuas geprek 2 cm"
- "Jeruk nipis peras airnya 1 buah"
- "lada bubuk 1/2 sdt"
- "kaldu bubuk 1/2 sdt"
- "bit bubuk  1 tetes pewarna merah 1 sdt"
- "daun jeruk 5 lembar"
- "Nasi daun Jeruk  "
- "Bawang Merah iris tipis 6 siung"
- "Bawang Putih iris tipis 4 siung"
- "Cabe merah iris serong 1"
- "Gula pasir 1 sdt"
- "Bawang putih cincang 4 siung"
- "Cabe rawit sesuai selera 15"
- "Sambal Luat Khas NTT  "
- "Bawang merah 4 siung"
- "Bawang putih 1 siung"
- "garam 1/2 sdt"
- "Garam 1/2 sdt"
- "garam 1/2 sdt"
recipeinstructions:
- "Marinasi daging sapi dengan lada bubuk, garam dan saus Inggris. kemudian aduk rata. diamkan di kulkas selama 30 sampai 1 jam. untuk membuat bahan asapnya, kita siapkan dulu Kertas aluminium foil lalu beri beras, daun pandan, daun salam, daun jeruk, gula palem daun serai dan lengkuas. kemudian tutup dengan Saringan yang berlubang."
- "Panaskan wajan tebal, beri bahan asapnya kemudian Letakkan daging di atasnya. jangan lupa ditutup. lakukan pengasapan selama 1 jam. 30 menit pertama balik daging. gunakan api kecil supaya dagingnya empuk merata."
- "Setelah daging matang Iris tipis-tipis. bisa juga langsung dimakan atau diolah lagi. Saya tumis lagi. tumis bawang merah,bawang putih, cabe merah, daun serai dan daun salam hingga harum. beri garam dan dan gula pasir kemudian masukkan irisan sei sapi. angkat dan sisihkan."
- "Rebus daun singkong hingga matang kemudian tiriskan. Iris untuk kita jadikan makanan pendamping Sei sapi."
- "Kita buat nasi daun jeruk nya :Tumis bawang putih, daun jeruk, daun salam, lengkuas dan daun jeruk hingga harum. kemudian tambahkan garam dan kaldu bubuk. aduk rata. yang terakhir masukkan margarin, angkat lalu masukkan bumbu ke dalam beras yang berisi air. (Masak hingga matang dalam rice cooker). untuk mendapatkan warna merahnya, ketika nasi sudah matang. Ambil sebagian nasi lalu beri bit bubuk atau pewarna merah. Aduk rata."
- "Untuk sambal luat-nya: haluskan semua bahan sambal. beri garam dan gula pasir. kemudian beru irisan daun kemangi dan perasaan jeruk nipis. sambal siap disajikan bersama dengan paket Sei sapi lengkap lainnya."
categories:
- Resep
tags:
- sei
- sapi
- dengan

katakunci: sei sapi dengan 
nutrition: 156 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT34M"
recipeyield: "2"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Sei Sapi Dengan Nasi Daun Jeruk](https://img-global.cpcdn.com/recipes/5c8fc9dfb830729e/682x484cq65/sei-sapi-dengan-nasi-daun-jeruk-foto-resep-utama.webp)

Ingin membuat Sei Sapi Dengan Nasi Daun Jeruk ? Coba resep berikut ini. Cara memasaknya sangat praktis namun jangan kaget jika hasilnya gurih dan lezat cocok sekali jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Dalam Pembuatan Sei Sapi Dengan Nasi Daun Jeruk:

1. daging sapi 300 gram
1. daun singkong 1 ikat
1. beras 50 gram
1. gula palem 15 gram
1. daun pandan 3 lembar
1. beras 500 gram
1. Kemangi iris 1 genggam
1. bahan pengasapan  
1. gula 1 sdt
1. Air disesuaikan 650 ml
1. Tomat 1 buah
1. kecap Inggris 1 sdm
1. daun salam 2 lembar
1. serai geprek 1 batang
1. lengkuas geprek 2 cm
1. Daun serai geprek 1
1. Bahan Tumis Sei Sapi  
1. Daun salam 2 lembar
1. Daun serai geprek 1 lembar
1. Daun salam 2 lembar
1. Lengkuas geprek 2 cm
1. Jeruk nipis peras airnya 1 buah
1. lada bubuk 1/2 sdt
1. kaldu bubuk 1/2 sdt
1. bit bubuk  1 tetes pewarna merah 1 sdt
1. daun jeruk 5 lembar
1. Nasi daun Jeruk  
1. Bawang Merah iris tipis 6 siung
1. Bawang Putih iris tipis 4 siung
1. Cabe merah iris serong 1
1. Gula pasir 1 sdt
1. Bawang putih cincang 4 siung
1. Cabe rawit sesuai selera 15
1. Sambal Luat Khas NTT  
1. Bawang merah 4 siung
1. Bawang putih 1 siung
1. garam 1/2 sdt
1. Garam 1/2 sdt
1. garam 1/2 sdt



<!--inarticleads2-->

## Cara Menyiapkan Sei Sapi Dengan Nasi Daun Jeruk:

1. Marinasi daging sapi dengan lada bubuk, garam dan saus Inggris. kemudian aduk rata. diamkan di kulkas selama 30 sampai 1 jam. untuk membuat bahan asapnya, kita siapkan dulu Kertas aluminium foil lalu beri beras, daun pandan, daun salam, daun jeruk, gula palem daun serai dan lengkuas. kemudian tutup dengan Saringan yang berlubang.
1. Panaskan wajan tebal, beri bahan asapnya kemudian Letakkan daging di atasnya. jangan lupa ditutup. lakukan pengasapan selama 1 jam. 30 menit pertama balik daging. gunakan api kecil supaya dagingnya empuk merata.
1. Setelah daging matang Iris tipis-tipis. bisa juga langsung dimakan atau diolah lagi. Saya tumis lagi. tumis bawang merah,bawang putih, cabe merah, daun serai dan daun salam hingga harum. beri garam dan dan gula pasir kemudian masukkan irisan sei sapi. angkat dan sisihkan.
1. Rebus daun singkong hingga matang kemudian tiriskan. Iris untuk kita jadikan makanan pendamping Sei sapi.
1. Kita buat nasi daun jeruk nya :Tumis bawang putih, daun jeruk, daun salam, lengkuas dan daun jeruk hingga harum. kemudian tambahkan garam dan kaldu bubuk. aduk rata. yang terakhir masukkan margarin, angkat lalu masukkan bumbu ke dalam beras yang berisi air. (Masak hingga matang dalam rice cooker). untuk mendapatkan warna merahnya, ketika nasi sudah matang. Ambil sebagian nasi lalu beri bit bubuk atau pewarna merah. Aduk rata.
1. Untuk sambal luat-nya: haluskan semua bahan sambal. beri garam dan gula pasir. kemudian beru irisan daun kemangi dan perasaan jeruk nipis. sambal siap disajikan bersama dengan paket Sei sapi lengkap lainnya.




Demikian informasi  resep Sei Sapi Dengan Nasi Daun Jeruk   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
