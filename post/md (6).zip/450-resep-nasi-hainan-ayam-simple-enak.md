---
description: "Resep Nasi Hainan Ayam Simple, Enak"
title: "Resep Nasi Hainan Ayam Simple, Enak"
slug: 450-resep-nasi-hainan-ayam-simple-enak
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-29T15:36:23.503Z 
thumbnail: https://img-global.cpcdn.com/recipes/c1ea15dca3582c5c/682x484cq65/nasi-hainan-ayam-simple-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/c1ea15dca3582c5c/682x484cq65/nasi-hainan-ayam-simple-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/c1ea15dca3582c5c/682x484cq65/nasi-hainan-ayam-simple-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/c1ea15dca3582c5c/682x484cq65/nasi-hainan-ayam-simple-foto-resep-utama.webp
author: Allie Norton
ratingvalue: 3.8
reviewcount: 10
recipeingredient:
- "Bahan Kaldu  "
- "dada ayam 250 gr"
- "bawang bombai iris 1/4 buah"
- "bawang putih cincang halus 2 siung"
- "jahe cincang kasar 1 ruas"
- "garam 1 sdt"
- "kaldu bubuk 1 sdt"
- "lada bubuk 1/2 sdt"
- "kecap ikan 1/2 sdt"
- "minyak wijen 1 sdm"
- "daun bawang iris serong 1 batang"
- "air Secukupnya"
- "Bahan Nasi  "
- "beras cuci bersih 200 gr"
- "bawang putih uleg 2 siung"
- "bawang merah uleg 1 siung"
- "jahe parut 1 ruas"
- "wortel parut 1 buah"
- "daun bawang iris 1 batang"
- "serai 1 batang"
- "saus tiram 1 sdt"
- "garam 1 sdt"
- "lada bubuk 1/2 sdt"
- "kecap asin 1/2 sdt"
- "minyak wijen 1 sdm"
- "air Secukupnya"
- "Bahan Sambal  "
- "bawang putih uleg 1 siung"
- "cabe rawit merah iris 5 buah"
- "air kaldu dan kecap asin Secukupnya"
recipeinstructions:
- "Pertama bersihkan dada ayam nya lalu beri perasan jeruk supaya tidak amis, diamkan 10 menit..siapkan bahan untuk kaldu, tumis bawang putih, bombai dan jahe hingga wangi lalu tuang secukupnya air (kira2 saja ya, tergantung mau seberapa banyak kuah kaldu yg kita inginkan) masukan bumbu lainnya, koreksi rasa abis itu masukin ayam nya, masak hingga ayam nya matang. Sisihkan ayam nya"
- "Siapkan bahan nasi..tumis dua bawang, wortel, daun bawang dan jahe hingga harum, setelah itu masukan beras dan bumbu lainnya, beri sedikit air supaya bumbu meresap, aduk2.. Selanjutnya pindahkan tumisan beras ke panci, beri secukupnya air kaldu dan air biasa (pokok nya airnya cukup untuk rebus nasi setengah matang ya)"
- "Panaskan kukusan. Pindahkan nasi setengah matang ke kukusan beserta ayam yg kita rebus tadi..kukus selama 10-15 menit sampai nasi matang.  Panaskan air kaldu dan beri irisan daun bawang. Untuk sambal nya bisa disesuaikan ya.. Siap untuk dinikmati🤤"
- "Penyajian: cetak nasi dalam mangkok kecil, letakkan diatas piring cantik-iris ayam secukupnya-ambil air kaldu tuangkan ke mangkok-sajikan dengan sambal Selamat mencoba ❤"
categories:
- Resep
tags:
- nasi
- hainan
- ayam

katakunci: nasi hainan ayam 
nutrition: 187 calories
recipecuisine: Indonesian
preptime: "PT19M"
cooktime: "PT33M"
recipeyield: "3"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Hainan Ayam Simple](https://img-global.cpcdn.com/recipes/c1ea15dca3582c5c/682x484cq65/nasi-hainan-ayam-simple-foto-resep-utama.webp)

4 langkah cepat dan mudah mengolah  Nasi Hainan Ayam Simple yang bisa kamu coba dirumah

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Untuk Menyiapkan Nasi Hainan Ayam Simple:

1. Bahan Kaldu  
1. dada ayam 250 gr
1. bawang bombai iris 1/4 buah
1. bawang putih cincang halus 2 siung
1. jahe cincang kasar 1 ruas
1. garam 1 sdt
1. kaldu bubuk 1 sdt
1. lada bubuk 1/2 sdt
1. kecap ikan 1/2 sdt
1. minyak wijen 1 sdm
1. daun bawang iris serong 1 batang
1. air Secukupnya
1. Bahan Nasi  
1. beras cuci bersih 200 gr
1. bawang putih uleg 2 siung
1. bawang merah uleg 1 siung
1. jahe parut 1 ruas
1. wortel parut 1 buah
1. daun bawang iris 1 batang
1. serai 1 batang
1. saus tiram 1 sdt
1. garam 1 sdt
1. lada bubuk 1/2 sdt
1. kecap asin 1/2 sdt
1. minyak wijen 1 sdm
1. air Secukupnya
1. Bahan Sambal  
1. bawang putih uleg 1 siung
1. cabe rawit merah iris 5 buah
1. air kaldu dan kecap asin Secukupnya



<!--inarticleads2-->

## Cara Mudah Membuat Nasi Hainan Ayam Simple:

1. Pertama bersihkan dada ayam nya lalu beri perasan jeruk supaya tidak amis, diamkan 10 menit..siapkan bahan untuk kaldu, tumis bawang putih, bombai dan jahe hingga wangi lalu tuang secukupnya air (kira2 saja ya, tergantung mau seberapa banyak kuah kaldu yg kita inginkan) masukan bumbu lainnya, koreksi rasa abis itu masukin ayam nya, masak hingga ayam nya matang. Sisihkan ayam nya
1. Siapkan bahan nasi..tumis dua bawang, wortel, daun bawang dan jahe hingga harum, setelah itu masukan beras dan bumbu lainnya, beri sedikit air supaya bumbu meresap, aduk2.. - Selanjutnya pindahkan tumisan beras ke panci, beri secukupnya air kaldu dan air biasa (pokok nya airnya cukup untuk rebus nasi setengah matang ya)
1. Panaskan kukusan. Pindahkan nasi setengah matang ke kukusan beserta ayam yg kita rebus tadi..kukus selama 10-15 menit sampai nasi matang.  - Panaskan air kaldu dan beri irisan daun bawang. Untuk sambal nya bisa disesuaikan ya.. Siap untuk dinikmati🤤
1. Penyajian: cetak nasi dalam mangkok kecil, letakkan diatas piring cantik-iris ayam secukupnya-ambil air kaldu tuangkan ke mangkok-sajikan dengan sambal - Selamat mencoba ❤




Demikian informasi  resep Nasi Hainan Ayam Simple   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
