---
description: "Cara Gampang Membuat Nasi Uduk Betawi Anti Gagal yang Bisa Manjain Lidah"
title: "Cara Gampang Membuat Nasi Uduk Betawi Anti Gagal yang Bisa Manjain Lidah"
slug: 28-cara-gampang-membuat-nasi-uduk-betawi-anti-gagal-yang-bisa-manjain-lidah
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-26T08:25:41.143Z 
thumbnail: https://img-global.cpcdn.com/recipes/cbc57c7e9d803e78/682x484cq65/nasi-uduk-betawi-anti-gagal-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/cbc57c7e9d803e78/682x484cq65/nasi-uduk-betawi-anti-gagal-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/cbc57c7e9d803e78/682x484cq65/nasi-uduk-betawi-anti-gagal-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/cbc57c7e9d803e78/682x484cq65/nasi-uduk-betawi-anti-gagal-foto-resep-utama.webp
author: Jerry Garcia
ratingvalue: 4.2
reviewcount: 13
recipeingredient:
- "beras 1 Kg"
- "santan sedang 1.200 ml"
- "minyak goreng 3 sdm (45 ml)"
- "bawang putih iris tipis cincang 3 siung"
- "bawang merah iris tipis 6 siung"
- "sereh geprek dan buat jadi simpul 3 batang"
- "garam 2 sdt"
- "jahe yang digeprek 1 ruas jempol"
- "lengkuas yang digeprek 1 ruas jempol"
- "46 cm kayu manis 2 ruas jari"
- "kecil daun salam jika besar pakai 2 lembar saja 4 lembar"
recipeinstructions:
- "Cuci beras sampai bersih dan air menjadi jernih, lalu rendam selama 1 jam."
- "Siapkan panci, nyalakan api kecil, lalu masukkan 3 sdm. minyak sayur."
- "Setelah minyak panas, masukkan bawang putih yang sudah dicincang."
- "Selanjutnya masukkan bawang merah yang sudah diiris tipis."
- "Aduk-aduk sampai bawang merah dan putih mengeluarkan aromanya."
- "Tambahkan 100 ml santan kemudian terus aduk supaya santan tidak pecah."
- "Tunggu beberapa saat lalu masukkan jahe, lengkuas, daun salam."
- "Masukkan juga kayu manis serta sereh yang sudah digeprek dan disimpul."
- "Aduk sampai wangi, lalu masukkan sisa santan dan garam ke dalam panci. Aduk sampai benar-benar merata."
- "Kalau sudah tercampur rata, besarkan sedikit api menjadi api sedang. Bila sudah mulai mendidih masukkan beras yang sudah disiapkan, kemudian masak hingga air terserap beras 80-90% dan menjadi aronan. Kemudian matikan api. Aduk sesekali saja, jangan terlalu sering supaya butiran beras tidak patah-patah."
- "Sisihkan aronan, kemudian siapkan kukusan. Saat kukusan sudah ngebul, kukus aronan selama 30 menit hingga matang. Bila sudah matang, pindahkan ke tempat lain dan jangan lupa sisihkan sisa rempah yang ada dalam nasi."
- "Sajikan nasi uduk bersama sambal, bawang goreng, kerupuk, dan hidangan lainnya sesuai selera Anda..."
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 258 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT54M"
recipeyield: "4"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Betawi Anti Gagal](https://img-global.cpcdn.com/recipes/cbc57c7e9d803e78/682x484cq65/nasi-uduk-betawi-anti-gagal-foto-resep-utama.webp)

12 langkah mudah dan cepat memasak  Nasi Uduk Betawi Anti Gagal yang harus ibu coba dirumah

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Untuk Pembuatan Nasi Uduk Betawi Anti Gagal:

1. beras 1 Kg
1. santan sedang 1.200 ml
1. minyak goreng 3 sdm (45 ml)
1. bawang putih iris tipis cincang 3 siung
1. bawang merah iris tipis 6 siung
1. sereh geprek dan buat jadi simpul 3 batang
1. garam 2 sdt
1. jahe yang digeprek 1 ruas jempol
1. lengkuas yang digeprek 1 ruas jempol
1. 46 cm kayu manis 2 ruas jari
1. kecil daun salam jika besar pakai 2 lembar saja 4 lembar



<!--inarticleads2-->

## Langkah-langkah Untuk Membuat Nasi Uduk Betawi Anti Gagal:

1. Cuci beras sampai bersih dan air menjadi jernih, lalu rendam selama 1 jam.
1. Siapkan panci, nyalakan api kecil, lalu masukkan 3 sdm. minyak sayur.
1. Setelah minyak panas, masukkan bawang putih yang sudah dicincang.
1. Selanjutnya masukkan bawang merah yang sudah diiris tipis.
1. Aduk-aduk sampai bawang merah dan putih mengeluarkan aromanya.
1. Tambahkan 100 ml santan kemudian terus aduk supaya santan tidak pecah.
1. Tunggu beberapa saat lalu masukkan jahe, lengkuas, daun salam.
1. Masukkan juga kayu manis serta sereh yang sudah digeprek dan disimpul.
1. Aduk sampai wangi, lalu masukkan sisa santan dan garam ke dalam panci. Aduk sampai benar-benar merata.
1. Kalau sudah tercampur rata, besarkan sedikit api menjadi api sedang. Bila sudah mulai mendidih masukkan beras yang sudah disiapkan, kemudian masak hingga air terserap beras 80-90% dan menjadi aronan. Kemudian matikan api. Aduk sesekali saja, jangan terlalu sering supaya butiran beras tidak patah-patah.
1. Sisihkan aronan, kemudian siapkan kukusan. Saat kukusan sudah ngebul, kukus aronan selama 30 menit hingga matang. Bila sudah matang, pindahkan ke tempat lain dan jangan lupa sisihkan sisa rempah yang ada dalam nasi.
1. Sajikan nasi uduk bersama sambal, bawang goreng, kerupuk, dan hidangan lainnya sesuai selera Anda...




Daripada   beli  Nasi Uduk Betawi Anti Gagal  diluar terus, bunda  bisa membuatnya sendiri dirumah. Resep  Nasi Uduk Betawi Anti Gagal  sederhana ini cukup praktis pembuatannya, serta cukup menggunakan bumbu-bumbu sederhana yang ada di dapur  Nasi Uduk Betawi Anti Gagal  yang enak, ibu nikmati di rumah.
