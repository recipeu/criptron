---
description: "Langkah Mudah untuk Membuat Nasi uduk bumbu kacang yang Enak Banget"
title: "Langkah Mudah untuk Membuat Nasi uduk bumbu kacang yang Enak Banget"
slug: 205-langkah-mudah-untuk-membuat-nasi-uduk-bumbu-kacang-yang-enak-banget
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-24T03:55:32.790Z 
thumbnail: https://img-global.cpcdn.com/recipes/775ebbcdeb597a21/682x484cq65/nasi-uduk-bumbu-kacang-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/775ebbcdeb597a21/682x484cq65/nasi-uduk-bumbu-kacang-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/775ebbcdeb597a21/682x484cq65/nasi-uduk-bumbu-kacang-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/775ebbcdeb597a21/682x484cq65/nasi-uduk-bumbu-kacang-foto-resep-utama.webp
author: Rebecca Clark
ratingvalue: 4.1
reviewcount: 10
recipeingredient:
- "santan asli 1200 ml"
- "nasi 5 kerek "
- "sereh 2 batang dikeprek "
- "daun salam 6"
- "jahe 2 ruas dikeprek "
- "lengkuas 2 ruas dikeprek "
- "kayu manis sekitar 1 jari"
- "cengkeh 5"
- "pala 1 yg kecil dihancurkan "
- "daun pandan 6 diikat masing2 2 daun "
- "garam lada totole sedikit"
- "minyak bawang merah minyak bekas msak bawang goreng disisihkan "
- "Bumbu Kacang "
- "kacang tanah digoreng "
- "bawang putih 2"
- "cabe besar 4"
- "cabe rawit segenggam"
- "jeruk lemon 50 ml"
- "gula merah "
- "garam totole secukupnya"
recipeinstructions:
- "Santan dituang diwajan dimasukkan semua dengan bahan lainnya dimasak sampai santan mendidih dengan api kecil terus diaduk agar tidak pecah santan, masukkan garam, lada, totole. kemudian setelah mendidih masukkan beras dan aron sampai semua menyerap. setelah itu siapkan kukusan dan beras setengah matang itu dikukus 45 menit sampai matang test rasa. setelah matang diaduk dan tutup sesaat. setelah itu diambil daun2, rempahnya dan diberikan minyak bawang, diaduk lagi dan pindahkan ke ricecooker warm"
- "Kacang, cabai, dan bawang digoreng kemudian dihaluskan dgn cara diulek ataupun diblender, kemudian campurkan air lemon, garam, totole, gula merah ratakan dan test rasa. jika dirasa kekentalan bisa ditambahkan air lagi."
- "Selamat menikmati. nasi uduk enakkk bgt dgn tambahan2 lauk yg cocok seperti ayam goreng, tempe orek, perkedel, bihun goreng dan pastinya bawang goreng dan krupuk. selamat menikmati"
categories:
- Resep
tags:
- nasi
- uduk
- bumbu

katakunci: nasi uduk bumbu 
nutrition: 108 calories
recipecuisine: Indonesian
preptime: "PT15M"
cooktime: "PT45M"
recipeyield: "4"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi uduk bumbu kacang](https://img-global.cpcdn.com/recipes/775ebbcdeb597a21/682x484cq65/nasi-uduk-bumbu-kacang-foto-resep-utama.webp)

Resep Nasi uduk bumbu kacang  enak dengan 3 langkahcepat cocok banget jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Dalam Pembuatan Nasi uduk bumbu kacang:

1. santan asli 1200 ml
1. nasi 5 kerek 
1. sereh 2 batang dikeprek 
1. daun salam 6
1. jahe 2 ruas dikeprek 
1. lengkuas 2 ruas dikeprek 
1. kayu manis sekitar 1 jari
1. cengkeh 5
1. pala 1 yg kecil dihancurkan 
1. daun pandan 6 diikat masing2 2 daun 
1. garam lada totole sedikit
1. minyak bawang merah minyak bekas msak bawang goreng disisihkan 
1. Bumbu Kacang 
1. kacang tanah digoreng 
1. bawang putih 2
1. cabe besar 4
1. cabe rawit segenggam
1. jeruk lemon 50 ml
1. gula merah 
1. garam totole secukupnya

Ok langsung saja, silahkan catat bahan-bahan dan bumbu apa saja yang dibutuhkan, berikut ini adalah Resep Cara Membuat Nasi Uduk Kebon Kacang untuk anda. Resep nasi uduk betawi sebenarnya cukup sederhana, cara membuatnya juga tidak terlalu sulit, bahan dan bumbunya mudah didapat, serta tidak Sajikan nasi uduk yang telah matang dengan tambahan sambal kacang kemudian beri pelengkap seperti Telur dadar, ikan teri, bawang dan kacang goreng. Cara membuat nasi uduk betawi komplet. Nasi uduk: rebus santan, garam, daun salam, cengkih, serai, dan daun pandan. 

<!--inarticleads2-->

## Cara Membuat Nasi uduk bumbu kacang:

1. Santan dituang diwajan dimasukkan semua dengan bahan lainnya dimasak sampai santan mendidih dengan api kecil terus diaduk agar tidak pecah santan, masukkan garam, lada, totole. - kemudian setelah mendidih masukkan beras dan aron sampai semua menyerap. setelah itu siapkan kukusan dan beras setengah matang itu dikukus 45 menit sampai matang test rasa. setelah matang diaduk dan tutup sesaat. setelah itu diambil daun2, rempahnya dan diberikan minyak bawang, diaduk lagi dan pindahkan ke ricecooker warm
1. Kacang, cabai, dan bawang digoreng kemudian dihaluskan dgn cara diulek ataupun diblender, kemudian campurkan air lemon, garam, totole, gula merah ratakan dan test rasa. jika dirasa kekentalan bisa ditambahkan air lagi.
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/04d55e18a4f7ecec/160x128cq70/nasi-uduk-bumbu-kacang-langkah-memasak-2-foto.webp" alt="Nasi uduk bumbu kacang" width="340" height="340">
>1. Selamat menikmati. nasi uduk enakkk bgt dgn tambahan2 lauk yg cocok seperti ayam goreng, tempe orek, perkedel, bihun goreng dan pastinya bawang goreng dan krupuk. selamat menikmati


Sambal kering tempe: panaskan minyak goreng. Cara Membuat Resep Nasi Uduk Betawi Bumbu Komplit Bisa Dikukus Atau Menggunakan Rice Cooker atau Magic Com Dengan Sambal Bumbu Kacang, Kering Tempe Mudah Sederhana. Resep nasi uduk sederhana ala rumahan! Dari bahan - bumbu nasi uduk betawi istimewa hingga, detail cara membuat nasi uduk spesial untuk jualan Aduk rata semua bumbu - bahan nasi uduk sederhana tersebt. Tutup rice cooker / magicomnya, nyalakan dan tunggu deh sampai resep nasi. 

Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
