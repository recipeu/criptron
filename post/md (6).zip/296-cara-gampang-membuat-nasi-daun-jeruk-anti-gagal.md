---
description: "Cara Gampang Membuat Nasi daun jeruk Anti Gagal"
title: "Cara Gampang Membuat Nasi daun jeruk Anti Gagal"
slug: 296-cara-gampang-membuat-nasi-daun-jeruk-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-26T22:16:31.950Z 
thumbnail: https://img-global.cpcdn.com/recipes/43302e25a13d5a38/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/43302e25a13d5a38/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/43302e25a13d5a38/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/43302e25a13d5a38/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
author: George Phelps
ratingvalue: 4.1
reviewcount: 5
recipeingredient:
- "beras 750 gr"
- "santan kental Saya  kara instant 65 gr"
- "garam 1 sdt"
- "kaldu bubuk Saya  rasa ayam 1 sdt"
- "Bahan cair  "
- "daun jeruk buang tangkainya 7 lembar"
- "daun pandan 1 lembar"
- "serai 1 batang"
- "air 600 ml"
- "Taburan  "
- "daun jeruk cincang halus 10 lembar"
- "bawang goreng           lihat resep 5 sdm"
recipeinstructions:
- "Blender bahan cair, saring."
- "Cuci beras, tambahkan Garam, kaldu bubuk dan santan, aduk rata beri bahan cair yang sudah disaring."
- "Aduk rata kembali. Masak di rice cooker."
- "Setelah matang aduk rata nasi, beri taburan daun jeruk cincang, aduk rata kembali."
- "Setelah tercampur rata, hidupkan kembali rice cooker dengan metode warm selama 5 menit. Kemudian salin nasi daun jeruk."
- "Sajikan nasi daun jeruk, beri bawang goreng. Hmmmm wangi. Anak Saya malah makan Tanpa lauk. Enak katanya. Pas rasanya. Alhamdulillah."
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 120 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT56M"
recipeyield: "2"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi daun jeruk](https://img-global.cpcdn.com/recipes/43302e25a13d5a38/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp)

Resep dan cara memasak  Nasi daun jeruk cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Untuk Pembuatan Nasi daun jeruk:

1. beras 750 gr
1. santan kental Saya  kara instant 65 gr
1. garam 1 sdt
1. kaldu bubuk Saya  rasa ayam 1 sdt
1. Bahan cair  
1. daun jeruk buang tangkainya 7 lembar
1. daun pandan 1 lembar
1. serai 1 batang
1. air 600 ml
1. Taburan  
1. daun jeruk cincang halus 10 lembar
1. bawang goreng           lihat resep 5 sdm

Nasi daun jeruk siap dihidangkan dengan. Nasi daun jeruk ini memang sedang tren di kalangan masyarakat Indonesia, banyak sekali kaum muda mudi yang berlomba-lomba membuat makanan nasi putih spesial ini. Nasi daun jeruk ala geprek bensu rekomended buat di coba. Geprek bensu nasi daun jeruk anti mainst. 

<!--inarticleads2-->

## Langkah-langkah Untuk Membuat Nasi daun jeruk:

1. Blender bahan cair, saring.
1. Cuci beras, tambahkan Garam, kaldu bubuk dan santan, aduk rata beri bahan cair yang sudah disaring.
1. Aduk rata kembali. Masak di rice cooker.
1. Setelah matang aduk rata nasi, beri taburan daun jeruk cincang, aduk rata kembali.
1. Setelah tercampur rata, hidupkan kembali rice cooker dengan metode warm selama 5 menit. Kemudian salin nasi daun jeruk.
1. Sajikan nasi daun jeruk, beri bawang goreng. Hmmmm wangi. Anak Saya malah makan Tanpa lauk. Enak katanya. Pas rasanya. Alhamdulillah.


Gurih dan wangi dari daun jeruk menambah kelezatan nasi daun jeruk. Nasi dengan campuran daun jeruk yang wangi sedang tren. Hai selamat pagi sahabat CWS, pagi ini saya share resep Nasi Daun Jeruk. Praktis banget karena saya gunakan rice cooker. Rasanya mirip nasi uduk tapi wangiiii. 

Terima kasih telah menggunakan resep yang tim kami tampilkan di halaman ini. Selamat mencoba!
