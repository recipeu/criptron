---
description: "Cara Gampang Menyiapkan Resep Lumpia Basah Semarang yang Sempurna"
title: "Cara Gampang Menyiapkan Resep Lumpia Basah Semarang yang Sempurna"
slug: 495-cara-gampang-menyiapkan-resep-lumpia-basah-semarang-yang-sempurna
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-11T05:28:05.389Z 
thumbnail: https://img-global.cpcdn.com/recipes/2f0cdb3e4a5e599e/682x484cq65/resep-lumpia-basah-semarang-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/2f0cdb3e4a5e599e/682x484cq65/resep-lumpia-basah-semarang-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/2f0cdb3e4a5e599e/682x484cq65/resep-lumpia-basah-semarang-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/2f0cdb3e4a5e599e/682x484cq65/resep-lumpia-basah-semarang-foto-resep-utama.webp
author: Jeffery Casey
ratingvalue: 4.1
reviewcount: 8
recipeingredient:
- "Bahan Kulit Lumpia "
- "Kobe Tepung Kentucky SuperCrispy 1 bungkus"
- "margarin cairkan 3 sendok makan"
- "air 150 ml"
- "Bahan Isian "
- "bawang putih cincang 1 siung"
- "jahe cincang 1 cm"
- "dada ayam fillet potong dadu 12cm 15 gr"
- "udang tanpa kulit potong 1 cm 100 gr"
- "rebung potong sebesar batang korek api 200 gr"
- "daun bawang iris halus 2 tangkai"
- "ebi goreng dan haluskan 15 gr"
- "minyak goreng 1 sendok makan"
- "Kobe Bumbu Nasi Goreng Poll Pedas 1 bungkus"
- "Bahan Saus dan Acar "
- "air 200 ml"
- "gula jawa 300 gr"
- "minyak goreng 1 sdt"
- "bawang putih cincang 1 siung"
- "tepung kanji ditambal 50 ml air 10 gr"
- "gula pasir 1 sendok makan"
- "garam secukupnya"
- "mentimun potong dadu 1 cm 100 gr"
- "cuka beras 3 sendok makan"
- "cabai rawit utuh 10 bh"
recipeinstructions:
- "Cara membuat Saus dan Acar Saus: Tumis bawang putih hingga harum. Masukkan air, gula jawa, garam dan gula pasir. Masak sampai mendidih kemudian saring. Didihkan lagi."
- "Masukkan larutan air kanji. Masak sampai mengental, angkat."
- "Acar: Aduk mentimun, cuka beras, garam dan gula. Diamkan minimal 1 jam."
- "Cara membuat Kulit Lumpia Basah Semarang Siapkan wadah. Tuangkan Kobe Tepung Kentucky Super Crispy lalu encerkan dengan 150 ml air. Aduk merata hingga menjadi adonan basah."
- "Panaskan teflon dengan margarin cair. Ambil sesendok adonan basah lalu ratakan ke seluruh teflon. Masak hingga matang, sisihkan. Ulangi terus hingga adonan habis."
- "Cara membuat Isian Lumpia Basah Semarang Tumis bawang putih sampai harum, lalu masukkan jahe dan udang. Aduk sampai berubah warna."
- "Masukkan ayam, rebung, Kobe Bumbu Nasi Goreng Poll Pedas, daun bawang, kaldu dan ebi. Masak hingga kering. Angkat dan dinginkan."
- "Ambil selembar kulit lumpia, letakkan isi di tengah. Lipat. Rekatkan dengan saus"
- "Sajikan Lumpia Basah Semarang dengan saus, acar dan cabe rawit."
categories:
- Resep
tags:
- resep
- lumpia
- basah

katakunci: resep lumpia basah 
nutrition: 144 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT31M"
recipeyield: "1"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Resep Lumpia Basah Semarang](https://img-global.cpcdn.com/recipes/2f0cdb3e4a5e599e/682x484cq65/resep-lumpia-basah-semarang-foto-resep-utama.webp)

Resep Resep Lumpia Basah Semarang    dengan 9 langkahcepat dan mudah yang musti kamu coba dirumah

<!--inarticleads1-->

## Bahan-bahan Yang Dibutuhkan Dalam Menyiapkan Resep Lumpia Basah Semarang:

1. Bahan Kulit Lumpia 
1. Kobe Tepung Kentucky SuperCrispy 1 bungkus
1. margarin cairkan 3 sendok makan
1. air 150 ml
1. Bahan Isian 
1. bawang putih cincang 1 siung
1. jahe cincang 1 cm
1. dada ayam fillet potong dadu 12cm 15 gr
1. udang tanpa kulit potong 1 cm 100 gr
1. rebung potong sebesar batang korek api 200 gr
1. daun bawang iris halus 2 tangkai
1. ebi goreng dan haluskan 15 gr
1. minyak goreng 1 sendok makan
1. Kobe Bumbu Nasi Goreng Poll Pedas 1 bungkus
1. Bahan Saus dan Acar 
1. air 200 ml
1. gula jawa 300 gr
1. minyak goreng 1 sdt
1. bawang putih cincang 1 siung
1. tepung kanji ditambal 50 ml air 10 gr
1. gula pasir 1 sendok makan
1. garam secukupnya
1. mentimun potong dadu 1 cm 100 gr
1. cuka beras 3 sendok makan
1. cabai rawit utuh 10 bh



<!--inarticleads2-->

## Cara Mudah Menyiapkan Resep Lumpia Basah Semarang:

1. Cara membuat Saus dan Acar - Saus: Tumis bawang putih hingga harum. Masukkan air, gula jawa, garam dan gula pasir. Masak sampai mendidih kemudian saring. Didihkan lagi.
1. Masukkan larutan air kanji. Masak sampai mengental, angkat.
1. Acar: Aduk mentimun, cuka beras, garam dan gula. Diamkan minimal 1 jam.
1. Cara membuat Kulit Lumpia Basah Semarang - Siapkan wadah. Tuangkan Kobe Tepung Kentucky Super Crispy lalu encerkan dengan 150 ml air. Aduk merata hingga menjadi adonan basah.
1. Panaskan teflon dengan margarin cair. Ambil sesendok adonan basah lalu ratakan ke seluruh teflon. Masak hingga matang, sisihkan. Ulangi terus hingga adonan habis.
1. Cara membuat Isian Lumpia Basah Semarang - Tumis bawang putih sampai harum, lalu masukkan jahe dan udang. Aduk sampai berubah warna.
1. Masukkan ayam, rebung, Kobe Bumbu Nasi Goreng Poll Pedas, daun bawang, kaldu dan ebi. Masak hingga kering. Angkat dan dinginkan.
1. Ambil selembar kulit lumpia, letakkan isi di tengah. Lipat. Rekatkan dengan saus
1. Sajikan Lumpia Basah Semarang dengan saus, acar dan cabe rawit.




Salah satu masakan yang cukup praktis pembuatannya adalah  Resep Lumpia Basah Semarang. Selain itu  Resep Lumpia Basah Semarang  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu lakukan 9 langkah, dan  Resep Lumpia Basah Semarang  pun siap di hidangkan. selamat mencoba !
