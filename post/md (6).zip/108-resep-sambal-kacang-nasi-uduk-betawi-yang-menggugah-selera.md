---
description: "Resep Sambal Kacang Nasi Uduk Betawi yang Menggugah Selera"
title: "Resep Sambal Kacang Nasi Uduk Betawi yang Menggugah Selera"
slug: 108-resep-sambal-kacang-nasi-uduk-betawi-yang-menggugah-selera
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-14T02:42:55.716Z 
thumbnail: https://img-global.cpcdn.com/recipes/e7fcb250e59c02f1/682x484cq65/sambal-kacang-nasi-uduk-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/e7fcb250e59c02f1/682x484cq65/sambal-kacang-nasi-uduk-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/e7fcb250e59c02f1/682x484cq65/sambal-kacang-nasi-uduk-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/e7fcb250e59c02f1/682x484cq65/sambal-kacang-nasi-uduk-betawi-foto-resep-utama.webp
author: Clara Schneider
ratingvalue: 3.9
reviewcount: 11
recipeingredient:
- "kacang tanah yg sudah digoreng 50 gram"
- "cabe rawit orange 3 buah"
- "cabe merah 5 buah"
- "bawang putih yg sudah digoreng 1 siung"
- "terasi optional yaaa 1/4 sdt"
- "gula pasir 1 sdt"
- "garam 1/2 sdt"
- "air hangat 50 ml"
- "air jeruk limau Secukupnya"
recipeinstructions:
- "Siapkan cobek atau blender untuk menghaluskan bumbu. Kalau aku ngulek pakai cobek."
- "Goreng terlebih dahulu aneka cabai, bawang putih, dan terasi hingga lunak. Angkat, tiriskan."
- "Haluskan cabe merah, cabe rawit, bawang putih, garam, gula pasir, dan terasi. Setelah halus, masukan kacang tanah. Ulek sampai kacang tanah halus."
- "Tambahkan air hangat dan air jeruk limau. Aduk rata. Jangan lupa cicipi rasanya."
- "Setelah rasanya pas, sambal kacang siap dihidangkan sebagai pelengkap nasi uduk. Selamat mencoba!"
- "Ini nasi uduk yg aku buat + sambal kacang + semur daging kentang + tempe goreng tepung + bawang goreng + lalab ketimun kemangi"
categories:
- Resep
tags:
- sambal
- kacang
- nasi

katakunci: sambal kacang nasi 
nutrition: 178 calories
recipecuisine: Indonesian
preptime: "PT24M"
cooktime: "PT58M"
recipeyield: "2"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Sambal Kacang Nasi Uduk Betawi](https://img-global.cpcdn.com/recipes/e7fcb250e59c02f1/682x484cq65/sambal-kacang-nasi-uduk-betawi-foto-resep-utama.webp)

Ingin membuat Sambal Kacang Nasi Uduk Betawi ? Coba resep berikut ini. Cara memasaknya sangat praktis namun jangan kaget jika hasilnya gurih dan lezat cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Dalam Pembuatan Sambal Kacang Nasi Uduk Betawi:

1. kacang tanah yg sudah digoreng 50 gram
1. cabe rawit orange 3 buah
1. cabe merah 5 buah
1. bawang putih yg sudah digoreng 1 siung
1. terasi optional yaaa 1/4 sdt
1. gula pasir 1 sdt
1. garam 1/2 sdt
1. air hangat 50 ml
1. air jeruk limau Secukupnya



<!--inarticleads2-->

## Langkah-langkah Untuk Menyiapkan Sambal Kacang Nasi Uduk Betawi:

1. Siapkan cobek atau blender untuk menghaluskan bumbu. Kalau aku ngulek pakai cobek.
1. Goreng terlebih dahulu aneka cabai, bawang putih, dan terasi hingga lunak. Angkat, tiriskan.
1. Haluskan cabe merah, cabe rawit, bawang putih, garam, gula pasir, dan terasi. Setelah halus, masukan kacang tanah. Ulek sampai kacang tanah halus.
1. Tambahkan air hangat dan air jeruk limau. Aduk rata. Jangan lupa cicipi rasanya.
1. Setelah rasanya pas, sambal kacang siap dihidangkan sebagai pelengkap nasi uduk. Selamat mencoba!
1. Ini nasi uduk yg aku buat + sambal kacang + semur daging kentang + tempe goreng tepung + bawang goreng + lalab ketimun kemangi




Terima kasih telah menggunakan resep yang tim kami tampilkan di halaman ini. Selamat mencoba!
