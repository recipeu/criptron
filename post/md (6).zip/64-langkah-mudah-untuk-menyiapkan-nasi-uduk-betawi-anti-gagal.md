---
description: "Langkah Mudah untuk Menyiapkan Nasi Uduk Betawi Anti Gagal"
title: "Langkah Mudah untuk Menyiapkan Nasi Uduk Betawi Anti Gagal"
slug: 64-langkah-mudah-untuk-menyiapkan-nasi-uduk-betawi-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-14T12:20:53.493Z 
thumbnail: https://img-global.cpcdn.com/recipes/a379d7a0ee1be478/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/a379d7a0ee1be478/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/a379d7a0ee1be478/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/a379d7a0ee1be478/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
author: Hettie Chambers
ratingvalue: 4.3
reviewcount: 9
recipeingredient:
- "Beras yang agak pera 300 gram"
- "Santan kental secukupnya"
- "Jahe digeprek 3 cm"
- "Serai di geprek 2 buah"
- "Lengkuas di greprek 3 cm"
- "daun Salam secukupnya 2 lembar"
- "cengkih 4 butir"
- "Daun Pandan secukupnya"
- "bubuk Pala 12 sendok teh Sejumput"
- "Garam secukupnya"
- "Bahan halus  "
- "bawang merah 4 siung"
- "bawang putih 1 siung"
recipeinstructions:
- "Cuci bersih beras, lalu rendam dalam air sekitar 30 menit. Setelah 3 menit angkat, tiriskan."
- "Rebus santan kental, garam, tambahkan air secukupnya (sesuaikan dengan banyaknya beras) dan semua rempah2 termasuk bahan halus."
- "Aduk terus santan sampai mendidih dan harum. PS : dijaga agar santan tidak pecah"
- "Setelah mendidih, masukan beras yang sudah direndam tadi. Lalu dimasak aron sampai air meresap habis. Sering2 di aduk agar tidak lengket."
- "Setelah di aron, masukan dalam panci kukusan. Kukus nasi sampai matang. Angkat dan sajikan"
- "Hasilnya nasi uduk betawi ini akan harum, gurih dan sedikit berminyak. Tapi rasanya sangat mantap. Bisa dinikmati dengan lauk pelengkap lainnya. Selamat Mencoba😍"
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 251 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT37M"
recipeyield: "1"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Betawi](https://img-global.cpcdn.com/recipes/a379d7a0ee1be478/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp)

Resep Nasi Uduk Betawi    dengan 6 langkahcepat yang musti ibu coba segera

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Untuk Menyiapkan Nasi Uduk Betawi:

1. Beras yang agak pera 300 gram
1. Santan kental secukupnya
1. Jahe digeprek 3 cm
1. Serai di geprek 2 buah
1. Lengkuas di greprek 3 cm
1. daun Salam secukupnya 2 lembar
1. cengkih 4 butir
1. Daun Pandan secukupnya
1. bubuk Pala 12 sendok teh Sejumput
1. Garam secukupnya
1. Bahan halus  
1. bawang merah 4 siung
1. bawang putih 1 siung



<!--inarticleads2-->

## Cara Mudah Membuat Nasi Uduk Betawi:

1. Cuci bersih beras, lalu rendam dalam air sekitar 30 menit. Setelah 3 menit angkat, tiriskan.
1. Rebus santan kental, garam, tambahkan air secukupnya (sesuaikan dengan banyaknya beras) dan semua rempah2 termasuk bahan halus.
1. Aduk terus santan sampai mendidih dan harum. PS : dijaga agar santan tidak pecah
1. Setelah mendidih, masukan beras yang sudah direndam tadi. Lalu dimasak aron sampai air meresap habis. Sering2 di aduk agar tidak lengket.
1. Setelah di aron, masukan dalam panci kukusan. Kukus nasi sampai matang. Angkat dan sajikan
1. Hasilnya nasi uduk betawi ini akan harum, gurih dan sedikit berminyak. Tapi rasanya sangat mantap. Bisa dinikmati dengan lauk pelengkap lainnya. Selamat Mencoba😍




Salah satu kuliner yang cukup praktis dalam pembuatannya adalah  Nasi Uduk Betawi. Selain itu  Nasi Uduk Betawi  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu lakukan 6 langkah, dan  Nasi Uduk Betawi  pun siap di hidangkan. selamat mencoba !
