---
description: "Bagaimana Menyiapkan Nasi Uduk Betawi Anti Gagal"
title: "Bagaimana Menyiapkan Nasi Uduk Betawi Anti Gagal"
slug: 87-bagaimana-menyiapkan-nasi-uduk-betawi-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-25T20:37:07.454Z 
thumbnail: https://img-global.cpcdn.com/recipes/c597d22d5128fcc1/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/c597d22d5128fcc1/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/c597d22d5128fcc1/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/c597d22d5128fcc1/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
author: Clifford Zimmerman
ratingvalue: 3.8
reviewcount: 11
recipeingredient:
- "beras 10 cup"
- "beras ketan 1 cup"
- "santan dari 1 butir kelapa 13 cup"
- "daun pandan 3 lembar"
- "daun salam 3 lembar"
- "daun jeruk 2 lembar"
- "serai keprek 3 buah"
- "jahe keprek 1 ruas jari"
- "lengkuas keprek 1 ruas jari"
- "Garam secukupnya"
recipeinstructions:
- "Rendam beras ketan kurang lebih 6 jam."
- "Cuci bersih beras lalu campur dengan beras ketan, kukus beras hingga setengah matang."
- "Rebus santan, daun salam, serai, daun jeruk, jahe, lengkuas daun pandan dan garam. Tunggu mendidih."
- "Masukkan beras setengah matang tadi, dengan menggunakan api kecil aduk terus hingga santan menyusut."
- "Lalu kukus kurang lebih 30 menit. Nasi siap di sajikan dengan pendampingnya ☺☺☺"
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 106 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT57M"
recipeyield: "2"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Betawi](https://img-global.cpcdn.com/recipes/c597d22d5128fcc1/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp)

Resep rahasia Nasi Uduk Betawi    dengan 5 langkahcepat yang harus bunda coba dirumah

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Dalam Menyiapkan Nasi Uduk Betawi:

1. beras 10 cup
1. beras ketan 1 cup
1. santan dari 1 butir kelapa 13 cup
1. daun pandan 3 lembar
1. daun salam 3 lembar
1. daun jeruk 2 lembar
1. serai keprek 3 buah
1. jahe keprek 1 ruas jari
1. lengkuas keprek 1 ruas jari
1. Garam secukupnya



<!--inarticleads2-->

## Langkah-langkah Untuk Membuat Nasi Uduk Betawi:

1. Rendam beras ketan kurang lebih 6 jam.
1. Cuci bersih beras lalu campur dengan beras ketan, kukus beras hingga setengah matang.
1. Rebus santan, daun salam, serai, daun jeruk, jahe, lengkuas daun pandan dan garam. Tunggu mendidih.
1. Masukkan beras setengah matang tadi, dengan menggunakan api kecil aduk terus hingga santan menyusut.
1. Lalu kukus kurang lebih 30 menit. Nasi siap di sajikan dengan pendampingnya ☺☺☺




Daripada kamu beli  Nasi Uduk Betawi  diluar terus, kamu  bisa membuatnya sendiri dirumah. Resep  Nasi Uduk Betawi  sederhana ini cukup praktis dalam proses pembuatannya, serta cukup menggunakan bumbu-bumbu sederhana yang ada di dapur  Nasi Uduk Betawi  yang enak, bunda nikmati di rumah.
