---
description: "Langkah Mudah untuk Membuat Steak Maranggi + Nasi Daun Jeruk Anti Gagal"
title: "Langkah Mudah untuk Membuat Steak Maranggi + Nasi Daun Jeruk Anti Gagal"
slug: 284-langkah-mudah-untuk-membuat-steak-maranggi-nasi-daun-jeruk-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-04T12:18:02.462Z 
thumbnail: https://img-global.cpcdn.com/recipes/ab6c7aaaf845d4e3/682x484cq65/steak-maranggi-nasi-daun-jeruk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/ab6c7aaaf845d4e3/682x484cq65/steak-maranggi-nasi-daun-jeruk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/ab6c7aaaf845d4e3/682x484cq65/steak-maranggi-nasi-daun-jeruk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/ab6c7aaaf845d4e3/682x484cq65/steak-maranggi-nasi-daun-jeruk-foto-resep-utama.webp
author: Steven Palmer
ratingvalue: 4
reviewcount: 15
recipeingredient:
- "Steak  "
- "daging sirloin 500 gr"
- "coca cola untuk merendam daging Secukupnya"
- "bawang merah 7 siung"
- "bawang putih 5 siung"
- "lengkuas memarkan 2 ruas jari"
- "gula merah 2 sdm"
- "kecap manis 3 sdm"
- "ketumbar sangrai 1 sdm"
- "air asam 3 sdm"
- "Garam kaldu jamur lada bubuk "
- "Pelengkap "
- "tomat iris tipis atau uleg kasar 1 butir"
- "cabe rawit merah atau sesuai selera uleg kasar 2 buah"
- "Garam "
- "jeruk limau peras 1 butir"
- "bawang merah iris tipis Secukupnya"
- "Nasi Daun Jeruk "
- "beras 3 cup"
- "garam 1 sdt"
- "serai memarkan 2 batang"
- "daun jeruk buang tulang  remas2 10 lembar"
- "santan 65 ml"
- "air Secukupnya"
recipeinstructions:
- "Olah nasi:"
- "Cuci bersih beras &amp; masukkan ke dalam com"
- "Tambahkan santan, garam, daun jeruk, &amp; serai. Tuang air seperti takaran masak nasi biasa. Aduk. Masak menggunakan magic com"
- "Olah steak:"
- "Rendam daging dengan coca cola selama 1/2 jam. Lap menggunakan tissue dapur. Sisihkan"
- "Haluskan bawang merah, bawang putih, ketumbar &amp; gula merah menggunakan sedikit minyak"
- "Masukkan bumbu ke dalam daging. Tambahkan garam, lada bubuk &amp; kaldu jamur. Remas perlahan agar bumbu meresap. Diamkan selama min 1 jam"
- "Olah sambal tomat:"
- "Campurkan tomat, cabe rawit, garam &amp; perasan jeruk limau. Aduk rata"
- "Panaskan grill pan. Masukkan margarine &amp; panggang daging di atasnya sambil dioles sisa bumbu sampai tingkat kematangan yang diinginkan"
- "Sajikan steak maranggi dengan nasi daun jeruk, sambal tomat &amp; bawang merah iris"
categories:
- Resep
tags:
- steak
- maranggi
- 

katakunci: steak maranggi  
nutrition: 224 calories
recipecuisine: Indonesian
preptime: "PT29M"
cooktime: "PT34M"
recipeyield: "3"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Steak Maranggi + Nasi Daun Jeruk](https://img-global.cpcdn.com/recipes/ab6c7aaaf845d4e3/682x484cq65/steak-maranggi-nasi-daun-jeruk-foto-resep-utama.webp)

11 langkah mudah dan cepat mengolah  Steak Maranggi + Nasi Daun Jeruk cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Dibutuhkan Untuk Menyiapkan Steak Maranggi + Nasi Daun Jeruk:

1. Steak  
1. daging sirloin 500 gr
1. coca cola untuk merendam daging Secukupnya
1. bawang merah 7 siung
1. bawang putih 5 siung
1. lengkuas memarkan 2 ruas jari
1. gula merah 2 sdm
1. kecap manis 3 sdm
1. ketumbar sangrai 1 sdm
1. air asam 3 sdm
1. Garam kaldu jamur lada bubuk 
1. Pelengkap 
1. tomat iris tipis atau uleg kasar 1 butir
1. cabe rawit merah atau sesuai selera uleg kasar 2 buah
1. Garam 
1. jeruk limau peras 1 butir
1. bawang merah iris tipis Secukupnya
1. Nasi Daun Jeruk 
1. beras 3 cup
1. garam 1 sdt
1. serai memarkan 2 batang
1. daun jeruk buang tulang  remas2 10 lembar
1. santan 65 ml
1. air Secukupnya



<!--inarticleads2-->

## Langkah-langkah Untuk Menyiapkan Steak Maranggi + Nasi Daun Jeruk:

1. Olah nasi:
1. Cuci bersih beras &amp; masukkan ke dalam com
1. Tambahkan santan, garam, daun jeruk, &amp; serai. Tuang air seperti takaran masak nasi biasa. Aduk. Masak menggunakan magic com
1. Olah steak:
1. Rendam daging dengan coca cola selama 1/2 jam. Lap menggunakan tissue dapur. Sisihkan
1. Haluskan bawang merah, bawang putih, ketumbar &amp; gula merah menggunakan sedikit minyak
1. Masukkan bumbu ke dalam daging. Tambahkan garam, lada bubuk &amp; kaldu jamur. Remas perlahan agar bumbu meresap. Diamkan selama min 1 jam
1. Olah sambal tomat:
1. Campurkan tomat, cabe rawit, garam &amp; perasan jeruk limau. Aduk rata
1. Panaskan grill pan. Masukkan margarine &amp; panggang daging di atasnya sambil dioles sisa bumbu sampai tingkat kematangan yang diinginkan
1. Sajikan steak maranggi dengan nasi daun jeruk, sambal tomat &amp; bawang merah iris




Daripada kamu beli  Steak Maranggi + Nasi Daun Jeruk  diluar terus, ibu  bisa membuatnya sendiri dirumah. Resep  Steak Maranggi + Nasi Daun Jeruk  sederhana ini cukup praktis dalam proses pembuatannya, serta cukup menggunakan bumbu-bumbu sederhana yang ada di dapur  Steak Maranggi + Nasi Daun Jeruk  yang enak, bunda nikmati di rumah.
