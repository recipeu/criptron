---
description: "Bagaimana Menyiapkan Nasi bakar ayam suir pedas Anti Gagal"
title: "Bagaimana Menyiapkan Nasi bakar ayam suir pedas Anti Gagal"
slug: 383-bagaimana-menyiapkan-nasi-bakar-ayam-suir-pedas-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-18T18:14:23.247Z 
thumbnail: https://img-global.cpcdn.com/recipes/090c14bb4e96fbfb/682x484cq65/nasi-bakar-ayam-suir-pedas-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/090c14bb4e96fbfb/682x484cq65/nasi-bakar-ayam-suir-pedas-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/090c14bb4e96fbfb/682x484cq65/nasi-bakar-ayam-suir-pedas-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/090c14bb4e96fbfb/682x484cq65/nasi-bakar-ayam-suir-pedas-foto-resep-utama.webp
author: Max Maxwell
ratingvalue: 5
reviewcount: 3
recipeingredient:
- "nasi sisa semalam yang masih bagus Secukupnya"
- "ayam rebus suir 250 gr"
- "Bumbu halus "
- "bawang putih 3 siung"
- "bawang merah 4 siung"
- "cabai merah 3 buah"
- "Beberapa cabai rawit merah optional "
- "Bumbu pelengkap "
- "lengkuas 1 cm"
- "daun salam 3 lembar"
- "daun jeruk 2 lembar"
- "bawang putih bubuk 2 sdt"
- "garam kaldu ayam dan sedikit gula pasir Secukupnya"
- "Alat bungkus "
- "Daun pisang yg sudah dilemaskan bakarjemur "
recipeinstructions:
- "Masukan garam, kaldu ayam dan bawang putih bubuk kedalam nasi. Aduk merata"
- "Haluskan bumbu halus"
- "Siapkan wajan beri sedikit minyak, nyalakan api kompor (sedang). Masukan bumbu halus bersama dengan lengkuas, daun salam dan daun jeruk. Tumis sampai harum. Lalu masukan jg secukupnya garam, kaldu ayam dan gulpas."
- "Masukan ayam suirnya, aduk merata sampai matang dan koreksi rasa. Lalu angkat dan tiriskan"
- "Siapkan daun pisang, lalu lemaskan agar tidak mudah robek. Tata nasi diatas daun pisang, masukan ayam diatas nasi. Lalu gulung dan rapikan sesuai selera           (lihat resep)"
- "Jika semua sudah selesai, siapkan teflon yg diolesi sedikit mentega, masukan nasi bakar keatasnya. Panggang hingga harum dan tekstur daun pisang kering. Bolak balik agar merata"
- "Nasi bakar ayam suir siap disajikan"
categories:
- Resep
tags:
- nasi
- bakar
- ayam

katakunci: nasi bakar ayam 
nutrition: 281 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT33M"
recipeyield: "3"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi bakar ayam suir pedas](https://img-global.cpcdn.com/recipes/090c14bb4e96fbfb/682x484cq65/nasi-bakar-ayam-suir-pedas-foto-resep-utama.webp)

Ingin membuat Nasi bakar ayam suir pedas ? Coba resep berikut ini. Cara memasaknya sangat praktis namun jangan kaget jika hasilnya gurih dan lezat yang harus kamu coba segera

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Untuk Menyiapkan Nasi bakar ayam suir pedas:

1. nasi sisa semalam yang masih bagus Secukupnya
1. ayam rebus suir 250 gr
1. Bumbu halus 
1. bawang putih 3 siung
1. bawang merah 4 siung
1. cabai merah 3 buah
1. Beberapa cabai rawit merah optional 
1. Bumbu pelengkap 
1. lengkuas 1 cm
1. daun salam 3 lembar
1. daun jeruk 2 lembar
1. bawang putih bubuk 2 sdt
1. garam kaldu ayam dan sedikit gula pasir Secukupnya
1. Alat bungkus 
1. Daun pisang yg sudah dilemaskan bakarjemur 

Nasi bakar memang enak bila disandingkan dengan apa saja. Salah satunya adalah tumis tuna pedas. Aroma harum daun pisang berpadu rasa tuna yang pedas-gurih bikin ingin nambah. Sajikan menu hidangan ini dengan sepiring nasi hangat yang pulen dan nikmati selagi masih segar baru diangkat dari wajan. 

<!--inarticleads2-->

## Langkah-langkah Untuk Menyiapkan Nasi bakar ayam suir pedas:

1. Masukan garam, kaldu ayam dan bawang putih bubuk kedalam nasi. Aduk merata
1. Haluskan bumbu halus
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/ef08161bc9a5467c/160x128cq70/nasi-bakar-ayam-suir-pedas-langkah-memasak-2-foto.webp" alt="Nasi bakar ayam suir pedas" width="340" height="340">
>1. Siapkan wajan beri sedikit minyak, nyalakan api kompor (sedang). Masukan bumbu halus bersama dengan lengkuas, daun salam dan daun jeruk. Tumis sampai harum. Lalu masukan jg secukupnya garam, kaldu ayam dan gulpas.
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/e6bcd13dd1620cda/160x128cq70/nasi-bakar-ayam-suir-pedas-langkah-memasak-3-foto.webp" alt="Nasi bakar ayam suir pedas" width="340" height="340">
>1. Masukan ayam suirnya, aduk merata sampai matang dan koreksi rasa. Lalu angkat dan tiriskan
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/4bbac6b45b721baf/160x128cq70/nasi-bakar-ayam-suir-pedas-langkah-memasak-4-foto.webp" alt="Nasi bakar ayam suir pedas" width="340" height="340">
>1. Siapkan daun pisang, lalu lemaskan agar tidak mudah robek. Tata nasi diatas daun pisang, masukan ayam diatas nasi. Lalu gulung dan rapikan sesuai selera -           (lihat resep)
1. Jika semua sudah selesai, siapkan teflon yg diolesi sedikit mentega, masukan nasi bakar keatasnya. Panggang hingga harum dan tekstur daun pisang kering. Bolak balik agar merata
1. Nasi bakar ayam suir siap disajikan


Nah, agar anda bisa menyajikan hidangan ayam goreng bumbu pedas manis dirumah, yuk simak langsung seperti apa resep membuatnya dibawah ini. Rasa nasi bakar tetap lezat, bahkan teksturnya lebih gurih serta menyehatkan. Yuk, masak nasi bakar ikan teri dengan resep di bawah ini! Biasanya, isian nasi bakar selalu berupa daging ayam, ikan tuna, atau cumi. Namun, kamu tetap bisa menggunakan protein lainnya, seperti ikan teri misalnya. 

Terima kasih telah membaca resep yang tim kami tampilkan di sini. Selamat mencoba!
