---
description: "Resep Nasi Daun Jeruk Anti Gagal"
title: "Resep Nasi Daun Jeruk Anti Gagal"
slug: 288-resep-nasi-daun-jeruk-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-19T18:13:57.608Z 
thumbnail: https://img-global.cpcdn.com/recipes/c52e775444875b5c/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/c52e775444875b5c/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/c52e775444875b5c/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/c52e775444875b5c/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
author: Jean Perry
ratingvalue: 3.4
reviewcount: 10
recipeingredient:
- "Beras 1-2 Cup"
- "Air secukupnya"
- "Kaldu jamur bubuk 1-2 sdt"
- "Bumbu Tumis "
- "Bawang putih 4 Siung"
- "Daun jeruk 11 Lembar"
- "Daun salam 2-3 Lembar"
- "Sereh 1-2 Btg"
- "margarin 1-2 sdm"
- "minyak goreng Sedikit"
recipeinstructions:
- "Potong halus daun jeruk, cincang bawang putih, memarkan sereh"
- "Panaskan minyak goreng, tumis semua bumbu hingga harum dengan api kecil (usahakan jgn sampai gosong baputnya)"
- "Setelah harum masukkan margarin, tunggu sampai meleleh. Aduk sebentar trus matikan apinya."
- "Cuci bersih beras, bila sudah bersih tambahkan air secukupnya (seperti biasa masak nasi pakai rice cooker)"
- "Masukkan bumbu tumis kedalam beras yang sudah dicuci dan ditambahkan air. Aduk rata"
- "Tambahkan kaldu jamur, aduk-aduk lagi. (Koreksi rasa) tambahkan garam apabila kurang (optional)"
- "Masak pakai rice cooker, tunggu sampei bunyi &#34;klek&#34; tandanya nasi sudah matang."
- "Selamat mencoba 🙂"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 242 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT42M"
recipeyield: "4"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk](https://img-global.cpcdn.com/recipes/c52e775444875b5c/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp)

Ingin membuat Nasi Daun Jeruk ? Coba resep berikut ini. Cara memasaknya sangat praktis namun jangan kaget jika hasilnya gurih dan lezat cocok banget jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Bahan-bahan Yang Dibutuhkan Dalam Pembuatan Nasi Daun Jeruk:

1. Beras 1-2 Cup
1. Air secukupnya
1. Kaldu jamur bubuk 1-2 sdt
1. Bumbu Tumis 
1. Bawang putih 4 Siung
1. Daun jeruk 11 Lembar
1. Daun salam 2-3 Lembar
1. Sereh 1-2 Btg
1. margarin 1-2 sdm
1. minyak goreng Sedikit



<!--inarticleads2-->

## Cara Membuat Nasi Daun Jeruk:

1. Potong halus daun jeruk, cincang bawang putih, memarkan sereh
1. Panaskan minyak goreng, tumis semua bumbu hingga harum dengan api kecil (usahakan jgn sampai gosong baputnya)
1. Setelah harum masukkan margarin, tunggu sampai meleleh. Aduk sebentar trus matikan apinya.
1. Cuci bersih beras, bila sudah bersih tambahkan air secukupnya (seperti biasa masak nasi pakai rice cooker)
1. Masukkan bumbu tumis kedalam beras yang sudah dicuci dan ditambahkan air. Aduk rata
1. Tambahkan kaldu jamur, aduk-aduk lagi. - (Koreksi rasa) tambahkan garam apabila kurang (optional)
1. Masak pakai rice cooker, tunggu sampei bunyi &#34;klek&#34; tandanya nasi sudah matang.
1. Selamat mencoba 🙂




Salah satu kuliner yang cukup praktis pembuatannya adalah  Nasi Daun Jeruk. Selain itu  Nasi Daun Jeruk  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu ikuti 8 langkah, dan  Nasi Daun Jeruk  pun siap di hidangkan. selamat mencoba !
