---
description: "Resep Nasi Bakar Tuna Pedas Anti Gagal"
title: "Resep Nasi Bakar Tuna Pedas Anti Gagal"
slug: 371-resep-nasi-bakar-tuna-pedas-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-30T05:33:36.387Z 
thumbnail: https://img-global.cpcdn.com/recipes/0edbcbbfd94201ff/682x484cq65/nasi-bakar-tuna-pedas-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/0edbcbbfd94201ff/682x484cq65/nasi-bakar-tuna-pedas-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/0edbcbbfd94201ff/682x484cq65/nasi-bakar-tuna-pedas-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/0edbcbbfd94201ff/682x484cq65/nasi-bakar-tuna-pedas-foto-resep-utama.webp
author: Linnie Stewart
ratingvalue: 4.7
reviewcount: 15
recipeingredient:
- " bahan nasi  "
- "beras 1000 gr"
- "santan 1200 ml"
- "sereh 4 batang"
- "daun salam 6 lembar"
- "garam Secukupnya"
- " topping tambahan  "
- "ikan teri goreng 25 gr"
- "bawang goreng dan daun kemangi segar Secukupnya"
- " topping tuna pedas  "
- "tuna suwirsuwir 3 kaleng"
- "santan kental 250 ml"
- "daun salam 6 lembar"
- "daun jeruk 6 lembar"
- "serai geprek 4 batang"
- "lengkuas geprek 1 ruas"
- "daun kemangi petiki daun nya 2 ikat"
- " bumbu halus  "
- "bawang putih 6 siung"
- "bawang merah 10 butir"
- "kemiri sangrai 8 butir"
- "cabe rawit 12 buah"
- "cabe merah keriting 14 buah"
- "kunyit bakar 1 ruas"
- "minyak goreng Secukupnya"
- "gula garam lada bubuk  penyedap rasa Secukupnya"
recipeinstructions:
- "▶️ nasi : campur semua bahan, dengan cara masak di atas kompor aduk-aduk beras supaya gosong sampai air santan meresap. Setelah meresap angkat, masak di panci lain dengan cara dikukus hingga matang. Angkat, sisihkan."
- "▶️ isian : tumis bumbu halus hingga harum, lalu masukan daun salam, daun jeruk, lengkuas, dan serai sambil di aduk hingga harum. Kemudian masukan suwiran ikan tuna, aduk-aduk dan tambahkan sedikit air. Lalu masukan santan dan bumbui dengan gula, garam, lada bubuk, dan penyedap rasa. Tes rasa, jika dirasa sudah pas tambahkan daun kemangi. Oseng hingga daun nya layu dan harum."
- "▶️ Penyelesaian : ketika nasi masih hangat, campur dengan teri goreng dan bawang goreng. Ambil secukupnya nasi, taruh di atas daun pisang. Beri topping tuna pedas dan daun kemangi segar. Kemudian bungkus dan tusuk ujung-ujung nya dengan tusuk gigi. Lalu bakar. Sajikan."
categories:
- Resep
tags:
- nasi
- bakar
- tuna

katakunci: nasi bakar tuna 
nutrition: 292 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT49M"
recipeyield: "3"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Bakar Tuna Pedas](https://img-global.cpcdn.com/recipes/0edbcbbfd94201ff/682x484cq65/nasi-bakar-tuna-pedas-foto-resep-utama.webp)

Ingin membuat Nasi Bakar Tuna Pedas ? Coba resep berikut ini. Cara memasaknya sangat praktis namun jangan kaget jika hasilnya gurih dan lezat yang musti ibu coba dirumah

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Dalam Menyiapkan Nasi Bakar Tuna Pedas:

1.  bahan nasi  
1. beras 1000 gr
1. santan 1200 ml
1. sereh 4 batang
1. daun salam 6 lembar
1. garam Secukupnya
1.  topping tambahan  
1. ikan teri goreng 25 gr
1. bawang goreng dan daun kemangi segar Secukupnya
1.  topping tuna pedas  
1. tuna suwirsuwir 3 kaleng
1. santan kental 250 ml
1. daun salam 6 lembar
1. daun jeruk 6 lembar
1. serai geprek 4 batang
1. lengkuas geprek 1 ruas
1. daun kemangi petiki daun nya 2 ikat
1.  bumbu halus  
1. bawang putih 6 siung
1. bawang merah 10 butir
1. kemiri sangrai 8 butir
1. cabe rawit 12 buah
1. cabe merah keriting 14 buah
1. kunyit bakar 1 ruas
1. minyak goreng Secukupnya
1. gula garam lada bubuk  penyedap rasa Secukupnya



<!--inarticleads2-->

## Cara Membuat Nasi Bakar Tuna Pedas:

1. ▶️ nasi : campur semua bahan, dengan cara masak di atas kompor aduk-aduk beras supaya gosong sampai air santan meresap. Setelah meresap angkat, masak di panci lain dengan cara dikukus hingga matang. Angkat, sisihkan.
1. ▶️ isian : tumis bumbu halus hingga harum, lalu masukan daun salam, daun jeruk, lengkuas, dan serai sambil di aduk hingga harum. Kemudian masukan suwiran ikan tuna, aduk-aduk dan tambahkan sedikit air. Lalu masukan santan dan bumbui dengan gula, garam, lada bubuk, dan penyedap rasa. Tes rasa, jika dirasa sudah pas tambahkan daun kemangi. Oseng hingga daun nya layu dan harum.
1. ▶️ Penyelesaian : ketika nasi masih hangat, campur dengan teri goreng dan bawang goreng. Ambil secukupnya nasi, taruh di atas daun pisang. Beri topping tuna pedas dan daun kemangi segar. Kemudian bungkus dan tusuk ujung-ujung nya dengan tusuk gigi. Lalu bakar. Sajikan.




Demikian informasi  resep Nasi Bakar Tuna Pedas   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
