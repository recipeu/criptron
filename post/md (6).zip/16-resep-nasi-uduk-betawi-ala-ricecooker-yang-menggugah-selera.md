---
description: "Resep Nasi uduk betawi ala ricecooker yang Menggugah Selera"
title: "Resep Nasi uduk betawi ala ricecooker yang Menggugah Selera"
slug: 16-resep-nasi-uduk-betawi-ala-ricecooker-yang-menggugah-selera
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-05T15:58:16.684Z 
thumbnail: https://img-global.cpcdn.com/recipes/55a791da71af60e3/682x484cq65/nasi-uduk-betawi-ala-ricecooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/55a791da71af60e3/682x484cq65/nasi-uduk-betawi-ala-ricecooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/55a791da71af60e3/682x484cq65/nasi-uduk-betawi-ala-ricecooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/55a791da71af60e3/682x484cq65/nasi-uduk-betawi-ala-ricecooker-foto-resep-utama.webp
author: Ethel Young
ratingvalue: 4.2
reviewcount: 8
recipeingredient:
- "beras yg agak perak 1 liter"
- "santan 12 butir kelapa sy 2 sachet santan instan 1200 ml"
- "Bumbu aromatic  "
- "daun salam 6 lembar"
- "serai geprek 2 btg"
- "jahe geprek Sejempol"
- "lengkuas geprek Sejempol"
- "pala ukuran kecil geprek sy 12 butir 1 btr"
- "kayu manis 1 btg"
- "cengkih sy skip gada stok 6 btr"
recipeinstructions:
- "Tuang santan ke dalam wajan, masukkan semua bumbu. Masak sambil diaduk2 hingga mendidih, jangan sampai santan nya pecah ya"
- "Setelah santan mendidih masukkan beras. Masak sambil diaron hingga santan terserap habis. (Jangan pakai api yg besar y). Panaskan kukusan. Pindahkan beras aron ke kukusan. Kukus sampai matang. Kurang lebih kukus selama 45 menit / sampai matang."
- "Saya karena mau praktis jadi setelah santan dan bumbu mendidih langsung dimasukan ke dalam ricecooker lalu beras aduk rata masak diricecooker hingga matang. setelah matang atau lampu ricecooker pindah ke warm, saya aduk rata lalu saya klik lagi cook lagi sampai pindah ke warm lg"
- "Sajikan nasi uduk hangat2 ditabur bawang goreng masya Allah nikmat."
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 125 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT42M"
recipeyield: "3"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi uduk betawi ala ricecooker](https://img-global.cpcdn.com/recipes/55a791da71af60e3/682x484cq65/nasi-uduk-betawi-ala-ricecooker-foto-resep-utama.webp)

Resep rahasia dan cara memasak  Nasi uduk betawi ala ricecooker cocok sekali jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Bahan-bahan Yang Dibutuhkan Dalam Pembuatan Nasi uduk betawi ala ricecooker:

1. beras yg agak perak 1 liter
1. santan 12 butir kelapa sy 2 sachet santan instan 1200 ml
1. Bumbu aromatic  
1. daun salam 6 lembar
1. serai geprek 2 btg
1. jahe geprek Sejempol
1. lengkuas geprek Sejempol
1. pala ukuran kecil geprek sy 12 butir 1 btr
1. kayu manis 1 btg
1. cengkih sy skip gada stok 6 btr

KOMPAS.com - Nasi uduk betawi adalah makanan klasik yang kerap jadi menu sarapan di Jakarta. Resep nasi uduk betawi sebenarnya cukup sederhana, cara membuatnya juga tidak terlalu sulit, bahan dan bumbunya mudah didapat, serta tidak butuh waktu lama untuk memasaknya. Silahkan di simak resep nasi uduk betawi menggunakan rice cooker dibawah ini. Ulek bawang putih dan bawang merah sampai halus. 

<!--inarticleads2-->

## Langkah-langkah Untuk Menyiapkan Nasi uduk betawi ala ricecooker:

1. Tuang santan ke dalam wajan, masukkan semua bumbu. Masak sambil diaduk2 hingga mendidih, jangan sampai santan nya pecah ya
1. Setelah santan mendidih masukkan beras. Masak sambil diaron hingga santan terserap habis. (Jangan pakai api yg besar y). Panaskan kukusan. Pindahkan beras aron ke kukusan. Kukus sampai matang. Kurang lebih kukus selama 45 menit / sampai matang.
1. Saya karena mau praktis jadi setelah santan dan bumbu mendidih langsung dimasukan ke dalam ricecooker lalu beras aduk rata masak diricecooker hingga matang. setelah matang atau lampu ricecooker pindah ke warm, saya aduk rata lalu saya klik lagi cook lagi sampai pindah ke warm lg
1. Sajikan nasi uduk hangat2 ditabur bawang goreng masya Allah nikmat.


Panaskan minyak goreng, tumis bumbu yang sudah dihaluskan sampai harum Nah itu dia sobat nasi uduk betawi rice cookernya, resep, cara buat dan tipsnya sudah dikasih tau. Sekarang tinggal dilihat video tutorialnya dibawah ini. Make this easy and aromatic Betawi-style nasi uduk that goes with many main and side dishes. I&#39;m sharing how you can make it easily with a rice cooker but it can be cooked on the stove and Instant Pot too. My favorite way of cooking nasi uduk is with a rice cooker or Instant Pot. 

Daripada bunda beli  Nasi uduk betawi ala ricecooker  diluar terus, ibu  bisa membuatnya sendiri dirumah. Resep  Nasi uduk betawi ala ricecooker  sederhana ini cukup praktis pembuatannya, cukup menggunakan bumbu sederhana  Nasi uduk betawi ala ricecooker  yang enak, bunda nikmati di rumah.
