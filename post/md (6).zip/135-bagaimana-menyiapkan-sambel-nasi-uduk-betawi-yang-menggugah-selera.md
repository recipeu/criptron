---
description: "Bagaimana Menyiapkan Sambel nasi uduk betawi yang Menggugah Selera"
title: "Bagaimana Menyiapkan Sambel nasi uduk betawi yang Menggugah Selera"
slug: 135-bagaimana-menyiapkan-sambel-nasi-uduk-betawi-yang-menggugah-selera
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-05T19:32:42.791Z 
thumbnail: https://img-global.cpcdn.com/recipes/7db038f0e496dd2f/682x484cq65/sambel-nasi-uduk-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/7db038f0e496dd2f/682x484cq65/sambel-nasi-uduk-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/7db038f0e496dd2f/682x484cq65/sambel-nasi-uduk-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/7db038f0e496dd2f/682x484cq65/sambel-nasi-uduk-betawi-foto-resep-utama.webp
author: Marguerite Welch
ratingvalue: 4.9
reviewcount: 6
recipeingredient:
- "cabe rawit merah 1/4"
- "cabe kriting 100 gr"
- "bawang merah 10 siung"
- "bawang putih 5 siung"
- "tomat 3 buah"
- "sereh geprek 2 batang"
- "daun salam 3 lembar"
- "Gula merah 1 buah"
- "gula putih 1 sdm"
- "Garam sesuai selera"
- "kaldu bubuk 1 bungkus"
recipeinstructions:
- "Rebus cabe, duo bawang serta tomat sampai matang, kemudian tiriskan lalu uleg."
- "Panaskan minyak lalu tuang bumbu yg telah di uleg serta masukkan sereh yg telah di geprek, daun salam, gula merah, gula pasir, garam serta kaldu bubuk.. Aduk semua hingga rata.. Masak dengan api cenderung kecil hingga tanak"
categories:
- Resep
tags:
- sambel
- nasi
- uduk

katakunci: sambel nasi uduk 
nutrition: 263 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT52M"
recipeyield: "4"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Sambel nasi uduk betawi](https://img-global.cpcdn.com/recipes/7db038f0e496dd2f/682x484cq65/sambel-nasi-uduk-betawi-foto-resep-utama.webp)

Ingin membuat Sambel nasi uduk betawi ? Coba resep berikut ini. Cara memasaknya sangat praktis namun hasilnya gurih dan lezat cocok sekali jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Untuk Pembuatan Sambel nasi uduk betawi:

1. cabe rawit merah 1/4
1. cabe kriting 100 gr
1. bawang merah 10 siung
1. bawang putih 5 siung
1. tomat 3 buah
1. sereh geprek 2 batang
1. daun salam 3 lembar
1. Gula merah 1 buah
1. gula putih 1 sdm
1. Garam sesuai selera
1. kaldu bubuk 1 bungkus

Sajikan nasi uduk yang telah matang dengan tambahan sambal kacang kemudian beri pelengkap seperti Telur. Nasi uduk betawi komplet lengkap dengan sambal kering tempe, sambal kacang, telur dadar, dan kerupuk. Cara bikin nasi uduk betawi biasanya menggunakan teknik aron agar nasi lebih matang. Alternatifnya, bisa menggunakan rice cooker atau magic com. 

<!--inarticleads2-->

## Cara Mudah Membuat Sambel nasi uduk betawi:

1. Rebus cabe, duo bawang serta tomat sampai matang, kemudian tiriskan lalu uleg.
1. Panaskan minyak lalu tuang bumbu yg telah di uleg serta masukkan sereh yg telah di geprek, daun salam, gula merah, gula pasir, garam serta kaldu bubuk.. Aduk semua hingga rata.. Masak dengan api cenderung kecil hingga tanak


Make this easy and aromatic Betawi-style nasi uduk that goes with many main and side dishes. My favorite way of cooking nasi uduk is with a rice cooker or Instant Pot. It&#39;s a no brainer because I just need to put everything in there without having to attend to it. Buat kamu yang suka makan nasi uduk, pasti suka dengan nasi uduk Betawi dengan sambal kacang yang harum, gurih, dan enak banget. Kamu bisa membuatnya di rumah, dengan mempraktikkan resep masakan yang diunggah YouTube Wiwit MamAdit. 

Salah satu kuliner yang cukup praktis pembuatannya adalah  Sambel nasi uduk betawi. Selain itu  Sambel nasi uduk betawi  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu ikuti 2 langkah, dan  Sambel nasi uduk betawi  pun siap di hidangkan. selamat mencoba !
