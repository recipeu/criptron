---
description: "Resep Nasi Daun Jeruk (Rice Cooker) Anti Gagal"
title: "Resep Nasi Daun Jeruk (Rice Cooker) Anti Gagal"
slug: 262-resep-nasi-daun-jeruk-rice-cooker-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-12T20:29:00.092Z 
thumbnail: https://img-global.cpcdn.com/recipes/137fe89f320f8673/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/137fe89f320f8673/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/137fe89f320f8673/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/137fe89f320f8673/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
author: Mattie Terry
ratingvalue: 4.1
reviewcount: 4
recipeingredient:
- "beras cuci bersih dan rendam semalaman 500 gr"
- "air 700 mL"
- "santan kental murni boleh pakai santan siap pakai 100 mL"
- "kaldu ayam atau jamur bubuk 2 sdt"
- "daun jeruk buang seratnya dan iris tipis 12-15 lbr"
- "serai memarkan 1 batang"
- "gula pasir 1 sdt"
- "Garam 1 1/2 sdt"
- "Bahan Pelengkap "
- "Kering kentangkering teri "
- "Ayam goreng atau saya tadi buat ayam suwir bumbu sambal "
- "Sambal "
- "Bawang goreng "
- "Telur dadar iris tipis "
- "Lalapan Mentimun dan daun kemangi "
recipeinstructions:
- "Tiriskan beras. Berasnya dianginkan sebentar dalam piring datar. Panaskan sedikit minyak dan tumis daun jeruk dan serai hingga aroma nya wangi. Tambahkan beras dan tumis sebentar. Masukkan beras ke dalam rice cooker bersama dengan air, kaldu ayam bubuk, garam, gula, kaldu bubuk. Masak. Setelah matang, buka rice cooker dan tuang santan kental. Aduk dengan garpu. Rasakan. Bila kurang asin, boleh tambahkan garam. Masak sekali lagi."
- "Sajikan dengan kering kentang/teri, ayam goreng, telur dadar, sambal bajak dan lalapan. Dan tidak lupa bawang goreng nya."
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 191 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT43M"
recipeyield: "1"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk (Rice Cooker)](https://img-global.cpcdn.com/recipes/137fe89f320f8673/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp)

Resep Nasi Daun Jeruk (Rice Cooker)    dengan 2 langkahcepat cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Untuk Pembuatan Nasi Daun Jeruk (Rice Cooker):

1. beras cuci bersih dan rendam semalaman 500 gr
1. air 700 mL
1. santan kental murni boleh pakai santan siap pakai 100 mL
1. kaldu ayam atau jamur bubuk 2 sdt
1. daun jeruk buang seratnya dan iris tipis 12-15 lbr
1. serai memarkan 1 batang
1. gula pasir 1 sdt
1. Garam 1 1/2 sdt
1. Bahan Pelengkap 
1. Kering kentangkering teri 
1. Ayam goreng atau saya tadi buat ayam suwir bumbu sambal 
1. Sambal 
1. Bawang goreng 
1. Telur dadar iris tipis 
1. Lalapan Mentimun dan daun kemangi 

Penanak nasi (rice cooker) adalah pilihan yang mudah dan efektif digunakan untuk memasak nasi. Saat ini, ada banyak penanak nasi yang dilengkapi fitur penghangat sehingga tetap bisa menjaga nasi tetap hangat setelah matang. Anda tidak perlu mengawasi penanak nasi setiap saat hingga nasi. Gurih dan wangi dari daun jeruk menambah kelezatan nasi daun jeruk. 

<!--inarticleads2-->

## Cara Mudah Membuat Nasi Daun Jeruk (Rice Cooker):

1. Tiriskan beras. Berasnya dianginkan sebentar dalam piring datar. - Panaskan sedikit minyak dan tumis daun jeruk dan serai hingga aroma nya wangi. - Tambahkan beras dan tumis sebentar. - Masukkan beras ke dalam rice cooker bersama dengan air, kaldu ayam bubuk, garam, gula, kaldu bubuk. Masak. - Setelah matang, buka rice cooker dan tuang santan kental. Aduk dengan garpu. Rasakan. Bila kurang asin, boleh tambahkan garam. Masak sekali lagi.
1. Sajikan dengan kering kentang/teri, ayam goreng, telur dadar, sambal bajak dan lalapan. Dan tidak lupa bawang goreng nya.


Dash Mini Rice Cooker Steamer With Removable Nonstick Pot Nasi dengan aroma yang khas ini memang cocok dinikmati bersama Ketika bosan mengonsumsi nasi putih biasa, kamu bisa menggantinya dengan nasi daun jeruk. Siapkan rice cooker, lalu masukkan tiga cangkir gelas. Setelah itu, cuci beras hingga bersih atau. Nasi putih daun jeruk rice cooker. 

Daripada bunda beli  Nasi Daun Jeruk (Rice Cooker)  diluar terus, kamu  bisa membuatnya sendiri dirumah. Resep  Nasi Daun Jeruk (Rice Cooker)  sederhana ini cukup praktis pembuatannya, serta cukup menggunakan bumbu sederhana  Nasi Daun Jeruk (Rice Cooker)  yang enak, ibu nikmati di rumah.
