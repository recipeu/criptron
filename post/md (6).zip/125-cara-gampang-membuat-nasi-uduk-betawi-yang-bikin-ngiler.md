---
description: "Cara Gampang Membuat Nasi Uduk Betawi yang Bikin Ngiler"
title: "Cara Gampang Membuat Nasi Uduk Betawi yang Bikin Ngiler"
slug: 125-cara-gampang-membuat-nasi-uduk-betawi-yang-bikin-ngiler
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-13T18:55:12.551Z 
thumbnail: https://img-global.cpcdn.com/recipes/dc884a7220ac3bf2/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/dc884a7220ac3bf2/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/dc884a7220ac3bf2/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/dc884a7220ac3bf2/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
author: Jeremiah Gordon
ratingvalue: 3
reviewcount: 8
recipeingredient:
- "beras cuci bersih 4 cup"
- "santan kental campur dengan air secukupnya 400 ml"
- "garam Secukupnya"
- "sereh geprek 1 batang"
- "daun jeruk sobek2 5 lbr"
- "daun salam 2 lbr"
- "cengkeh 2 butir"
- "pala bubuk 1/2 sdt"
- "kayu manis bubuk 1/2 sdt"
- "jahe geprek saya pake 12 sdt jahe bubuk 1 ruas"
- "ketumbar bubuk 1 sdt"
- "lengkuas geprek atau 12 sdt lengkuas bubuk 1 ruas"
recipeinstructions:
- "Cuci bersih beras, tiriskan."
- "Panaskan santan, air beserta semua bumbu2 sampe mendidih, matikan api."
- "Masukkan beras yg sudah bersih tadi, aduk2 dengan santan sampai semua santan terserap, koreksi rasa."
- "Kukus nasi sampai matang."
- "Kalo versi gampangnya, campur semua bahan ke dalam rice cooker, ukur santan dan air sesuai takaran menanak nasi, koreksi rasa, lalu masak nasi seperti biasa dengan rice cooker. Sempatkan untuk mengaduk nasi sesekali supaya tercampur rata dan nasi tidak gosong di bagian bawah. Masak sampai matang, aduk lagi saat matang. Mudah dan enak!! 😊"
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 292 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT51M"
recipeyield: "3"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Betawi](https://img-global.cpcdn.com/recipes/dc884a7220ac3bf2/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp)

Ingin membuat Nasi Uduk Betawi ? Coba resep berikut ini. Cara memasaknya sangat praktis namun hasilnya gurih dan lezat cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Dalam Pembuatan Nasi Uduk Betawi:

1. beras cuci bersih 4 cup
1. santan kental campur dengan air secukupnya 400 ml
1. garam Secukupnya
1. sereh geprek 1 batang
1. daun jeruk sobek2 5 lbr
1. daun salam 2 lbr
1. cengkeh 2 butir
1. pala bubuk 1/2 sdt
1. kayu manis bubuk 1/2 sdt
1. jahe geprek saya pake 12 sdt jahe bubuk 1 ruas
1. ketumbar bubuk 1 sdt
1. lengkuas geprek atau 12 sdt lengkuas bubuk 1 ruas



<!--inarticleads2-->

## Langkah-langkah Untuk Menyiapkan Nasi Uduk Betawi:

1. Cuci bersih beras, tiriskan.
1. Panaskan santan, air beserta semua bumbu2 sampe mendidih, matikan api.
1. Masukkan beras yg sudah bersih tadi, aduk2 dengan santan sampai semua santan terserap, koreksi rasa.
1. Kukus nasi sampai matang.
1. Kalo versi gampangnya, campur semua bahan ke dalam rice cooker, ukur santan dan air sesuai takaran menanak nasi, koreksi rasa, lalu masak nasi seperti biasa dengan rice cooker. Sempatkan untuk mengaduk nasi sesekali supaya tercampur rata dan nasi tidak gosong di bagian bawah. Masak sampai matang, aduk lagi saat matang. Mudah dan enak!! 😊




Salah satu masakan yang cukup praktis pembuatannya adalah  Nasi Uduk Betawi. Selain itu  Nasi Uduk Betawi  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu ikuti 5 langkah, dan  Nasi Uduk Betawi  pun siap di hidangkan. selamat mencoba !
