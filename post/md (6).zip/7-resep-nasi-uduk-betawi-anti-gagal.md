---
description: "Resep Nasi Uduk Betawi Anti Gagal"
title: "Resep Nasi Uduk Betawi Anti Gagal"
slug: 7-resep-nasi-uduk-betawi-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-09T04:03:19.661Z 
thumbnail: https://img-global.cpcdn.com/recipes/040d4acb3668f067/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/040d4acb3668f067/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/040d4acb3668f067/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/040d4acb3668f067/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
author: Pauline Gregory
ratingvalue: 4.2
reviewcount: 3
recipeingredient:
- "beras 500 gr"
- "santan dr 14 kelapa 600"
- "air panas 100 ml"
- "Bahan bumbu "
- "sere geprek 1 bh"
- "daun salam 3 helai"
- "jahe geprek Seruas"
- "pala 1/4 bh"
- "Laos geprek Seruas"
- "cengkeh 3 bh"
- "kayu manis Secuil"
- "Garam "
recipeinstructions:
- "Cuci beras. Tiriskan"
- "Siapkan santan dan bahan bumbu. Masak di atas api kecil, aduk&#34; jangan sampai santan pecah sampai mendidih."
- "Pindahkan santan rebus ke dlm magic com. Tambahkan air panas sekiranya air kurang(sy tambah kira&#34; 100ml). Sesekali diaduk agar santan merata ke beras.  Tunggu kira &#34; 1jam setelah beras matang baru disajikan."
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 296 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT48M"
recipeyield: "1"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Betawi](https://img-global.cpcdn.com/recipes/040d4acb3668f067/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp)

3 langkah cepat dan mudah mengolah  Nasi Uduk Betawi yang bisa bunda coba segera

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Untuk Pembuatan Nasi Uduk Betawi:

1. beras 500 gr
1. santan dr 14 kelapa 600
1. air panas 100 ml
1. Bahan bumbu 
1. sere geprek 1 bh
1. daun salam 3 helai
1. jahe geprek Seruas
1. pala 1/4 bh
1. Laos geprek Seruas
1. cengkeh 3 bh
1. kayu manis Secuil
1. Garam 



<!--inarticleads2-->

## Langkah-langkah Untuk Menyiapkan Nasi Uduk Betawi:

1. Cuci beras. Tiriskan
1. Siapkan santan dan bahan bumbu. Masak di atas api kecil, aduk&#34; jangan sampai santan pecah sampai mendidih.
1. Pindahkan santan rebus ke dlm magic com. Tambahkan air panas sekiranya air kurang(sy tambah kira&#34; 100ml). Sesekali diaduk agar santan merata ke beras.  - Tunggu kira &#34; 1jam setelah beras matang baru disajikan.




Demikian informasi  resep Nasi Uduk Betawi   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
