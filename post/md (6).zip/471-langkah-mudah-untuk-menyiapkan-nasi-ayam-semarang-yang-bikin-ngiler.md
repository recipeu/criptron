---
description: "Langkah Mudah untuk Menyiapkan Nasi ayam Semarang yang Bikin Ngiler"
title: "Langkah Mudah untuk Menyiapkan Nasi ayam Semarang yang Bikin Ngiler"
slug: 471-langkah-mudah-untuk-menyiapkan-nasi-ayam-semarang-yang-bikin-ngiler
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-27T03:17:57.841Z 
thumbnail: https://img-global.cpcdn.com/recipes/ad40038f91693a1c/682x484cq65/nasi-ayam-semarang-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/ad40038f91693a1c/682x484cq65/nasi-ayam-semarang-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/ad40038f91693a1c/682x484cq65/nasi-ayam-semarang-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/ad40038f91693a1c/682x484cq65/nasi-ayam-semarang-foto-resep-utama.webp
author: Ronnie Mason
ratingvalue: 3.8
reviewcount: 15
recipeingredient:
- "Bahan nasi gurih "
- "nasi sekitar 14 kg 2 cup"
- "daun salam 3 lembar"
- "daun pandan 1 lembar"
- "Air secukupnya untuk masak nasi "
- "santan 1/2 gelas"
- "garam 1 sdt"
- "Bumbu opor ayam tahu telur "
- "ayam potong2 1/2 kg"
- "telur ayam 2 butir"
- "tahu kuning potong dua 2 buah"
- "santan 1 gelas"
- "lengkuas geprek 1 ruas"
- "serai geprek 1 batang"
- "daun jeruk 5 lembar"
- "daun salam 3 lembar"
- "bawang goreng 1 sdt"
- "Air secukupnya"
- "gula 1 sdm"
- "garam 1 sdt"
- "merica bubuk 1/2 sdt"
- "jintan bubuk 1/4 sdt"
- "Bumbu halus  "
- "bawang merah 6 siung"
- "bawang putih 3 siung"
- "kemiri sangrai 5 butir"
- "jahe bakar 1 ruas"
- "kunyit bakar 1 cm"
- "ketumbar 1 sdt"
- "Minyak untuk menumis "
- "Bumbu sambel goreng jipang  "
- "jipang  waluh kira2 14kg 2 buah"
- "Bawang merah 6 siung"
- "Bawang putih 3 siung"
- "Cabe merah keriting 6 pcs"
- "daun salam 3 lembar"
- "Lengkuas geprek 1 ruas"
- "gula merah 1 sdm"
- "cabe rawit 10 pcs"
- "santan 150 ml"
- "garam 1 sdt"
- "Sate jeroan "
- "hati ampela ayam 4 pasang"
- "bawang putih 2 siung"
- "bawang merah 2 siung"
- "kecap manis 3 sdm"
- "jahe 1 iris"
recipeinstructions:
- "Nasi gurih : Campur semua bahan kedalam rice cooker. Tambahkan air sesuai ukuran masak nasi di rice cooker seperti biasa. Masak hingga matang. Cetak dipiring saji. Taburi bawang goreng."
- "Membuat opor ayam : Tumis bumbu halus dengan minyak sedikit hingga harum lalu masukkan ayam potong. Aduk rata. Beri jintan, garam, gula, merica. Aduk hingga harum."
- "Beri air secukupnya dan santan. Aduk rata."
- "Masukkan tahu &amp; telur rebus. Aduk2 hingga bumbu meresap."
- "Membuat sambal goreng jipang : iris2 jipang/ waluh seukuran korek api. Remas2 dengan garam untuk membuang getah &amp; melembutkan. Lalu cuci bersih. Tumis bumbu halus dengan sedikit minyak lalu masukkan daun salam."
- "Beri air secukupnya hingga mendidih lalu masukkan jipang/waluh. Aduk rata hingga matang. Beri santan. Kecilkan api. Aduk2 agar santan tidak pecah."
- "Koreksi rasa &amp; matikan api sesudah bumbu terserap."
- "Membuat Sate jeroan ayam : rebus semua bahan hingga bumbu terserap &amp; air menyusut. Tata di tusukan sate."
- "Sajikan dengan kerupuk"
categories:
- Resep
tags:
- nasi
- ayam
- semarang

katakunci: nasi ayam semarang 
nutrition: 180 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT49M"
recipeyield: "4"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi ayam Semarang](https://img-global.cpcdn.com/recipes/ad40038f91693a1c/682x484cq65/nasi-ayam-semarang-foto-resep-utama.webp)

9 langkah mudah membuat  Nasi ayam Semarang cocok sekali jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Dalam Pembuatan Nasi ayam Semarang:

1. Bahan nasi gurih 
1. nasi sekitar 14 kg 2 cup
1. daun salam 3 lembar
1. daun pandan 1 lembar
1. Air secukupnya untuk masak nasi 
1. santan 1/2 gelas
1. garam 1 sdt
1. Bumbu opor ayam tahu telur 
1. ayam potong2 1/2 kg
1. telur ayam 2 butir
1. tahu kuning potong dua 2 buah
1. santan 1 gelas
1. lengkuas geprek 1 ruas
1. serai geprek 1 batang
1. daun jeruk 5 lembar
1. daun salam 3 lembar
1. bawang goreng 1 sdt
1. Air secukupnya
1. gula 1 sdm
1. garam 1 sdt
1. merica bubuk 1/2 sdt
1. jintan bubuk 1/4 sdt
1. Bumbu halus  
1. bawang merah 6 siung
1. bawang putih 3 siung
1. kemiri sangrai 5 butir
1. jahe bakar 1 ruas
1. kunyit bakar 1 cm
1. ketumbar 1 sdt
1. Minyak untuk menumis 
1. Bumbu sambel goreng jipang  
1. jipang  waluh kira2 14kg 2 buah
1. Bawang merah 6 siung
1. Bawang putih 3 siung
1. Cabe merah keriting 6 pcs
1. daun salam 3 lembar
1. Lengkuas geprek 1 ruas
1. gula merah 1 sdm
1. cabe rawit 10 pcs
1. santan 150 ml
1. garam 1 sdt
1. Sate jeroan 
1. hati ampela ayam 4 pasang
1. bawang putih 2 siung
1. bawang merah 2 siung
1. kecap manis 3 sdm
1. jahe 1 iris

Semarang jangan lupa Baca juga Kumpulan Pin BB Artis Indonesia Terbaru. Jawa Tengah, Kota Magelang, Kota Pekalongan, Kota Salatiga, Kota Semarang, Kota Surakarta, Kota Tegal. Nasi ayam menyajikan citarasa gurih yang cukup pekat karena disiram kuah opor. Pasti rugi, deh kalau ke Semarang kalian gak icip kuliner nasi ayam ini. 

<!--inarticleads2-->

## Cara Mudah Membuat Nasi ayam Semarang:

1. Nasi gurih : Campur semua bahan kedalam rice cooker. Tambahkan air sesuai ukuran masak nasi di rice cooker seperti biasa. Masak hingga matang. Cetak dipiring saji. Taburi bawang goreng.
1. Membuat opor ayam : Tumis bumbu halus dengan minyak sedikit hingga harum lalu masukkan ayam potong. Aduk rata. Beri jintan, garam, gula, merica. Aduk hingga harum.
1. Beri air secukupnya dan santan. Aduk rata.
1. Masukkan tahu &amp; telur rebus. Aduk2 hingga bumbu meresap.
1. Membuat sambal goreng jipang : iris2 jipang/ waluh seukuran korek api. Remas2 dengan garam untuk membuang getah &amp; melembutkan. Lalu cuci bersih. Tumis bumbu halus dengan sedikit minyak lalu masukkan daun salam.
1. Beri air secukupnya hingga mendidih lalu masukkan jipang/waluh. Aduk rata hingga matang. Beri santan. Kecilkan api. Aduk2 agar santan tidak pecah.
1. Koreksi rasa &amp; matikan api sesudah bumbu terserap.
1. Membuat Sate jeroan ayam : rebus semua bahan hingga bumbu terserap &amp; air menyusut. Tata di tusukan sate.
1. Sajikan dengan kerupuk


You can choose to buy it spicy or not. The skewers were also good This is a very good Nasi Ayam, the best in Semarang. The portion of vegetables and other ingredients are. Pagi semua, Ini aku posting lagi menu Nasi Ayam Semarang ya teman-teman, walau dulu udah pernah posting, tapi ini ada beberapa pelengkap yang baru. Tapi jangan di sama-samakan, karena baik orang semarang dan orang solo, suka tidak terima jika antara nasi liwet di samakan dengan nasi ayam. 

Demikian informasi  resep Nasi ayam Semarang   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
