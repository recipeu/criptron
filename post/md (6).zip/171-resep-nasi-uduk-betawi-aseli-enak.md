---
description: "Resep Nasi uduk Betawi Aseli, Enak"
title: "Resep Nasi uduk Betawi Aseli, Enak"
slug: 171-resep-nasi-uduk-betawi-aseli-enak
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-14T17:22:44.865Z 
thumbnail: https://img-global.cpcdn.com/recipes/ab24abffd092d052/682x484cq65/nasi-uduk-betawi-aseli-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/ab24abffd092d052/682x484cq65/nasi-uduk-betawi-aseli-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/ab24abffd092d052/682x484cq65/nasi-uduk-betawi-aseli-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/ab24abffd092d052/682x484cq65/nasi-uduk-betawi-aseli-foto-resep-utama.webp
author: Julian Roy
ratingvalue: 3.5
reviewcount: 13
recipeingredient:
- "beras 3 L"
- "bawang merah 20 siung"
- "jahe 4 ruas"
- "daun salam 10 lembar"
- "sereh 7 batang"
- "santan dari kelapa parut 1 butir"
- "garam secukupnya"
- "penyedap secukupnya"
recipeinstructions:
- "Cuci beras sampai bersih."
- "Siapkan dandang beri saringan beras yg terbuat dari kain, kukus selama 20 mnt"
- "Haluskan bawang merah dan jahe."
- "Masak santan dan bumbu halus tambahkan salam sereh, garam dan penyedap sampai mendidih"
- "Aron beras yg sdh dikukus tadi sampai santam asat."
- "Setelah asat pindahkan ke dandang dan masak sampai matang"
- "Selamat mencoba dan selamat ketagihan"
- "Kalau mau simpel bisa masak dg magic com kok,, tdk merubah rassa..... 😆😀"
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 119 calories
recipecuisine: Indonesian
preptime: "PT16M"
cooktime: "PT35M"
recipeyield: "1"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi uduk Betawi Aseli](https://img-global.cpcdn.com/recipes/ab24abffd092d052/682x484cq65/nasi-uduk-betawi-aseli-foto-resep-utama.webp)

Resep dan cara mengolah  Nasi uduk Betawi Aseli yang bisa ibu coba dirumah

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Dalam Menyiapkan Nasi uduk Betawi Aseli:

1. beras 3 L
1. bawang merah 20 siung
1. jahe 4 ruas
1. daun salam 10 lembar
1. sereh 7 batang
1. santan dari kelapa parut 1 butir
1. garam secukupnya
1. penyedap secukupnya



<!--inarticleads2-->

## Langkah-langkah Untuk Menyiapkan Nasi uduk Betawi Aseli:

1. Cuci beras sampai bersih.
1. Siapkan dandang beri saringan beras yg terbuat dari kain, kukus selama 20 mnt
1. Haluskan bawang merah dan jahe.
1. Masak santan dan bumbu halus tambahkan salam sereh, garam dan penyedap sampai mendidih
1. Aron beras yg sdh dikukus tadi sampai santam asat.
1. Setelah asat pindahkan ke dandang dan masak sampai matang
1. Selamat mencoba dan selamat ketagihan
1. Kalau mau simpel bisa masak dg magic com kok,, tdk merubah rassa..... 😆😀




Salah satu kuliner yang cukup praktis pembuatannya adalah  Nasi uduk Betawi Aseli. Selain itu  Nasi uduk Betawi Aseli  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu lakukan 8 langkah, dan  Nasi uduk Betawi Aseli  pun siap di hidangkan. selamat mencoba !
