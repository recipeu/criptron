---
description: "Cara Gampang Membuat Nasi Bakar Tuna Anti Gagal"
title: "Cara Gampang Membuat Nasi Bakar Tuna Anti Gagal"
slug: 370-cara-gampang-membuat-nasi-bakar-tuna-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-19T10:16:13.981Z 
thumbnail: https://img-global.cpcdn.com/recipes/dc24279c7e1b8e08/682x484cq65/nasi-bakar-tuna-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/dc24279c7e1b8e08/682x484cq65/nasi-bakar-tuna-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/dc24279c7e1b8e08/682x484cq65/nasi-bakar-tuna-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/dc24279c7e1b8e08/682x484cq65/nasi-bakar-tuna-foto-resep-utama.webp
author: Edwin Garner
ratingvalue: 4.5
reviewcount: 8
recipeingredient:
- "Bumbu halus isian tuna  "
- "bawang putih 3 siung"
- "bawang merah 6 btr"
- "kemiri sangrai 3 btr"
- "kunyit bakar 3 ruas"
- "cabe merah besar 3 buah"
- "cabai rawit merah 10 buah"
- " Bahan lainnya  "
- "daun pisang dan tusuk gigi Secukupnya"
- "daun kemangi Segenggam"
- "Bahan nasi  "
- "beras cuci beras dan tiriskan 500 gr"
- "santansesuaikan dengan kondisi beras yaa 750 ml"
- "garam 1/2 Sdm"
- "sereh geprek 1 btg"
- "daun salam 2 lbr"
- "daun jeruk 4 lbr"
- "daun pandan simpulkan 2 lbr"
- "Bahan isian tuna  "
- "ikan tongkoltuna kukus  suwir2 2-3 buah"
- "daun jeruk 3 lbr"
- "sereh geprek 1 btg"
- "daun salam 2 lbr"
- "santan 250 ml"
- "jari lengkuas Seruas"
- "kaldu bubuk gula dan garam Secukupnya"
- "minyak untuk menumis Secukupnya"
recipeinstructions:
- "Siapkan terlebih dahulu semua bahan yg diperlukan"
- "Nasi : didihkan santan. Masukkan semua bahan. Aron nasi hingga airnya habis. Panaskan kukusan/dandang lalu matangkan nasi Aron tadi. Kira kira 20-30 menit. Angkat nasi dan sisihkan."
- "Isian tuna : panaskan minyak, tuang bumbu halus. Tumis hingga harum dan Tanak. Kemudian tambahkan lengkuas, daun salam, daun jeruk dan sereh. Aduk rata. Tambahkan suwiran ikan. Aduk rata. Tuang santan. Tambahkan gula,garam dan kaldu bubuk. Koreksi rasa. Masak hingga kuah menyusut. Tambahkan kemangi, aduk hingga layu. Matikan api"
- "Penataan nasi bungkus : ambil selembar daun, tata nasi lalu tambahkan isian. Kalo mau ditambah sambal terasi didalamnya juga ok... Hehehe.. gulung dan padatkan. Semat ujungnya dengan tusuk gigi. Lakukan hingga habis."
- "Bakar diatas api atau dengan menggunakan teflon untuk finishingnya. Bakar hingga daun pisang layu. Sajikan."
categories:
- Resep
tags:
- nasi
- bakar
- tuna

katakunci: nasi bakar tuna 
nutrition: 203 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT40M"
recipeyield: "1"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Bakar Tuna](https://img-global.cpcdn.com/recipes/dc24279c7e1b8e08/682x484cq65/nasi-bakar-tuna-foto-resep-utama.webp)

5 langkah mudah membuat  Nasi Bakar Tuna cocok sekali jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Dalam Pembuatan Nasi Bakar Tuna:

1. Bumbu halus isian tuna  
1. bawang putih 3 siung
1. bawang merah 6 btr
1. kemiri sangrai 3 btr
1. kunyit bakar 3 ruas
1. cabe merah besar 3 buah
1. cabai rawit merah 10 buah
1.  Bahan lainnya  
1. daun pisang dan tusuk gigi Secukupnya
1. daun kemangi Segenggam
1. Bahan nasi  
1. beras cuci beras dan tiriskan 500 gr
1. santansesuaikan dengan kondisi beras yaa 750 ml
1. garam 1/2 Sdm
1. sereh geprek 1 btg
1. daun salam 2 lbr
1. daun jeruk 4 lbr
1. daun pandan simpulkan 2 lbr
1. Bahan isian tuna  
1. ikan tongkoltuna kukus  suwir2 2-3 buah
1. daun jeruk 3 lbr
1. sereh geprek 1 btg
1. daun salam 2 lbr
1. santan 250 ml
1. jari lengkuas Seruas
1. kaldu bubuk gula dan garam Secukupnya
1. minyak untuk menumis Secukupnya



<!--inarticleads2-->

## Langkah-langkah Untuk Membuat Nasi Bakar Tuna:

1. Siapkan terlebih dahulu semua bahan yg diperlukan
1. Nasi : didihkan santan. Masukkan semua bahan. Aron nasi hingga airnya habis. Panaskan kukusan/dandang lalu matangkan nasi Aron tadi. Kira kira 20-30 menit. Angkat nasi dan sisihkan.
1. Isian tuna : panaskan minyak, tuang bumbu halus. Tumis hingga harum dan Tanak. Kemudian tambahkan lengkuas, daun salam, daun jeruk dan sereh. Aduk rata. Tambahkan suwiran ikan. Aduk rata. Tuang santan. Tambahkan gula,garam dan kaldu bubuk. Koreksi rasa. Masak hingga kuah menyusut. Tambahkan kemangi, aduk hingga layu. Matikan api
1. Penataan nasi bungkus : ambil selembar daun, tata nasi lalu tambahkan isian. Kalo mau ditambah sambal terasi didalamnya juga ok... Hehehe.. gulung dan padatkan. Semat ujungnya dengan tusuk gigi. Lakukan hingga habis.
1. Bakar diatas api atau dengan menggunakan teflon untuk finishingnya. Bakar hingga daun pisang layu. Sajikan.




Salah satu masakan yang cukup praktis dalam pembuatannya adalah  Nasi Bakar Tuna. Selain itu  Nasi Bakar Tuna  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu ikuti 5 langkah, dan  Nasi Bakar Tuna  pun siap di hidangkan. selamat mencoba !
