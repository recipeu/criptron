---
description: "Resep Nasi Uduk Betawi Karakter Anti Gagal"
title: "Resep Nasi Uduk Betawi Karakter Anti Gagal"
slug: 5-resep-nasi-uduk-betawi-karakter-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-17T21:58:20.004Z 
thumbnail: https://img-global.cpcdn.com/recipes/ec56dc98b26e0b79/682x484cq65/nasi-uduk-betawi-karakter-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/ec56dc98b26e0b79/682x484cq65/nasi-uduk-betawi-karakter-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/ec56dc98b26e0b79/682x484cq65/nasi-uduk-betawi-karakter-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/ec56dc98b26e0b79/682x484cq65/nasi-uduk-betawi-karakter-foto-resep-utama.webp
author: Tommy Tate
ratingvalue: 3.1
reviewcount: 5
recipeingredient:
- "beras putih 500 gr"
- "air santan 200 ml santan instan  air sd 600 ml 600 ml"
- "daun salam 3 lembar"
- "daun jeruk 3 lembar"
- "sereh digeprek 1 batang"
- "jahe geprek 1 ruas"
- "lengkuas geprek 1 ruas"
- "pala geprek 1/2 butir"
- "kayu manis ukuran kecil 1 batang"
- "bunga cengkeh 3 pcs"
- "garam 1/2 sdm"
- "BAHAN PELENGKAP  "
- "kering tempe           lihat resep "
- "Telur dadar           lihat resep "
- "Bihun  mie goreng "
- "Balado jengkol "
- "Edible stamp karakter unicorn "
- "Semur telur betawi           lihat resep "
recipeinstructions:
- "Masak nasi uduk : Tuang santan ke dalam wadah, masukkan semua bumbu. Masak sambil diaduk2 hingga mendidih. Masukkan beras masak sambil diaduk hingga air menyusut."
- "Setelah air menyusut pindahkan ke dalam panci kukusan yang telah panas. Kukus selama 30 menit hingga 45 menit."
- "Siapkan bahan pelengkap. Membuat telur dadar           (lihat resep)"
- "Membuat kering tempe           (lihat resep)"
- "Membuat balado jengkol teri. Tumis semua bumbu halus dan pelengkap. Masukkan jengkol yang telah direbus dan empuk. Tumis hingga rata lalu Masukkan teri goreng."
- "Masukkan air, bumbu lainnya tumis hingga rata dan koreksi rasa."
- "Tambahkan bahan pelengkap lainnya seperti bihun / mie goreng."
- "Pada nasi uduk betawi ditempel bahan edible stamp karakter unicorn. Tata semua lauk dibagian tepi Nasi uduk betawi lalu hidangkan."
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 207 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT55M"
recipeyield: "2"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Betawi Karakter](https://img-global.cpcdn.com/recipes/ec56dc98b26e0b79/682x484cq65/nasi-uduk-betawi-karakter-foto-resep-utama.webp)

Ingin membuat Nasi Uduk Betawi Karakter ? Coba resep berikut ini. Cara memasaknya sangat praktis namun jangan kaget jika hasilnya gurih dan lezat cocok sekali jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Dalam Pembuatan Nasi Uduk Betawi Karakter:

1. beras putih 500 gr
1. air santan 200 ml santan instan  air sd 600 ml 600 ml
1. daun salam 3 lembar
1. daun jeruk 3 lembar
1. sereh digeprek 1 batang
1. jahe geprek 1 ruas
1. lengkuas geprek 1 ruas
1. pala geprek 1/2 butir
1. kayu manis ukuran kecil 1 batang
1. bunga cengkeh 3 pcs
1. garam 1/2 sdm
1. BAHAN PELENGKAP  
1. kering tempe           lihat resep 
1. Telur dadar           lihat resep 
1. Bihun  mie goreng 
1. Balado jengkol 
1. Edible stamp karakter unicorn 
1. Semur telur betawi           lihat resep 



<!--inarticleads2-->

## Cara Mudah Membuat Nasi Uduk Betawi Karakter:

1. Masak nasi uduk : Tuang santan ke dalam wadah, masukkan semua bumbu. Masak sambil diaduk2 hingga mendidih. Masukkan beras masak sambil diaduk hingga air menyusut.
1. Setelah air menyusut pindahkan ke dalam panci kukusan yang telah panas. Kukus selama 30 menit hingga 45 menit.
1. Siapkan bahan pelengkap. Membuat telur dadar -           (lihat resep)
1. Membuat kering tempe -           (lihat resep)
1. Membuat balado jengkol teri. Tumis semua bumbu halus dan pelengkap. Masukkan jengkol yang telah direbus dan empuk. Tumis hingga rata lalu Masukkan teri goreng.
1. Masukkan air, bumbu lainnya tumis hingga rata dan koreksi rasa.
1. Tambahkan bahan pelengkap lainnya seperti bihun / mie goreng.
1. Pada nasi uduk betawi ditempel bahan edible stamp karakter unicorn. Tata semua lauk dibagian tepi Nasi uduk betawi lalu hidangkan.




Salah satu kuliner yang cukup praktis dalam pembuatannya adalah  Nasi Uduk Betawi Karakter. Selain itu  Nasi Uduk Betawi Karakter  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu lakukan 8 langkah, dan  Nasi Uduk Betawi Karakter  pun siap di hidangkan. selamat mencoba !
