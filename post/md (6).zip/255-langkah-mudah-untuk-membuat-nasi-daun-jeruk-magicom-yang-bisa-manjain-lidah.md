---
description: "Langkah Mudah untuk Membuat Nasi Daun Jeruk Magicom yang Bisa Manjain Lidah"
title: "Langkah Mudah untuk Membuat Nasi Daun Jeruk Magicom yang Bisa Manjain Lidah"
slug: 255-langkah-mudah-untuk-membuat-nasi-daun-jeruk-magicom-yang-bisa-manjain-lidah
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-15T21:41:38.745Z 
thumbnail: https://img-global.cpcdn.com/recipes/895ba378aa21851e/682x484cq65/nasi-daun-jeruk-magicom-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/895ba378aa21851e/682x484cq65/nasi-daun-jeruk-magicom-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/895ba378aa21851e/682x484cq65/nasi-daun-jeruk-magicom-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/895ba378aa21851e/682x484cq65/nasi-daun-jeruk-magicom-foto-resep-utama.webp
author: Duane Richards
ratingvalue: 3.1
reviewcount: 9
recipeingredient:
- "beras cuci bersih 500 gr"
- "santan kelapa 700 ml"
- "serai di geprek 1 batang"
- "daun salam 2 lembar"
- "daun jeruk 17 lembar"
- "garam 1 1/2 sdt"
recipeinstructions:
- "Ambil 2 lembar daun jeruk buang tulang tengahnya, sisihkan"
- "Iris tipis 15 lembar daun jeruk, sisihkan"
- "Masukkan beras yg sudah di cuci bersih, beserta salam, serai, daun jeruk, garam dan santan ke dalam teflon magicom (banyaknya santan yg dimasukkan kira2 sampai 1 ruas jari diatas beras seperti masak nasi biasanya)"
- "Setelah semua bahan dimasukan masak nasi dgn magicom hingga matang"
- "Setelah matang aduk rata nasi nya sampai buih santan hilang atau tercampur dengan nasi.. tutup lagi magicomnya sebentar kurleb 10 menitan. Nasi daun jeruk sudah siap disajikan dengan lauk pauk dan sambal."
- "Selamat mencoba. Untuk visualisasi resep bisa dilihat di channel you tube saya di YUKMASAK Jangan lupa di like and subscribe ya. Tks 😉🤝"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 218 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT44M"
recipeyield: "4"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk Magicom](https://img-global.cpcdn.com/recipes/895ba378aa21851e/682x484cq65/nasi-daun-jeruk-magicom-foto-resep-utama.webp)

Resep dan cara memasak  Nasi Daun Jeruk Magicom yang bisa kamu coba dirumah

<!--inarticleads1-->

## Bahan-bahan Yang Dibutuhkan Untuk Menyiapkan Nasi Daun Jeruk Magicom:

1. beras cuci bersih 500 gr
1. santan kelapa 700 ml
1. serai di geprek 1 batang
1. daun salam 2 lembar
1. daun jeruk 17 lembar
1. garam 1 1/2 sdt



<!--inarticleads2-->

## Tata Cara Menyiapkan Nasi Daun Jeruk Magicom:

1. Ambil 2 lembar daun jeruk buang tulang tengahnya, sisihkan
1. Iris tipis 15 lembar daun jeruk, sisihkan
1. Masukkan beras yg sudah di cuci bersih, beserta salam, serai, daun jeruk, garam dan santan ke dalam teflon magicom (banyaknya santan yg dimasukkan kira2 sampai 1 ruas jari diatas beras seperti masak nasi biasanya)
1. Setelah semua bahan dimasukan masak nasi dgn magicom hingga matang
1. Setelah matang aduk rata nasi nya sampai buih santan hilang atau tercampur dengan nasi.. tutup lagi magicomnya sebentar kurleb 10 menitan. Nasi daun jeruk sudah siap disajikan dengan lauk pauk dan sambal.
1. Selamat mencoba. Untuk visualisasi resep bisa dilihat di channel you tube saya di YUKMASAK Jangan lupa di like and subscribe ya. Tks 😉🤝




Demikian informasi  resep Nasi Daun Jeruk Magicom   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
