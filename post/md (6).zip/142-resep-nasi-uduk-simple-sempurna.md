---
description: "Resep Nasi Uduk Simple, Sempurna"
title: "Resep Nasi Uduk Simple, Sempurna"
slug: 142-resep-nasi-uduk-simple-sempurna
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-14T10:20:20.165Z 
thumbnail: https://img-global.cpcdn.com/recipes/4bf557fe35d3f3a7/682x484cq65/nasi-uduk-simple-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/4bf557fe35d3f3a7/682x484cq65/nasi-uduk-simple-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/4bf557fe35d3f3a7/682x484cq65/nasi-uduk-simple-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/4bf557fe35d3f3a7/682x484cq65/nasi-uduk-simple-foto-resep-utama.webp
author: Eunice Hopkins
ratingvalue: 4.6
reviewcount: 12
recipeingredient:
- "beras 4 gelas takar"
- "Santan "
- "serai 1 batang"
- "daun salam 2 lembar"
- "daun jeruk 2 lembar"
- "nya Garam fetsin lada Secukup"
recipeinstructions:
- "Cuci bersih beras masukan santan (sesuai takaran memasak nasi), serai, daun salam, daun jeruk lada garam fetsin. Aduk2 lalu masak di Magic Com."
categories:
- Resep
tags:
- nasi
- uduk
- simple

katakunci: nasi uduk simple 
nutrition: 164 calories
recipecuisine: Indonesian
preptime: "PT11M"
cooktime: "PT55M"
recipeyield: "3"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Simple](https://img-global.cpcdn.com/recipes/4bf557fe35d3f3a7/682x484cq65/nasi-uduk-simple-foto-resep-utama.webp)

Resep rahasia Nasi Uduk Simple  sederhana dengan 1 langkahcepat dan mudah cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Untuk Pembuatan Nasi Uduk Simple:

1. beras 4 gelas takar
1. Santan 
1. serai 1 batang
1. daun salam 2 lembar
1. daun jeruk 2 lembar
1. nya Garam fetsin lada Secukup



<!--inarticleads2-->

## Cara Mudah Menyiapkan Nasi Uduk Simple:

1. Cuci bersih beras masukan santan (sesuai takaran memasak nasi), serai, daun salam, daun jeruk lada garam fetsin. Aduk2 lalu masak di Magic Com.




Selamat memasak dan menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
