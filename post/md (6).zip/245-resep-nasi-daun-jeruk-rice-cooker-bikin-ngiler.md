---
description: "Resep Nasi daun jeruk rice cooker, Bikin Ngiler"
title: "Resep Nasi daun jeruk rice cooker, Bikin Ngiler"
slug: 245-resep-nasi-daun-jeruk-rice-cooker-bikin-ngiler
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-01T00:28:04.675Z 
thumbnail: https://img-global.cpcdn.com/recipes/78c3bcc21a0260a9/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/78c3bcc21a0260a9/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/78c3bcc21a0260a9/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/78c3bcc21a0260a9/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
author: Steven Greer
ratingvalue: 3.7
reviewcount: 9
recipeingredient:
- "beras 2 cup"
- "bawang putih cincang 2 bh"
- "daun jeruk buang tulang daun lalu iris tipis 8 lbr"
- "daun salam 3 lbr"
- "sereh geprek  simpulkan 2 ruas"
- "margarine 1 1/2 sdm"
- "garam 1 sdt"
- "kaldu jamur totole 2 sdt"
- "air Secukupnya"
recipeinstructions:
- "Siapkan bahan, cuci bersih beras &amp; tiriskan,"
- "Panaskan wajan kemudian masukkan margarine sampai meleleh, lalu masukkan irisan daun jeruk,bawang putih, salam,sereh, tumis hingga harum &amp; layu, matikan kompor"
- "Masukkan kedalam beras yg sudah di cuci tadi, lalu tambahkan garam &amp; kaldu, aduk² hingga rata, masukkan air, aduk rata kembali &amp; masak nasi di rice cooker sampai matang. Setelah matang jgn lupa diaduk dulu ya supaya rasanya lebih tercampur. Selamat mencoba 🙂"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 129 calories
recipecuisine: Indonesian
preptime: "PT15M"
cooktime: "PT48M"
recipeyield: "3"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi daun jeruk rice cooker](https://img-global.cpcdn.com/recipes/78c3bcc21a0260a9/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp)

Resep Nasi daun jeruk rice cooker  sederhana dengan 3 langkahcepat dan mudah cocok banget jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Untuk Menyiapkan Nasi daun jeruk rice cooker:

1. beras 2 cup
1. bawang putih cincang 2 bh
1. daun jeruk buang tulang daun lalu iris tipis 8 lbr
1. daun salam 3 lbr
1. sereh geprek  simpulkan 2 ruas
1. margarine 1 1/2 sdm
1. garam 1 sdt
1. kaldu jamur totole 2 sdt
1. air Secukupnya

Hai selamat pagi sahabat CWS, pagi ini saya share resep Nasi Daun Jeruk. Praktis banget karena saya gunakan rice cooker. Rasanya mirip nasi uduk tapi wangiiii. Yukkk mari dipantengin dan dipraktekin yah. 

<!--inarticleads2-->

## Langkah-langkah Untuk Membuat Nasi daun jeruk rice cooker:

1. Siapkan bahan, cuci bersih beras &amp; tiriskan,
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/dcd6d5962ca881c5/160x128cq70/nasi-daun-jeruk-rice-cooker-langkah-memasak-1-foto.webp" alt="Nasi daun jeruk rice cooker" width="340" height="340">
><img class="lazyload" data-src="https://img-global.cpcdn.com/steps/8513db9673af6d59/160x128cq70/nasi-daun-jeruk-rice-cooker-langkah-memasak-1-foto.webp" alt="Nasi daun jeruk rice cooker" width="340" height="340">
>1. Panaskan wajan kemudian masukkan margarine sampai meleleh, lalu masukkan irisan daun jeruk,bawang putih, salam,sereh, tumis hingga harum &amp; layu, matikan kompor
1. Masukkan kedalam beras yg sudah di cuci tadi, lalu tambahkan garam &amp; kaldu, aduk² hingga rata, masukkan air, aduk rata kembali &amp; masak nasi di rice cooker sampai matang. - Setelah matang jgn lupa diaduk dulu ya supaya rasanya lebih tercampur. Selamat mencoba 🙂
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/ded8f9ccbaf1417e/160x128cq70/nasi-daun-jeruk-rice-cooker-langkah-memasak-3-foto.webp" alt="Nasi daun jeruk rice cooker" width="340" height="340">
><img class="lazyload" data-src="https://img-global.cpcdn.com/steps/f935c05420ebac16/160x128cq70/nasi-daun-jeruk-rice-cooker-langkah-memasak-3-foto.webp" alt="Nasi daun jeruk rice cooker" width="340" height="340">
><img class="lazyload" data-src="https://img-global.cpcdn.com/steps/ad4ab7aae071bd66/160x128cq70/nasi-daun-jeruk-rice-cooker-langkah-memasak-3-foto.webp" alt="Nasi daun jeruk rice cooker" width="340" height="340">
>

Berikut nih tips dari saya supaya nasi nya matang. Gurih dan wangi dari daun jeruk menambah kelezatan nasi daun jeruk. Setelah tombol menyatakan matang, masukkan daun jeruk. Jangan buka rice cooker sampai uap hilang. Sajikan nasi bersama lauk pelengkap seperti dadar rawis atau bakwan jagung. 

Daripada   beli  Nasi daun jeruk rice cooker  diluar terus, kamu  bisa membuatnya sendiri dirumah. Resep  Nasi daun jeruk rice cooker  sederhana ini cukup praktis dalam proses pembuatannya, serta cukup menggunakan bumbu sederhana  Nasi daun jeruk rice cooker  yang enak, ibu nikmati di rumah.
