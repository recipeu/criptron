---
description: "Resep Nasi Uduk Khas Betawi yang Sempurna"
title: "Resep Nasi Uduk Khas Betawi yang Sempurna"
slug: 85-resep-nasi-uduk-khas-betawi-yang-sempurna
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-30T04:52:41.783Z 
thumbnail: https://img-global.cpcdn.com/recipes/924d9ee74a9ad941/682x484cq65/nasi-uduk-khas-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/924d9ee74a9ad941/682x484cq65/nasi-uduk-khas-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/924d9ee74a9ad941/682x484cq65/nasi-uduk-khas-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/924d9ee74a9ad941/682x484cq65/nasi-uduk-khas-betawi-foto-resep-utama.webp
author: Rosa Blake
ratingvalue: 5
reviewcount: 12
recipeingredient:
- "beras pulen 1 liter"
- "air santan dengan kekentalan sedang Secukupnya"
- "sereh 3 batang"
- "bawang merah agak besar diparut 5 buah"
- "daun salam 7 lembar"
- "jahe kupas kulitnya di parutgeprek 1 ruas"
- "kayu manis bisa di skip 1 ruas"
- "garam Secukupnya"
- "lengkuas di geprek 1 ruas"
recipeinstructions:
- "Cuci beras hingga bersih, sisihkan"
- "Rebus air santan beri garam, aduk2 sampai mendidih"
- "Setelah itu, masukkan jahe parut/geprek dan bawang merah parutnya, aduk2 kembali"
- "Berturut-turut masukkan daun salam, sereh, lengkuas, kemudian masukkan berasnya, aduk2 sampai menjadi aron, koreksi rasa"
- "Kukus nasi uduk aronnya, kurleb selama 30 menit hingga matang, angkat dan siap disajikan bersama menu kesukaan kamu tips : kalau membuat nasi uduk jangan takut menggunakan bumbu rempah, seperti daun salam dan sereh yang agak banyak"
categories:
- Resep
tags:
- nasi
- uduk
- khas

katakunci: nasi uduk khas 
nutrition: 235 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT42M"
recipeyield: "3"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Khas Betawi](https://img-global.cpcdn.com/recipes/924d9ee74a9ad941/682x484cq65/nasi-uduk-khas-betawi-foto-resep-utama.webp)

5 langkah cepat mengolah  Nasi Uduk Khas Betawi cocok banget jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Dalam Menyiapkan Nasi Uduk Khas Betawi:

1. beras pulen 1 liter
1. air santan dengan kekentalan sedang Secukupnya
1. sereh 3 batang
1. bawang merah agak besar diparut 5 buah
1. daun salam 7 lembar
1. jahe kupas kulitnya di parutgeprek 1 ruas
1. kayu manis bisa di skip 1 ruas
1. garam Secukupnya
1. lengkuas di geprek 1 ruas



<!--inarticleads2-->

## Langkah-langkah Untuk Menyiapkan Nasi Uduk Khas Betawi:

1. Cuci beras hingga bersih, sisihkan
1. Rebus air santan beri garam, aduk2 sampai mendidih
1. Setelah itu, masukkan jahe parut/geprek dan bawang merah parutnya, aduk2 kembali
1. Berturut-turut masukkan daun salam, sereh, lengkuas, kemudian masukkan berasnya, aduk2 sampai menjadi aron, koreksi rasa
1. Kukus nasi uduk aronnya, kurleb selama 30 menit hingga matang, angkat dan siap disajikan bersama menu kesukaan kamu tips : kalau membuat nasi uduk jangan takut menggunakan bumbu rempah, seperti daun salam dan sereh yang agak banyak




Terima kasih telah membaca resep yang tim kami tampilkan di halaman ini. Selamat mencoba!
