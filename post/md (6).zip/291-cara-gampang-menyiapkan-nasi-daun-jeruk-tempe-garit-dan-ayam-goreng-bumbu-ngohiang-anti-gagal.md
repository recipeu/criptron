---
description: "Cara Gampang Menyiapkan Nasi Daun Jeruk, Tempe Garit dan Ayam Goreng Bumbu Ngohiang Anti Gagal"
title: "Cara Gampang Menyiapkan Nasi Daun Jeruk, Tempe Garit dan Ayam Goreng Bumbu Ngohiang Anti Gagal"
slug: 291-cara-gampang-menyiapkan-nasi-daun-jeruk-tempe-garit-dan-ayam-goreng-bumbu-ngohiang-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-13T18:43:56.962Z 
thumbnail: https://img-global.cpcdn.com/recipes/369bdaf7dffaf3cc/682x484cq65/nasi-daun-jeruk-tempe-garit-dan-ayam-goreng-bumbu-ngohiang-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/369bdaf7dffaf3cc/682x484cq65/nasi-daun-jeruk-tempe-garit-dan-ayam-goreng-bumbu-ngohiang-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/369bdaf7dffaf3cc/682x484cq65/nasi-daun-jeruk-tempe-garit-dan-ayam-goreng-bumbu-ngohiang-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/369bdaf7dffaf3cc/682x484cq65/nasi-daun-jeruk-tempe-garit-dan-ayam-goreng-bumbu-ngohiang-foto-resep-utama.webp
author: Sara Pena
ratingvalue: 4.3
reviewcount: 15
recipeingredient:
- "Untuk Nasi Daun Jeruk "
- "beras cuci bersih lalu tiriskan 2 mug"
- "Daun jeruk 15 lembar"
- "Salam 2 lembar"
- "Sereh geprek "
- "Bawang putih 4 siung"
- "Garam secukupnya"
- "Air secukupnya"
- "kaldu ayam bubuk 1 sdm"
- "mentega untuk menumis 2 sdm"
- "Bahan Tempe Garit  "
- "Tempe secukupnya"
- "bawang putih ulek halus 3 siung"
- "ketumbar bubuk 1/2 sdt"
- "kunyit bubuk 1/2 sdt"
- "Garam secukupnya"
- "air 4 sdm"
- "Minyak goreng secukupnya untuk menggoreng tempe "
- "Bahan ayam bumbu Ngohiang  "
- "ayam cuci bersih lalu tiriskan 500 gr"
- "garam untuk marinasi 1 sdt"
- "bumbu Ngohiang 5 spices 1 1/2 sdt"
- "kecap asin 1/2 sdt"
- "Garam 1 sdt"
- "Minyak goreng secukupnya untuk menggoreng "
- "Bahan pelengkap lainnya  "
- "Tomat timun bawang goreng telur dadar "
recipeinstructions:
- "Untuk Nasi Daun Jeruknya : tumis daun jeruk yang sudah digunting tipis - tipis, bawang putih, sereh dan salam hingga harum."
- "Masukkan ke dalam magiccom yg sudah berisikan beras. Masak seperti memasak nasi biasa hingga harum dan matang. Sisihkan."
- "Sementara itu buat tempe garitnya : potong-potong tempe, lalu buat Garit - Garit pada kedua sisi tempe. Campur kunyit bubuk, ketumbar bubuk, air dan garam. Aduk rata."
- "Lumuri tempe dengan bahan pencelupnya dan diamkan sebentar. Panaskan minyak, goreng tempe hingga matang. Sisihkan."
- "Selanjutnya untuk ayam goreng bumbu Ngohiang : lumuri ayam dengan bumbu Ngohiang, kecap asin dan garam. Diamkan selama 15 menit. Lebih bagus lagi jika didiamkan selama semalaman di dalam kulkas."
- "Ketika hendak menggoreng ayam, tambahkan garam sedikit demi sedikit sambil dites rasa. Jangan sampai keasinan. Goreng ayam dalam minyak panas hingga matang dan kecoklatan."
- "Sajikan ayam goreng dengan nasi daun jeruk, tempe Garit dengan sambal. Lalapan dan bawang goreng. Sajikan."
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 164 calories
recipecuisine: Indonesian
preptime: "PT24M"
cooktime: "PT39M"
recipeyield: "2"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk, Tempe Garit dan Ayam Goreng Bumbu Ngohiang](https://img-global.cpcdn.com/recipes/369bdaf7dffaf3cc/682x484cq65/nasi-daun-jeruk-tempe-garit-dan-ayam-goreng-bumbu-ngohiang-foto-resep-utama.webp)

Ingin membuat Nasi Daun Jeruk, Tempe Garit dan Ayam Goreng Bumbu Ngohiang ? Coba resep berikut ini. Cara memasaknya sangat praktis namun jangan kaget jika hasilnya gurih dan lezat cocok banget jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Dalam Menyiapkan Nasi Daun Jeruk, Tempe Garit dan Ayam Goreng Bumbu Ngohiang:

1. Untuk Nasi Daun Jeruk 
1. beras cuci bersih lalu tiriskan 2 mug
1. Daun jeruk 15 lembar
1. Salam 2 lembar
1. Sereh geprek 
1. Bawang putih 4 siung
1. Garam secukupnya
1. Air secukupnya
1. kaldu ayam bubuk 1 sdm
1. mentega untuk menumis 2 sdm
1. Bahan Tempe Garit  
1. Tempe secukupnya
1. bawang putih ulek halus 3 siung
1. ketumbar bubuk 1/2 sdt
1. kunyit bubuk 1/2 sdt
1. Garam secukupnya
1. air 4 sdm
1. Minyak goreng secukupnya untuk menggoreng tempe 
1. Bahan ayam bumbu Ngohiang  
1. ayam cuci bersih lalu tiriskan 500 gr
1. garam untuk marinasi 1 sdt
1. bumbu Ngohiang 5 spices 1 1/2 sdt
1. kecap asin 1/2 sdt
1. Garam 1 sdt
1. Minyak goreng secukupnya untuk menggoreng 
1. Bahan pelengkap lainnya  
1. Tomat timun bawang goreng telur dadar 



<!--inarticleads2-->

## Tata Cara Menyiapkan Nasi Daun Jeruk, Tempe Garit dan Ayam Goreng Bumbu Ngohiang:

1. Untuk Nasi Daun Jeruknya : tumis daun jeruk yang sudah digunting tipis - tipis, bawang putih, sereh dan salam hingga harum.
1. Masukkan ke dalam magiccom yg sudah berisikan beras. Masak seperti memasak nasi biasa hingga harum dan matang. Sisihkan.
1. Sementara itu buat tempe garitnya : potong-potong tempe, lalu buat Garit - Garit pada kedua sisi tempe. Campur kunyit bubuk, ketumbar bubuk, air dan garam. Aduk rata.
1. Lumuri tempe dengan bahan pencelupnya dan diamkan sebentar. Panaskan minyak, goreng tempe hingga matang. Sisihkan.
1. Selanjutnya untuk ayam goreng bumbu Ngohiang : lumuri ayam dengan bumbu Ngohiang, kecap asin dan garam. Diamkan selama 15 menit. Lebih bagus lagi jika didiamkan selama semalaman di dalam kulkas.
1. Ketika hendak menggoreng ayam, tambahkan garam sedikit demi sedikit sambil dites rasa. Jangan sampai keasinan. Goreng ayam dalam minyak panas hingga matang dan kecoklatan.
1. Sajikan ayam goreng dengan nasi daun jeruk, tempe Garit dengan sambal. Lalapan dan bawang goreng. Sajikan.




Salah satu masakan yang cukup praktis pembuatannya adalah  Nasi Daun Jeruk, Tempe Garit dan Ayam Goreng Bumbu Ngohiang. Selain itu  Nasi Daun Jeruk, Tempe Garit dan Ayam Goreng Bumbu Ngohiang  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu lakukan 7 langkah, dan  Nasi Daun Jeruk, Tempe Garit dan Ayam Goreng Bumbu Ngohiang  pun siap di hidangkan. selamat mencoba !
