---
description: "Cara Gampang Menyiapkan Nasi Uduk Betawi Anti Gagal"
title: "Cara Gampang Menyiapkan Nasi Uduk Betawi Anti Gagal"
slug: 20-cara-gampang-menyiapkan-nasi-uduk-betawi-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-08T15:09:25.280Z 
thumbnail: https://img-global.cpcdn.com/recipes/cbb27a0c9c964518/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/cbb27a0c9c964518/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/cbb27a0c9c964518/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/cbb27a0c9c964518/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
author: Erik Peters
ratingvalue: 3.9
reviewcount: 12
recipeingredient:
- "beras 3 cup"
- "daun pandan ikat simpul 2 lembar"
- "sereh geprek 2 batang"
- "daun salam 4 lembar"
- "lengkuas geprek seruas"
- "cengkeh 3 butir"
- "jahe bubuk 1 sdt"
- "kayu manis kecil 1 batang"
- "pala bubuk 1/2 sdt"
- "kara ukuran 65ml 1 sachet"
- "garam 1 sdm"
- "Air secukupnya"
- "Minyak bawang tambahan dari saya "
- "beberapa siung bawang merah iris tipis "
- "minyak goreng secukupnya"
- "Bahan pelengkap "
- "Bawang goreng "
- "Telur dadar potong"
- "Gorengan bakwan "
- "Sambal bawang "
- "Timun "
recipeinstructions:
- "Cuci bersih beras Lalu masukkan semua ke dalam wajan atau panci. Takaran airnya disesuaikan seperti kita memasak nasi di rice cooker. Masak hingga airnya asat sambil terus diaduk supaya bawahnya gak gosong."
- "Kukus nasi aron tadi (yang sudah kita masak tadi) selama 1 jam. Ini supaya nasinya benar2 matang dan gak cepat basi. Angkat dan pindahkan ke dalam baskom."
- "Minyak bawang: Goreng bawang merah dengan minyak secukupnya seperti kita membuat bawang goreng. Goreng hingga agak kecoklatan dan garing lalu saring. Minyak bawang nanti disiram ke dalam nasi uduk sebelum disajikan."
- "Aduk2 nasi sambil dikipasin. Tuang minyak bawang sedikit2 lalu aduk2 hingga rata. Buang daun salam, lengkuas, batang sereh, kayu manis dan cengkeh."
- "Sajikan nasi uduk dengan bahan pelengkap. Nasi uduk siap disantap."
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 110 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT55M"
recipeyield: "3"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Betawi](https://img-global.cpcdn.com/recipes/cbb27a0c9c964518/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp)

Resep dan cara memasak  Nasi Uduk Betawi yang harus kamu coba segera

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Dalam Pembuatan Nasi Uduk Betawi:

1. beras 3 cup
1. daun pandan ikat simpul 2 lembar
1. sereh geprek 2 batang
1. daun salam 4 lembar
1. lengkuas geprek seruas
1. cengkeh 3 butir
1. jahe bubuk 1 sdt
1. kayu manis kecil 1 batang
1. pala bubuk 1/2 sdt
1. kara ukuran 65ml 1 sachet
1. garam 1 sdm
1. Air secukupnya
1. Minyak bawang tambahan dari saya 
1. beberapa siung bawang merah iris tipis 
1. minyak goreng secukupnya
1. Bahan pelengkap 
1. Bawang goreng 
1. Telur dadar potong
1. Gorengan bakwan 
1. Sambal bawang 
1. Timun 



<!--inarticleads2-->

## Cara Menyiapkan Nasi Uduk Betawi:

1. Cuci bersih beras Lalu masukkan semua ke dalam wajan atau panci. Takaran airnya disesuaikan seperti kita memasak nasi di rice cooker. Masak hingga airnya asat sambil terus diaduk supaya bawahnya gak gosong.
1. Kukus nasi aron tadi (yang sudah kita masak tadi) selama 1 jam. Ini supaya nasinya benar2 matang dan gak cepat basi. Angkat dan pindahkan ke dalam baskom.
1. Minyak bawang: Goreng bawang merah dengan minyak secukupnya seperti kita membuat bawang goreng. Goreng hingga agak kecoklatan dan garing lalu saring. Minyak bawang nanti disiram ke dalam nasi uduk sebelum disajikan.
1. Aduk2 nasi sambil dikipasin. Tuang minyak bawang sedikit2 lalu aduk2 hingga rata. Buang daun salam, lengkuas, batang sereh, kayu manis dan cengkeh.
1. Sajikan nasi uduk dengan bahan pelengkap. Nasi uduk siap disantap.




Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
