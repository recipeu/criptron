---
description: "Langkah Mudah untuk Menyiapkan Nasi Ayam Hainan yang Lezat Sekali"
title: "Langkah Mudah untuk Menyiapkan Nasi Ayam Hainan yang Lezat Sekali"
slug: 453-langkah-mudah-untuk-menyiapkan-nasi-ayam-hainan-yang-lezat-sekali
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-11T03:22:54.384Z 
thumbnail: https://img-global.cpcdn.com/recipes/8e1f67ce9236560b/682x484cq65/nasi-ayam-hainan-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/8e1f67ce9236560b/682x484cq65/nasi-ayam-hainan-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/8e1f67ce9236560b/682x484cq65/nasi-ayam-hainan-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/8e1f67ce9236560b/682x484cq65/nasi-ayam-hainan-foto-resep-utama.webp
author: Steven Gordon
ratingvalue: 4.7
reviewcount: 11
recipeingredient:
- "Rebusan Ayam "
- "ayam potong ukuran sedang 1 ekor"
- "bawang bombay potong kasar 1/2"
- "daun bawang ikat jadi satu 3"
- "jahe iris tipis 5 cm"
- "air 3 Liter"
- "garam 1,25 sdm"
- "Nasi "
- "beras cuci bersih 500 gr"
- "air rebusan ayam 1 Liter"
- "bawang putih geprek 3 siung"
- "jahe geprek 1 ruas jari"
- "Garam  merica bubuk secukupnya"
- "minyak wijen 1,5 sdm"
- "Kaldu "
- "Kaldu sisa rebusan ayam "
- "Air "
- "bawang putih geprek 5 siung"
- "daun bawang iris sekitar 1 cm 2 batang"
- "gula pasir 1/2 sdt"
- "Garam  merica bubuk secukupnya"
- "minyak wijen 1 sdm"
- "Saus cocolan "
- "bawang putih parut 3 siung"
- "jahe parut 5 cm"
- "kecap asin 5 sdm"
recipeinstructions:
- "Masukkan bawang bombay, jahe, dan daun bawang yang telah diikat ke dalam rongga ayam."
- "Masukkan ayam dalam air dan tambahkan garam, rebus hingga matang (sekitar 40 menit dengan api sedang). Pastikan ayam terendam dengan baik. Pada saat merebus buang busa yang mengambang di atas air rebusan"
- "Setelah ayam matang, tiriskan ayam. Biarkan agak dingin, buang isi rongganya. Potong-potong ayam, atau pisahkan tulangnya dan potong-potong dagingnya. Sisihkan."
- "Kita buat nasinya. Tumis bawang putih dan jahe dalam minyak panas hingga harum. Tuang kaldu, masak hingga mendidih. Masukkan beras, aduk-aduk hingga kaldu habis, tuang minyak wijen, aduk sebentar. Kemudian kukus beras hingga matang."
- "Kaldu: tambahkan air pada sisa kaldu ayam hingga kurang lebih 2 liter. Mau lebih banyak juga ga masalah, tapi usahakan perbandingan air kaldu dan air biasa tidak lebih dari 1:1 ya.. Tumis bawang putih dalam minyak panas hingga harum, tuang dalam kaldu. Rebus kaldu, tambahkan gula, garam, dan merica bubuk secukupnya. Setelah mendidih, masukkan irisan daun bawang, aduk sebentar, kemudian masukkan minyak wijen, aduk sebentar, matikan api."
- "Saus cocolan: campur semua bahan hingga rata."
- "Tata nasi dengan potongan ayam, beri saus cocolan di atas ayam. Sajikan dengan kuah hangat."
categories:
- Resep
tags:
- nasi
- ayam
- hainan

katakunci: nasi ayam hainan 
nutrition: 116 calories
recipecuisine: Indonesian
preptime: "PT16M"
cooktime: "PT56M"
recipeyield: "3"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Ayam Hainan](https://img-global.cpcdn.com/recipes/8e1f67ce9236560b/682x484cq65/nasi-ayam-hainan-foto-resep-utama.webp)

Resep rahasia Nasi Ayam Hainan  enak dengan 7 langkahmudah dan cepat yang musti bunda coba dirumah

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Untuk Pembuatan Nasi Ayam Hainan:

1. Rebusan Ayam 
1. ayam potong ukuran sedang 1 ekor
1. bawang bombay potong kasar 1/2
1. daun bawang ikat jadi satu 3
1. jahe iris tipis 5 cm
1. air 3 Liter
1. garam 1,25 sdm
1. Nasi 
1. beras cuci bersih 500 gr
1. air rebusan ayam 1 Liter
1. bawang putih geprek 3 siung
1. jahe geprek 1 ruas jari
1. Garam  merica bubuk secukupnya
1. minyak wijen 1,5 sdm
1. Kaldu 
1. Kaldu sisa rebusan ayam 
1. Air 
1. bawang putih geprek 5 siung
1. daun bawang iris sekitar 1 cm 2 batang
1. gula pasir 1/2 sdt
1. Garam  merica bubuk secukupnya
1. minyak wijen 1 sdm
1. Saus cocolan 
1. bawang putih parut 3 siung
1. jahe parut 5 cm
1. kecap asin 5 sdm



<!--inarticleads2-->

## Cara Menyiapkan Nasi Ayam Hainan:

1. Masukkan bawang bombay, jahe, dan daun bawang yang telah diikat ke dalam rongga ayam.
1. Masukkan ayam dalam air dan tambahkan garam, rebus hingga matang (sekitar 40 menit dengan api sedang). Pastikan ayam terendam dengan baik. Pada saat merebus buang busa yang mengambang di atas air rebusan
1. Setelah ayam matang, tiriskan ayam. Biarkan agak dingin, buang isi rongganya. Potong-potong ayam, atau pisahkan tulangnya dan potong-potong dagingnya. Sisihkan.
1. Kita buat nasinya. Tumis bawang putih dan jahe dalam minyak panas hingga harum. Tuang kaldu, masak hingga mendidih. Masukkan beras, aduk-aduk hingga kaldu habis, tuang minyak wijen, aduk sebentar. Kemudian kukus beras hingga matang.
1. Kaldu: tambahkan air pada sisa kaldu ayam hingga kurang lebih 2 liter. Mau lebih banyak juga ga masalah, tapi usahakan perbandingan air kaldu dan air biasa tidak lebih dari 1:1 ya.. - Tumis bawang putih dalam minyak panas hingga harum, tuang dalam kaldu. Rebus kaldu, tambahkan gula, garam, dan merica bubuk secukupnya. Setelah mendidih, masukkan irisan daun bawang, aduk sebentar, kemudian masukkan minyak wijen, aduk sebentar, matikan api.
1. Saus cocolan: campur semua bahan hingga rata.
1. Tata nasi dengan potongan ayam, beri saus cocolan di atas ayam. Sajikan dengan kuah hangat.




Demikian informasi  resep Nasi Ayam Hainan   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
