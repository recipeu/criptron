---
description: "Langkah Mudah untuk Menyiapkan Nasi bakar ikan tuna (ricecooker), Lezat"
title: "Langkah Mudah untuk Menyiapkan Nasi bakar ikan tuna (ricecooker), Lezat"
slug: 363-langkah-mudah-untuk-menyiapkan-nasi-bakar-ikan-tuna-ricecooker-lezat
future: true
lang: id
language: id
languageCode: id
publishDate: 2022-01-02T02:20:11.787Z 
thumbnail: https://img-global.cpcdn.com/recipes/3e532fa8b47b1250/682x484cq65/nasi-bakar-ikan-tuna-ricecooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/3e532fa8b47b1250/682x484cq65/nasi-bakar-ikan-tuna-ricecooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/3e532fa8b47b1250/682x484cq65/nasi-bakar-ikan-tuna-ricecooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/3e532fa8b47b1250/682x484cq65/nasi-bakar-ikan-tuna-ricecooker-foto-resep-utama.webp
author: Lillie Clark
ratingvalue: 3.2
reviewcount: 3
recipeingredient:
- "bahan buat nasi  "
- "beras 1 kg"
- "santan kelapa yg kental 500 ml"
- "serai 2 batang"
- "daun jeruk 3 lembar"
- "daun salam 3 lembar"
- "garam secukupnya"
- "bahan untuk isian  "
- "ikan tuna 250 gr"
- "cabai rawit 7 buah"
- "bawang merah 4 buah"
- "bawang putih 2 buah"
- "kemiri 4 buah"
- "tomat 1 buah"
- "daun kemangi 1 ikat"
- "gula dan garam secukupnya"
recipeinstructions:
- "Cara membuat nasi : maklum ya bun... saya kadang males jdnya saya pakai ricecooker aja hehehehhe masukan santan beras lalu serai,garam, daun jeruk dan daun salam"
- "Bahan isiannya : ikan tuna di iris kecil2 lalu bahan lainnya seperti bawang merah,bawang putih,cabai,kemiri,tomat di blender aja ya....(blender jgn pakai air tapi minyak ya bun)"
- "Setelah halus bumbunya sangrai sampai harum masukan ikan dan kemangi lalu beri garam dan gula cekrasa ya bun setelah tercampur semua angkat"
- "Ambil daun pisang lalu ratakan nasi yang sudah masak di daun pisang tersebut lalu isi dengan isian tuna tersebut lalu bentuk seperti lontong begitu..."
- "Setelah terbentuk panaskan teflon lalu panggang sampai daun kehitam2an"
- "Nasi bakar ikan tuna siap di hidangkan.... bahan pelengkap terong goreng,tempe goreng,ikan asin 😍"
categories:
- Resep
tags:
- nasi
- bakar
- ikan

katakunci: nasi bakar ikan 
nutrition: 168 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT41M"
recipeyield: "2"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi bakar ikan tuna (ricecooker)](https://img-global.cpcdn.com/recipes/3e532fa8b47b1250/682x484cq65/nasi-bakar-ikan-tuna-ricecooker-foto-resep-utama.webp)

6 langkah cepat dan mudah membuat  Nasi bakar ikan tuna (ricecooker) cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Untuk Menyiapkan Nasi bakar ikan tuna (ricecooker):

1. bahan buat nasi  
1. beras 1 kg
1. santan kelapa yg kental 500 ml
1. serai 2 batang
1. daun jeruk 3 lembar
1. daun salam 3 lembar
1. garam secukupnya
1. bahan untuk isian  
1. ikan tuna 250 gr
1. cabai rawit 7 buah
1. bawang merah 4 buah
1. bawang putih 2 buah
1. kemiri 4 buah
1. tomat 1 buah
1. daun kemangi 1 ikat
1. gula dan garam secukupnya

Menggunakan Rice Cooker Untuk Membuat Telur Rebus. Biasanya rice cooker dijual satu paket dengan sebuah wadah plastik (biasanya berwarna Tutupi dasar mangkuk ricecooker dengan kertas roti. Ikan bakar is an Indonesian and Malaysian dish, prepared with charcoal-grilled fish or other forms of seafood. Ikan bakar literally means &#34;roasted fish&#34; in Indonesian and Malay. 

<!--inarticleads2-->

## Cara Menyiapkan Nasi bakar ikan tuna (ricecooker):

1. Cara membuat nasi : maklum ya bun... saya kadang males jdnya saya pakai ricecooker aja hehehehhe masukan santan beras lalu serai,garam, daun jeruk dan daun salam
1. Bahan isiannya : ikan tuna di iris kecil2 lalu bahan lainnya seperti bawang merah,bawang putih,cabai,kemiri,tomat di blender aja ya....(blender jgn pakai air tapi minyak ya bun)
1. Setelah halus bumbunya sangrai sampai harum masukan ikan dan kemangi lalu beri garam dan gula cekrasa ya bun setelah tercampur semua angkat
1. Ambil daun pisang lalu ratakan nasi yang sudah masak di daun pisang tersebut lalu isi dengan isian tuna tersebut lalu bentuk seperti lontong begitu...
1. Setelah terbentuk panaskan teflon lalu panggang sampai daun kehitam2an
1. Nasi bakar ikan tuna siap di hidangkan.... bahan pelengkap terong goreng,tempe goreng,ikan asin 😍


READY hari ini Nasi bakar ikan tuna Nasi bakar ayam suwir. Nasi Bakar Tuna Kecombrang. foto: Instagram/@amakigai. Buat pengganti nasi bungkus, siapkan saja nasi bakar dengan isian lauk yang sedap. Misalnya nasi bakar isi ikan teri dan tongkol suwir di resep berikut ini. In general, Nasi bakar/grilled steam rice is aromatic steam rice stuffed with spiced chicken, meat, fish, prawns or mushrooms and then wrapped with banana leaves. 

Daripada kamu beli  Nasi bakar ikan tuna (ricecooker)  diluar terus, kamu  bisa membuatnya sendiri dirumah. Resep  Nasi bakar ikan tuna (ricecooker)  sederhana ini cukup praktis pembuatannya, serta cukup menggunakan bumbu-bumbu sederhana yang ada di dapur  Nasi bakar ikan tuna (ricecooker)  yang enak, ibu nikmati di rumah.
