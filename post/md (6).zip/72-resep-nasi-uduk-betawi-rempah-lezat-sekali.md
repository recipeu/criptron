---
description: "Resep Nasi uduk betawi rempah, Lezat Sekali"
title: "Resep Nasi uduk betawi rempah, Lezat Sekali"
slug: 72-resep-nasi-uduk-betawi-rempah-lezat-sekali
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-28T19:23:57.918Z 
thumbnail: https://img-global.cpcdn.com/recipes/0a0f9dd6e3d82161/682x484cq65/nasi-uduk-betawi-rempah-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/0a0f9dd6e3d82161/682x484cq65/nasi-uduk-betawi-rempah-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/0a0f9dd6e3d82161/682x484cq65/nasi-uduk-betawi-rempah-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/0a0f9dd6e3d82161/682x484cq65/nasi-uduk-betawi-rempah-foto-resep-utama.webp
author: Harry Franklin
ratingvalue: 3.9
reviewcount: 10
recipeingredient:
- "beras cuci bersih tiriskan 1/2 liter"
- "santan kara kecil 1 bks"
- "air 250 ml"
- "jahe 1 ruas"
- "sereh kalau kecil 2 btg 1 btg"
- "Lada bulat utuh sedikit "
- "daun salam 2 lembar"
- "cengkeh 1 butir"
- "pala bubuk Sedikit"
- "Garam secukupnya"
- "penyedap rasa aku pakai royco sapi Sedikit"
- "Bumbu yg dihaluskan  "
- "bawang merah 1 siung"
- "kecil bawang putih 1 siung"
recipeinstructions:
- "Campur air dan santan, lalu masukan ke dalam beras. Airnya dikira2 ya seperti masak nasi biasa cuma dilebihkan sedikit."
- "Masukan jahe, daun salam, lada, sereh, cengkeh, pala bubuk dan bumbu halus. Aduk rata. Masukan garam dan penyedap rasa."
- "Masak campuran beras dan rempah td sampai jd aron atau sampai air kering."
- "Setelah itu kukus nasi sampai matang kira2 10 - 15 menit. Angkat, dan singkirkan semua lada, sereh, daun salam dll. Siap disajikan dengan bawang goreng dan telur dadar"
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 226 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT56M"
recipeyield: "2"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi uduk betawi rempah](https://img-global.cpcdn.com/recipes/0a0f9dd6e3d82161/682x484cq65/nasi-uduk-betawi-rempah-foto-resep-utama.webp)

Ingin membuat Nasi uduk betawi rempah ? Coba resep berikut ini. Cara memasaknya sangat praktis namun hasilnya gurih dan lezat cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Dalam Menyiapkan Nasi uduk betawi rempah:

1. beras cuci bersih tiriskan 1/2 liter
1. santan kara kecil 1 bks
1. air 250 ml
1. jahe 1 ruas
1. sereh kalau kecil 2 btg 1 btg
1. Lada bulat utuh sedikit 
1. daun salam 2 lembar
1. cengkeh 1 butir
1. pala bubuk Sedikit
1. Garam secukupnya
1. penyedap rasa aku pakai royco sapi Sedikit
1. Bumbu yg dihaluskan  
1. bawang merah 1 siung
1. kecil bawang putih 1 siung

Resep nasi uduk betawi sebenarnya cukup sederhana, cara membuatnya juga tidak terlalu sulit, bahan dan bumbunya mudah didapat, serta tidak butuh waktu lama untuk memasaknya. Nasi Uduk Betawi - Betawi merupakan suku asli warga jakarta, Betawi Selain untuk di konsumsi sendiri, resep nasi uduk betawi bisa juga dipergunakan untuk jualan. Masak santan dengan rempah-rempah yang sudah dikeprek-keprek dengan api sedang hingga matang. Resep Nasi Uduk - Salah satu dari variasi nasi biasa yang memiliki banyak penggemar adalah nasi uduk. 

<!--inarticleads2-->

## Tata Cara Menyiapkan Nasi uduk betawi rempah:

1. Campur air dan santan, lalu masukan ke dalam beras. Airnya dikira2 ya seperti masak nasi biasa cuma dilebihkan sedikit.
1. Masukan jahe, daun salam, lada, sereh, cengkeh, pala bubuk dan bumbu halus. Aduk rata. Masukan garam dan penyedap rasa.
1. Masak campuran beras dan rempah td sampai jd aron atau sampai air kering.
1. Setelah itu kukus nasi sampai matang kira2 10 - 15 menit. Angkat, dan singkirkan semua lada, sereh, daun salam dll. Siap disajikan dengan bawang goreng dan telur dadar


Apabila nasi biasa dimasak hanya dengan menggunakan air, nasi uduk dimasak dengan menggunakan santang dan dibumbui dengan beberapa rempah-rempah. Mencicipi nasi uduk Betawi (Foto: Instagram @regunancha). JAKARTA, iNews.id - Resep Nasi Uduk Betawi menjadi salah satu menu spesial yang bisa dibuat kapan saja. Nasi putih yang memiliki rasa gurih ini biasanya dimasak dengan rempah-rempah pilihan dan santan. Nasi gurih dengan bumbu rempah segar dan kering rasanya sudah enak. 

Terima kasih telah membaca resep yang kami tampilkan di halaman ini. Semoga bermanfaat dan selamat mencoba!
