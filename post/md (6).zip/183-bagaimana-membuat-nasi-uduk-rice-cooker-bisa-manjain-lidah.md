---
description: "Bagaimana Membuat Nasi Uduk Rice Cooker, Bisa Manjain Lidah"
title: "Bagaimana Membuat Nasi Uduk Rice Cooker, Bisa Manjain Lidah"
slug: 183-bagaimana-membuat-nasi-uduk-rice-cooker-bisa-manjain-lidah
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-19T11:42:01.520Z 
thumbnail: https://img-global.cpcdn.com/recipes/c2b38fe273ec3ba6/682x484cq65/nasi-uduk-rice-cooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/c2b38fe273ec3ba6/682x484cq65/nasi-uduk-rice-cooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/c2b38fe273ec3ba6/682x484cq65/nasi-uduk-rice-cooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/c2b38fe273ec3ba6/682x484cq65/nasi-uduk-rice-cooker-foto-resep-utama.webp
author: Bernard Luna
ratingvalue: 3.3
reviewcount: 11
recipeingredient:
- "Beras 200 gr"
- "Daun Salam 2 lbr"
- "Daun Pandan 2 lbr"
- "Sereh 1 btg"
- "Lengkuas 2 cm"
- "Jahe 2 cm"
- "Kayu Manis 3 cm"
- "Cengkeh 2 bh"
- "Pala Bubuk 1/2 sdt"
- "Santan 65 ml"
- "Garam 1 sdt"
- "Kaldu Bubuk 2 sdt"
recipeinstructions:
- "Cuci bersih Beras, kemudian geprek jahe, lengkuas dan sereh"
- "Masukkan semua bumbu ke dalam beras"
- "Tambahkan santan dan air, lalu campur rata (air yg digunakan sama seperti masak nasi biasa)"
- "Masak mengguka rice cooker"
- "Saat mateng, siap dihidangkan, tambah taburan bawang goreng agar lebih wangi"
categories:
- Resep
tags:
- nasi
- uduk
- rice

katakunci: nasi uduk rice 
nutrition: 282 calories
recipecuisine: Indonesian
preptime: "PT29M"
cooktime: "PT49M"
recipeyield: "2"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Rice Cooker](https://img-global.cpcdn.com/recipes/c2b38fe273ec3ba6/682x484cq65/nasi-uduk-rice-cooker-foto-resep-utama.webp)

5 langkah cepat memasak  Nasi Uduk Rice Cooker cocok sekali jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Untuk Pembuatan Nasi Uduk Rice Cooker:

1. Beras 200 gr
1. Daun Salam 2 lbr
1. Daun Pandan 2 lbr
1. Sereh 1 btg
1. Lengkuas 2 cm
1. Jahe 2 cm
1. Kayu Manis 3 cm
1. Cengkeh 2 bh
1. Pala Bubuk 1/2 sdt
1. Santan 65 ml
1. Garam 1 sdt
1. Kaldu Bubuk 2 sdt



<!--inarticleads2-->

## Cara Mudah Menyiapkan Nasi Uduk Rice Cooker:

1. Cuci bersih Beras, kemudian geprek jahe, lengkuas dan sereh
1. Masukkan semua bumbu ke dalam beras
1. Tambahkan santan dan air, lalu campur rata (air yg digunakan sama seperti masak nasi biasa)
1. Masak mengguka rice cooker
1. Saat mateng, siap dihidangkan, tambah taburan bawang goreng agar lebih wangi




Demikian informasi  resep Nasi Uduk Rice Cooker   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
