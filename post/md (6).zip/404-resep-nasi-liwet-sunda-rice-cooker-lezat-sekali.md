---
description: "Resep Nasi Liwet Sunda Rice Cooker, Lezat Sekali"
title: "Resep Nasi Liwet Sunda Rice Cooker, Lezat Sekali"
slug: 404-resep-nasi-liwet-sunda-rice-cooker-lezat-sekali
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-10T00:03:22.401Z 
thumbnail: https://img-global.cpcdn.com/recipes/c1515c7962c82dd4/682x484cq65/nasi-liwet-sunda-rice-cooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/c1515c7962c82dd4/682x484cq65/nasi-liwet-sunda-rice-cooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/c1515c7962c82dd4/682x484cq65/nasi-liwet-sunda-rice-cooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/c1515c7962c82dd4/682x484cq65/nasi-liwet-sunda-rice-cooker-foto-resep-utama.webp
author: Francisco Vasquez
ratingvalue: 3.6
reviewcount: 6
recipeingredient:
- "beras 3 cup"
- "santan instan bisa skip 1 sachet"
- "bawang merah 6 buah"
- "bawang putih 5 siung"
- "daun salam 5 lembar"
- "serai ambil putihnya geprek 1 batang"
- "daun jeruk 2 lembar"
- "garam 1/2 sdt"
- "kaldu bubuk 1/2 sachet"
- "pete kupas 2 papan"
- "teri nasi yang sudah digoreng Secukupnya"
- "cabe rawit 10 buah"
- "minyak goreng sisa gpreng ikan asin Sedikit"
- "air tinggi air seruas jari diatas permukaan beras Secukupnya"
recipeinstructions:
- "Cuci bersih beras"
- "Tambahkan santan yg telah diberi air kira2 seruas jari diatas permukaan beras (dalam panci rice cooker)"
- "Iris tipis bawang merah &amp; bawang putih"
- "Tumis bawang merah, bawang putih, serai, salam dan daun jeruk"
- "Masukan tumisan bumbu, tambahkan kaldu bubuk dan garam"
- "Tambahkan minyak sisa goreng ikan asin (sedikit saja untuk aroma)"
- "Tambahkan pete dan cabe rawit, aduk"
- "Nyalakan rice cooker tunggu hingga matang"
- "Setelah matang buka rice cooker aduk hingga santan diatas tercampur rata"
- "Hidangkan nasi liwet dg lauk sesuai selera"
categories:
- Resep
tags:
- nasi
- liwet
- sunda

katakunci: nasi liwet sunda 
nutrition: 181 calories
recipecuisine: Indonesian
preptime: "PT11M"
cooktime: "PT32M"
recipeyield: "2"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Liwet Sunda Rice Cooker](https://img-global.cpcdn.com/recipes/c1515c7962c82dd4/682x484cq65/nasi-liwet-sunda-rice-cooker-foto-resep-utama.webp)

10 langkah cepat dan mudah memasak  Nasi Liwet Sunda Rice Cooker cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Dalam Pembuatan Nasi Liwet Sunda Rice Cooker:

1. beras 3 cup
1. santan instan bisa skip 1 sachet
1. bawang merah 6 buah
1. bawang putih 5 siung
1. daun salam 5 lembar
1. serai ambil putihnya geprek 1 batang
1. daun jeruk 2 lembar
1. garam 1/2 sdt
1. kaldu bubuk 1/2 sachet
1. pete kupas 2 papan
1. teri nasi yang sudah digoreng Secukupnya
1. cabe rawit 10 buah
1. minyak goreng sisa gpreng ikan asin Sedikit
1. air tinggi air seruas jari diatas permukaan beras Secukupnya



<!--inarticleads2-->

## Langkah-langkah Untuk Membuat Nasi Liwet Sunda Rice Cooker:

1. Cuci bersih beras
1. Tambahkan santan yg telah diberi air kira2 seruas jari diatas permukaan beras (dalam panci rice cooker)
1. Iris tipis bawang merah &amp; bawang putih
1. Tumis bawang merah, bawang putih, serai, salam dan daun jeruk
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/c194cf2d3fa775b8/160x128cq70/nasi-liwet-sunda-rice-cooker-langkah-memasak-4-foto.webp" alt="Nasi Liwet Sunda Rice Cooker" width="340" height="340">
>1. Masukan tumisan bumbu, tambahkan kaldu bubuk dan garam
1. Tambahkan minyak sisa goreng ikan asin (sedikit saja untuk aroma)
1. Tambahkan pete dan cabe rawit, aduk
1. Nyalakan rice cooker tunggu hingga matang
1. Setelah matang buka rice cooker aduk hingga santan diatas tercampur rata
1. Hidangkan nasi liwet dg lauk sesuai selera




Terima kasih telah menggunakan resep yang kami tampilkan di sini. Selamat mencoba!
