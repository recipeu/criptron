---
description: "Resep Nasi Uduk Semur Jengkol Nasi Uduknye Betawi, Enak Banget"
title: "Resep Nasi Uduk Semur Jengkol Nasi Uduknye Betawi, Enak Banget"
slug: 80-resep-nasi-uduk-semur-jengkol-nasi-uduknye-betawi-enak-banget
future: true
lang: id
language: id
languageCode: id
publishDate: 2022-01-01T07:33:23.615Z 
thumbnail: https://img-global.cpcdn.com/recipes/15dc763e3bf28c12/682x484cq65/nasi-uduk-semur-jengkol-nasi-uduknye-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/15dc763e3bf28c12/682x484cq65/nasi-uduk-semur-jengkol-nasi-uduknye-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/15dc763e3bf28c12/682x484cq65/nasi-uduk-semur-jengkol-nasi-uduknye-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/15dc763e3bf28c12/682x484cq65/nasi-uduk-semur-jengkol-nasi-uduknye-betawi-foto-resep-utama.webp
author: Estelle Holloway
ratingvalue: 4
reviewcount: 13
recipeingredient:
- "Bahan Nasi Uduk "
- "beras 3 cup"
- "daun salam 3 lembar"
- "sereh 3 ruas"
- "santan kental campur dengan air kira2 seruas ujung jari 65 ml"
- "garam Secukupnya"
- "Bahan semur jengkol "
- "jengkol yang tua 1/4 kg"
- "kecap manis 5 sdm"
- "kecap asin 1 sdm"
- "gula merah 1 sdm"
- "cengkeh 3 butir"
- "kayu manis 1 ruas"
- "Garam secukupnya"
- "air 500 ml"
- "pala geprek 1/4"
- "daun salam 3 lembar"
- "Bumbu halus untuk semur "
- "bawang merah 6 siung"
- "bawang putih 1 siung"
- "jahe 1 ruas"
- "kemiri 3"
- "Bahan kering tempe "
- "tempe daun 1 papan"
- "cabe merah iris 5 buah"
- "bawang merah iris 5 buah"
- "bawang putih iris 1 siung"
- "gula merah sisir halus 1 sdt"
- "Kecap manis secukupnya"
- "Garam secukup nya "
- "Bahan sambel "
- "cabe merah 10 buah"
- "cabe rawit 5 buah"
- "bawang merah 5 buah"
- "bawang putih 1 siung"
- "tomat 1 buah"
- "Pelengkap "
- "timun dan kerupuk Irisan"
- "Bawang goreng bila suka"
- "telur kocok lepas 1 butir"
recipeinstructions:
- "Cuci bersih beras,taruh dalam magic com, masukkan santan, garam, daun salam dan sereh, aduk sebentar, lalu nyalakan magic com nya, masak nasi seperti biasa,kalau untuk nasi uduk, jangam lupa sesekali diaduk nasi nya agar matang nya sempurna dan garam teraduk rata."
- "Membuat semur jengkol : Cuci bersih jengkol lalu rebus sampai empuk dengan daun salam dan sereh, tujuan nya agar tidak bau saat di rebus. Kemudian angkat dan siram jengkol dengan air matang.Getok dengan ulekan. Kemudian kita tumis bumbunya sampai harum,tambahkan air, gula merah, kecap manis,kecap asin, dan garam aduk rata, lalu masukkan jengkol nya, aduk rata masak sampai kuah mengental."
- "Membuat kering tempe : iris tempe memanjang, lalu goreng sampai matang, kemudian tumis bumbu sampai harum, masukkan tempe, gula merah, kecap manis dan garam, aduk rata, cek rasa lalu angkat."
- "Membuat Sambel Goreng dan Telur dadar : Rebus semua bahan sambel, lalu ulek atau blender, tambahkan garam dan minyak goreng secukupnya. Lalu dadar telur dan iris iris setelah matang."
- "Sekarang semua sudah matang, Tata nasi dalam plate saji, tambahakan kering tempe, sambel, semur, irisan telur,kerupuk dan irisan timun, Nasi uduk siap disantap."
categories:
- Resep
tags:
- nasi
- uduk
- semur

katakunci: nasi uduk semur 
nutrition: 106 calories
recipecuisine: Indonesian
preptime: "PT16M"
cooktime: "PT60M"
recipeyield: "4"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Semur Jengkol Nasi Uduknye Betawi](https://img-global.cpcdn.com/recipes/15dc763e3bf28c12/682x484cq65/nasi-uduk-semur-jengkol-nasi-uduknye-betawi-foto-resep-utama.webp)

5 langkah mudah dan cepat membuat  Nasi Uduk Semur Jengkol Nasi Uduknye Betawi cocok sekali jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Untuk Menyiapkan Nasi Uduk Semur Jengkol Nasi Uduknye Betawi:

1. Bahan Nasi Uduk 
1. beras 3 cup
1. daun salam 3 lembar
1. sereh 3 ruas
1. santan kental campur dengan air kira2 seruas ujung jari 65 ml
1. garam Secukupnya
1. Bahan semur jengkol 
1. jengkol yang tua 1/4 kg
1. kecap manis 5 sdm
1. kecap asin 1 sdm
1. gula merah 1 sdm
1. cengkeh 3 butir
1. kayu manis 1 ruas
1. Garam secukupnya
1. air 500 ml
1. pala geprek 1/4
1. daun salam 3 lembar
1. Bumbu halus untuk semur 
1. bawang merah 6 siung
1. bawang putih 1 siung
1. jahe 1 ruas
1. kemiri 3
1. Bahan kering tempe 
1. tempe daun 1 papan
1. cabe merah iris 5 buah
1. bawang merah iris 5 buah
1. bawang putih iris 1 siung
1. gula merah sisir halus 1 sdt
1. Kecap manis secukupnya
1. Garam secukup nya 
1. Bahan sambel 
1. cabe merah 10 buah
1. cabe rawit 5 buah
1. bawang merah 5 buah
1. bawang putih 1 siung
1. tomat 1 buah
1. Pelengkap 
1. timun dan kerupuk Irisan
1. Bawang goreng bila suka
1. telur kocok lepas 1 butir



<!--inarticleads2-->

## Cara Mudah Menyiapkan Nasi Uduk Semur Jengkol Nasi Uduknye Betawi:

1. Cuci bersih beras,taruh dalam magic com, masukkan santan, garam, daun salam dan sereh, aduk sebentar, lalu nyalakan magic com nya, masak nasi seperti biasa,kalau untuk nasi uduk, jangam lupa sesekali diaduk nasi nya agar matang nya sempurna dan garam teraduk rata.
1. Membuat semur jengkol : Cuci bersih jengkol lalu rebus sampai empuk dengan daun salam dan sereh, tujuan nya agar tidak bau saat di rebus. Kemudian angkat dan siram jengkol dengan air matang.Getok dengan ulekan. Kemudian kita tumis bumbunya sampai harum,tambahkan air, gula merah, kecap manis,kecap asin, dan garam aduk rata, lalu masukkan jengkol nya, aduk rata masak sampai kuah mengental.
1. Membuat kering tempe : iris tempe memanjang, lalu goreng sampai matang, kemudian tumis bumbu sampai harum, masukkan tempe, gula merah, kecap manis dan garam, aduk rata, cek rasa lalu angkat.
1. Membuat Sambel Goreng dan Telur dadar : Rebus semua bahan sambel, lalu ulek atau blender, tambahkan garam dan minyak goreng secukupnya. Lalu dadar telur dan iris iris setelah matang.
1. Sekarang semua sudah matang, Tata nasi dalam plate saji, tambahakan kering tempe, sambel, semur, irisan telur,kerupuk dan irisan timun, Nasi uduk siap disantap.




Daripada bunda beli  Nasi Uduk Semur Jengkol Nasi Uduknye Betawi  diluar terus, ibu  bisa membuatnya sendiri dirumah. Resep  Nasi Uduk Semur Jengkol Nasi Uduknye Betawi  sederhana ini cukup praktis pembuatannya, serta cukup menggunakan bumbu sederhana  Nasi Uduk Semur Jengkol Nasi Uduknye Betawi  yang enak, ibu nikmati di rumah.
