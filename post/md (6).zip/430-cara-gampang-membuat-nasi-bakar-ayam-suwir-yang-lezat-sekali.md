---
description: "Cara Gampang Membuat Nasi bakar ayam suwir yang Lezat Sekali"
title: "Cara Gampang Membuat Nasi bakar ayam suwir yang Lezat Sekali"
slug: 430-cara-gampang-membuat-nasi-bakar-ayam-suwir-yang-lezat-sekali
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-17T19:29:24.053Z 
thumbnail: https://img-global.cpcdn.com/recipes/8ebaa8eed939d53b/682x484cq65/nasi-bakar-ayam-suwir-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/8ebaa8eed939d53b/682x484cq65/nasi-bakar-ayam-suwir-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/8ebaa8eed939d53b/682x484cq65/nasi-bakar-ayam-suwir-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/8ebaa8eed939d53b/682x484cq65/nasi-bakar-ayam-suwir-foto-resep-utama.webp
author: Craig Gordon
ratingvalue: 3.5
reviewcount: 7
recipeingredient:
- "Nasi uduk harumnasi biasa 1 cup           lihat resep "
- "daun kemangi 1 ikat"
- "dada ayam 1/2"
- "daun salam 1"
- "garam Sejumput"
- "air Secukupnya"
- "daun pisang Secukupnya"
- "Bumbu halus "
- "bawang putih 3"
- "bawang merah 3"
- "kemiri sangrai 1 butir"
- "cabe merah 1"
- "cabai keriting 2"
- "Bumbu lainnya "
- "kunyit bubuk 1/2 sdt"
- "lada bubuk 1/2 sdt"
- "garam 1/4 sdt"
- "kaldu bubuk 1/4 sdt"
- "kecap manis 1 sdm"
- "air Secukupnya"
recipeinstructions:
- "Rebus dada ayam + daun salam + sejumput garam hingga matang. Angkat dan biarkan dingin kemudian disuwir-suwir, sisihkan."
- "Tumis bumbu halus hingga harum, tambahkan semua bumbu lainnya, aduk rata."
- "Tambahkan ayam suwir, aduk rata hingga bumbu meresap. Angkat dan sisihkan."
- "Siapkan dua lembar daun pisang yang kecil di atas, masukkan nasi uduk secukupnya. Tambahkan ayam suwir di atasnya + kemangi di samping, bungkus sesuai selera."
- "Panaskan kukusan, kukus nasi selama 30 menit. Angkat. Lalu bakar dgn teflon atau arang. Bolak² sampai daunnya kecoklatan."
categories:
- Resep
tags:
- nasi
- bakar
- ayam

katakunci: nasi bakar ayam 
nutrition: 249 calories
recipecuisine: Indonesian
preptime: "PT13M"
cooktime: "PT34M"
recipeyield: "3"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi bakar ayam suwir](https://img-global.cpcdn.com/recipes/8ebaa8eed939d53b/682x484cq65/nasi-bakar-ayam-suwir-foto-resep-utama.webp)

Resep rahasia Nasi bakar ayam suwir  anti gagal dengan 5 langkahmudah cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Dalam Pembuatan Nasi bakar ayam suwir:

1. Nasi uduk harumnasi biasa 1 cup           lihat resep 
1. daun kemangi 1 ikat
1. dada ayam 1/2
1. daun salam 1
1. garam Sejumput
1. air Secukupnya
1. daun pisang Secukupnya
1. Bumbu halus 
1. bawang putih 3
1. bawang merah 3
1. kemiri sangrai 1 butir
1. cabe merah 1
1. cabai keriting 2
1. Bumbu lainnya 
1. kunyit bubuk 1/2 sdt
1. lada bubuk 1/2 sdt
1. garam 1/4 sdt
1. kaldu bubuk 1/4 sdt
1. kecap manis 1 sdm
1. air Secukupnya

Ini Resep mudah Membuat Nasi Bakar isi Ayam Suwir yang paling enak dan lezat. Berikut resep Membuat Nasi Bakar yang sedap dan gurih isi suwir ayam. Bahan dan bumbu  Pemakaian ayam suwir memudahkan untuk menyantapnya, selain itu bumbu lebih mudah menyatu. Agar lebih spesial gunakan ayam kampung. 

<!--inarticleads2-->

## Langkah-langkah Untuk Menyiapkan Nasi bakar ayam suwir:

1. Rebus dada ayam + daun salam + sejumput garam hingga matang. Angkat dan biarkan dingin kemudian disuwir-suwir, sisihkan.
1. Tumis bumbu halus hingga harum, tambahkan semua bumbu lainnya, aduk rata.
1. Tambahkan ayam suwir, aduk rata hingga bumbu meresap. Angkat dan sisihkan.
1. Siapkan dua lembar daun pisang yang kecil di atas, masukkan nasi uduk secukupnya. Tambahkan ayam suwir di atasnya + kemangi di samping, bungkus sesuai selera.
1. Panaskan kukusan, kukus nasi selama 30 menit. Angkat. Lalu bakar dgn teflon atau arang. Bolak² sampai daunnya kecoklatan.


Nasi bakar ayam suwir is a dish of grilled rice with shredded chicken. Spiced chicken breast is enveloped with rice, which is then wrapped in banana leaves, and then grilled for a charred, smokey flavour. Nasi Bakar Tuna/Tongkol Suwir Teri Medan + Sambal &amp; Lalapan+Tahu Tempe. Tenang saja, cara membuat nasi bakar ayam suwir bali ini simpel. Cara membakarnya saja cukup menggunakan wajan teflon antilengket. 

Terima kasih telah membaca resep yang tim kami tampilkan di halaman ini. Selamat mencoba!
