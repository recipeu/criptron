---
description: "Langkah Mudah untuk Menyiapkan Nasi Daun Jeruk, Bikin Ngiler"
title: "Langkah Mudah untuk Menyiapkan Nasi Daun Jeruk, Bikin Ngiler"
slug: 290-langkah-mudah-untuk-menyiapkan-nasi-daun-jeruk-bikin-ngiler
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-16T14:48:55.008Z 
thumbnail: https://img-global.cpcdn.com/recipes/8140c67bc3f693e3/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/8140c67bc3f693e3/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/8140c67bc3f693e3/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/8140c67bc3f693e3/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
author: George Williams
ratingvalue: 3.7
reviewcount: 6
recipeingredient:
- "beras 2 gelas teh"
- "daun jeruk iris tipis 10 lembar"
- "mentega 2 sdm"
- "lengkuas geprek 2 cm"
- "sereh 1 batang"
- "daun salam 1"
- "Bumbu halus  "
- "baput 4 siung"
- "daun jeruk 3 lembar"
- "garam Secukupnya"
recipeinstructions:
- "Cuci beras seperti biasa. Tiriskan. Lalu uleg bumbu halus, sy pake ulegan aja."
- "Cemplungin semua bahan di beras yg mau dimasak. Lalu masak selama 45 menit atau sampek tanak ya. Setelah matang aduk2, lalu tutup kembali ricecooker nya tunggu sebentar. Siap disajikan.Tambahkan lauk dan sambal."
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 296 calories
recipecuisine: Indonesian
preptime: "PT16M"
cooktime: "PT51M"
recipeyield: "1"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk](https://img-global.cpcdn.com/recipes/8140c67bc3f693e3/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp)

Resep dan cara memasak  Nasi Daun Jeruk yang musti ibu coba dirumah

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Untuk Menyiapkan Nasi Daun Jeruk:

1. beras 2 gelas teh
1. daun jeruk iris tipis 10 lembar
1. mentega 2 sdm
1. lengkuas geprek 2 cm
1. sereh 1 batang
1. daun salam 1
1. Bumbu halus  
1. baput 4 siung
1. daun jeruk 3 lembar
1. garam Secukupnya



<!--inarticleads2-->

## Langkah-langkah Untuk Membuat Nasi Daun Jeruk:

1. Cuci beras seperti biasa. Tiriskan. Lalu uleg bumbu halus, sy pake ulegan aja.
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/0cd67668e506afe6/160x128cq70/nasi-daun-jeruk-langkah-memasak-1-foto.webp" alt="Nasi Daun Jeruk" width="340" height="340">
>1. Cemplungin semua bahan di beras yg mau dimasak. Lalu masak selama 45 menit atau sampek tanak ya. Setelah matang aduk2, lalu tutup kembali ricecooker nya tunggu sebentar. Siap disajikan.Tambahkan lauk dan sambal.
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/7850aa9ed19aad43/160x128cq70/nasi-daun-jeruk-langkah-memasak-2-foto.webp" alt="Nasi Daun Jeruk" width="340" height="340">
><img class="lazyload" data-src="https://img-global.cpcdn.com/steps/5b18aeb673f69ae3/160x128cq70/nasi-daun-jeruk-langkah-memasak-2-foto.webp" alt="Nasi Daun Jeruk" width="340" height="340">
><img class="lazyload" data-src="https://img-global.cpcdn.com/steps/0dd8df09697897f1/160x128cq70/nasi-daun-jeruk-langkah-memasak-2-foto.webp" alt="Nasi Daun Jeruk" width="340" height="340">
>



Salah satu masakan yang cukup praktis pembuatannya adalah  Nasi Daun Jeruk. Selain itu  Nasi Daun Jeruk  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu lakukan 2 langkah, dan  Nasi Daun Jeruk  pun siap di hidangkan. selamat mencoba !
