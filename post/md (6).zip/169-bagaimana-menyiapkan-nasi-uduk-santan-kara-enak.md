---
description: "Bagaimana Menyiapkan Nasi uduk santan kara, Enak"
title: "Bagaimana Menyiapkan Nasi uduk santan kara, Enak"
slug: 169-bagaimana-menyiapkan-nasi-uduk-santan-kara-enak
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-23T00:20:49.550Z 
thumbnail: https://img-global.cpcdn.com/recipes/836fbf0d126ebab1/682x484cq65/nasi-uduk-santan-kara-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/836fbf0d126ebab1/682x484cq65/nasi-uduk-santan-kara-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/836fbf0d126ebab1/682x484cq65/nasi-uduk-santan-kara-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/836fbf0d126ebab1/682x484cq65/nasi-uduk-santan-kara-foto-resep-utama.webp
author: Jeffrey Joseph
ratingvalue: 5
reviewcount: 11
recipeingredient:
- "beras 1 kg"
- "santan kara 65 ml 3 bungkus"
- "lengkuas geprek Sejempol"
- "serai geprek 3 batang"
- "daun pandan ikat simpul 3 lembar"
- "daun salam 6 lembar"
- "garam sesuai selera Secukupnya"
- "Air sesuai takaran masak biasa "
recipeinstructions:
- "Cuci bersih beras, masukkan air + santan kara sesuai takaran memasak biasa. Kemudian masukkan pula serai, lengkuas, daun pandan dan garam."
- "Kalau memasak dengan magic com, tinggal hidupkan magic com, masak nasi seperti biasa sambil sesekali diaduk."
- "Kalau memasak dengan cara di aron, masak bahan2 no. 1 dengan api kecil sampai air mengering. Kemudian pindahkan ke panci kukusan. Kukus hingga nasi matang."
- "Hidangkan dengan sambal kering tempe, telur dadar, nugget atau mie goreng sesuai selera."
categories:
- Resep
tags:
- nasi
- uduk
- santan

katakunci: nasi uduk santan 
nutrition: 185 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT52M"
recipeyield: "3"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi uduk santan kara](https://img-global.cpcdn.com/recipes/836fbf0d126ebab1/682x484cq65/nasi-uduk-santan-kara-foto-resep-utama.webp)

4 langkah cepat dan mudah memasak  Nasi uduk santan kara cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Untuk Menyiapkan Nasi uduk santan kara:

1. beras 1 kg
1. santan kara 65 ml 3 bungkus
1. lengkuas geprek Sejempol
1. serai geprek 3 batang
1. daun pandan ikat simpul 3 lembar
1. daun salam 6 lembar
1. garam sesuai selera Secukupnya
1. Air sesuai takaran masak biasa 

Nasi lemak senang dijumpai di Malaysia, ia adalah makanan kebangsaan di Malaysia. Ia juga menjadi popular di negara jiran seperti Singapura, Brunei and Negara Thai selatan. Nasi lemak yang cukup rasa, perlukan santan yang cukup wangi (Kara Santa) dan daun pandan. - Untuk nasi uduk, didihkan santan, masukkan daun salam, dan serai. - Kemudian masukkan beras dan minyak goreng. Masak dengan api kecil sambil diaduk sampai santan terserap. - Angkat, kukus bersama pandan sampai nasi matang. - mask kering tempe, goreng tempe sampai setengah matang. 

<!--inarticleads2-->

## Cara Membuat Nasi uduk santan kara:

1. Cuci bersih beras, masukkan air + santan kara sesuai takaran memasak biasa. Kemudian masukkan pula serai, lengkuas, daun pandan dan garam.
1. Kalau memasak dengan magic com, tinggal hidupkan magic com, masak nasi seperti biasa sambil sesekali diaduk.
1. Kalau memasak dengan cara di aron, masak bahan2 no. 1 dengan api kecil sampai air mengering. Kemudian pindahkan ke panci kukusan. Kukus hingga nasi matang.
1. Hidangkan dengan sambal kering tempe, telur dadar, nugget atau mie goreng sesuai selera.


Nasi Kuning Bumbu Ikan Santan Kara Masaknya Pake Mejicom,di Jamin Rasanya Mantul. Cara Membuat Nasi Uduk Masak Bareng Dengan Nasi Biasa Buat Usaha Warung Pecel Lele. Berikut ini adalah cara meresep nya. Campurkan dari Sepaket bumbu lengkap (daun salam, daun jeruk, lengkuas, sereh). Nasi uduk juga menjadi primadona bagi para pelajar dan juga anak rantau yang tidak sempat membuat sarapan nya sendiri. 

Demikian informasi  resep Nasi uduk santan kara   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
