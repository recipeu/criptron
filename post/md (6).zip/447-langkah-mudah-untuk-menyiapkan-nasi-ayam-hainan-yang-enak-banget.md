---
description: "Langkah Mudah untuk Menyiapkan Nasi Ayam Hainan yang Enak Banget"
title: "Langkah Mudah untuk Menyiapkan Nasi Ayam Hainan yang Enak Banget"
slug: 447-langkah-mudah-untuk-menyiapkan-nasi-ayam-hainan-yang-enak-banget
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-03T17:00:34.798Z 
thumbnail: https://img-global.cpcdn.com/recipes/b71a0a9220ad13e4/682x484cq65/nasi-ayam-hainan-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/b71a0a9220ad13e4/682x484cq65/nasi-ayam-hainan-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/b71a0a9220ad13e4/682x484cq65/nasi-ayam-hainan-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/b71a0a9220ad13e4/682x484cq65/nasi-ayam-hainan-foto-resep-utama.webp
author: Owen Rodgers
ratingvalue: 4.1
reviewcount: 13
recipeingredient:
- "Rebusan ayam  sup "
- "ayam 1/2 ekor"
- "bawang putih cukup di geprek 1 bonggol"
- "jahe kupas kulit potong besar dan geprek 1 jempol"
- "minyak wijen 3 sdm"
- "saus tiram 1 sdm"
- "tomat 2 bh"
- "daun bawang potong kasar 1 batang"
- "daun seledri potong kasar 2"
- "Garam gula sedikit lada penyedap "
- "Nasi "
- "Beras secukupnya"
- "Minyak ayam yg dibuat dari gorengan kulit dan lemak ayam "
- "Atau bisa minyak goreng biasa "
- "bawang putih cincang halus 4 siung"
- "jahe cincang halus 1 ruas"
- "kunyit cincang halus boleh skip 1 ruas"
- "Air rebusan ayam "
- "Garam penyedap "
- "Kecap ayam "
- "jahe parut 1 ruas"
- "bawang putih parut 3"
- "Kecap asin "
- "Kecap manis "
- "Saus tiram "
- "Sambel ayam "
- "cabe merah 10 batang"
- "cabe setan jika mau pedas 10 batang"
- "Bawang putih "
- "Jahe "
- "jeruk sambal 2 buah"
recipeinstructions:
- "Rebus ayam tanpa kulit bersama bawang putih dan jahe geprek, saus tiram, minyak wijen sampai ayam matang dengan api kecil. Beri garam, penyedap."
- "Ayam yg telah matang diangkat dan tiriskan."
- "Sisa air rebusan ayam dibagi 2 untuk sup dan memasak nasi"
- "Untuk sup, tambahkan potongan tomat, daun bawang dan daun sup, boleh tambahkan air jika dirasa sedikit, cicipi ulang"
- "Untuk nasi, tumis jahe, bawang putih dan kunyit yg sudah dicincang halus menggunakan minyak yg dihasilkan oleh kulit ayam"
- "Tuangkan tumisan beserta minyak ke beras yg telah dicuci bersih, berikan kuah rebusan ayam yg disisihkan tadi, aduk. Berikan garam dan penyedap, masak di magic com"
- "Untuk kecap ayam,  Tumis parutan jahe dan bawang putih sampai harum, tambahkan kecap asin, saus tiram dan kecap manis, tambahkan sedikit air dan sesuaikan rasa"
- "Untuk sambal. Rebus cabe beserta bawang putih dan jahe sebentar, lalu blender sampai semi halus. Tambahkan gula, garam, air panas dan perasan jeruk. Sesuaikan rasa"
- "Sajikan"
categories:
- Resep
tags:
- nasi
- ayam
- hainan

katakunci: nasi ayam hainan 
nutrition: 299 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT46M"
recipeyield: "1"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Ayam Hainan](https://img-global.cpcdn.com/recipes/b71a0a9220ad13e4/682x484cq65/nasi-ayam-hainan-foto-resep-utama.webp)

Resep rahasia Nasi Ayam Hainan    dengan 9 langkahcepat dan mudah cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Dalam Menyiapkan Nasi Ayam Hainan:

1. Rebusan ayam  sup 
1. ayam 1/2 ekor
1. bawang putih cukup di geprek 1 bonggol
1. jahe kupas kulit potong besar dan geprek 1 jempol
1. minyak wijen 3 sdm
1. saus tiram 1 sdm
1. tomat 2 bh
1. daun bawang potong kasar 1 batang
1. daun seledri potong kasar 2
1. Garam gula sedikit lada penyedap 
1. Nasi 
1. Beras secukupnya
1. Minyak ayam yg dibuat dari gorengan kulit dan lemak ayam 
1. Atau bisa minyak goreng biasa 
1. bawang putih cincang halus 4 siung
1. jahe cincang halus 1 ruas
1. kunyit cincang halus boleh skip 1 ruas
1. Air rebusan ayam 
1. Garam penyedap 
1. Kecap ayam 
1. jahe parut 1 ruas
1. bawang putih parut 3
1. Kecap asin 
1. Kecap manis 
1. Saus tiram 
1. Sambel ayam 
1. cabe merah 10 batang
1. cabe setan jika mau pedas 10 batang
1. Bawang putih 
1. Jahe 
1. jeruk sambal 2 buah



<!--inarticleads2-->

## Tata Cara Membuat Nasi Ayam Hainan:

1. Rebus ayam tanpa kulit bersama bawang putih dan jahe geprek, saus tiram, minyak wijen sampai ayam matang dengan api kecil. Beri garam, penyedap.
1. Ayam yg telah matang diangkat dan tiriskan.
1. Sisa air rebusan ayam dibagi 2 untuk sup dan memasak nasi
1. Untuk sup, tambahkan potongan tomat, daun bawang dan daun sup, boleh tambahkan air jika dirasa sedikit, cicipi ulang
1. Untuk nasi, tumis jahe, bawang putih dan kunyit yg sudah dicincang halus menggunakan minyak yg dihasilkan oleh kulit ayam
1. Tuangkan tumisan beserta minyak ke beras yg telah dicuci bersih, berikan kuah rebusan ayam yg disisihkan tadi, aduk. Berikan garam dan penyedap, masak di magic com
1. Untuk kecap ayam,  - Tumis parutan jahe dan bawang putih sampai harum, tambahkan kecap asin, saus tiram dan kecap manis, tambahkan sedikit air dan sesuaikan rasa
1. Untuk sambal. Rebus cabe beserta bawang putih dan jahe sebentar, lalu blender sampai semi halus. Tambahkan gula, garam, air panas dan perasan jeruk. Sesuaikan rasa
1. Sajikan




Selamat memasak dan menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
