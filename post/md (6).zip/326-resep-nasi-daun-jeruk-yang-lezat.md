---
description: "Resep Nasi Daun Jeruk yang Lezat"
title: "Resep Nasi Daun Jeruk yang Lezat"
slug: 326-resep-nasi-daun-jeruk-yang-lezat
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-16T22:28:00.483Z 
thumbnail: https://img-global.cpcdn.com/recipes/d8882f631267cf5c/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/d8882f631267cf5c/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/d8882f631267cf5c/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/d8882f631267cf5c/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
author: Marc Burton
ratingvalue: 4.2
reviewcount: 12
recipeingredient:
- "beras 1 cup"
- "daun jeruk iris halus 4 lbr"
- "bawang merah 3 btr"
- "daun salam 1 lbr"
- "serai 1 btg"
- "santak kental 3 sdm"
recipeinstructions:
- "Tumis bawang merah yg sudah diiris tipis, daun salam &amp; serai yg sudah digeprek sampai wangi"
- "Cuci beras, tambahkan bumbu yg sudah ditumis, aduk rata"
- "Tuang santan dan air takaran seperti masak nasi biasa"
- "Masak menggunakan ricecooker"
- "Setelah matang, beri irisan daun jeruk, aduk rata, panaskan kembali"
- "Setelah matang kedua diamkan dulu 5 menit baru siap dimakan"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 164 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT50M"
recipeyield: "4"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk](https://img-global.cpcdn.com/recipes/d8882f631267cf5c/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp)

Resep Nasi Daun Jeruk    dengan 6 langkahmudah dan cepat cocok banget jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Dalam Pembuatan Nasi Daun Jeruk:

1. beras 1 cup
1. daun jeruk iris halus 4 lbr
1. bawang merah 3 btr
1. daun salam 1 lbr
1. serai 1 btg
1. santak kental 3 sdm

Nasi daun jeruk siap dihidangkan dengan. Nasi daun jeruk ini memang sedang tren di kalangan masyarakat Indonesia, banyak sekali kaum muda mudi yang berlomba-lomba membuat makanan nasi putih spesial ini. Nasi daun jeruk ala geprek bensu rekomended buat di coba. Geprek bensu nasi daun jeruk anti mainst. 

<!--inarticleads2-->

## Langkah-langkah Untuk Menyiapkan Nasi Daun Jeruk:

1. Tumis bawang merah yg sudah diiris tipis, daun salam &amp; serai yg sudah digeprek sampai wangi
1. Cuci beras, tambahkan bumbu yg sudah ditumis, aduk rata
1. Tuang santan dan air takaran seperti masak nasi biasa
1. Masak menggunakan ricecooker
1. Setelah matang, beri irisan daun jeruk, aduk rata, panaskan kembali
1. Setelah matang kedua diamkan dulu 5 menit baru siap dimakan


Gurih dan wangi dari daun jeruk menambah kelezatan nasi daun jeruk. Nasi dengan campuran daun jeruk yang wangi sedang tren. Hai selamat pagi sahabat CWS, pagi ini saya share resep Nasi Daun Jeruk. Praktis banget karena saya gunakan rice cooker. Rasanya mirip nasi uduk tapi wangiiii. 

Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
