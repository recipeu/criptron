---
description: "Resep Nasi uduk betawi rice coooker, Enak"
title: "Resep Nasi uduk betawi rice coooker, Enak"
slug: 51-resep-nasi-uduk-betawi-rice-coooker-enak
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-17T03:59:52.113Z 
thumbnail: https://img-global.cpcdn.com/recipes/1fd6204958d12022/682x484cq65/nasi-uduk-betawi-rice-coooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/1fd6204958d12022/682x484cq65/nasi-uduk-betawi-rice-coooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/1fd6204958d12022/682x484cq65/nasi-uduk-betawi-rice-coooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/1fd6204958d12022/682x484cq65/nasi-uduk-betawi-rice-coooker-foto-resep-utama.webp
author: Kate Reeves
ratingvalue: 4.8
reviewcount: 13
recipeingredient:
- "Nasi uduk  "
- "beras 400 gram"
- "santan 600 ml"
- "daun salam 4 lembar"
- "serai geprek 2 Batang"
- "laos geprek 2 cm"
- "jahe geprek 2 cm"
- "garam Secukupnya"
- "Bawang merah goreng taburan "
- "Sambal kacang  "
- "Cabe merah keriting goreng 2 buah"
- "cabe rawit merah goreng 3 buah"
- "cabe rawit hijau goreng jika suka pedes bisa tambah jumlah cabenya 2 buah"
- "bawang putih goreng 2 siung"
- "kacang tanah goreng bisa di sesuaikan 150 gram"
- "cuka 1/4 sdm"
- "garam 1/2 sdm"
- "gula 1 sdm"
- "air hangat 100 ml"
recipeinstructions:
- "Cuci beras di air mengalir"
- "Setelah bersih masukan ke dalam rice cooker, tambahkan serai, daun salam, laos/lengkuas, jahe"
- "Tambahkan santan dan beri garam, aduk - aduk, tutup dan tekan tombol cook biarkan sampai jadi nasi"
- "Untuk sambal, giling/tumbuk kacang tanah goreng, bawang dan cabe sampai halus"
- "Pindahkan ke wadah tambah gula, garam, cuka, dan air. aduk dan cicipi"
- "Setelah nasi uduk matang sajikan dengan lauk dan sambal, dan taburi bawang merah goreng diatasnya, selamat mencoba"
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 217 calories
recipecuisine: Indonesian
preptime: "PT12M"
cooktime: "PT37M"
recipeyield: "1"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi uduk betawi rice coooker](https://img-global.cpcdn.com/recipes/1fd6204958d12022/682x484cq65/nasi-uduk-betawi-rice-coooker-foto-resep-utama.webp)

Resep rahasia dan cara memasak  Nasi uduk betawi rice coooker yang harus kamu coba dirumah

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Dalam Menyiapkan Nasi uduk betawi rice coooker:

1. Nasi uduk  
1. beras 400 gram
1. santan 600 ml
1. daun salam 4 lembar
1. serai geprek 2 Batang
1. laos geprek 2 cm
1. jahe geprek 2 cm
1. garam Secukupnya
1. Bawang merah goreng taburan 
1. Sambal kacang  
1. Cabe merah keriting goreng 2 buah
1. cabe rawit merah goreng 3 buah
1. cabe rawit hijau goreng jika suka pedes bisa tambah jumlah cabenya 2 buah
1. bawang putih goreng 2 siung
1. kacang tanah goreng bisa di sesuaikan 150 gram
1. cuka 1/4 sdm
1. garam 1/2 sdm
1. gula 1 sdm
1. air hangat 100 ml

Cara membuat nasi uduk betawi bisa menggunakan rice cooker. Jadi, masakan ini cocok untuk pemula. Make this easy and aromatic Betawi-style nasi uduk that goes with many main and side dishes. I&#39;m sharing how you can make it easily with a rice My favorite way of cooking nasi uduk is with a rice cooker or Instant Pot. 

<!--inarticleads2-->

## Cara Membuat Nasi uduk betawi rice coooker:

1. Cuci beras di air mengalir
1. Setelah bersih masukan ke dalam rice cooker, tambahkan serai, daun salam, laos/lengkuas, jahe
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/e4328f23b42453ee/160x128cq70/nasi-uduk-betawi-rice-coooker-langkah-memasak-2-foto.webp" alt="Nasi uduk betawi rice coooker" width="340" height="340">
><img class="lazyload" data-src="https://img-global.cpcdn.com/steps/8d53f39b57110413/160x128cq70/nasi-uduk-betawi-rice-coooker-langkah-memasak-2-foto.webp" alt="Nasi uduk betawi rice coooker" width="340" height="340">
><img class="lazyload" data-src="https://img-global.cpcdn.com/steps/38eb855bf8cea9ff/160x128cq70/nasi-uduk-betawi-rice-coooker-langkah-memasak-2-foto.webp" alt="Nasi uduk betawi rice coooker" width="340" height="340">
>1. Tambahkan santan dan beri garam, aduk - aduk, tutup dan tekan tombol cook biarkan sampai jadi nasi
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/f4ccd9803f08b9c5/160x128cq70/nasi-uduk-betawi-rice-coooker-langkah-memasak-3-foto.webp" alt="Nasi uduk betawi rice coooker" width="340" height="340">
>1. Untuk sambal, giling/tumbuk kacang tanah goreng, bawang dan cabe sampai halus
1. Pindahkan ke wadah tambah gula, garam, cuka, dan air. aduk dan cicipi
1. Setelah nasi uduk matang sajikan dengan lauk dan sambal, dan taburi bawang merah goreng diatasnya, selamat mencoba


It&#39;s a no brainer because I just need to put everything in there without having to. Nah itu dia sobat nasi uduk betawi rice cookernya, resep, cara buat dan tipsnya sudah dikasih tau. Sekarang tinggal dilihat video tutorialnya dibawah ini biar lebih gamblang. Cara Membuat Nasi Uduk Rice Cooker. Tuangkan santan kedalam rice cooker lalu susul dengan memasukkan beras, aduk menggunakan centong Cara Membuat Nasi Uduk Betawi. 

Daripada   beli  Nasi uduk betawi rice coooker  diluar terus, ibu  bisa membuatnya sendiri dirumah. Resep  Nasi uduk betawi rice coooker  sederhana ini cukup praktis pembuatannya, serta cukup menggunakan bumbu-bumbu sederhana yang ada di dapur  Nasi uduk betawi rice coooker  yang enak, ibu nikmati di rumah.
