---
description: "Bagaimana Menyiapkan Nasi Daun Jeruk Tanpa Santan, Lezat"
title: "Bagaimana Menyiapkan Nasi Daun Jeruk Tanpa Santan, Lezat"
slug: 322-bagaimana-menyiapkan-nasi-daun-jeruk-tanpa-santan-lezat
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-30T07:53:48.271Z 
thumbnail: https://img-global.cpcdn.com/recipes/7b112550153147a1/682x484cq65/nasi-daun-jeruk-tanpa-santan-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/7b112550153147a1/682x484cq65/nasi-daun-jeruk-tanpa-santan-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/7b112550153147a1/682x484cq65/nasi-daun-jeruk-tanpa-santan-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/7b112550153147a1/682x484cq65/nasi-daun-jeruk-tanpa-santan-foto-resep-utama.webp
author: Maria Andrews
ratingvalue: 3
reviewcount: 9
recipeingredient:
- "beras pulen 2 cup"
- "daun jeruk iris 5 lembar"
- "daun salam 2 lembar"
- "serei 1 batang"
- "bawang putih 2 siung"
- "bawang merah 2 siung"
- "garam 1/2 sdt"
- "royko sapi 1/2 sdt"
- "minyak goreng 1 sdm"
recipeinstructions:
- "Cuci beras, tambahkan air hingga satu ruas jari tingginya."
- "Ulek bawang merah dan bawang putih, masukkan bersama irisan daun jeruk, daun salam, serei, garam, dan royko. Lalu tambahkan minyak goreng."
- "Tutup magic com dan masak hingga matang. Nasi daun jeruk enak dinikmati selagi hangat."
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 122 calories
recipecuisine: Indonesian
preptime: "PT19M"
cooktime: "PT35M"
recipeyield: "1"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk Tanpa Santan](https://img-global.cpcdn.com/recipes/7b112550153147a1/682x484cq65/nasi-daun-jeruk-tanpa-santan-foto-resep-utama.webp)

Resep Nasi Daun Jeruk Tanpa Santan    dengan 3 langkahmudah cocok sekali jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Untuk Pembuatan Nasi Daun Jeruk Tanpa Santan:

1. beras pulen 2 cup
1. daun jeruk iris 5 lembar
1. daun salam 2 lembar
1. serei 1 batang
1. bawang putih 2 siung
1. bawang merah 2 siung
1. garam 1/2 sdt
1. royko sapi 1/2 sdt
1. minyak goreng 1 sdm



<!--inarticleads2-->

## Cara Membuat Nasi Daun Jeruk Tanpa Santan:

1. Cuci beras, tambahkan air hingga satu ruas jari tingginya.
1. Ulek bawang merah dan bawang putih, masukkan bersama irisan daun jeruk, daun salam, serei, garam, dan royko. Lalu tambahkan minyak goreng.
1. Tutup magic com dan masak hingga matang. Nasi daun jeruk enak dinikmati selagi hangat.




Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
