---
description: "Resep Nasi Daun Jeruk Magicom, Sempurna"
title: "Resep Nasi Daun Jeruk Magicom, Sempurna"
slug: 238-resep-nasi-daun-jeruk-magicom-sempurna
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-23T15:57:05.636Z 
thumbnail: https://img-global.cpcdn.com/recipes/9849b6b6bdc83b2f/682x484cq65/nasi-daun-jeruk-magicom-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/9849b6b6bdc83b2f/682x484cq65/nasi-daun-jeruk-magicom-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/9849b6b6bdc83b2f/682x484cq65/nasi-daun-jeruk-magicom-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/9849b6b6bdc83b2f/682x484cq65/nasi-daun-jeruk-magicom-foto-resep-utama.webp
author: Jim Guerrero
ratingvalue: 3.7
reviewcount: 7
recipeingredient:
- "beras 3 cup"
- "bawang putih besar 3 bh"
- "daun jeruk 10 lembar"
- "serai 2 bh"
- "daun salam 5 lmbr"
- "garam 1 sdt"
- "minyak kelapaminyak sayur 1 sdt"
recipeinstructions:
- "Cuci beras lalu tambahkan air seperti memasak biasa, tambahkan garam dan aduk rata."
- "Siapkan bahan-bahan lain. Geprek bawang &amp; cincang halus. Buang tulang daun jeruk dan iris tipis. Geprek serai."
- "Tumis bawang putih. Masukkan bumbu lainnya. Sreng sreng sampai harum lalu masukkan ke dalam magicom. Masak seperti biasa."
- "Nasi matang, aduk agar rata &amp; siap dinikmati."
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 119 calories
recipecuisine: Indonesian
preptime: "PT12M"
cooktime: "PT55M"
recipeyield: "2"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk Magicom](https://img-global.cpcdn.com/recipes/9849b6b6bdc83b2f/682x484cq65/nasi-daun-jeruk-magicom-foto-resep-utama.webp)

Resep Nasi Daun Jeruk Magicom    dengan 4 langkahmudah dan cepat cocok sekali jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Untuk Pembuatan Nasi Daun Jeruk Magicom:

1. beras 3 cup
1. bawang putih besar 3 bh
1. daun jeruk 10 lembar
1. serai 2 bh
1. daun salam 5 lmbr
1. garam 1 sdt
1. minyak kelapaminyak sayur 1 sdt



<!--inarticleads2-->

## Langkah-langkah Untuk Menyiapkan Nasi Daun Jeruk Magicom:

1. Cuci beras lalu tambahkan air seperti memasak biasa, tambahkan garam dan aduk rata.
1. Siapkan bahan-bahan lain. Geprek bawang &amp; cincang halus. Buang tulang daun jeruk dan iris tipis. Geprek serai.
1. Tumis bawang putih. Masukkan bumbu lainnya. Sreng sreng sampai harum lalu masukkan ke dalam magicom. Masak seperti biasa.
1. Nasi matang, aduk agar rata &amp; siap dinikmati.




Terima kasih telah membaca resep yang kami tampilkan di sini. Selamat mencoba!
