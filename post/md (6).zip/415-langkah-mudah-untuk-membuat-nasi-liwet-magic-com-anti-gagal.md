---
description: "Langkah Mudah untuk Membuat Nasi Liwet Magic Com ✨ Anti Gagal"
title: "Langkah Mudah untuk Membuat Nasi Liwet Magic Com ✨ Anti Gagal"
slug: 415-langkah-mudah-untuk-membuat-nasi-liwet-magic-com-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-09T01:19:12.750Z 
thumbnail: https://img-global.cpcdn.com/recipes/ea339a05cd1bff61/682x484cq65/nasi-liwet-magic-com-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/ea339a05cd1bff61/682x484cq65/nasi-liwet-magic-com-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/ea339a05cd1bff61/682x484cq65/nasi-liwet-magic-com-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/ea339a05cd1bff61/682x484cq65/nasi-liwet-magic-com-foto-resep-utama.webp
author: Jennie Parks
ratingvalue: 3.6
reviewcount: 9
recipeingredient:
- "Beras  450 gram beras 3 Cup"
- "santan 65 ml"
- "teri medan 50 gram"
- "sereh geprek 2 batang"
- "daun salam 3 lembar"
- "daun jeruk 3 lembar"
- "Di iris untuk di tumis "
- "bawang merah 8 buah"
- "bawang putih 6 buah"
- "Cabe setan atau sesuai selera 3-5 buah"
- "Garam secukupnya"
- "Penyedap rasa totole jamur "
recipeinstructions:
- "Iris bawang putih bawang merah cabe lalu tumis"
- "Teri medan di rendem pakai air panas sebentar lalu goreng —&gt; pisahkan"
- "Siapkan beras yg sudah dicuci lalu campurkan bahan2 yg sudah ditumis"
- "Masukkan teri medan 1/2 saja lalu aduk"
- "Masukin santan lalu aduk, tambahkan garam dan totole jAmur. tambahkan air secukupnya seperti masak nasi biasa"
- "Setelah matang taburkan 1/2 teri medan td.. jadi deh 😘"
categories:
- Resep
tags:
- nasi
- liwet
- magic

katakunci: nasi liwet magic 
nutrition: 160 calories
recipecuisine: Indonesian
preptime: "PT16M"
cooktime: "PT32M"
recipeyield: "4"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Liwet Magic Com ✨](https://img-global.cpcdn.com/recipes/ea339a05cd1bff61/682x484cq65/nasi-liwet-magic-com-foto-resep-utama.webp)

6 langkah mudah dan cepat membuat  Nasi Liwet Magic Com ✨ cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Dalam Menyiapkan Nasi Liwet Magic Com ✨:

1. Beras  450 gram beras 3 Cup
1. santan 65 ml
1. teri medan 50 gram
1. sereh geprek 2 batang
1. daun salam 3 lembar
1. daun jeruk 3 lembar
1. Di iris untuk di tumis 
1. bawang merah 8 buah
1. bawang putih 6 buah
1. Cabe setan atau sesuai selera 3-5 buah
1. Garam secukupnya
1. Penyedap rasa totole jamur 



<!--inarticleads2-->

## Tata Cara Menyiapkan Nasi Liwet Magic Com ✨:

1. Iris bawang putih bawang merah cabe lalu tumis
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/2099c12a2bf77837/160x128cq70/nasi-liwet-magic-com-langkah-memasak-1-foto.webp" alt="Nasi Liwet Magic Com ✨" width="340" height="340">
><img class="lazyload" data-src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Nasi Liwet Magic Com ✨" width="340" height="340">
><img class="lazyload" data-src="https://img-global.cpcdn.com/steps/f1d908b481e27ff5/160x128cq70/nasi-liwet-magic-com-langkah-memasak-1-foto.webp" alt="Nasi Liwet Magic Com ✨" width="340" height="340">
>1. Teri medan di rendem pakai air panas sebentar lalu goreng —&gt; pisahkan
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/3ca4287f3cb5851e/160x128cq70/nasi-liwet-magic-com-langkah-memasak-2-foto.webp" alt="Nasi Liwet Magic Com ✨" width="340" height="340">
>1. Siapkan beras yg sudah dicuci lalu campurkan bahan2 yg sudah ditumis
<img class="lazyload" data-src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Nasi Liwet Magic Com ✨" width="340" height="340">
><img class="lazyload" data-src="https://img-global.cpcdn.com/steps/523882ed35416c68/160x128cq70/nasi-liwet-magic-com-langkah-memasak-3-foto.webp" alt="Nasi Liwet Magic Com ✨" width="340" height="340">
>1. Masukkan teri medan 1/2 saja lalu aduk
<img class="lazyload" data-src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Nasi Liwet Magic Com ✨" width="340" height="340">
>1. Masukin santan lalu aduk, tambahkan garam dan totole jAmur. tambahkan air secukupnya seperti masak nasi biasa
1. Setelah matang taburkan 1/2 teri medan td.. jadi deh 😘
<img class="lazyload" data-src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Nasi Liwet Magic Com ✨" width="340" height="340">
>



Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
