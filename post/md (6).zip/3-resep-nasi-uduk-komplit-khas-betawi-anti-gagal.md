---
description: "Resep Nasi Uduk Komplit khas Betawi Anti Gagal"
title: "Resep Nasi Uduk Komplit khas Betawi Anti Gagal"
slug: 3-resep-nasi-uduk-komplit-khas-betawi-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2022-01-04T19:18:14.673Z 
thumbnail: https://img-global.cpcdn.com/recipes/93e9274564c8b08f/682x484cq65/nasi-uduk-komplit-khas-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/93e9274564c8b08f/682x484cq65/nasi-uduk-komplit-khas-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/93e9274564c8b08f/682x484cq65/nasi-uduk-komplit-khas-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/93e9274564c8b08f/682x484cq65/nasi-uduk-komplit-khas-betawi-foto-resep-utama.webp
author: Stanley Ortiz
ratingvalue: 3.8
reviewcount: 14
recipeingredient:
- "Bahan nasi uduk  "
- "beras cup magic com cuci bersih 11"
- "santan dari 1 butir besar kelapa parut 1,9 liter"
- "garam himsalt 1.5 sdt"
- "besar serai potong 3 lalu geprek 1 batang"
- "daun salam 4 lembar"
- "jahe geprek 2 cm"
- "lengkuas geprek 2 ruas jari"
- "Bahan sambal telur  "
- "telur rebus kupas 20 butir"
- "cabe merah keriting haluskan 200 gr"
- "bawang merah haluskan 10 butir"
- "bawang putih haluskan 8 siung"
- "tomat merah besar haluskan 1 buah"
- "garam 1 sdt"
- "kaldu bubuk 1 sdt"
- "gula pasirsecukupnya 1 sdm"
- "minyak goreng untuk menumis 50 ml"
- "Bahan semur tahu  "
- "tahu potong 2 segitiga 12 buah"
- "bawang merah haluskan 5 butir"
- "bawang putih haluskan 5 siung"
- "pala haluskan Seujung jari"
- "jawa 2 mata asam"
- "serai geprek 1 batang"
- "daun salam 2 lembar"
- "garam 1 sdt"
- "kaldu bubuk 1/2 sdt"
- "gula pasir 1/2 sdm"
- "kecap manis 5 sdm"
- "air 350 ml"
- "minyak untuk menumis 3 sdm"
- "Bahan bihun goreng  "
- "gr1 bungkus bihun rendam air panas hingga empuk  tiriskan 130"
- "bawang merah iris 3 butir besar"
- "bawang putih iris 3 siung besar"
- "daun bawang iris 2 batang"
- "daun seledri iris 2 batang"
- "garam 1/2 sdt"
- "kaldu bubuk 1/2 sdt"
- "kaldu udang bubuk bisa diganti udang rebon           lihat resep 1 sdm"
- "merica bubuk 1/4 sdt"
- "kecap manis 3 sdm"
- "minyak goreng untuk menumis 3 sdm"
- "Pelengkap lainnya  "
- "Bawang goreng "
- "timun Irisan"
- "Kerupuk "
recipeinstructions:
- "NASI UDUK :  campur semua bahan nasi, aduk rata. Masak dengan magic com hingga matang dan tanak lalu aduk rata sambil dibuang serai dan daun salamnya. Taburi bawang goreng. Nasi uduk siap disajikan"
- "SAMBAL TELUR REBUS :  tumis bumbu halus (bawang merah putih, cabe dan tomat), garam, kaldu bubuk &amp; gula pasir hingga harum dan setengah tanak. Kecilkan api lalu masukkan telur rebus. Masak lagi hingga tanak/berminyak sambil sesekali diaduk. Koreksi rasa dan sambal telur siap disajikan"
- "SEMUR TAHU : Tumis bumbu halus (bawang merah putih, pala), asam jawa, serai dan daun salam hingga harum. Tuang air dan kecap. Beri garam, kaldu bubuk &amp; gula pasir. Biarkan mendidih"
- "Masukkan tahu. Masak hingga bumbu meresap dan kuah menyusut. Koreksi rasa, angkat dan siap disajikan"
- "BIHUN GORENG : Campur rata bihun, kecap, garam, kaldu bubuk dan merica bubuk. Tumis bawang merah putih dan kaldu udang bubuk hingga harum. Masukkan campuran bihun, aduk rata"
- "Tambahkan daun bawang dan seledri. Masak lagi sebentar hingga bihun matang (panas). Angkat dan sajikan"
- "Sajikan nasi uduk bersama menu pendamping dan pelengkapnya"
categories:
- Resep
tags:
- nasi
- uduk
- komplit

katakunci: nasi uduk komplit 
nutrition: 248 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT58M"
recipeyield: "4"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Komplit khas Betawi](https://img-global.cpcdn.com/recipes/93e9274564c8b08f/682x484cq65/nasi-uduk-komplit-khas-betawi-foto-resep-utama.webp)

Resep rahasia Nasi Uduk Komplit khas Betawi  sederhana dengan 7 langkahcepat cocok sekali jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Untuk Pembuatan Nasi Uduk Komplit khas Betawi:

1. Bahan nasi uduk  
1. beras cup magic com cuci bersih 11
1. santan dari 1 butir besar kelapa parut 1,9 liter
1. garam himsalt 1.5 sdt
1. besar serai potong 3 lalu geprek 1 batang
1. daun salam 4 lembar
1. jahe geprek 2 cm
1. lengkuas geprek 2 ruas jari
1. Bahan sambal telur  
1. telur rebus kupas 20 butir
1. cabe merah keriting haluskan 200 gr
1. bawang merah haluskan 10 butir
1. bawang putih haluskan 8 siung
1. tomat merah besar haluskan 1 buah
1. garam 1 sdt
1. kaldu bubuk 1 sdt
1. gula pasirsecukupnya 1 sdm
1. minyak goreng untuk menumis 50 ml
1. Bahan semur tahu  
1. tahu potong 2 segitiga 12 buah
1. bawang merah haluskan 5 butir
1. bawang putih haluskan 5 siung
1. pala haluskan Seujung jari
1. jawa 2 mata asam
1. serai geprek 1 batang
1. daun salam 2 lembar
1. garam 1 sdt
1. kaldu bubuk 1/2 sdt
1. gula pasir 1/2 sdm
1. kecap manis 5 sdm
1. air 350 ml
1. minyak untuk menumis 3 sdm
1. Bahan bihun goreng  
1. gr1 bungkus bihun rendam air panas hingga empuk  tiriskan 130
1. bawang merah iris 3 butir besar
1. bawang putih iris 3 siung besar
1. daun bawang iris 2 batang
1. daun seledri iris 2 batang
1. garam 1/2 sdt
1. kaldu bubuk 1/2 sdt
1. kaldu udang bubuk bisa diganti udang rebon           lihat resep 1 sdm
1. merica bubuk 1/4 sdt
1. kecap manis 3 sdm
1. minyak goreng untuk menumis 3 sdm
1. Pelengkap lainnya  
1. Bawang goreng 
1. timun Irisan
1. Kerupuk 



<!--inarticleads2-->

## Cara Membuat Nasi Uduk Komplit khas Betawi:

1. NASI UDUK :  - campur semua bahan nasi, aduk rata. Masak dengan magic com hingga matang dan tanak lalu aduk rata sambil dibuang serai dan daun salamnya. Taburi bawang goreng. Nasi uduk siap disajikan
1. SAMBAL TELUR REBUS :  - tumis bumbu halus (bawang merah putih, cabe dan tomat), garam, kaldu bubuk &amp; gula pasir hingga harum dan setengah tanak. Kecilkan api lalu masukkan telur rebus. Masak lagi hingga tanak/berminyak sambil sesekali diaduk. Koreksi rasa dan sambal telur siap disajikan
1. SEMUR TAHU : - Tumis bumbu halus (bawang merah putih, pala), asam jawa, serai dan daun salam hingga harum. Tuang air dan kecap. Beri garam, kaldu bubuk &amp; gula pasir. Biarkan mendidih
1. Masukkan tahu. Masak hingga bumbu meresap dan kuah menyusut. Koreksi rasa, angkat dan siap disajikan
1. BIHUN GORENG : - Campur rata bihun, kecap, garam, kaldu bubuk dan merica bubuk. Tumis bawang merah putih dan kaldu udang bubuk hingga harum. Masukkan campuran bihun, aduk rata
1. Tambahkan daun bawang dan seledri. Masak lagi sebentar hingga bihun matang (panas). Angkat dan sajikan
1. Sajikan nasi uduk bersama menu pendamping dan pelengkapnya




Selamat memasak dan menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
