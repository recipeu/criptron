---
description: "Bagaimana Membuat NASI UDUK DAUN JERUK PEDAS (RICE COOKER) Anti Gagal"
title: "Bagaimana Membuat NASI UDUK DAUN JERUK PEDAS (RICE COOKER) Anti Gagal"
slug: 344-bagaimana-membuat-nasi-uduk-daun-jeruk-pedas-rice-cooker-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2022-01-01T04:04:11.707Z 
thumbnail: https://img-global.cpcdn.com/recipes/25cc77cdbb028ccb/682x484cq65/nasi-uduk-daun-jeruk-pedas-rice-cooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/25cc77cdbb028ccb/682x484cq65/nasi-uduk-daun-jeruk-pedas-rice-cooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/25cc77cdbb028ccb/682x484cq65/nasi-uduk-daun-jeruk-pedas-rice-cooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/25cc77cdbb028ccb/682x484cq65/nasi-uduk-daun-jeruk-pedas-rice-cooker-foto-resep-utama.webp
author: Duane Rodriquez
ratingvalue: 5
reviewcount: 4
recipeingredient:
- "beras putih pulen aku biasanya pake merk petruk 300 gram"
- "Santan secukupnya"
- "dihaluskan "
- "bawang putih 4 siung"
- "bawang merah 3 siung"
- "kemiri 3 butir"
- "ketumbar "
- "Bumbu "
- "Penyedap rasa merk halawa 1 bks"
- "garam "
- "gula pasir "
- "bubuk lada "
- "daun sirih geprek 2 batang"
- "daun salam 5 lembar"
- "Diiris "
- "cabe rawit merah 5 butir"
- "cabe rawit hijau 2 butir"
- "daun jeruk 5 lembar"
recipeinstructions:
- "Cuci bersih beras, tiriskan"
- "Haluskan bawang merah, bawang putih, ketumbar dan kemiri (aku pake blender biar halus banget)"
- "Tumis bumbu2 yang sudah dihaluskan, masukkan santan yang sudah di campur air"
- "Masukkan daun salam, sereh, irisan cabe, irisan daun jeruk"
- "Masukan bumbu bumbu lalu koreksi rasanya, godok hingga mendidih"
- "Masukkan air rebusan tersebut ke dalam rice cooker, lalu masak nasi uduk tersebut dalam rice cokker. tunggu hingga matang sempurna"
- "Nasi uduk bisa dihidangkan dengan lauk yang anda suka 😍"
categories:
- Resep
tags:
- nasi
- uduk
- daun

katakunci: nasi uduk daun 
nutrition: 194 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT41M"
recipeyield: "2"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![NASI UDUK DAUN JERUK PEDAS (RICE COOKER)](https://img-global.cpcdn.com/recipes/25cc77cdbb028ccb/682x484cq65/nasi-uduk-daun-jeruk-pedas-rice-cooker-foto-resep-utama.webp)

7 langkah cepat mengolah  NASI UDUK DAUN JERUK PEDAS (RICE COOKER) cocok sekali jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Untuk Menyiapkan NASI UDUK DAUN JERUK PEDAS (RICE COOKER):

1. beras putih pulen aku biasanya pake merk petruk 300 gram
1. Santan secukupnya
1. dihaluskan 
1. bawang putih 4 siung
1. bawang merah 3 siung
1. kemiri 3 butir
1. ketumbar 
1. Bumbu 
1. Penyedap rasa merk halawa 1 bks
1. garam 
1. gula pasir 
1. bubuk lada 
1. daun sirih geprek 2 batang
1. daun salam 5 lembar
1. Diiris 
1. cabe rawit merah 5 butir
1. cabe rawit hijau 2 butir
1. daun jeruk 5 lembar

Nasi Uduk is more of Jakarta-style coconut rice cooked in spices and herbs. My favorite way of cooking nasi uduk is with a rice cooker or Instant Pot. It&#39;s a no brainer because I just need to put everything in there without having to attend to it. The rice in nasi uduk is cooked in coconut milk together with lemongrass, cloves, pandan leaves, and cinnamon. 

<!--inarticleads2-->

## Cara Mudah Menyiapkan NASI UDUK DAUN JERUK PEDAS (RICE COOKER):

1. Cuci bersih beras, tiriskan
1. Haluskan bawang merah, bawang putih, ketumbar dan kemiri (aku pake blender biar halus banget)
1. Tumis bumbu2 yang sudah dihaluskan, masukkan santan yang sudah di campur air
1. Masukkan daun salam, sereh, irisan cabe, irisan daun jeruk
1. Masukan bumbu bumbu lalu koreksi rasanya, godok hingga mendidih
1. Masukkan air rebusan tersebut ke dalam rice cooker, lalu masak nasi uduk tersebut dalam rice cokker. tunggu hingga matang sempurna
1. Nasi uduk bisa dihidangkan dengan lauk yang anda suka 😍


The process results in wonderfully fluffy, fragrant rice, and right before it is served, each portion is usually topped with fried shallots. It is a dish rarely eaten on its own, but rather served with a. Masak nasi uduk dengan rice cooker: Siapkan pan rice cooker. Cuci beras dan tuang ke dalam pan rice cooker. Tambahkan dengan serai, lengkuas, daun salam, cengkih, daun jeruk, biji pala daun pandan, garam, dan santan. 

Salah satu masakan yang cukup praktis pembuatannya adalah  NASI UDUK DAUN JERUK PEDAS (RICE COOKER). Selain itu  NASI UDUK DAUN JERUK PEDAS (RICE COOKER)  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu lakukan 7 langkah, dan  NASI UDUK DAUN JERUK PEDAS (RICE COOKER)  pun siap di hidangkan. selamat mencoba !
