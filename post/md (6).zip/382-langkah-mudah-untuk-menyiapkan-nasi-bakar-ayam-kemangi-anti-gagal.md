---
description: "Langkah Mudah untuk Menyiapkan Nasi bakar ayam kemangi Anti Gagal"
title: "Langkah Mudah untuk Menyiapkan Nasi bakar ayam kemangi Anti Gagal"
slug: 382-langkah-mudah-untuk-menyiapkan-nasi-bakar-ayam-kemangi-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-09T19:26:01.654Z 
thumbnail: https://img-global.cpcdn.com/recipes/e2763a38c609e810/682x484cq65/nasi-bakar-ayam-kemangi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/e2763a38c609e810/682x484cq65/nasi-bakar-ayam-kemangi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/e2763a38c609e810/682x484cq65/nasi-bakar-ayam-kemangi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/e2763a38c609e810/682x484cq65/nasi-bakar-ayam-kemangi-foto-resep-utama.webp
author: Ethan Cunningham
ratingvalue: 4.6
reviewcount: 7
recipeingredient:
- "ekor ayam 1/2 kg"
- "Beras 3 gelas belimbing dibkin nasi gurih dgn magicom "
- "kemangi segar 5 ikat"
- "Daun pisang "
- "Bumbu2 "
- "bawang merah 10 siung"
- "bawang putih 3 siung"
- "cabe keriting 10"
- "jahe lengkuas dan kunyit 1 ruas"
- "daun salam 1"
- "kemiri 3"
- "garam kaldu jamur gula pasir 1/4 sdt"
recipeinstructions:
- "Potong ayam mnjadi 2 bagian cuci bersih dan rebus sampai matang. Tiriskan, tunggu dingin dan suwir2"
- "Siapkan bumbu yg akan dihaluskan (kecuali daun salam dan lengkuas) Blender/uleg semua bumbu halus."
- "Oseng/gongso bumbu halus di wajan tmbahkan daun salam dan lengkuas geprek. Jika air sudah menyusut, masukkan ayam suwir, aduk rata, tambahkan air sedikit tunggu sampai mendidih. Setelah itu beri garam, gula pasir dan kaldu jamur. Cek rasa"
- "Setelah di rasa sudah cukup, masukkan daun kemangi dan masak sampai daun kemangi setengah layu."
- "Jika sudah di bungkus dengan daun pisang, kukus terlebih dahulu dan siap untuk di bakar (dibakar sbntar saja)."
- "Setelah dibakar"
categories:
- Resep
tags:
- nasi
- bakar
- ayam

katakunci: nasi bakar ayam 
nutrition: 139 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT33M"
recipeyield: "4"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi bakar ayam kemangi](https://img-global.cpcdn.com/recipes/e2763a38c609e810/682x484cq65/nasi-bakar-ayam-kemangi-foto-resep-utama.webp)

Ingin membuat Nasi bakar ayam kemangi ? Coba resep berikut ini. Cara memasaknya sangat praktis namun jangan kaget jika hasilnya gurih dan lezat yang musti ibu coba segera

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Dalam Pembuatan Nasi bakar ayam kemangi:

1. ekor ayam 1/2 kg
1. Beras 3 gelas belimbing dibkin nasi gurih dgn magicom 
1. kemangi segar 5 ikat
1. Daun pisang 
1. Bumbu2 
1. bawang merah 10 siung
1. bawang putih 3 siung
1. cabe keriting 10
1. jahe lengkuas dan kunyit 1 ruas
1. daun salam 1
1. kemiri 3
1. garam kaldu jamur gula pasir 1/4 sdt

Resep dan cara memasak nasi bakar. Nasi Bakar Ayam Suwir Kemangi. beras•Santan•daun pandan•daun serai•garam•Isian nasi bakarnya di resep sebelumnya•daun kemangi. Kemudian tata daun pisang, nasi liwet serta tambahkan kemangi kemudian tambahkan suwiran ayam, tembahkan lagi kemangi di atas ayam dan dapat pula tambahkan irisan cabe rawit apabila anda menyukai pedas, setelah itu bakar di atas grill pan, bolak - balik hingga matang, angkat dan hidangkan. Biasa ditemukan di Pulau Jawa, nasi bakar berisi beragam protein. 

<!--inarticleads2-->

## Tata Cara Membuat Nasi bakar ayam kemangi:

1. Potong ayam mnjadi 2 bagian cuci bersih dan rebus sampai matang. Tiriskan, tunggu dingin dan suwir2
1. Siapkan bumbu yg akan dihaluskan (kecuali daun salam dan lengkuas) - Blender/uleg semua bumbu halus.
1. Oseng/gongso bumbu halus di wajan tmbahkan daun salam dan lengkuas geprek. Jika air sudah menyusut, masukkan ayam suwir, aduk rata, tambahkan air sedikit tunggu sampai mendidih. Setelah itu beri garam, gula pasir dan kaldu jamur. Cek rasa
1. Setelah di rasa sudah cukup, masukkan daun kemangi dan masak sampai daun kemangi setengah layu.
1. Jika sudah di bungkus dengan daun pisang, kukus terlebih dahulu dan siap untuk di bakar (dibakar sbntar saja).
1. Setelah dibakar


Salah satu yang paling disukai adalah daging ayam dengan sentuhan daun kemangi. Bisa untuk ide menu makan siang bersama keluarga, berikut resep membuat nasi bakar ayam kemangi yang enak dan mudah. Nasi bakar ayam kemangi adalah salah satu inovasi masakan Nusantara yang sangat terkenal di seluruh Indonesia terutama di pulau Jawa. Aroma harum muncul dari daun kemangi yang ada dan dipadukan dengan daging ayam, sungguh menambah nikmatnya nasi goreng bakar kemangi ini. There are so many versions of nasi bakar out there and honestly, there aren&#39;t really any right or wrong recipes if you ask me. 

Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
