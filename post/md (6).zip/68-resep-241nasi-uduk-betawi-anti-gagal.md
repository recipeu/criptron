---
description: "Resep 241.Nasi uduk betawi Anti Gagal"
title: "Resep 241.Nasi uduk betawi Anti Gagal"
slug: 68-resep-241nasi-uduk-betawi-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-21T06:43:40.602Z 
thumbnail: https://img-global.cpcdn.com/recipes/f313b2abfaf44160/682x484cq65/241nasi-uduk-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/f313b2abfaf44160/682x484cq65/241nasi-uduk-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/f313b2abfaf44160/682x484cq65/241nasi-uduk-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/f313b2abfaf44160/682x484cq65/241nasi-uduk-betawi-foto-resep-utama.webp
author: Myrtle Collins
ratingvalue: 4.6
reviewcount: 10
recipeingredient:
- "beras 4 cup"
- "santan 65 ml 1 bungkus"
- "Daun pandan 1 lembar"
- "Serai dgeprek 1 batang"
- "Daun salam 2 lembar"
- "Garam secukupnya"
- "Air secukupnya"
- "Bumbu halus "
- "Bawang merah "
- "Bawang putih "
- "jahe 3 ruas"
- "jahe 2 ruas"
- "Pelengkap "
- "Ayam bumbu kecap "
- "Bihun goreng "
- "Kering tempe "
- "Serundeng "
recipeinstructions:
- "Siapkan bahan2,haluskan bumbu halus lalu tumis hingga harum."
- "Cuci bersih beras,siiapkan wajan atau teflon,masukan beras beri air,santan,sereh,daun pandan,daun salam,tumisan bumbu halus lalu tambahkan garam,aduk rata dengan api sedang sampai air menyusut,tes rasa..matikan kompor"
- "Siapkan kukusan yg sdh dpanaskan,masukan nasi aron,kukus selama 25 menit.Angkat"
- "Sajikan nasi uduk dengan lauk pelengkap sesuai selera."
- "Selamat mencoba"
categories:
- Resep
tags:
- 241nasi
- uduk
- betawi

katakunci: 241nasi uduk betawi 
nutrition: 249 calories
recipecuisine: Indonesian
preptime: "PT36M"
cooktime: "PT57M"
recipeyield: "3"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![241.Nasi uduk betawi](https://img-global.cpcdn.com/recipes/f313b2abfaf44160/682x484cq65/241nasi-uduk-betawi-foto-resep-utama.webp)

5 langkah cepat dan mudah mengolah  241.Nasi uduk betawi yang harus kamu coba segera

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Untuk Pembuatan 241.Nasi uduk betawi:

1. beras 4 cup
1. santan 65 ml 1 bungkus
1. Daun pandan 1 lembar
1. Serai dgeprek 1 batang
1. Daun salam 2 lembar
1. Garam secukupnya
1. Air secukupnya
1. Bumbu halus 
1. Bawang merah 
1. Bawang putih 
1. jahe 3 ruas
1. jahe 2 ruas
1. Pelengkap 
1. Ayam bumbu kecap 
1. Bihun goreng 
1. Kering tempe 
1. Serundeng 

Paling terkenal nasi uduk kebun kacang di wilayah kami. Ditambah ayam goreng atau lele goreng dengan sayuran lalapan membuat rasa nasi uduk menjadi bintang lima dengan harga kaki lima. Nasi Uduk Betawi hadir dengan inovasi terbaru paket menu Ungkepan. Menyediakan nasi uduk asli jakarta lengkap dengan lauk andalan AYAM BEBEK REMEK; kreasi olahan Ayam dan Bebek yg menonjolkan kelembutan dan dagingnya yg empuk. 

<!--inarticleads2-->

## Tata Cara Menyiapkan 241.Nasi uduk betawi:

1. Siapkan bahan2,haluskan bumbu halus lalu tumis hingga harum.
1. Cuci bersih beras,siiapkan wajan atau teflon,masukan beras beri air,santan,sereh,daun pandan,daun salam,tumisan bumbu halus lalu tambahkan garam,aduk rata dengan api sedang sampai air menyusut,tes rasa..matikan kompor
1. Siapkan kukusan yg sdh dpanaskan,masukan nasi aron,kukus selama 25 menit.Angkat
1. Sajikan nasi uduk dengan lauk pelengkap sesuai selera.
1. Selamat mencoba


Nasi Uduk is one of the Betawi culinary culture which in Malay society is known as &#34;fat rice&#34;. The menu of Nasi Uduk Betawi is stews (jengkol, tahu, tempe) balado egg, vermicelli, fried onion, crackers, peanut sauce. Even fried chicken, it becomes the main complement of uduk rice in other cities. Nasi Uduk Betawi is an Indonesian Betawi style of coconut rice. To eat this meal, I went to a restaurant called Zainal Fanani in Jakarta, that serves a traditional version. 

Salah satu kuliner yang cukup praktis dalam pembuatannya adalah  241.Nasi uduk betawi. Selain itu  241.Nasi uduk betawi  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu lakukan 5 langkah, dan  241.Nasi uduk betawi  pun siap di hidangkan. selamat mencoba !
