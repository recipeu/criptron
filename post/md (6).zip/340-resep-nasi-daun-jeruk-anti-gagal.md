---
description: "Resep Nasi Daun Jeruk Anti Gagal"
title: "Resep Nasi Daun Jeruk Anti Gagal"
slug: 340-resep-nasi-daun-jeruk-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-30T01:41:39.618Z 
thumbnail: https://img-global.cpcdn.com/recipes/8e5d9d11624701f6/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/8e5d9d11624701f6/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/8e5d9d11624701f6/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/8e5d9d11624701f6/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
author: Eric Schmidt
ratingvalue: 3.3
reviewcount: 8
recipeingredient:
- "beras 1 cup"
- "Larutan krimer boleh juga santan encer seukuran air saat memasak nasi "
- "barang sereh geprek 1"
- "Daun jeruk iris yang banyak "
- "garam Sejumput"
recipeinstructions:
- "Cuci beras hingga bersih. Tambahkan bahan lain ke wasah rice cooker. Klik tombol cook, tunggu hingga matang."
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 207 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT45M"
recipeyield: "4"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk](https://img-global.cpcdn.com/recipes/8e5d9d11624701f6/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp)

Resep Nasi Daun Jeruk  enak dengan 1 langkahmudah dan cepat yang bisa ibu coba segera

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Untuk Menyiapkan Nasi Daun Jeruk:

1. beras 1 cup
1. Larutan krimer boleh juga santan encer seukuran air saat memasak nasi 
1. barang sereh geprek 1
1. Daun jeruk iris yang banyak 
1. garam Sejumput

Nasi daun jeruk siap dihidangkan dengan. Nasi daun jeruk ini memang sedang tren di kalangan masyarakat Indonesia, banyak sekali kaum muda mudi yang berlomba-lomba membuat makanan nasi putih spesial ini. Nasi daun jeruk ala geprek bensu rekomended buat di coba. Geprek bensu nasi daun jeruk anti mainst. 

<!--inarticleads2-->

## Tata Cara Membuat Nasi Daun Jeruk:

1. Cuci beras hingga bersih. Tambahkan bahan lain ke wasah rice cooker. Klik tombol cook, tunggu hingga matang.


Gurih dan wangi dari daun jeruk menambah kelezatan nasi daun jeruk. Nasi dengan campuran daun jeruk yang wangi sedang tren. Hai selamat pagi sahabat CWS, pagi ini saya share resep Nasi Daun Jeruk. Praktis banget karena saya gunakan rice cooker. Rasanya mirip nasi uduk tapi wangiiii. 

Salah satu kuliner yang cukup praktis dalam pembuatannya adalah  Nasi Daun Jeruk. Selain itu  Nasi Daun Jeruk  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu ikuti 1 langkah, dan  Nasi Daun Jeruk  pun siap di hidangkan. selamat mencoba !
