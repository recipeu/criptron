---
description: "Cara Gampang Menyiapkan •Nasi Uduk Semur Telur Tahu Betawi• by Dapur Itha yang Lezat Sekali"
title: "Cara Gampang Menyiapkan •Nasi Uduk Semur Telur Tahu Betawi• by Dapur Itha yang Lezat Sekali"
slug: 100-cara-gampang-menyiapkan-nasi-uduk-semur-telur-tahu-betawi-by-dapur-itha-yang-lezat-sekali
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-04T04:09:56.707Z 
thumbnail: https://img-global.cpcdn.com/recipes/6717d8b11d06e2e2/682x484cq65/nasi-uduk-semur-telur-tahu-betawi-by-dapur-itha-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/6717d8b11d06e2e2/682x484cq65/nasi-uduk-semur-telur-tahu-betawi-by-dapur-itha-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/6717d8b11d06e2e2/682x484cq65/nasi-uduk-semur-telur-tahu-betawi-by-dapur-itha-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/6717d8b11d06e2e2/682x484cq65/nasi-uduk-semur-telur-tahu-betawi-by-dapur-itha-foto-resep-utama.webp
author: Chris Austin
ratingvalue: 3.1
reviewcount: 15
recipeingredient:
- "Bahan Nasi Uduk  "
- "beras cuci bersih 400 gram"
- "santan 600 gram"
- "3 lembar daun salam "
- "1 batang serai digeprek "
- "2 cm lengkuas "
- "Secukupnya garam "
- "Bahan Sambal Kacang  "
- "150 gram kacang tanah digoreng "
- "2 buah cabe merah besar digoreng "
- "3 buah cabe merah rawit digoreng "
- "2 siung bawang putih digoreng "
- "12 sendok makan cuka "
- "12 sendok makan gula pasir "
- "Secukupnya garam "
- "150 ml air "
- "Bahan Semur Telur Tahu  "
- "telur direbus 3 butir"
- "tahu dipotong menjadi 2 digoreng 3 buah"
- "1 buah tomat dipotong "
- "1 lembar daun salam "
- "1 batang serai digeprek "
- "5 sendok makan kecap manis "
- "500 ml air "
- "3 sendok makan minyak goreng untuk menumis "
- "Bumbu yang dihaluskan  "
- "3 siung bawang merah "
- "3 siung bawang putih "
- "3 buah kemiri disangrai "
- "14 sendok teh merica "
- "Secukupnya gula pasir "
- "Secukupnya garam "
- "Bahan Orek Tempe  "
- "250 gram tempe dipotong tipistipis digoreng "
- "4 siung bawang merah digoreng "
- "3 siung bawang putih digoreng "
- "3 buah cabe merah keriting digoreng "
- "1 batang serai digeprek "
- "3 cm lengkuas digeprek "
- "1 lembar daun salam "
- "1 sendok makan gula jawa "
- "2 sendok makan gula pasir "
- "3 sendok makan air asam jawa "
- "50 ml air "
- "Secukupnya garam "
- "2 sendok makan minyak goreng untuk menumis "
- "Bahan Pelengkap  "
- "Telur dadar "
- "Emping goreng "
- "Kacang tanah goreng "
recipeinstructions:
- "Cara Membuat Nasi Uduk : Semua bahan dicampur jadi satu dan diaduk hingga merata. Tes rasa."
- "Masak Nasi Uduk hingga matang dengan menggunakan magic com."
- "Cara Membuat Sambal Kacang : Giling atau tumbuk hingga halus kacang tanah goreng, cabe merah besar, cabe merah rawit dan bawang putih."
- "Masak air hingga mendidih, lalu masukkan kacang tanah, cabe merah besar, cabe merah rawit dan bawang putih yang sudah dihaluskan, cuka, gula pasir dan garam. Masak hingga matang dengan menggunakan api kecil. Tes rasa."
- "Cara Membuat Semur Telur Tahu : Tumis bumbu yang sudah dihaluskan hingga harum. Masukkan tomat, daun salam dan serai. Aduk hingga merata."
- "Masukkan air, telur rebus, tahu goreng, kecap manis, gula pasir dan garam. Masak hingga air berkurang atau agak mengental dengan menggunakan api sedang. Tes rasa."
- "Cara Membuat Tempe Orek : Tumis serai, lengkuas dan daun salam hingga harum. Lalu masukkan air asam jawa, gula jawa, gula pasir, garam dan air. Masak hingga mengental. Tes rasa."
- "Lalu masukkan tempe goreng, bawang merah goreng, bawang putih goreng dan cabe merah keriting goreng. Aduk hingga merata."
- "Nasi Uduk Semur Telur Tahu Betawi siap disajikan....❤️"
categories:
- Resep
tags:
- nasi
- uduk
- semur

katakunci: nasi uduk semur 
nutrition: 117 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT55M"
recipeyield: "3"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![•Nasi Uduk Semur Telur Tahu Betawi• by Dapur Itha](https://img-global.cpcdn.com/recipes/6717d8b11d06e2e2/682x484cq65/nasi-uduk-semur-telur-tahu-betawi-by-dapur-itha-foto-resep-utama.webp)

Resep rahasia •Nasi Uduk Semur Telur Tahu Betawi• by Dapur Itha  sederhana dengan 9 langkahcepat cocok banget jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Untuk Menyiapkan •Nasi Uduk Semur Telur Tahu Betawi• by Dapur Itha:

1. Bahan Nasi Uduk  
1. beras cuci bersih 400 gram
1. santan 600 gram
1. 3 lembar daun salam 
1. 1 batang serai digeprek 
1. 2 cm lengkuas 
1. Secukupnya garam 
1. Bahan Sambal Kacang  
1. 150 gram kacang tanah digoreng 
1. 2 buah cabe merah besar digoreng 
1. 3 buah cabe merah rawit digoreng 
1. 2 siung bawang putih digoreng 
1. 12 sendok makan cuka 
1. 12 sendok makan gula pasir 
1. Secukupnya garam 
1. 150 ml air 
1. Bahan Semur Telur Tahu  
1. telur direbus 3 butir
1. tahu dipotong menjadi 2 digoreng 3 buah
1. 1 buah tomat dipotong 
1. 1 lembar daun salam 
1. 1 batang serai digeprek 
1. 5 sendok makan kecap manis 
1. 500 ml air 
1. 3 sendok makan minyak goreng untuk menumis 
1. Bumbu yang dihaluskan  
1. 3 siung bawang merah 
1. 3 siung bawang putih 
1. 3 buah kemiri disangrai 
1. 14 sendok teh merica 
1. Secukupnya gula pasir 
1. Secukupnya garam 
1. Bahan Orek Tempe  
1. 250 gram tempe dipotong tipistipis digoreng 
1. 4 siung bawang merah digoreng 
1. 3 siung bawang putih digoreng 
1. 3 buah cabe merah keriting digoreng 
1. 1 batang serai digeprek 
1. 3 cm lengkuas digeprek 
1. 1 lembar daun salam 
1. 1 sendok makan gula jawa 
1. 2 sendok makan gula pasir 
1. 3 sendok makan air asam jawa 
1. 50 ml air 
1. Secukupnya garam 
1. 2 sendok makan minyak goreng untuk menumis 
1. Bahan Pelengkap  
1. Telur dadar 
1. Emping goreng 
1. Kacang tanah goreng 



<!--inarticleads2-->

## Tata Cara Menyiapkan •Nasi Uduk Semur Telur Tahu Betawi• by Dapur Itha:

1. Cara Membuat Nasi Uduk : Semua bahan dicampur jadi satu dan diaduk hingga merata. Tes rasa.
1. Masak Nasi Uduk hingga matang dengan menggunakan magic com.
1. Cara Membuat Sambal Kacang : Giling atau tumbuk hingga halus kacang tanah goreng, cabe merah besar, cabe merah rawit dan bawang putih.
1. Masak air hingga mendidih, lalu masukkan kacang tanah, cabe merah besar, cabe merah rawit dan bawang putih yang sudah dihaluskan, cuka, gula pasir dan garam. Masak hingga matang dengan menggunakan api kecil. Tes rasa.
1. Cara Membuat Semur Telur Tahu : Tumis bumbu yang sudah dihaluskan hingga harum. Masukkan tomat, daun salam dan serai. Aduk hingga merata.
1. Masukkan air, telur rebus, tahu goreng, kecap manis, gula pasir dan garam. Masak hingga air berkurang atau agak mengental dengan menggunakan api sedang. Tes rasa.
1. Cara Membuat Tempe Orek : Tumis serai, lengkuas dan daun salam hingga harum. Lalu masukkan air asam jawa, gula jawa, gula pasir, garam dan air. Masak hingga mengental. Tes rasa.
1. Lalu masukkan tempe goreng, bawang merah goreng, bawang putih goreng dan cabe merah keriting goreng. Aduk hingga merata.
1. Nasi Uduk Semur Telur Tahu Betawi siap disajikan....❤️




Terima kasih telah membaca resep yang tim kami tampilkan di halaman ini. Selamat mencoba!
