---
description: "Langkah Mudah untuk Membuat Nasi Bakar Ayam Teri, Sempurna"
title: "Langkah Mudah untuk Membuat Nasi Bakar Ayam Teri, Sempurna"
slug: 390-langkah-mudah-untuk-membuat-nasi-bakar-ayam-teri-sempurna
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-28T10:46:27.434Z 
thumbnail: https://img-global.cpcdn.com/recipes/aa6005d6e29ac932/682x484cq65/nasi-bakar-ayam-teri-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/aa6005d6e29ac932/682x484cq65/nasi-bakar-ayam-teri-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/aa6005d6e29ac932/682x484cq65/nasi-bakar-ayam-teri-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/aa6005d6e29ac932/682x484cq65/nasi-bakar-ayam-teri-foto-resep-utama.webp
author: Eddie Larson
ratingvalue: 4.9
reviewcount: 14
recipeingredient:
- "Bahan Ayam Suwir Teri "
- "dada ayam filet 1"
- "teri 1 mangkok kecil"
- "bawang merah 8"
- "bawang putih 4"
- "kemiri 2 buah"
- "cabe merah besar 3 buah"
- "cabe rawit 5"
- "Jahe Sejempol"
- "kunyit 2 ruas jari"
- "daun salam 4 lembar"
- "daun jeruk 4 lembar"
- "GaramGulaKaldu Jamur secukupnya"
- "daun kemangi 1 ikat"
- "Bahan Nasi "
- "beras 4 cup"
- "santan kara 1 bungkus kecil"
- "bawang merah iris tipis 8"
- "bawang putih iris tipis 4"
- "sereh geprek 1 batang"
- "daun salam 2 lembar"
- "daun jeruk 2 lembar"
- "Garam dan Kaldu Jamur secukupnya"
- "Air secukupnya"
- "Daun Pisang "
- "daun kemangi untuk toping 1 ikat"
recipeinstructions:
- "Pertama bikin nasi nya dulu.Tumis bawang putih, bawang merah sampai wangi lalu masukkan daun salam,daun jeruk dan sereh.Masak sampai daun2nya layu."
- "Masukkan beras ke dalam panci rice cooker,tambahkan santan dan air seperti masak nasi biasa.Lalu masukkan tumisan bumbu,tambahkan garam dan kaldu jamur secukupnya.Masak sampai matang"
- "Untuk ayam suwir, rebus dahulu dada ayam dengan 1 lembar daun salam dan sedikit garam.Rebus sampai matang, dinginkan dan suwir"
- "Rendam sebentar ikan teri lalu cuci dan tiriskan.Goreng dalam minyak panas sampai agak kering"
- "Haluskan bawang merah, bawang putih, kunyit,jahe,kemiri dan cabe2an lalu tumis dalam minyak panas tambahkan daun2nya.Tumis sampai bumbu tanak dan wangi lalu tambahkan garam gula dan kaldu jamur,cek rasa.Lanjut masukkan ayam suwir dan ikan teri,aduk sampai bumbu tercampur rata.Klo terlalu kering bisa di tambahkan sedikit air kaldu rebusan ayam.Masak sampai kaldu meresap lalu tambahkan daun kemangi,aduk sebentar dan matikan kompor"
- "Setelah nasi masak, keluarkan dari panci rice cooker dan biarkan agak dingin"
- "Lalu bungkus dengan daun pisang,1 centong nasi di tekan2 pake sendok lalu tambahkan ayam suwir dan daun kemangi dan tutup kembali dengan 1 centong nasi.Padatkan dan gulung,semat dengan lidi.Ulangi semua sampai nasi habis"
categories:
- Resep
tags:
- nasi
- bakar
- ayam

katakunci: nasi bakar ayam 
nutrition: 133 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT58M"
recipeyield: "4"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Bakar Ayam Teri](https://img-global.cpcdn.com/recipes/aa6005d6e29ac932/682x484cq65/nasi-bakar-ayam-teri-foto-resep-utama.webp)

Resep rahasia Nasi Bakar Ayam Teri  anti gagal dengan 7 langkahmudah yang bisa bunda coba segera

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Untuk Pembuatan Nasi Bakar Ayam Teri:

1. Bahan Ayam Suwir Teri 
1. dada ayam filet 1
1. teri 1 mangkok kecil
1. bawang merah 8
1. bawang putih 4
1. kemiri 2 buah
1. cabe merah besar 3 buah
1. cabe rawit 5
1. Jahe Sejempol
1. kunyit 2 ruas jari
1. daun salam 4 lembar
1. daun jeruk 4 lembar
1. GaramGulaKaldu Jamur secukupnya
1. daun kemangi 1 ikat
1. Bahan Nasi 
1. beras 4 cup
1. santan kara 1 bungkus kecil
1. bawang merah iris tipis 8
1. bawang putih iris tipis 4
1. sereh geprek 1 batang
1. daun salam 2 lembar
1. daun jeruk 2 lembar
1. Garam dan Kaldu Jamur secukupnya
1. Air secukupnya
1. Daun Pisang 
1. daun kemangi untuk toping 1 ikat



<!--inarticleads2-->

## Cara Menyiapkan Nasi Bakar Ayam Teri:

1. Pertama bikin nasi nya dulu.Tumis bawang putih, bawang merah sampai wangi lalu masukkan daun salam,daun jeruk dan sereh.Masak sampai daun2nya layu.
1. Masukkan beras ke dalam panci rice cooker,tambahkan santan dan air seperti masak nasi biasa.Lalu masukkan tumisan bumbu,tambahkan garam dan kaldu jamur secukupnya.Masak sampai matang
1. Untuk ayam suwir, rebus dahulu dada ayam dengan 1 lembar daun salam dan sedikit garam.Rebus sampai matang, dinginkan dan suwir
1. Rendam sebentar ikan teri lalu cuci dan tiriskan.Goreng dalam minyak panas sampai agak kering
1. Haluskan bawang merah, bawang putih, kunyit,jahe,kemiri dan cabe2an lalu tumis dalam minyak panas tambahkan daun2nya.Tumis sampai bumbu tanak dan wangi lalu tambahkan garam gula dan kaldu jamur,cek rasa.Lanjut masukkan ayam suwir dan ikan teri,aduk sampai bumbu tercampur rata.Klo terlalu kering bisa di tambahkan sedikit air kaldu rebusan ayam.Masak sampai kaldu meresap lalu tambahkan daun kemangi,aduk sebentar dan matikan kompor
1. Setelah nasi masak, keluarkan dari panci rice cooker dan biarkan agak dingin
1. Lalu bungkus dengan daun pisang,1 centong nasi di tekan2 pake sendok lalu tambahkan ayam suwir dan daun kemangi dan tutup kembali dengan 1 centong nasi.Padatkan dan gulung,semat dengan lidi.Ulangi semua sampai nasi habis




Selamat memasak dan menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
