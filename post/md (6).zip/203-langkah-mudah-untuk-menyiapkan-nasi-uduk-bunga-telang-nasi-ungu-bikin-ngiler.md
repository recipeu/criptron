---
description: "Langkah Mudah untuk Menyiapkan Nasi Uduk Bunga Telang / Nasi Ungu, Bikin Ngiler"
title: "Langkah Mudah untuk Menyiapkan Nasi Uduk Bunga Telang / Nasi Ungu, Bikin Ngiler"
slug: 203-langkah-mudah-untuk-menyiapkan-nasi-uduk-bunga-telang-nasi-ungu-bikin-ngiler
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-24T03:53:29.674Z 
thumbnail: https://img-global.cpcdn.com/recipes/661b0590b74ee5ba/682x484cq65/nasi-uduk-bunga-telang-nasi-ungu-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/661b0590b74ee5ba/682x484cq65/nasi-uduk-bunga-telang-nasi-ungu-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/661b0590b74ee5ba/682x484cq65/nasi-uduk-bunga-telang-nasi-ungu-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/661b0590b74ee5ba/682x484cq65/nasi-uduk-bunga-telang-nasi-ungu-foto-resep-utama.webp
author: Mabelle Murphy
ratingvalue: 3.8
reviewcount: 6
recipeingredient:
- "Bunga Telang 30 kuntum"
- "Beras 1/2 kg"
- "Santan Sasa Cair 1/2 bks"
- "Bawang Putih 2 bj"
- "Kemiri 2 bj"
- "Garam Secukupnya"
- "Daun Salam 2 lembar"
- "sereh 1 batang"
- "Air Secukupnya"
recipeinstructions:
- "Rendam bunga telang menggunakan air panas hingga airnya berubah warna."
- "Ulek bawang putih dan kemiri hingga halus tambahkan garam."
- "Cuci beras sampe bersih kemudian masukan bumbu yg sudah di ulek tadi tambahkan daun salam dan sereh yg sebelumnya sudah di geprek."
- "Masukan air rendaman bunga telang kedalam beras (o iya bunganya di buang ya jangan ikut di masak hehe)"
- "Tambahkan santan. Lalu masak denga api sedang.. (Disini saya masak menggunakan panci presto ya) jdi pas pancinya bunyi api rada di kecilin tunggu 2-3 menit matikan apinya,tunggu uap habis batu deh di buka )"
- "Sajikan dengan topping sesuai selera ya 🤩"
categories:
- Resep
tags:
- nasi
- uduk
- bunga

katakunci: nasi uduk bunga 
nutrition: 130 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT57M"
recipeyield: "4"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Bunga Telang / Nasi Ungu](https://img-global.cpcdn.com/recipes/661b0590b74ee5ba/682x484cq65/nasi-uduk-bunga-telang-nasi-ungu-foto-resep-utama.webp)

Resep dan cara mengolah  Nasi Uduk Bunga Telang / Nasi Ungu yang harus ibu coba dirumah

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Dalam Pembuatan Nasi Uduk Bunga Telang / Nasi Ungu:

1. Bunga Telang 30 kuntum
1. Beras 1/2 kg
1. Santan Sasa Cair 1/2 bks
1. Bawang Putih 2 bj
1. Kemiri 2 bj
1. Garam Secukupnya
1. Daun Salam 2 lembar
1. sereh 1 batang
1. Air Secukupnya



<!--inarticleads2-->

## Cara Mudah Menyiapkan Nasi Uduk Bunga Telang / Nasi Ungu:

1. Rendam bunga telang menggunakan air panas hingga airnya berubah warna.
1. Ulek bawang putih dan kemiri hingga halus tambahkan garam.
1. Cuci beras sampe bersih kemudian masukan bumbu yg sudah di ulek tadi tambahkan daun salam dan sereh yg sebelumnya sudah di geprek.
1. Masukan air rendaman bunga telang kedalam beras (o iya bunganya di buang ya jangan ikut di masak hehe)
1. Tambahkan santan. - Lalu masak denga api sedang.. - (Disini saya masak menggunakan panci presto ya) jdi pas pancinya bunyi api rada di kecilin tunggu 2-3 menit matikan apinya,tunggu uap habis batu deh di buka )
1. Sajikan dengan topping sesuai selera ya 🤩




Terima kasih telah menggunakan resep yang kami tampilkan di halaman ini. Semoga bermanfaat dan selamat mencoba!
