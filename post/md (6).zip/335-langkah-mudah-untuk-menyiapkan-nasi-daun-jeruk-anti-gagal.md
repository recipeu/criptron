---
description: "Langkah Mudah untuk Menyiapkan Nasi daun jeruk Anti Gagal"
title: "Langkah Mudah untuk Menyiapkan Nasi daun jeruk Anti Gagal"
slug: 335-langkah-mudah-untuk-menyiapkan-nasi-daun-jeruk-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-11T08:51:15.994Z 
thumbnail: https://img-global.cpcdn.com/recipes/38ec35c262a704a3/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/38ec35c262a704a3/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/38ec35c262a704a3/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/38ec35c262a704a3/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
author: Elsie Allison
ratingvalue: 4.3
reviewcount: 3
recipeingredient:
- "takaran beras 3"
- "air Secukupnya"
- "daun jeruk 5 lembar"
- "bawang merah 5 siung"
- "sereh 1 batang"
- "garam 1 sdm"
recipeinstructions:
- "Siapkan beras cuci bersih tiriskan"
- "Siapkan bahan bawang merah iris tipis, daun jeruk buang bagian tengahnya iris halus &amp; sereh digeprek"
- "Panaskan sedikit minyak lalu tumis bawang hingga layu masukan sereh, tuang air kemudian masukan kedalam beras yang telah dicuci beri daun jeruk &amp; garam aduk2 lalu masak menggunakan rice cooker"
- "Setelah matang aduk rata dan siap dihidangkan bersama aneka lauk"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 119 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT60M"
recipeyield: "4"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi daun jeruk](https://img-global.cpcdn.com/recipes/38ec35c262a704a3/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp)

Resep dan cara mengolah  Nasi daun jeruk cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Untuk Pembuatan Nasi daun jeruk:

1. takaran beras 3
1. air Secukupnya
1. daun jeruk 5 lembar
1. bawang merah 5 siung
1. sereh 1 batang
1. garam 1 sdm

Nasi daun jeruk siap dihidangkan dengan. Nasi daun jeruk ini memang sedang tren di kalangan masyarakat Indonesia, banyak sekali kaum muda mudi yang berlomba-lomba membuat makanan nasi putih spesial ini. Nasi daun jeruk ala geprek bensu rekomended buat di coba. Geprek bensu nasi daun jeruk anti mainst. 

<!--inarticleads2-->

## Cara Mudah Membuat Nasi daun jeruk:

1. Siapkan beras cuci bersih tiriskan
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/aec4683b3279b4e6/160x128cq70/nasi-daun-jeruk-langkah-memasak-1-foto.webp" alt="Nasi daun jeruk" width="340" height="340">
>1. Siapkan bahan bawang merah iris tipis, daun jeruk buang bagian tengahnya iris halus &amp; sereh digeprek
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/6822b6a8ffc034e4/160x128cq70/nasi-daun-jeruk-langkah-memasak-2-foto.webp" alt="Nasi daun jeruk" width="340" height="340">
><img class="lazyload" data-src="https://img-global.cpcdn.com/steps/7ac624ad4a1d2f90/160x128cq70/nasi-daun-jeruk-langkah-memasak-2-foto.webp" alt="Nasi daun jeruk" width="340" height="340">
>1. Panaskan sedikit minyak lalu tumis bawang hingga layu masukan sereh, tuang air kemudian masukan kedalam beras yang telah dicuci beri daun jeruk &amp; garam aduk2 lalu masak menggunakan rice cooker
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/afa2a3c0eb2fa0c8/160x128cq70/nasi-daun-jeruk-langkah-memasak-3-foto.webp" alt="Nasi daun jeruk" width="340" height="340">
><img class="lazyload" data-src="https://img-global.cpcdn.com/steps/ca7c87a5bbf36ec3/160x128cq70/nasi-daun-jeruk-langkah-memasak-3-foto.webp" alt="Nasi daun jeruk" width="340" height="340">
>1. Setelah matang aduk rata dan siap dihidangkan bersama aneka lauk
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/a6ea1d7161b8234a/160x128cq70/nasi-daun-jeruk-langkah-memasak-4-foto.webp" alt="Nasi daun jeruk" width="340" height="340">
><img class="lazyload" data-src="https://img-global.cpcdn.com/steps/0d204742a1620763/160x128cq70/nasi-daun-jeruk-langkah-memasak-4-foto.webp" alt="Nasi daun jeruk" width="340" height="340">
>

Gurih dan wangi dari daun jeruk menambah kelezatan nasi daun jeruk. Nasi dengan campuran daun jeruk yang wangi sedang tren. Hai selamat pagi sahabat CWS, pagi ini saya share resep Nasi Daun Jeruk. Praktis banget karena saya gunakan rice cooker. Rasanya mirip nasi uduk tapi wangiiii. 

Daripada bunda beli  Nasi daun jeruk  diluar terus, kamu  bisa membuatnya sendiri dirumah. Resep  Nasi daun jeruk  sederhana ini cukup praktis dalam proses pembuatannya, cukup menggunakan bumbu-bumbu sederhana yang ada di dapur  Nasi daun jeruk  yang enak, bunda nikmati di rumah.
