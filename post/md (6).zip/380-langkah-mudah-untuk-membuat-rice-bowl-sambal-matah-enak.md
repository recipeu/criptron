---
description: "Langkah Mudah untuk Membuat Rice Bowl Sambal Matah, Enak"
title: "Langkah Mudah untuk Membuat Rice Bowl Sambal Matah, Enak"
slug: 380-langkah-mudah-untuk-membuat-rice-bowl-sambal-matah-enak
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-14T23:19:17.364Z 
thumbnail: https://img-global.cpcdn.com/recipes/3a6a495dfa7e6dc3/682x484cq65/rice-bowl-sambal-matah-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/3a6a495dfa7e6dc3/682x484cq65/rice-bowl-sambal-matah-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/3a6a495dfa7e6dc3/682x484cq65/rice-bowl-sambal-matah-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/3a6a495dfa7e6dc3/682x484cq65/rice-bowl-sambal-matah-foto-resep-utama.webp
author: Bettie Chapman
ratingvalue: 3
reviewcount: 6
recipeingredient:
- "ikan tuna basah potong kotak kecil 250 gram"
- "Bumbu rendaman "
- "kecap asin 1 sdt"
- "merica bubuk 1/4 sdt"
- "kaldu bubuk 1/4 sdt"
- "Bahan sambal matah iris halus "
- "bawang merah 8 butir"
- "cabe rawit merah 15 buah"
- "serai ambil putihnya 2 batang"
- "daun jeruk 5 lembar"
- "terasi bakar 1 bks kecil"
- "jeruk nipis ambil airnya 1 buah"
- "garam 1/2 sdt"
- "minyak goreng bekas goreng ikan sisihkan 50 ml"
- "Bahan tepung kering "
- "tepung terigu 150 gram"
- "baking powder 1/2 sdt"
- "nasi putih minyak goreng Secukupnya"
recipeinstructions:
- "Siapkan bahannya"
- "Dalam wadah masukkan potongan ikan tuna, tambahkan kecap asin, merica bubuk, kaldu bubuk, diamkan selam kurleb 30 menit, sisihkan"
- "Buat sambal matah, iris halus bawang merah, cabe rawit merah, serai, daun jeruk, terasi bakar, air jeruk nipis, dalam mangkok, sisihkan"
- "Siapkan tepung terigu dalam wadah, masukkan baking powder, aduk rata, potongan ikan balut dengan tepung, goreng sampai matang, angkat, tiriskan, sisihkan"
- "Didihkan minyak goreng, bekas goreng ikan asin, langsung tuang ke mangkok aduk rata, sisihkan"
- "Sajika nasi dalam mangkok, tambahkan diatasnya potongan ikan yang sudah digoreng, tambahkan sambal matah, siap disajikan"
categories:
- Resep
tags:
- rice
- bowl
- sambal

katakunci: rice bowl sambal 
nutrition: 273 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT54M"
recipeyield: "1"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Rice Bowl Sambal Matah](https://img-global.cpcdn.com/recipes/3a6a495dfa7e6dc3/682x484cq65/rice-bowl-sambal-matah-foto-resep-utama.webp)

6 langkah mudah membuat  Rice Bowl Sambal Matah yang wajib ibu coba segera

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Dalam Menyiapkan Rice Bowl Sambal Matah:

1. ikan tuna basah potong kotak kecil 250 gram
1. Bumbu rendaman 
1. kecap asin 1 sdt
1. merica bubuk 1/4 sdt
1. kaldu bubuk 1/4 sdt
1. Bahan sambal matah iris halus 
1. bawang merah 8 butir
1. cabe rawit merah 15 buah
1. serai ambil putihnya 2 batang
1. daun jeruk 5 lembar
1. terasi bakar 1 bks kecil
1. jeruk nipis ambil airnya 1 buah
1. garam 1/2 sdt
1. minyak goreng bekas goreng ikan sisihkan 50 ml
1. Bahan tepung kering 
1. tepung terigu 150 gram
1. baking powder 1/2 sdt
1. nasi putih minyak goreng Secukupnya



<!--inarticleads2-->

## Tata Cara Menyiapkan Rice Bowl Sambal Matah:

1. Siapkan bahannya
1. Dalam wadah masukkan potongan ikan tuna, tambahkan kecap asin, merica bubuk, kaldu bubuk, diamkan selam kurleb 30 menit, sisihkan
1. Buat sambal matah, iris halus bawang merah, cabe rawit merah, serai, daun jeruk, terasi bakar, air jeruk nipis, dalam mangkok, sisihkan
1. Siapkan tepung terigu dalam wadah, masukkan baking powder, aduk rata, potongan ikan balut dengan tepung, goreng sampai matang, angkat, tiriskan, sisihkan
1. Didihkan minyak goreng, bekas goreng ikan asin, langsung tuang ke mangkok aduk rata, sisihkan
1. Sajika nasi dalam mangkok, tambahkan diatasnya potongan ikan yang sudah digoreng, tambahkan sambal matah, siap disajikan




Demikian informasi  resep Rice Bowl Sambal Matah   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
