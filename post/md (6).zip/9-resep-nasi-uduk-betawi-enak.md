---
description: "Resep Nasi Uduk Betawi, Enak"
title: "Resep Nasi Uduk Betawi, Enak"
slug: 9-resep-nasi-uduk-betawi-enak
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-06T22:38:06.664Z 
thumbnail: https://img-global.cpcdn.com/recipes/b0e7b9110a52c31b/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/b0e7b9110a52c31b/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/b0e7b9110a52c31b/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/b0e7b9110a52c31b/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
author: Barry Gomez
ratingvalue: 3.8
reviewcount: 8
recipeingredient:
- "Beras 500 gr"
- "santan 200 ml santan instant  sd 600 ml 600 ml"
- "daun salam 3 lembar"
- "daun jeruk 3 lembar"
- "sereh geprek 1 batang"
- "Garam 1/2 sdm"
- "jahe geprek 1 ruas"
- "lengkuas geprek 1 ruas"
- "pala geprek 1/2 butir"
- "bunga cengkeh 3 pcs"
- "kayu manis 1 pcs"
recipeinstructions:
- "Masukkan santam dan air lalu semua bumbu. Aduk hingga rata sambil dinyalakan kompor dengan api kecil. Masak hingga mendidih sambik terus diaduk. Cuci beras."
- "Masukkan beras lalu dimasak sambil diaduk hingga air menyusut."
- "Pindahkan ke kukusan yang telah panas (sistem aron). Kukus hingga 30-45 menit."
- "Bungkus dengan daun diberi toping bawang merah. Siap dihidangkan dengan lauk lainnya seperti semur betawi. Telur Dadar, bihun goreng dll"
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 131 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT46M"
recipeyield: "3"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Betawi](https://img-global.cpcdn.com/recipes/b0e7b9110a52c31b/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp)

Resep rahasia dan cara memasak  Nasi Uduk Betawi cocok sekali jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Untuk Pembuatan Nasi Uduk Betawi:

1. Beras 500 gr
1. santan 200 ml santan instant  sd 600 ml 600 ml
1. daun salam 3 lembar
1. daun jeruk 3 lembar
1. sereh geprek 1 batang
1. Garam 1/2 sdm
1. jahe geprek 1 ruas
1. lengkuas geprek 1 ruas
1. pala geprek 1/2 butir
1. bunga cengkeh 3 pcs
1. kayu manis 1 pcs



<!--inarticleads2-->

## Cara Mudah Menyiapkan Nasi Uduk Betawi:

1. Masukkan santam dan air lalu semua bumbu. Aduk hingga rata sambil dinyalakan kompor dengan api kecil. Masak hingga mendidih sambik terus diaduk. Cuci beras.
1. Masukkan beras lalu dimasak sambil diaduk hingga air menyusut.
1. Pindahkan ke kukusan yang telah panas (sistem aron). Kukus hingga 30-45 menit.
1. Bungkus dengan daun diberi toping bawang merah. Siap dihidangkan dengan lauk lainnya seperti semur betawi. Telur Dadar, bihun goreng dll




Demikian informasi  resep Nasi Uduk Betawi   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
