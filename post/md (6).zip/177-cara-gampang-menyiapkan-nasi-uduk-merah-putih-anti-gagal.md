---
description: "Cara Gampang Menyiapkan Nasi uduk merah putih 🇮🇩 Anti Gagal"
title: "Cara Gampang Menyiapkan Nasi uduk merah putih 🇮🇩 Anti Gagal"
slug: 177-cara-gampang-menyiapkan-nasi-uduk-merah-putih-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-01T10:18:51.802Z 
thumbnail: https://img-global.cpcdn.com/recipes/860f8dfb07b9e1f5/682x484cq65/nasi-uduk-merah-putih-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/860f8dfb07b9e1f5/682x484cq65/nasi-uduk-merah-putih-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/860f8dfb07b9e1f5/682x484cq65/nasi-uduk-merah-putih-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/860f8dfb07b9e1f5/682x484cq65/nasi-uduk-merah-putih-foto-resep-utama.webp
author: Belle Wheeler
ratingvalue: 4.7
reviewcount: 4
recipeingredient:
- "Nasi uduk putih "
- "beras putih 1 cup"
- "santan instan 65ml 1 bks"
- "Air secukupnya"
- "daun salam 1 lembar"
- "daun pandan 1 lembar"
- "garam 1 sdt"
- "Nasi uduk secang "
- "kayu secang 1 genggam"
- "air 300 ml"
- "beras 1 cup"
- "santan instan 65ml 1 bks"
- "daun salam 1 lembar"
- "daun pandan 1 lembar"
- "garam 1 sdt"
- "Pelengkap "
- "Mie goreng "
- "Ayam gorengoporbakar "
- "Telur bumbu bali "
- "Sambel goreng kentang "
- "Urapan sayur "
recipeinstructions:
- "Cuci bersih beras, masukkan semua bahan, masak seperti biasa"
- "Untuk nasi uduk secang, rebus air dan secang, tunggu mendidih dan mendapatkan warna yang diinginkan"
- "Gunakan air rebusan secang dan bahan lainnya untuk menanak nasi."
- "Cetak dan atur di piring saji"
categories:
- Resep
tags:
- nasi
- uduk
- merah

katakunci: nasi uduk merah 
nutrition: 218 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT55M"
recipeyield: "3"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi uduk merah putih 🇮🇩](https://img-global.cpcdn.com/recipes/860f8dfb07b9e1f5/682x484cq65/nasi-uduk-merah-putih-foto-resep-utama.webp)

Resep rahasia Nasi uduk merah putih 🇮🇩  sederhana dengan 4 langkahcepat cocok banget jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Dalam Pembuatan Nasi uduk merah putih 🇮🇩:

1. Nasi uduk putih 
1. beras putih 1 cup
1. santan instan 65ml 1 bks
1. Air secukupnya
1. daun salam 1 lembar
1. daun pandan 1 lembar
1. garam 1 sdt
1. Nasi uduk secang 
1. kayu secang 1 genggam
1. air 300 ml
1. beras 1 cup
1. santan instan 65ml 1 bks
1. daun salam 1 lembar
1. daun pandan 1 lembar
1. garam 1 sdt
1. Pelengkap 
1. Mie goreng 
1. Ayam gorengoporbakar 
1. Telur bumbu bali 
1. Sambel goreng kentang 
1. Urapan sayur 

Nasi uduk memiliki cita rasa yang enak, dilengkapi dengan lauk-pauk yang Nasi uduk yang berasal dari Betawi sangat terkenal, meskipun berwarna putih akan tetapi butiran nasi tidak lengket bahkan proses memasaknya menggunakan. Lazimnya, warna Nasi Uduk Betawi atau nasi uduk mana pun pasti berwarna putih. Kalau nasi uduk biasa, warnanya putih. Nasi gurih merah putih viral di hari kemerdekaan RI, enak gilaaaa. 

<!--inarticleads2-->

## Langkah-langkah Untuk Membuat Nasi uduk merah putih 🇮🇩:

1. Cuci bersih beras, masukkan semua bahan, masak seperti biasa
1. Untuk nasi uduk secang, rebus air dan secang, tunggu mendidih dan mendapatkan warna yang diinginkan
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/c6f3f58602e3f782/160x128cq70/nasi-uduk-merah-putih-langkah-memasak-2-foto.webp" alt="Nasi uduk merah putih 🇮🇩" width="340" height="340">
>1. Gunakan air rebusan secang dan bahan lainnya untuk menanak nasi.
1. Cetak dan atur di piring saji


Film pertama GADING MARTIN (Demi Merah Putih Di Pundakku). Merah Putih Memanggil, Film yang Diperankan Prajurit TNI. Coba intip resep nasi uduk beras merah ala Philips disini. Lirik Lagu Bendera Merah Putih Karangan / Ciptaan : Ibu Sud Berdera merah putih Bendera tanah airku Gagah dan jernih tampak. Bawang putih dioles ke alat vital dianggap banyak kaum Adam dapat memperbesar Mr. 

Selamat memasak dan menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
