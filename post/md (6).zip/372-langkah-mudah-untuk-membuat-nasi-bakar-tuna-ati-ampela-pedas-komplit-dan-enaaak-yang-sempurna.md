---
description: "Langkah Mudah untuk Membuat Nasi bakar tuna ati ampela pedas komplit dan enaaak!! yang Sempurna"
title: "Langkah Mudah untuk Membuat Nasi bakar tuna ati ampela pedas komplit dan enaaak!! yang Sempurna"
slug: 372-langkah-mudah-untuk-membuat-nasi-bakar-tuna-ati-ampela-pedas-komplit-dan-enaaak-yang-sempurna
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-19T04:34:05.800Z 
thumbnail: https://img-global.cpcdn.com/recipes/d24f15f322b39ec3/682x484cq65/nasi-bakar-tuna-ati-ampela-pedas-komplit-dan-enaaak-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/d24f15f322b39ec3/682x484cq65/nasi-bakar-tuna-ati-ampela-pedas-komplit-dan-enaaak-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/d24f15f322b39ec3/682x484cq65/nasi-bakar-tuna-ati-ampela-pedas-komplit-dan-enaaak-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/d24f15f322b39ec3/682x484cq65/nasi-bakar-tuna-ati-ampela-pedas-komplit-dan-enaaak-foto-resep-utama.webp
author: Harvey Huff
ratingvalue: 4.6
reviewcount: 14
recipeingredient:
- "Bahan nasi "
- "daun pisang Secukupnya"
- "beras 3 cup"
- "sereh 2 batang"
- "bawang merah iris 6 siung"
- "bawang putih iris 4 siung"
- "cabe keriting iris 4 buah"
- "daun salam 5 lembar"
- "daun jeruk 3 lembar"
- "garam Secukupnya"
- "kaldu bubuk Secukupnya"
- "Bahan tuna pedas "
- "ikan tuna 2 kaleng"
- "daun bawang ambil bagian putihnya saja 2 batang"
- "daun bombay iris 1 buah"
- "daun kemangi 1 batang"
- "garam Secukupnya"
- "kaldu bubuk Secukupnya"
- "Bumbu halus tuna pedas "
- "cabe keriting 10 buah"
- "kemiri 3 buah"
- "bawang merah 8 siung"
- "bawang putih 5 siung"
- "cabe rawit 10 buah"
- "jahe 2 cm"
- "ketumbar 1/2 sdt"
- "Pelengkap nasi bakar "
- "pete kupas 5 batang"
- "ati ampela rebus dan goreng 5 pasang"
- "daun kemangi 5 batang"
- "cabe rawit Secukupnya"
recipeinstructions:
- "Pertama membuat nasi liwetnya dahulu : cuci beras, sisihkan.. kemudian tumis semua bahan kecuali beras hingga harum dengan sedikit minyak, masukkan tumisan kedalam beras, beri air seperti takaran memasak nasi biasanya."
- "Kemudian memasak tuna pedas : tumis bumbu halus, bawang bombay dan daun bawang hingga benar benar harum dengan minyak, tambahkan garam dan kaldu bubuk, masukkan tuna, aduk merata"
- "Tambahkan air sekitar 50 ml, aduk merata hingga bumbu benar benar meresap sempurna, masukkan kemangi, tes rasa"
- "Rebus ati ampela sebentar kemudian goreng agak kering, potong dadu kecil sesuai selera, sisihkan"
- "Daun pisang di jemur / di panaskan di atas kompor hingga layu dan mudah untuk di bentuk"
- "Penataan nasi bakar : masukkan 1 centong penuh nasi ketengah daun pisang yang telah disesuaikan, diatas nasi sajikan pete, ati ampela, daun kemangi, cabe rawit utuh dan 1 sendok makan tuna pedas"
- "Gulung rapi dan sematkan lidi di ujung daun, bakar di atas teflon hingga kecoklatan serta daun pisang tercium aroma khasnya 😊😊 selamat makaaan.."
categories:
- Resep
tags:
- nasi
- bakar
- tuna

katakunci: nasi bakar tuna 
nutrition: 208 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT48M"
recipeyield: "2"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi bakar tuna ati ampela pedas komplit dan enaaak!!](https://img-global.cpcdn.com/recipes/d24f15f322b39ec3/682x484cq65/nasi-bakar-tuna-ati-ampela-pedas-komplit-dan-enaaak-foto-resep-utama.webp)

Resep Nasi bakar tuna ati ampela pedas komplit dan enaaak!!  enak dengan 7 langkahmudah dan cepat yang harus ibu coba segera

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Untuk Pembuatan Nasi bakar tuna ati ampela pedas komplit dan enaaak!!:

1. Bahan nasi 
1. daun pisang Secukupnya
1. beras 3 cup
1. sereh 2 batang
1. bawang merah iris 6 siung
1. bawang putih iris 4 siung
1. cabe keriting iris 4 buah
1. daun salam 5 lembar
1. daun jeruk 3 lembar
1. garam Secukupnya
1. kaldu bubuk Secukupnya
1. Bahan tuna pedas 
1. ikan tuna 2 kaleng
1. daun bawang ambil bagian putihnya saja 2 batang
1. daun bombay iris 1 buah
1. daun kemangi 1 batang
1. garam Secukupnya
1. kaldu bubuk Secukupnya
1. Bumbu halus tuna pedas 
1. cabe keriting 10 buah
1. kemiri 3 buah
1. bawang merah 8 siung
1. bawang putih 5 siung
1. cabe rawit 10 buah
1. jahe 2 cm
1. ketumbar 1/2 sdt
1. Pelengkap nasi bakar 
1. pete kupas 5 batang
1. ati ampela rebus dan goreng 5 pasang
1. daun kemangi 5 batang
1. cabe rawit Secukupnya

Iris bawang merah, bawang putih, cabe rawit merah. Nasi bakar dengan isi ati ampela dengan tambahan bumbu rempah yang mudah dan sederhana. Lebih komplit lagi apabila anda menghidangkan dengan lauk tambahan. Nasi bakar yang terkenal adalah nasi bakar sumsum khas Banten atau nasi bakar isi ikan teri yang yummi. 

<!--inarticleads2-->

## Tata Cara Membuat Nasi bakar tuna ati ampela pedas komplit dan enaaak!!:

1. Pertama membuat nasi liwetnya dahulu : cuci beras, sisihkan.. kemudian tumis semua bahan kecuali beras hingga harum dengan sedikit minyak, masukkan tumisan kedalam beras, beri air seperti takaran memasak nasi biasanya.
1. Kemudian memasak tuna pedas : tumis bumbu halus, bawang bombay dan daun bawang hingga benar benar harum dengan minyak, tambahkan garam dan kaldu bubuk, masukkan tuna, aduk merata
1. Tambahkan air sekitar 50 ml, aduk merata hingga bumbu benar benar meresap sempurna, masukkan kemangi, tes rasa
1. Rebus ati ampela sebentar kemudian goreng agak kering, potong dadu kecil sesuai selera, sisihkan
1. Daun pisang di jemur / di panaskan di atas kompor hingga layu dan mudah untuk di bentuk
1. Penataan nasi bakar : masukkan 1 centong penuh nasi ketengah daun pisang yang telah disesuaikan, diatas nasi sajikan pete, ati ampela, daun kemangi, cabe rawit utuh dan 1 sendok makan tuna pedas
1. Gulung rapi dan sematkan lidi di ujung daun, bakar di atas teflon hingga kecoklatan serta daun pisang tercium aroma khasnya 😊😊 selamat makaaan..


Sangat Simple dan Mudah sekali bikin Nasi bakar, nasinya sengaja pakai nasi uduk, ini enak Hallo teman-teman, di video kali ini aku mau berbagi resep nasi bakar ati ampela yang super enak!. Untuk membuat Nasi Bakar Ayam Pedas ini perlu kesabaran yang tinggi karena masaknya lumayan. Kali ini aku mau berbagi resep masakan harian yang mudah dan enak banget yaitu TUMIS OSENG ATI AMPELA. Resep Masak Ati Ampela Ayam Kecap Pedas Manis rasanya dijamin enak banget pedasnya bikin makan pengen nambah terus. Kali ini aku mau berbagi resep masakan harian yang mudah dan enak banget yaitu TUMIS OSENG ATI AMPELA. 

Selamat memasak dan menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
