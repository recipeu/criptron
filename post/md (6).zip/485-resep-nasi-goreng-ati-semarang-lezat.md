---
description: "Resep Nasi Goreng Ati Semarang, Lezat"
title: "Resep Nasi Goreng Ati Semarang, Lezat"
slug: 485-resep-nasi-goreng-ati-semarang-lezat
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-20T10:18:36.522Z 
thumbnail: https://img-global.cpcdn.com/recipes/0ccf5d8fe3745ea5/682x484cq65/nasi-goreng-ati-semarang-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/0ccf5d8fe3745ea5/682x484cq65/nasi-goreng-ati-semarang-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/0ccf5d8fe3745ea5/682x484cq65/nasi-goreng-ati-semarang-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/0ccf5d8fe3745ea5/682x484cq65/nasi-goreng-ati-semarang-foto-resep-utama.webp
author: Virgie Brock
ratingvalue: 3.3
reviewcount: 5
recipeingredient:
- "Nasi 1 piring"
- "Ati ayam 1 potong"
- "Bawang putih 2 siung"
- "bawang merah 3 siung"
- "Grm Mrica Kemiri secukupnya"
- "Kecap secukupnya"
- "Daun bawang 1 batang"
- "Telur 1 butir"
- "Timun  tomat 1 buah"
recipeinstructions:
- "Cuci ati lalu rebus -+10/15menit beri sedikit garam, sembari menunggu potong bawang merah tipis2, Potong ati lalu goreng &amp; bawang Goreng juga sisihkan"
- "Potong2 Daun Bawang, Lalu uleg bumbu bawang putih, kemiri, merica, garam, sisihkan"
- "Goreng telur, setelah matang masukan bumbu ditumis dan daun bawang lalu nasi ati goreng lalu beri kecap secukupnya aduk sampai campur dan matang, koreksi rasa lalu...."
- "Sajikan dengan bawang goreng dan timun / tomat"
categories:
- Resep
tags:
- nasi
- goreng
- ati

katakunci: nasi goreng ati 
nutrition: 128 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT59M"
recipeyield: "2"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Goreng Ati Semarang](https://img-global.cpcdn.com/recipes/0ccf5d8fe3745ea5/682x484cq65/nasi-goreng-ati-semarang-foto-resep-utama.webp)

Resep rahasia Nasi Goreng Ati Semarang  enak dengan 4 langkahcepat cocok banget jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Dalam Pembuatan Nasi Goreng Ati Semarang:

1. Nasi 1 piring
1. Ati ayam 1 potong
1. Bawang putih 2 siung
1. bawang merah 3 siung
1. Grm Mrica Kemiri secukupnya
1. Kecap secukupnya
1. Daun bawang 1 batang
1. Telur 1 butir
1. Timun  tomat 1 buah



<!--inarticleads2-->

## Tata Cara Membuat Nasi Goreng Ati Semarang:

1. Cuci ati lalu rebus -+10/15menit beri sedikit garam, sembari menunggu potong bawang merah tipis2, Potong ati lalu goreng &amp; bawang Goreng juga sisihkan
1. Potong2 Daun Bawang, Lalu uleg bumbu bawang putih, kemiri, merica, garam, sisihkan
1. Goreng telur, setelah matang masukan bumbu ditumis dan daun bawang lalu nasi ati goreng lalu beri kecap secukupnya aduk sampai campur dan matang, koreksi rasa lalu....
1. Sajikan dengan bawang goreng dan timun / tomat




Selamat memasak dan menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
