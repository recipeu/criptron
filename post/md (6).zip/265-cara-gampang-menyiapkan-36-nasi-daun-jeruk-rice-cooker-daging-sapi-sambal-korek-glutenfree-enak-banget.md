---
description: "Cara Gampang Menyiapkan 36. Nasi Daun Jeruk (Rice Cooker) + Daging Sapi Sambal Korek #GlutenFree, Enak Banget"
title: "Cara Gampang Menyiapkan 36. Nasi Daun Jeruk (Rice Cooker) + Daging Sapi Sambal Korek #GlutenFree, Enak Banget"
slug: 265-cara-gampang-menyiapkan-36-nasi-daun-jeruk-rice-cooker-daging-sapi-sambal-korek-glutenfree-enak-banget
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-16T17:58:22.771Z 
thumbnail: https://img-global.cpcdn.com/recipes/1e53924fe9f72be1/682x484cq65/36-nasi-daun-jeruk-rice-cooker-daging-sapi-sambal-korek-glutenfree-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/1e53924fe9f72be1/682x484cq65/36-nasi-daun-jeruk-rice-cooker-daging-sapi-sambal-korek-glutenfree-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/1e53924fe9f72be1/682x484cq65/36-nasi-daun-jeruk-rice-cooker-daging-sapi-sambal-korek-glutenfree-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/1e53924fe9f72be1/682x484cq65/36-nasi-daun-jeruk-rice-cooker-daging-sapi-sambal-korek-glutenfree-foto-resep-utama.webp
author: Joel Long
ratingvalue: 3
reviewcount: 12
recipeingredient:
- "Nasi Daun jeruk "
- "Beras 1 cup"
- "daun jeruk buang batang potong halus 8"
- "bawang putih cincang 4 siung"
- "garam 1/2 sdt"
- "gula 1/2 sdt"
- "lada 1/2 sdt"
- "Air secukupnya"
- "Daging sapi goreng tepung "
- "Tepung bumbu serbaguna gluten free "
- "Air "
- "Sambal korek "
- "cabe rawit merah 5"
- "bawang putih 1 siung"
- "bawang merah 2 siung"
- "cabe keriting 1"
- "sdt garam 1 sdt"
- "gula 1 sdt"
- "kaldu jamur 1/2 sdt"
- "Minyak secukupnya"
recipeinstructions:
- "NASI DAUN JERUK : Masukan daun jeruk yang sudah dipotong halus dan bawang putih cincang ke minyak yg sudah dipanaskan. Aduk rata sampai kecoklatan dan harum."
- "Cuci bersih beras, masukan beras ke dalam bawang putih dan daun jeruk, aduk sebentar sampai rata. Lalu masukan gula, garam, lada. Koreksi rasa (gurih)."
- "Matikan api, lalu masukan air secukupnya (saya suka nasi gak lembek, kira-kira seperti di gambar). Lalu masukan ke rice cooker dan tunggu hingga matang."
- "DAGING SAPI GORENG TEPUNG : Masukan daging yg sudah direbus ke dalam tepung basah dan tepung kering. Sisihkan."
- "Goreng hingga kecoklatan, sebentar aja, karena daging sudah matang."
- "SAMBAL KOREK : Tumbuk kasar/blender kasar cabai dan bawang. Lalu masukan gula, garam, kaldu jamur."
- "Tuang minyak panas sisa goreng daging, sampai cabe berbuih dan artinya matang."
- "Tinggal disatuin deh bun, rasanya gurih dan enak bgt. Selamat mencoba!"
categories:
- Resep
tags:
- 36
- nasi
- daun

katakunci: 36 nasi daun 
nutrition: 132 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT51M"
recipeyield: "1"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![36. Nasi Daun Jeruk (Rice Cooker) + Daging Sapi Sambal Korek #GlutenFree](https://img-global.cpcdn.com/recipes/1e53924fe9f72be1/682x484cq65/36-nasi-daun-jeruk-rice-cooker-daging-sapi-sambal-korek-glutenfree-foto-resep-utama.webp)

Ingin membuat 36. Nasi Daun Jeruk (Rice Cooker) + Daging Sapi Sambal Korek #GlutenFree ? Coba resep berikut ini. Cara memasaknya sangat praktis namun jangan kaget jika hasilnya gurih dan lezat yang musti kamu coba segera

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Dalam Pembuatan 36. Nasi Daun Jeruk (Rice Cooker) + Daging Sapi Sambal Korek #GlutenFree:

1. Nasi Daun jeruk 
1. Beras 1 cup
1. daun jeruk buang batang potong halus 8
1. bawang putih cincang 4 siung
1. garam 1/2 sdt
1. gula 1/2 sdt
1. lada 1/2 sdt
1. Air secukupnya
1. Daging sapi goreng tepung 
1. Tepung bumbu serbaguna gluten free 
1. Air 
1. Sambal korek 
1. cabe rawit merah 5
1. bawang putih 1 siung
1. bawang merah 2 siung
1. cabe keriting 1
1. sdt garam 1 sdt
1. gula 1 sdt
1. kaldu jamur 1/2 sdt
1. Minyak secukupnya



<!--inarticleads2-->

## Langkah-langkah Untuk Membuat 36. Nasi Daun Jeruk (Rice Cooker) + Daging Sapi Sambal Korek #GlutenFree:

1. NASI DAUN JERUK : Masukan daun jeruk yang sudah dipotong halus dan bawang putih cincang ke minyak yg sudah dipanaskan. Aduk rata sampai kecoklatan dan harum.
1. Cuci bersih beras, masukan beras ke dalam bawang putih dan daun jeruk, aduk sebentar sampai rata. Lalu masukan gula, garam, lada. Koreksi rasa (gurih).
1. Matikan api, lalu masukan air secukupnya (saya suka nasi gak lembek, kira-kira seperti di gambar). Lalu masukan ke rice cooker dan tunggu hingga matang.
1. DAGING SAPI GORENG TEPUNG : Masukan daging yg sudah direbus ke dalam tepung basah dan tepung kering. Sisihkan.
1. Goreng hingga kecoklatan, sebentar aja, karena daging sudah matang.
1. SAMBAL KOREK : Tumbuk kasar/blender kasar cabai dan bawang. Lalu masukan gula, garam, kaldu jamur.
1. Tuang minyak panas sisa goreng daging, sampai cabe berbuih dan artinya matang.
1. Tinggal disatuin deh bun, rasanya gurih dan enak bgt. Selamat mencoba!




Demikian informasi  resep 36. Nasi Daun Jeruk (Rice Cooker) + Daging Sapi Sambal Korek #GlutenFree   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
