---
description: "Resep Nasi Daun Jeruk yang Enak"
title: "Resep Nasi Daun Jeruk yang Enak"
slug: 304-resep-nasi-daun-jeruk-yang-enak
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-27T01:14:33.810Z 
thumbnail: https://img-global.cpcdn.com/recipes/540d1df988227612/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/540d1df988227612/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/540d1df988227612/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/540d1df988227612/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
author: Mollie Baker
ratingvalue: 3
reviewcount: 15
recipeingredient:
- "Nasi secukupnya sesuai selera "
- "daun jeruk 10 buah"
- "bawang putih cincang halus 3 siung"
- "margarin 2-3 sdm"
- "kaldu jamur secukupnya"
recipeinstructions:
- "Cincang bawang putih"
- "Iris tipis daun jeruk, buang tulang daunnya agar engga pahit"
- "Tumis bawang putih margarin"
- "Tmabahkan daun jeruk aduk2 lalu masukkan kaldu jamur"
- "Masukkan ke dalam nasi magic com yg sudah matang, aduk2 lalu icipi dan sajikan"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 170 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT41M"
recipeyield: "2"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk](https://img-global.cpcdn.com/recipes/540d1df988227612/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp)

Resep rahasia dan cara mengolah  Nasi Daun Jeruk cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Dalam Pembuatan Nasi Daun Jeruk:

1. Nasi secukupnya sesuai selera 
1. daun jeruk 10 buah
1. bawang putih cincang halus 3 siung
1. margarin 2-3 sdm
1. kaldu jamur secukupnya

Nasi daun jeruk siap dihidangkan dengan. Nasi daun jeruk ini memang sedang tren di kalangan masyarakat Indonesia, banyak sekali kaum muda mudi yang berlomba-lomba membuat makanan nasi putih spesial ini. Nasi daun jeruk ala geprek bensu rekomended buat di coba. Geprek bensu nasi daun jeruk anti mainst. 

<!--inarticleads2-->

## Langkah-langkah Untuk Menyiapkan Nasi Daun Jeruk:

1. Cincang bawang putih
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/a3fc49ff54484265/160x128cq70/nasi-daun-jeruk-langkah-memasak-1-foto.webp" alt="Nasi Daun Jeruk" width="340" height="340">
>1. Iris tipis daun jeruk, buang tulang daunnya agar engga pahit
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/af692f416a65dffd/160x128cq70/nasi-daun-jeruk-langkah-memasak-2-foto.webp" alt="Nasi Daun Jeruk" width="340" height="340">
>1. Tumis bawang putih margarin
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/cab71dfacb4d68c3/160x128cq70/nasi-daun-jeruk-langkah-memasak-3-foto.webp" alt="Nasi Daun Jeruk" width="340" height="340">
>1. Tmabahkan daun jeruk aduk2 lalu masukkan kaldu jamur
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/5a290784b5020fb8/160x128cq70/nasi-daun-jeruk-langkah-memasak-4-foto.webp" alt="Nasi Daun Jeruk" width="340" height="340">
>1. Masukkan ke dalam nasi magic com yg sudah matang, aduk2 lalu icipi dan sajikan
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/994f9ee3f90f7cad/160x128cq70/nasi-daun-jeruk-langkah-memasak-5-foto.webp" alt="Nasi Daun Jeruk" width="340" height="340">
>

Gurih dan wangi dari daun jeruk menambah kelezatan nasi daun jeruk. Nasi dengan campuran daun jeruk yang wangi sedang tren. Hai selamat pagi sahabat CWS, pagi ini saya share resep Nasi Daun Jeruk. Praktis banget karena saya gunakan rice cooker. Rasanya mirip nasi uduk tapi wangiiii. 

Terima kasih telah menggunakan resep yang kami tampilkan di sini. Semoga bermanfaat dan selamat mencoba!
