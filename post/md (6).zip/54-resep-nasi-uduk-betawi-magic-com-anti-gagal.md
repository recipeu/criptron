---
description: "Resep Nasi Uduk Betawi (Magic Com) Anti Gagal"
title: "Resep Nasi Uduk Betawi (Magic Com) Anti Gagal"
slug: 54-resep-nasi-uduk-betawi-magic-com-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-22T03:38:06.750Z 
thumbnail: https://img-global.cpcdn.com/recipes/e5ae4738b23f01f1/682x484cq65/nasi-uduk-betawi-magic-com-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/e5ae4738b23f01f1/682x484cq65/nasi-uduk-betawi-magic-com-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/e5ae4738b23f01f1/682x484cq65/nasi-uduk-betawi-magic-com-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/e5ae4738b23f01f1/682x484cq65/nasi-uduk-betawi-magic-com-foto-resep-utama.webp
author: Rena Schmidt
ratingvalue: 3.8
reviewcount: 8
recipeingredient:
- "beras pulen cuci bersih seperti biasa memasak beras 2 cup"
- "santan instan 100 ml"
- "air disesuaikan dengan magic com masingmasing 4 cup"
- "bawang merah parut 5 siung"
- "jahe parut 1 ruas"
- "sereh geprek lebih banyak lebih wangi dan sedap 3 batang"
- "lengkuas geprek 1 ruas"
- "daun salam sobeksobek 7 lembar"
- "kayumanis bubuk bisa pakai batang lebih bagus 2 sdt"
- "garam sesuai selera 1 sdm"
- "kaldu bubuk Sejumput"
recipeinstructions:
- "Cuci bersih beras seperti biasa memasak beras. Tambahkan santan cair dan air."
- "Masukan bawang merah dan jahe serut. Tambahkan kayu manis. Kemudian tambahkan juga kaldu bubuk dan garam."
- "Pencet tombol memasak (sesuai dengan cara memasak magic com masing-masing ya) sampai berbunyi jegleg (matang)"
- "Sisihkan bumbu dapur. Siap dihidangkan dengan menu pelengkap seperti semur daging, bihun goreng, tempe orek dan sambal kacang."
- "Resep bihun goreng           (lihat resep)"
- "Resep tempe orek           (lihat resep)"
- "Resep semur daging           (lihat resep)"
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 217 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT46M"
recipeyield: "4"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Betawi (Magic Com)](https://img-global.cpcdn.com/recipes/e5ae4738b23f01f1/682x484cq65/nasi-uduk-betawi-magic-com-foto-resep-utama.webp)

Resep rahasia Nasi Uduk Betawi (Magic Com)    dengan 7 langkahcepat dan mudah cocok banget jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Untuk Pembuatan Nasi Uduk Betawi (Magic Com):

1. beras pulen cuci bersih seperti biasa memasak beras 2 cup
1. santan instan 100 ml
1. air disesuaikan dengan magic com masingmasing 4 cup
1. bawang merah parut 5 siung
1. jahe parut 1 ruas
1. sereh geprek lebih banyak lebih wangi dan sedap 3 batang
1. lengkuas geprek 1 ruas
1. daun salam sobeksobek 7 lembar
1. kayumanis bubuk bisa pakai batang lebih bagus 2 sdt
1. garam sesuai selera 1 sdm
1. kaldu bubuk Sejumput



<!--inarticleads2-->

## Tata Cara Menyiapkan Nasi Uduk Betawi (Magic Com):

1. Cuci bersih beras seperti biasa memasak beras. Tambahkan santan cair dan air.
1. Masukan bawang merah dan jahe serut. Tambahkan kayu manis. Kemudian tambahkan juga kaldu bubuk dan garam.
1. Pencet tombol memasak (sesuai dengan cara memasak magic com masing-masing ya) sampai berbunyi jegleg (matang)
1. Sisihkan bumbu dapur. Siap dihidangkan dengan menu pelengkap seperti semur daging, bihun goreng, tempe orek dan sambal kacang.
1. Resep bihun goreng -           (lihat resep)
1. Resep tempe orek -           (lihat resep)
1. Resep semur daging -           (lihat resep)




Selamat memasak dan menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
