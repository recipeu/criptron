---
description: "Resep Nasi uduk magic com, Sempurna"
title: "Resep Nasi uduk magic com, Sempurna"
slug: 158-resep-nasi-uduk-magic-com-sempurna
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-18T08:36:46.555Z 
thumbnail: https://img-global.cpcdn.com/recipes/293ba0384d1d2f29/682x484cq65/nasi-uduk-magic-com-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/293ba0384d1d2f29/682x484cq65/nasi-uduk-magic-com-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/293ba0384d1d2f29/682x484cq65/nasi-uduk-magic-com-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/293ba0384d1d2f29/682x484cq65/nasi-uduk-magic-com-foto-resep-utama.webp
author: Tyler Myers
ratingvalue: 4
reviewcount: 11
recipeingredient:
- "beras 4 cup"
- "santan instan 65 ml 1 bks"
- "air 6 cup"
- "garam 3 sdt"
- "daun jeruk sobek 3 lembar"
- "daun salam sobek 3 lembar"
- "sereh geprek 2 batang"
- "lengkuas geprek 3 cm"
- "sg bwg merah geprek 2"
- "sg bwg putih geprek 1"
recipeinstructions:
- "Siapkan bumbu cemplung, geprek bawang, sereh, dan lengkuas, robek daun salam dan daun jeruk"
- "Tambahkan bumbu cemplung ke beras yang sudah dicuci bersih, masukkan air dan santan. Tambahkan 3 sdt garam, aduk rata. Masak di rice cooker"
- "Setelah nasi matang, buka rice cooker dan aduk2 nasi"
- "Nasi uduk siap disajikan dengan pelengkap sesuai selera"
categories:
- Resep
tags:
- nasi
- uduk
- magic

katakunci: nasi uduk magic 
nutrition: 286 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT58M"
recipeyield: "4"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi uduk magic com](https://img-global.cpcdn.com/recipes/293ba0384d1d2f29/682x484cq65/nasi-uduk-magic-com-foto-resep-utama.webp)

Resep Nasi uduk magic com  sederhana dengan 4 langkahmudah dan cepat cocok sekali jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Dalam Pembuatan Nasi uduk magic com:

1. beras 4 cup
1. santan instan 65 ml 1 bks
1. air 6 cup
1. garam 3 sdt
1. daun jeruk sobek 3 lembar
1. daun salam sobek 3 lembar
1. sereh geprek 2 batang
1. lengkuas geprek 3 cm
1. sg bwg merah geprek 2
1. sg bwg putih geprek 1

Cara membuatnya memang tidak terlalu sulit namun tidak gampang juga. Siapkan piring saji lalu tata nasi uduk beserta lauk pelengkap nya seperti semur jengkol, bihun goreng,telur balado &amp; orek tempe. Paling terkenal nasi uduk kebun kacang di wilayah kami. Ditambah ayam goreng atau lele goreng dengan sayuran lalapan membuat rasa nasi uduk Kata orang Jakarta, ente belom ke Jakarta bila belum menikmati nasi uduk kebon kacang. 

<!--inarticleads2-->

## Cara Membuat Nasi uduk magic com:

1. Siapkan bumbu cemplung, geprek bawang, sereh, dan lengkuas, robek daun salam dan daun jeruk
1. Tambahkan bumbu cemplung ke beras yang sudah dicuci bersih, masukkan air dan santan. Tambahkan 3 sdt garam, aduk rata. Masak di rice cooker
1. Setelah nasi matang, buka rice cooker dan aduk2 nasi
1. Nasi uduk siap disajikan dengan pelengkap sesuai selera


Setiap hari selalu saja ada orang yang datang menyantap. KOMPAS.com - Nasi uduk umumnya berwarna putih, dari warna asli beras dan santan kelapa. Namun, nasi uduk juga bisa dibuat dengan tampilan berbeda, misalnya jadi berwarna hijau. Umumnya pada masakan tradisional menggunakan daun suji sebagai pewarna hijau. Paling terkenal nasi uduk kebun kacang di wilayah kami. 

Terima kasih telah membaca resep yang tim kami tampilkan di sini. Selamat mencoba!
