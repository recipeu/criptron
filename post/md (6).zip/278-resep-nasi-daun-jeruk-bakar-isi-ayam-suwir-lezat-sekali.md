---
description: "Resep NASI DAUN JERUK BAKAR isi AYAM SUWIR, Lezat Sekali"
title: "Resep NASI DAUN JERUK BAKAR isi AYAM SUWIR, Lezat Sekali"
slug: 278-resep-nasi-daun-jeruk-bakar-isi-ayam-suwir-lezat-sekali
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-16T02:30:45.671Z 
thumbnail: https://img-global.cpcdn.com/recipes/d7c8b0997c8ff00b/682x484cq65/nasi-daun-jeruk-bakar-isi-ayam-suwir-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/d7c8b0997c8ff00b/682x484cq65/nasi-daun-jeruk-bakar-isi-ayam-suwir-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/d7c8b0997c8ff00b/682x484cq65/nasi-daun-jeruk-bakar-isi-ayam-suwir-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/d7c8b0997c8ff00b/682x484cq65/nasi-daun-jeruk-bakar-isi-ayam-suwir-foto-resep-utama.webp
author: Adelaide Higgins
ratingvalue: 3.6
reviewcount: 7
recipeingredient:
- "Bahan nasi daun jeruk  "
- "beras 4 cup"
- "baput cincang halus 4"
- "daun jeruk buang tulang iris tipis 10"
- "serai geprek 2 batang"
- "kaldu jamur 2 sdm"
- "garam 1 sdt"
- "air secukupnya sesuai takaran memasak nasi "
- "daun pisang secukupnya bersihkan dan jemur sebelum digunakan "
- "Bahan ayam suwir  "
- "ayam fillet potong kecil panjang 400 gr"
- "cabe rawit merah 10"
- "bamer iris tipis 5"
- "baput iris tipis 4"
- "kecap manis 5 sdm"
- "saos tiram 1 sdm"
- "kaldu jamur 1 sdm"
- "parsley bisa diganti daun kemangi "
- "lada "
- "garam "
- "Bahan pelengkap  "
- "sambal goreng ati kentang "
- "selada "
- "timun potongan"
- "kerupuk "
recipeinstructions:
- "Tumis baput hingga agak coklat dan harum, sisihkan"
- "Cuci bersih beras, lalu masukkan wadah magic com, beri air sesuai takaran menanak nasi"
- "Tambahkan tumisan baput, daun jeruk, kaldu jamur, serai dan garam, masak hingga matang, sisihkan"
- "Tumis baput dan bamer hingga harum, masukkan ayam dan masak hingga berubah warna"
- "Tambahkan cabe rawit utuh, kecap manis, saos tiram, kaldu jamur, lada, garam serta parsley secukupnya, masak hingga bumbu meresap (bian : sengaja cabe tidak dipotong potong agar tidak pedas karena buat makan bocah kicik)"
- "Tes dan koreksi rasa, matikan kompor"
- "Tata nasi diatas daun pisang, lalu tambahkan suwiran ayam dan bungkus sematkan dengan lidi, lakukan hingga bahan habis"
- "Panggang bungkusan nasi diatas teflon/happy call hingga daun kecoklatan, angkat"
- "Sajikan bersama sambal goreng ati kentang, selada, potongan timun serta kerupuk Selamat mencoba"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 123 calories
recipecuisine: Indonesian
preptime: "PT20M"
cooktime: "PT38M"
recipeyield: "3"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![NASI DAUN JERUK BAKAR isi AYAM SUWIR](https://img-global.cpcdn.com/recipes/d7c8b0997c8ff00b/682x484cq65/nasi-daun-jeruk-bakar-isi-ayam-suwir-foto-resep-utama.webp)

9 langkah cepat dan mudah membuat  NASI DAUN JERUK BAKAR isi AYAM SUWIR cocok sekali jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Dalam Menyiapkan NASI DAUN JERUK BAKAR isi AYAM SUWIR:

1. Bahan nasi daun jeruk  
1. beras 4 cup
1. baput cincang halus 4
1. daun jeruk buang tulang iris tipis 10
1. serai geprek 2 batang
1. kaldu jamur 2 sdm
1. garam 1 sdt
1. air secukupnya sesuai takaran memasak nasi 
1. daun pisang secukupnya bersihkan dan jemur sebelum digunakan 
1. Bahan ayam suwir  
1. ayam fillet potong kecil panjang 400 gr
1. cabe rawit merah 10
1. bamer iris tipis 5
1. baput iris tipis 4
1. kecap manis 5 sdm
1. saos tiram 1 sdm
1. kaldu jamur 1 sdm
1. parsley bisa diganti daun kemangi 
1. lada 
1. garam 
1. Bahan pelengkap  
1. sambal goreng ati kentang 
1. selada 
1. timun potongan
1. kerupuk 

Aduk rata, masak sampai Taruh nasi secukupnya lalu beri isian ayam suwir di atasnya. Tutup dan gulung nasi pada daun pisang. Sepertinya enak membuat nasi bakar isi ayam suwir khas Bali. Dengan wangi daun jeruk, cita rasa yang cenderung pedas dan guriiiih, hmm …. baru membayangkan saja rasanya sudah nikmat. 

<!--inarticleads2-->

## Cara Mudah Menyiapkan NASI DAUN JERUK BAKAR isi AYAM SUWIR:

1. Tumis baput hingga agak coklat dan harum, sisihkan
1. Cuci bersih beras, lalu masukkan wadah magic com, beri air sesuai takaran menanak nasi
1. Tambahkan tumisan baput, daun jeruk, kaldu jamur, serai dan garam, masak hingga matang, sisihkan
1. Tumis baput dan bamer hingga harum, masukkan ayam dan masak hingga berubah warna
1. Tambahkan cabe rawit utuh, kecap manis, saos tiram, kaldu jamur, lada, garam serta parsley secukupnya, masak hingga bumbu meresap - (bian : sengaja cabe tidak dipotong potong agar tidak pedas karena buat makan bocah kicik)
1. Tes dan koreksi rasa, matikan kompor
1. Tata nasi diatas daun pisang, lalu tambahkan suwiran ayam dan bungkus sematkan dengan lidi, lakukan hingga bahan habis
1. Panggang bungkusan nasi diatas teflon/happy call hingga daun kecoklatan, angkat
1. Sajikan bersama sambal goreng ati kentang, selada, potongan timun serta kerupuk - Selamat mencoba


Pada dasarnya resep yang digunakan masih sama dengan resep ayam suwir khas Bali yang pernah saya. Nasi bakar dengan aroma kemangi dan isi daging ayam yang lezat dapat anda coba resepnya di rumah, Inilah resep dan tutorialnya untuk anda. Selanjutnya panaskan minyak wijen untuk menumis. Nasi bakar adalah masakan khas Indonesia yang bisa dijumpai dimana saja, terutama Pulau Jawa. Rebus ayam dengan selembar daun salam hingga matang. 

Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
