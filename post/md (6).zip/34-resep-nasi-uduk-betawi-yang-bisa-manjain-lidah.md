---
description: "Resep Nasi Uduk Betawi yang Bisa Manjain Lidah"
title: "Resep Nasi Uduk Betawi yang Bisa Manjain Lidah"
slug: 34-resep-nasi-uduk-betawi-yang-bisa-manjain-lidah
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-10T18:24:32.727Z 
thumbnail: https://img-global.cpcdn.com/recipes/b1e323f48ae6610b/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/b1e323f48ae6610b/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/b1e323f48ae6610b/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/b1e323f48ae6610b/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
author: Lydia Ingram
ratingvalue: 4.3
reviewcount: 4
recipeingredient:
- "beras 1 liter"
- "santan kental 800 ml"
- "daun pandan 2 lembar"
- "serai geprek 2 batang"
- "daun salam 3 lembar"
- "bawang merah iris halus 5 siung"
- "merica bubuk 1 sdm"
- "biji pala parut  geprek 1 buah"
- "minyak bawang merah minyak bekas goreng bawang merah 1,5 sdm"
- "garam 1/2-1 sdm"
- "kaldu bubuk optional Secukupnya"
recipeinstructions:
- "Masak santan, daun pandan, daun salam, serai, biji pala, bawang merah iris dan merica bubuk hingga mendidih"
- "Setelah mendidih masukkan garam, kaldu bubuk dan minyak bawang merah. Lalu tes rasa,jika rasa sudah oke, masukkan beras yang sudah dicuci hingga menjadi aron."
- "Panaskan kukusan, jika nasi Uduk ingin beraroma rempah, maka masukkan 5 buah cengkeh kedalam air kukusan. Setelah kukusan panas, kukus nasi hingga matang sekitar 45-60menit."
- "Nasi uduk siap dihidangkan."
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 138 calories
recipecuisine: Indonesian
preptime: "PT38M"
cooktime: "PT39M"
recipeyield: "2"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Betawi](https://img-global.cpcdn.com/recipes/b1e323f48ae6610b/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp)

Resep dan cara memasak  Nasi Uduk Betawi yang harus ibu coba segera

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Dalam Pembuatan Nasi Uduk Betawi:

1. beras 1 liter
1. santan kental 800 ml
1. daun pandan 2 lembar
1. serai geprek 2 batang
1. daun salam 3 lembar
1. bawang merah iris halus 5 siung
1. merica bubuk 1 sdm
1. biji pala parut  geprek 1 buah
1. minyak bawang merah minyak bekas goreng bawang merah 1,5 sdm
1. garam 1/2-1 sdm
1. kaldu bubuk optional Secukupnya



<!--inarticleads2-->

## Cara Mudah Menyiapkan Nasi Uduk Betawi:

1. Masak santan, daun pandan, daun salam, serai, biji pala, bawang merah iris dan merica bubuk hingga mendidih
1. Setelah mendidih masukkan garam, kaldu bubuk dan minyak bawang merah. Lalu tes rasa,jika rasa sudah oke, masukkan beras yang sudah dicuci hingga menjadi aron.
1. Panaskan kukusan, jika nasi Uduk ingin beraroma rempah, maka masukkan 5 buah cengkeh kedalam air kukusan. Setelah kukusan panas, kukus nasi hingga matang sekitar 45-60menit.
1. Nasi uduk siap dihidangkan.




Terima kasih telah membaca resep yang tim kami tampilkan di sini. Semoga bermanfaat dan selamat mencoba!
