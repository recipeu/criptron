---
description: "Resep Nasi Daun Jeruk Sederhana (Tanpa Santan Tanpa Magic com) yang Enak Banget"
title: "Resep Nasi Daun Jeruk Sederhana (Tanpa Santan Tanpa Magic com) yang Enak Banget"
slug: 271-resep-nasi-daun-jeruk-sederhana-tanpa-santan-tanpa-magic-com-yang-enak-banget
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-26T06:08:58.101Z 
thumbnail: https://img-global.cpcdn.com/recipes/6b9b9594ccbf5781/682x484cq65/nasi-daun-jeruk-sederhana-tanpa-santan-tanpa-magic-com-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/6b9b9594ccbf5781/682x484cq65/nasi-daun-jeruk-sederhana-tanpa-santan-tanpa-magic-com-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/6b9b9594ccbf5781/682x484cq65/nasi-daun-jeruk-sederhana-tanpa-santan-tanpa-magic-com-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/6b9b9594ccbf5781/682x484cq65/nasi-daun-jeruk-sederhana-tanpa-santan-tanpa-magic-com-foto-resep-utama.webp
author: Elmer Bryant
ratingvalue: 5
reviewcount: 15
recipeingredient:
- "yang sudah jadi 5 centong nasi"
- "bawang putih 4 siung"
- "daun jeruk 20 lembar"
- "garam kaldu bubuk ayamsapijamur Secukupnya"
recipeinstructions:
- "Cincang halus bawang putih dan iris memanjang daun jeruk. (TIPS: buang tulang daun jeruk agar tidak pahit)"
- "Panaskan wajan. Tumis sebentar bawang putih kemudian masukkan daun jeruk. (TIPS: gunakan api kecil, jangan sampai bawang putih gosong)."
- "Matikan api kompor. Masukkan nasi putih. Tambahkan sedikit saja garam, secukupnya kaldu bubuk jika berkenan. Aduk merata."
- "Nasi Daun Jeruk siap disajikan dengan lauk kesukaan anda 😄👍🏻"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 255 calories
recipecuisine: Indonesian
preptime: "PT20M"
cooktime: "PT34M"
recipeyield: "3"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk Sederhana (Tanpa Santan Tanpa Magic com)](https://img-global.cpcdn.com/recipes/6b9b9594ccbf5781/682x484cq65/nasi-daun-jeruk-sederhana-tanpa-santan-tanpa-magic-com-foto-resep-utama.webp)

Resep rahasia Nasi Daun Jeruk Sederhana (Tanpa Santan Tanpa Magic com)  sederhana dengan 4 langkahmudah yang wajib ibu coba segera

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Untuk Menyiapkan Nasi Daun Jeruk Sederhana (Tanpa Santan Tanpa Magic com):

1. yang sudah jadi 5 centong nasi
1. bawang putih 4 siung
1. daun jeruk 20 lembar
1. garam kaldu bubuk ayamsapijamur Secukupnya



<!--inarticleads2-->

## Cara Membuat Nasi Daun Jeruk Sederhana (Tanpa Santan Tanpa Magic com):

1. Cincang halus bawang putih dan iris memanjang daun jeruk. (TIPS: buang tulang daun jeruk agar tidak pahit)
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/69c89b7406ca0790/160x128cq70/nasi-daun-jeruk-sederhana-tanpa-santan-tanpa-magic-com-langkah-memasak-1-foto.webp" alt="Nasi Daun Jeruk Sederhana (Tanpa Santan Tanpa Magic com)" width="340" height="340">
>1. Panaskan wajan. Tumis sebentar bawang putih kemudian masukkan daun jeruk. (TIPS: gunakan api kecil, jangan sampai bawang putih gosong).
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/6d046db3c26dc563/160x128cq70/nasi-daun-jeruk-sederhana-tanpa-santan-tanpa-magic-com-langkah-memasak-2-foto.webp" alt="Nasi Daun Jeruk Sederhana (Tanpa Santan Tanpa Magic com)" width="340" height="340">
><img class="lazyload" data-src="https://img-global.cpcdn.com/steps/aebd82c4194ef57a/160x128cq70/nasi-daun-jeruk-sederhana-tanpa-santan-tanpa-magic-com-langkah-memasak-2-foto.webp" alt="Nasi Daun Jeruk Sederhana (Tanpa Santan Tanpa Magic com)" width="340" height="340">
>1. Matikan api kompor. Masukkan nasi putih. Tambahkan sedikit saja garam, secukupnya kaldu bubuk jika berkenan. Aduk merata.
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/d4328e7a75d13d03/160x128cq70/nasi-daun-jeruk-sederhana-tanpa-santan-tanpa-magic-com-langkah-memasak-3-foto.webp" alt="Nasi Daun Jeruk Sederhana (Tanpa Santan Tanpa Magic com)" width="340" height="340">
>1. Nasi Daun Jeruk siap disajikan dengan lauk kesukaan anda 😄👍🏻
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/ff4f27f44f5ec30b/160x128cq70/nasi-daun-jeruk-sederhana-tanpa-santan-tanpa-magic-com-langkah-memasak-4-foto.webp" alt="Nasi Daun Jeruk Sederhana (Tanpa Santan Tanpa Magic com)" width="340" height="340">
>



Selamat memasak dan menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
