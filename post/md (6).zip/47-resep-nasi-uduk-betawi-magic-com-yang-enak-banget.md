---
description: "Resep Nasi uduk Betawi (magic com) yang Enak Banget"
title: "Resep Nasi uduk Betawi (magic com) yang Enak Banget"
slug: 47-resep-nasi-uduk-betawi-magic-com-yang-enak-banget
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-27T15:03:01.916Z 
thumbnail: https://img-global.cpcdn.com/recipes/8dce8381472d65eb/682x484cq65/nasi-uduk-betawi-magic-com-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/8dce8381472d65eb/682x484cq65/nasi-uduk-betawi-magic-com-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/8dce8381472d65eb/682x484cq65/nasi-uduk-betawi-magic-com-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/8dce8381472d65eb/682x484cq65/nasi-uduk-betawi-magic-com-foto-resep-utama.webp
author: Cody Nichols
ratingvalue: 3.4
reviewcount: 13
recipeingredient:
- "beras cup magic com 4 cup"
- "santan kara 65 ml"
- "bawang merah dihaluskan 2 siung"
- "daun pandan ikat simpul 2 lembar"
- "daun salam 5 lembar"
- "serai 2 batang"
- "kayu manis sepanjang jari kelingking 1 batang"
- "garam 1 sdt"
- "kaldu bubuk 1 sdt"
- "air banyaknya air sama seperti masak nasi biasa 600 ml"
recipeinstructions:
- "Cuci bersih beras lalu tuang kedalam panci magic com tambahkan bawang merah yg sudah dihaluskan,daun pandan,daun salam,serai yg telah di memarkan,garam,kaldu bubuk,santan &amp; air lalu aduk rata"
- "Masak seperti biasa dimagic com tekan tombol cook setelah bunyi klik / matang aduk nasi hati2 uap panasnya lalu biarkan tunggu sampai 15-30 menit nasi matang dengan sempurna / Tanak aduk kembali buang daun2an &amp; rempah."
- "Siapkan piring saji lalu tata nasi uduk beserta lauk pelengkap nya seperti semur jengkol, bihun goreng,telur balado &amp; orek tempe"
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 273 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT39M"
recipeyield: "4"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi uduk Betawi (magic com)](https://img-global.cpcdn.com/recipes/8dce8381472d65eb/682x484cq65/nasi-uduk-betawi-magic-com-foto-resep-utama.webp)

Resep rahasia dan cara memasak  Nasi uduk Betawi (magic com) yang harus bunda coba dirumah

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Untuk Menyiapkan Nasi uduk Betawi (magic com):

1. beras cup magic com 4 cup
1. santan kara 65 ml
1. bawang merah dihaluskan 2 siung
1. daun pandan ikat simpul 2 lembar
1. daun salam 5 lembar
1. serai 2 batang
1. kayu manis sepanjang jari kelingking 1 batang
1. garam 1 sdt
1. kaldu bubuk 1 sdt
1. air banyaknya air sama seperti masak nasi biasa 600 ml

Setiap daerah punya menunya masing-masing dan ada yang diaduk. Kalau di Jakarta akan lebih nikmat dengan semur tahu dan semur jengkol. Menggunakan magic com, kita bisa membuat nasi uduk yang enak. Salah satunya nasi uduk yang punya rasa gurih dan tidak lengket. 

<!--inarticleads2-->

## Langkah-langkah Untuk Menyiapkan Nasi uduk Betawi (magic com):

1. Cuci bersih beras lalu tuang kedalam panci magic com tambahkan bawang merah yg sudah dihaluskan,daun pandan,daun salam,serai yg telah di memarkan,garam,kaldu bubuk,santan &amp; air lalu aduk rata
1. Masak seperti biasa dimagic com tekan tombol cook setelah bunyi klik / matang aduk nasi hati2 uap panasnya lalu biarkan tunggu sampai 15-30 menit nasi matang dengan sempurna / Tanak aduk kembali buang daun2an &amp; rempah.
1. Siapkan piring saji lalu tata nasi uduk beserta lauk pelengkap nya seperti semur jengkol, bihun goreng,telur balado &amp; orek tempe


Dipadukan dengan lauk apa pun juga makin nikmat. Nah, kali ini IDN Times akan bagikan kamu beberapa resep nasi uduk dan cara membuatnya yang enak dan. Nasi Uduk Betawi Rice Cooker praktis,anti gagal dan enak ~ Memang saat ini sedang banyak dicari oleh teman-teman disekitar kita, salah. Padahal nasi uduk magic com yang enak harusnya sih memiliki aroma dan rasa yang bisa memancing selera kita. Tak perlu pusing kalau mau menyiapkan nasi uduk magic com enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat menjadi sajian istimewa. 

Terima kasih telah menggunakan resep yang tim kami tampilkan di halaman ini. Semoga bermanfaat dan selamat mencoba!
