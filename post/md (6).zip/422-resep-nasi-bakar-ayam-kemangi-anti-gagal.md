---
description: "Resep Nasi Bakar Ayam Kemangi Anti Gagal"
title: "Resep Nasi Bakar Ayam Kemangi Anti Gagal"
slug: 422-resep-nasi-bakar-ayam-kemangi-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-28T19:10:45.782Z 
thumbnail: https://img-global.cpcdn.com/recipes/ba821cc91fc30470/682x484cq65/nasi-bakar-ayam-kemangi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/ba821cc91fc30470/682x484cq65/nasi-bakar-ayam-kemangi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/ba821cc91fc30470/682x484cq65/nasi-bakar-ayam-kemangi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/ba821cc91fc30470/682x484cq65/nasi-bakar-ayam-kemangi-foto-resep-utama.webp
author: Jeremy Lindsey
ratingvalue: 4.7
reviewcount: 7
recipeingredient:
- "Nasi gurih saya pakai nasi liwet "
- "Ayam suwir Kemangi           lihat resep "
- "Tempe orek optional "
- "Daun pisang dan tusuk lidi "
- "Untuk nasi liwet "
- "beras 3 cup"
- "bawang merah 5 siung"
- "bawang putih 3 siung"
- "sereh 3 batang"
- "daun salam 3 lembar"
- "daun jeruk 3 lembar"
- "Garam secukupnya"
- "Minyak untuk menumis "
recipeinstructions:
- "Cuci beras beri air. Iris bumbu untuk nasi liwet, lalu tumis sampai harum, masukkan kedalam panci beras tambahkan garam secukupnya, masak di rice cooker (seperti masak nasi pada umumnya)"
- "Siapkan semua bahan. Ambil daun, lalu ambil 1-2 centong tata nasi didaun, tambahkan juga ayam suwir dan tempe oreknya, gulung lalu semat bagian ujung daunnya"
- "Lakukan sampai habis yaa."
- "Bakar nasi diatas bara, (saya pakai teflon). Balik balik hingga sisi sisi daunnya agak menggelap...  Nasi bakar siap disajikan"
categories:
- Resep
tags:
- nasi
- bakar
- ayam

katakunci: nasi bakar ayam 
nutrition: 187 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT49M"
recipeyield: "4"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Bakar Ayam Kemangi](https://img-global.cpcdn.com/recipes/ba821cc91fc30470/682x484cq65/nasi-bakar-ayam-kemangi-foto-resep-utama.webp)

4 langkah mudah membuat  Nasi Bakar Ayam Kemangi yang wajib bunda coba dirumah

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Dalam Pembuatan Nasi Bakar Ayam Kemangi:

1. Nasi gurih saya pakai nasi liwet 
1. Ayam suwir Kemangi           lihat resep 
1. Tempe orek optional 
1. Daun pisang dan tusuk lidi 
1. Untuk nasi liwet 
1. beras 3 cup
1. bawang merah 5 siung
1. bawang putih 3 siung
1. sereh 3 batang
1. daun salam 3 lembar
1. daun jeruk 3 lembar
1. Garam secukupnya
1. Minyak untuk menumis 



<!--inarticleads2-->

## Cara Menyiapkan Nasi Bakar Ayam Kemangi:

1. Cuci beras beri air. Iris bumbu untuk nasi liwet, lalu tumis sampai harum, masukkan kedalam panci beras tambahkan garam secukupnya, masak di rice cooker (seperti masak nasi pada umumnya)
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/b5964bf71b800100/160x128cq70/nasi-bakar-ayam-kemangi-langkah-memasak-1-foto.webp" alt="Nasi Bakar Ayam Kemangi" width="340" height="340">
><img class="lazyload" data-src="https://img-global.cpcdn.com/steps/9f2ae27c9e914976/160x128cq70/nasi-bakar-ayam-kemangi-langkah-memasak-1-foto.webp" alt="Nasi Bakar Ayam Kemangi" width="340" height="340">
>1. Siapkan semua bahan. Ambil daun, lalu ambil 1-2 centong tata nasi didaun, tambahkan juga ayam suwir dan tempe oreknya, gulung lalu semat bagian ujung daunnya
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/94dab3a2033b8ad4/160x128cq70/nasi-bakar-ayam-kemangi-langkah-memasak-2-foto.webp" alt="Nasi Bakar Ayam Kemangi" width="340" height="340">
><img class="lazyload" data-src="https://img-global.cpcdn.com/steps/4970c9ec2384e5e7/160x128cq70/nasi-bakar-ayam-kemangi-langkah-memasak-2-foto.webp" alt="Nasi Bakar Ayam Kemangi" width="340" height="340">
><img class="lazyload" data-src="https://img-global.cpcdn.com/steps/97541f0ce49c80e8/160x128cq70/nasi-bakar-ayam-kemangi-langkah-memasak-2-foto.webp" alt="Nasi Bakar Ayam Kemangi" width="340" height="340">
>1. Lakukan sampai habis yaa.
1. Bakar nasi diatas bara, (saya pakai teflon). Balik balik hingga sisi sisi daunnya agak menggelap...  - Nasi bakar siap disajikan




Demikian informasi  resep Nasi Bakar Ayam Kemangi   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
