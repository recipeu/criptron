---
description: "Bagaimana Menyiapkan Nasi uduk betawi yang Enak"
title: "Bagaimana Menyiapkan Nasi uduk betawi yang Enak"
slug: 137-bagaimana-menyiapkan-nasi-uduk-betawi-yang-enak
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-23T11:56:02.937Z 
thumbnail: https://img-global.cpcdn.com/recipes/739118d7ad6751f9/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/739118d7ad6751f9/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/739118d7ad6751f9/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/739118d7ad6751f9/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
author: Craig Hayes
ratingvalue: 4.7
reviewcount: 4
recipeingredient:
- "Beras 4 cup"
- "Santan secukupnya"
- "Air kelapa 600 ml"
- "Garam secukupnya"
- "Sereh 2 batang"
- "Salam 2 batang"
- "Lengkuas 1 ruas jari"
- "Bahan semur  "
- "Bawang putih 3 butir"
- "Bawang bombay 1 butir"
- "Tahu 5 buah"
- "tempe 5 buah"
- "Minyak "
- "Garam "
- "Penyedap "
- "Jahe 1 ruas jari"
- "Pala bubuk secukupnya"
- "Kayu manis 1 ruas jari"
- "Cengkeh 2 butir"
- "Lada "
- "Kecap manis "
- "Pelengkap "
- "Sambal kacang "
- "Kerupuk "
- "Bawang goreng "
recipeinstructions:
- "Cuci beras sampai bersih,setelah bersih isi dengan air santan dan kelapa,lalu masukan sereh,salam, dan lengkuas,beri garam seckupnya..lalu diaroni"
- "Setelah nasi setengah matang,masukan ke magicjar sampai matang."
- "Untuk membuat semur"
- "Aluskan bawang putih lalu tumis dengan bawang bombay dan jahe sampai harum,setelah itu beri air dan kecap,tunggu sampai mendidih"
- "Setelah mendidih,masukan tahu yang telah di goreng,serta tempe,tunggu beberapa saat"
- "Setelah itu masukan lada,garam,penyedap, pala bubuk, kayu manis dan cengkeh..tunggu hingga semur benar&#34; meresap.dan sajikan"
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 174 calories
recipecuisine: Indonesian
preptime: "PT19M"
cooktime: "PT35M"
recipeyield: "1"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi uduk betawi](https://img-global.cpcdn.com/recipes/739118d7ad6751f9/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp)

6 langkah cepat membuat  Nasi uduk betawi yang musti kamu coba dirumah

<!--inarticleads1-->

## Bahan-bahan Yang Dibutuhkan Untuk Menyiapkan Nasi uduk betawi:

1. Beras 4 cup
1. Santan secukupnya
1. Air kelapa 600 ml
1. Garam secukupnya
1. Sereh 2 batang
1. Salam 2 batang
1. Lengkuas 1 ruas jari
1. Bahan semur  
1. Bawang putih 3 butir
1. Bawang bombay 1 butir
1. Tahu 5 buah
1. tempe 5 buah
1. Minyak 
1. Garam 
1. Penyedap 
1. Jahe 1 ruas jari
1. Pala bubuk secukupnya
1. Kayu manis 1 ruas jari
1. Cengkeh 2 butir
1. Lada 
1. Kecap manis 
1. Pelengkap 
1. Sambal kacang 
1. Kerupuk 
1. Bawang goreng 

Menu siap saji, tinggal goreng dan siap disantap dengan. There are no reviews for Nasi Uduk Betawi Bang Acim, Indonesia yet. Be the first to write a review! Cara membuat nasi uduk betawi bisa dibikin mudah, cukup gunakan magic com. 

<!--inarticleads2-->

## Tata Cara Membuat Nasi uduk betawi:

1. Cuci beras sampai bersih,setelah bersih isi dengan air santan dan kelapa,lalu masukan sereh,salam, dan lengkuas,beri garam seckupnya..lalu diaroni
1. Setelah nasi setengah matang,masukan ke magicjar sampai matang.
1. Untuk membuat semur
1. Aluskan bawang putih lalu tumis dengan bawang bombay dan jahe sampai harum,setelah itu beri air dan kecap,tunggu sampai mendidih
1. Setelah mendidih,masukan tahu yang telah di goreng,serta tempe,tunggu beberapa saat
1. Setelah itu masukan lada,garam,penyedap, pala bubuk, kayu manis dan cengkeh..tunggu hingga semur benar&#34; meresap.dan sajikan


Berikut resep nasi uduk betawi sederhana yang bisa untuk dijual. Resep Nasi Uduk Betawi - Makanan khas Betawi ini cocok sekali dijadikan menu sarapan. Uhh, sajian nasi uduk betawi ini akan semakin lezat dan komplit. Baca Juga : Resep Mie Aceh Tumis. Nasi uduk Betawi memiliki kekhasannya sendiri dan sudah memiliki citra tersendiri. 

Terima kasih telah membaca resep yang kami tampilkan di halaman ini. Semoga bermanfaat dan selamat mencoba!
