---
description: "Cara Gampang Membuat Nasi Daun Jeruk Rice Cooker yang Enak Banget"
title: "Cara Gampang Membuat Nasi Daun Jeruk Rice Cooker yang Enak Banget"
slug: 243-cara-gampang-membuat-nasi-daun-jeruk-rice-cooker-yang-enak-banget
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-22T11:28:21.061Z 
thumbnail: https://img-global.cpcdn.com/recipes/85a0acb8307e7390/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/85a0acb8307e7390/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/85a0acb8307e7390/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/85a0acb8307e7390/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
author: Jerome Anderson
ratingvalue: 4.6
reviewcount: 5
recipeingredient:
- "nasi putih 2 cup"
- "sereh  serai 2 batang"
- "bawang putih 6 siung"
- "daun jeruk 10 lembar"
- "kaldu jamur 1 sdm"
- "garam 1 sdt"
- "Minyak secukupnya utk menumis bawang putih "
- "Air "
- "cengek opsional 3 buah"
recipeinstructions:
- "Cuci beras hingga bersih lalu masukkan ke dalam panci rice cooker."
- "Siapkan bahan-bahan terlebih dahulu. Iris daun jeruk tipis-tipis (buang batangnya, kita hanya akan pakai daunnya saja). Lalu memarkan serai yang sudah disiapkan. Kemudian masukkan daun jeruk dan serai ke dalam panci rice cooker."
- "Oseng bawang putih dengan minyak sampai harum, lalu masukkan juga ke dalam panci rice cooker."
- "Masukkan air (seperti biasa kita memasak nasi), lalu masukkan garam dan kaldu jamur, dan aduk hingga rata."
- "Terakhir masukkan cengek utuh untuk menambah aroma dan rasa."
- "Masukkan ke rice cooker dan tunggu hingga matang. Setelah matang, sebaiknya nasi diaduk agar tercampur dengan merata dan tidak menempel pada panci."
- "Nasi daun jeruk siap dimakan ! Sajikan dengan lauk yang kamu gemari 😌"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 266 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT40M"
recipeyield: "1"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk Rice Cooker](https://img-global.cpcdn.com/recipes/85a0acb8307e7390/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp)

Ingin membuat Nasi Daun Jeruk Rice Cooker ? Coba resep berikut ini. Cara memasaknya sangat praktis namun hasilnya gurih dan lezat cocok sekali jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Dalam Menyiapkan Nasi Daun Jeruk Rice Cooker:

1. nasi putih 2 cup
1. sereh  serai 2 batang
1. bawang putih 6 siung
1. daun jeruk 10 lembar
1. kaldu jamur 1 sdm
1. garam 1 sdt
1. Minyak secukupnya utk menumis bawang putih 
1. Air 
1. cengek opsional 3 buah



<!--inarticleads2-->

## Cara Membuat Nasi Daun Jeruk Rice Cooker:

1. Cuci beras hingga bersih lalu masukkan ke dalam panci rice cooker.
1. Siapkan bahan-bahan terlebih dahulu. Iris daun jeruk tipis-tipis (buang batangnya, kita hanya akan pakai daunnya saja). - Lalu memarkan serai yang sudah disiapkan. - Kemudian masukkan daun jeruk dan serai ke dalam panci rice cooker.
1. Oseng bawang putih dengan minyak sampai harum, lalu masukkan juga ke dalam panci rice cooker.
1. Masukkan air (seperti biasa kita memasak nasi), lalu masukkan garam dan kaldu jamur, dan aduk hingga rata.
1. Terakhir masukkan cengek utuh untuk menambah aroma dan rasa.
1. Masukkan ke rice cooker dan tunggu hingga matang. - Setelah matang, sebaiknya nasi diaduk agar tercampur dengan merata dan tidak menempel pada panci.
1. Nasi daun jeruk siap dimakan ! - Sajikan dengan lauk yang kamu gemari 😌




Demikian informasi  resep Nasi Daun Jeruk Rice Cooker   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
