---
description: "Langkah Mudah untuk Menyiapkan Nasi daun jeruk purut yang Enak"
title: "Langkah Mudah untuk Menyiapkan Nasi daun jeruk purut yang Enak"
slug: 306-langkah-mudah-untuk-menyiapkan-nasi-daun-jeruk-purut-yang-enak
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-24T06:27:45.485Z 
thumbnail: https://img-global.cpcdn.com/recipes/8b365a905a4240fa/682x484cq65/nasi-daun-jeruk-purut-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/8b365a905a4240fa/682x484cq65/nasi-daun-jeruk-purut-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/8b365a905a4240fa/682x484cq65/nasi-daun-jeruk-purut-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/8b365a905a4240fa/682x484cq65/nasi-daun-jeruk-purut-foto-resep-utama.webp
author: Clarence Mendoza
ratingvalue: 3.6
reviewcount: 3
recipeingredient:
- "nasi 2 cup"
- "air 3 cup"
- "daun jeruk purut potong kecil 5"
- "santan 60 ml"
- "garam 1/2 sdt"
- "lada gula kaldu hubuk 1/4 sdt"
- "bawang putih halus 1/4 sdt"
recipeinstructions:
- "Cuci beras,campur semua bahan,masauk di mejikom. Aduk sesekali"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 241 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT37M"
recipeyield: "4"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi daun jeruk purut](https://img-global.cpcdn.com/recipes/8b365a905a4240fa/682x484cq65/nasi-daun-jeruk-purut-foto-resep-utama.webp)

Resep rahasia Nasi daun jeruk purut    dengan 1 langkahcepat cocok sekali jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Untuk Pembuatan Nasi daun jeruk purut:

1. nasi 2 cup
1. air 3 cup
1. daun jeruk purut potong kecil 5
1. santan 60 ml
1. garam 1/2 sdt
1. lada gula kaldu hubuk 1/4 sdt
1. bawang putih halus 1/4 sdt

Buah dan daunnya menjadi salah satu bahan dalam berbagai resep makanan di Asia. Manfaat jeruk purut untuk kesehatan rupanya sangat beragam. Dari sembilanmanfaat yang dipercaya dimiliki oleh buah ini, dua di antaranya begitu luar biasa, yaitu mem bersihkan darah dari Tidak hanya bagian buahnya saja, daun, minyak, dan kulitnya pun kerap digunakan untuk berbagai keperluan. Seruni.id - Daun jeruk purut dikenal sebagai salah satu penyedap makanan atau bumbu dapur. 

<!--inarticleads2-->

## Tata Cara Membuat Nasi daun jeruk purut:

1. Cuci beras,campur semua bahan,masauk di mejikom. Aduk sesekali


Namun, ternyata manfaat daun jeruk purut tidak hanya untuk masakan saja, loh. Tetapi, dipercaya mujarab untuk mengatasi berbagai masalah kesehatan. Nasi jeruk: Masukkan beras, nasi, air, dan santan ke dalam rice cooker. Tambahkan tumisan bumbu, cabai rawit merah, garam, dan penyedap rasa. Nasi putih (matang)•bawang putih•daun jeruk purut•garam (sedikit saja biar gak keasinan krn sdh pakai margarin n teri medan)•kaldu jamur•margarin blueband serbaguna•teri wadah kecil beras•daun jeruk•daun salam•serai geprek•bawang putih•mentega untuk menumis•garam•kaldu bubuk. 

Daripada   beli  Nasi daun jeruk purut  diluar terus, ibu  bisa membuatnya sendiri dirumah. Resep  Nasi daun jeruk purut  sederhana ini cukup praktis pembuatannya, cukup menggunakan bumbu-bumbu sederhana yang ada di dapur  Nasi daun jeruk purut  yang enak, bunda nikmati di rumah.
