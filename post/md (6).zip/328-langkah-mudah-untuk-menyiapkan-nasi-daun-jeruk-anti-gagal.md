---
description: "Langkah Mudah untuk Menyiapkan Nasi Daun Jeruk Anti Gagal"
title: "Langkah Mudah untuk Menyiapkan Nasi Daun Jeruk Anti Gagal"
slug: 328-langkah-mudah-untuk-menyiapkan-nasi-daun-jeruk-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-07T11:28:08.425Z 
thumbnail: https://img-global.cpcdn.com/recipes/64070fde100fae75/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/64070fde100fae75/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/64070fde100fae75/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/64070fde100fae75/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
author: Jimmy Lewis
ratingvalue: 3.5
reviewcount: 8
recipeingredient:
- "Bahan "
- "beras 1 cup"
- "air 300 ml"
- "serai 1"
- "daun jeruk 4 lembar"
- "garam dan kaldu bubuk Secukupnya"
recipeinstructions:
- "Cuci bersih beras.Taruh dalam ricecooker."
- "Masukkan bagian putih serai yang sudah di geprek,daun jeruk yang sudah diiris tipis,garam dan kaldu bubuk"
- "Tambahkan air,aduk rata. Masak seperti biasa."
- "Harum banget nasinya."
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 100 calories
recipecuisine: Indonesian
preptime: "PT19M"
cooktime: "PT50M"
recipeyield: "1"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk](https://img-global.cpcdn.com/recipes/64070fde100fae75/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp)

Ingin membuat Nasi Daun Jeruk ? Coba resep berikut ini. Cara memasaknya sangat praktis namun jangan kaget jika hasilnya gurih dan lezat yang harus bunda coba dirumah

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Dalam Menyiapkan Nasi Daun Jeruk:

1. Bahan 
1. beras 1 cup
1. air 300 ml
1. serai 1
1. daun jeruk 4 lembar
1. garam dan kaldu bubuk Secukupnya

Nasi daun jeruk siap dihidangkan dengan. Nasi daun jeruk ini memang sedang tren di kalangan masyarakat Indonesia, banyak sekali kaum muda mudi yang berlomba-lomba membuat makanan nasi putih spesial ini. Nasi daun jeruk ala geprek bensu rekomended buat di coba. Geprek bensu nasi daun jeruk anti mainst. 

<!--inarticleads2-->

## Langkah-langkah Untuk Menyiapkan Nasi Daun Jeruk:

1. Cuci bersih beras.Taruh dalam ricecooker.
1. Masukkan bagian putih serai yang sudah di geprek,daun jeruk yang sudah diiris tipis,garam dan kaldu bubuk
1. Tambahkan air,aduk rata. Masak seperti biasa.
1. Harum banget nasinya.


Gurih dan wangi dari daun jeruk menambah kelezatan nasi daun jeruk. Nasi dengan campuran daun jeruk yang wangi sedang tren. Hai selamat pagi sahabat CWS, pagi ini saya share resep Nasi Daun Jeruk. Praktis banget karena saya gunakan rice cooker. Rasanya mirip nasi uduk tapi wangiiii. 

Demikian informasi  resep Nasi Daun Jeruk   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
