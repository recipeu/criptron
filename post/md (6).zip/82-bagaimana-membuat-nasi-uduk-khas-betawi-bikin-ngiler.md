---
description: "Bagaimana Membuat Nasi Uduk Khas Betawi, Bikin Ngiler"
title: "Bagaimana Membuat Nasi Uduk Khas Betawi, Bikin Ngiler"
slug: 82-bagaimana-membuat-nasi-uduk-khas-betawi-bikin-ngiler
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-03T05:17:04.341Z 
thumbnail: https://img-global.cpcdn.com/recipes/26ea0d2772f6aece/682x484cq65/nasi-uduk-khas-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/26ea0d2772f6aece/682x484cq65/nasi-uduk-khas-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/26ea0d2772f6aece/682x484cq65/nasi-uduk-khas-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/26ea0d2772f6aece/682x484cq65/nasi-uduk-khas-betawi-foto-resep-utama.webp
author: Robert Barton
ratingvalue: 4.7
reviewcount: 15
recipeingredient:
- "beras pulen 1 ltr"
- "santan dari 1 btr kelapa 1000 ml"
- "garam halus 2 sdt"
- "serai geprek 1 btg"
- "daun salam 3 lbr"
- "jahe geprek 2 ruas"
- "lengkuas geprek 2 ruas"
- "kencur geprek 2 ruas"
- "bawang goreng Secukupnya"
recipeinstructions:
- "Cuci bersih beras kemudian rendam beberapa saat"
- "Rebus santan bersama garam, serai, daun salam, jahe, lengkuas, kencur yg sudah digeprek semuanya. Aduk2 supaya santan tidak pecah"
- "Setelah santan mendidih masukkan berasnya. Aduk sesekali supaya tidak hangus. Masak sampai menjadi aron (sekitar 10 menit). Matikan kompor."
- "Panaskan dandang/kukusan. Jika sudah panas masukan nasi aron ke dalam dandang atau kukusan. Masak sampai nasi matang (sekitar 30 menit).2"
- "Setelah matang sajikan nasi uduk bersama teman2nya 😊"
categories:
- Resep
tags:
- nasi
- uduk
- khas

katakunci: nasi uduk khas 
nutrition: 226 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT32M"
recipeyield: "3"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Khas Betawi](https://img-global.cpcdn.com/recipes/26ea0d2772f6aece/682x484cq65/nasi-uduk-khas-betawi-foto-resep-utama.webp)

5 langkah cepat membuat  Nasi Uduk Khas Betawi yang musti ibu coba segera

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Dalam Pembuatan Nasi Uduk Khas Betawi:

1. beras pulen 1 ltr
1. santan dari 1 btr kelapa 1000 ml
1. garam halus 2 sdt
1. serai geprek 1 btg
1. daun salam 3 lbr
1. jahe geprek 2 ruas
1. lengkuas geprek 2 ruas
1. kencur geprek 2 ruas
1. bawang goreng Secukupnya



<!--inarticleads2-->

## Cara Mudah Membuat Nasi Uduk Khas Betawi:

1. Cuci bersih beras kemudian rendam beberapa saat
1. Rebus santan bersama garam, serai, daun salam, jahe, lengkuas, kencur yg sudah digeprek semuanya. Aduk2 supaya santan tidak pecah
1. Setelah santan mendidih masukkan berasnya. Aduk sesekali supaya tidak hangus. Masak sampai menjadi aron (sekitar 10 menit). Matikan kompor.
1. Panaskan dandang/kukusan. Jika sudah panas masukan nasi aron ke dalam dandang atau kukusan. Masak sampai nasi matang (sekitar 30 menit).2
1. Setelah matang sajikan nasi uduk bersama teman2nya 😊




Terima kasih telah menggunakan resep yang kami tampilkan di sini. Selamat mencoba!
