---
description: "Resep Nasi Ayam Hainan Rice Cooker Presto (Ayam Kampung), Enak Banget"
title: "Resep Nasi Ayam Hainan Rice Cooker Presto (Ayam Kampung), Enak Banget"
slug: 460-resep-nasi-ayam-hainan-rice-cooker-presto-ayam-kampung-enak-banget
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-11T04:36:40.642Z 
thumbnail: https://img-global.cpcdn.com/recipes/361bb2ea37590cdf/682x484cq65/nasi-ayam-hainan-rice-cooker-presto-ayam-kampung-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/361bb2ea37590cdf/682x484cq65/nasi-ayam-hainan-rice-cooker-presto-ayam-kampung-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/361bb2ea37590cdf/682x484cq65/nasi-ayam-hainan-rice-cooker-presto-ayam-kampung-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/361bb2ea37590cdf/682x484cq65/nasi-ayam-hainan-rice-cooker-presto-ayam-kampung-foto-resep-utama.webp
author: Russell Sanchez
ratingvalue: 3.4
reviewcount: 7
recipeingredient:
- "ayam kampung muda potong 1 ekor menjadi 1012 bagian 1 ekor"
- "beras cuci dan tiriskan tidak perlu direndam 2 cup"
- "garam halus 1/2 sdt"
- "kecap asin 1 sdm"
- "kaldu ayam atau jamur bubuk 2 sdt"
- "daun pandan saya suka ganti dengan batang daun bawang kalau tidak ada daun pandan 2 lbr"
- "Se ibu jari jahe memarkan "
- "bawang putih cacah halus atau 1 sdm minyak bawang putih 3 siung"
- "air 2 3/4 cup"
- "Kuah "
- "air 1 1/2 L"
- "kepala ayam atau 56 buah ceker 2"
- "bawang putih cacah halus 3 siung"
- "kaldu ayam atau jamur bubuk 1 sdt"
- "Garam dan merica secukupnya"
- "sawi putih Irisan"
- "daun bawang Irisan"
- "Pelengkap "
- "Timun "
- "Optional telur masak kecap "
- "Saus bawang putih tumis parutan bawang putih dan jahe dengan api kecil hingga harum Beri garam dan sedikit kaldu bubuk "
- "Saus daun bawang saya tadi tambah cabai jadi sekalian jadi sambal httpcookingwsheilacomayampanggangcabaiijo "
recipeinstructions:
- "Di dalam presto, tumis ayam dengan sedikit minyak. Sebentar saja, jangan sampai berwarna cokelat. Tambahkan bawang putih dan jahe, tumis hingga harum. Masukkan beras dan aduk rata. Bumbuhi dengan kecap asin. Masak sebentar. Tuang air ke dalam presto. Airnya harus di atas beras setinggi satu ruas jari kelingking. Karena menggunakan presto, saya suka kurangin sedikit. Bumbuhi dengan garam dan kaldu bubuk juga tambahkan daun pandan. Masak dalam presto selama 20 menit hingga matang."
- "Saya tadi menggunakan tombol “Chicken”. Untuk kuah: buat kaldu dengan merebus kepala atau cakar. Tambahkan bawang putih dan rebus selama 1 jam. Bumbuhi dengan garam, merica, gula dan kaldu bubuk. Koreksi rasa. Terakhir tambahkan daun sawi dan daun bawang. Masak hingga layu dan matikan api. Sajikan panas dengan kuah, saus bawang putih dan saus daun bawang."
categories:
- Resep
tags:
- nasi
- ayam
- hainan

katakunci: nasi ayam hainan 
nutrition: 121 calories
recipecuisine: Indonesian
preptime: "PT36M"
cooktime: "PT48M"
recipeyield: "1"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Ayam Hainan Rice Cooker Presto (Ayam Kampung)](https://img-global.cpcdn.com/recipes/361bb2ea37590cdf/682x484cq65/nasi-ayam-hainan-rice-cooker-presto-ayam-kampung-foto-resep-utama.webp)

2 langkah mudah memasak  Nasi Ayam Hainan Rice Cooker Presto (Ayam Kampung) yang musti kamu coba segera

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Dalam Menyiapkan Nasi Ayam Hainan Rice Cooker Presto (Ayam Kampung):

1. ayam kampung muda potong 1 ekor menjadi 1012 bagian 1 ekor
1. beras cuci dan tiriskan tidak perlu direndam 2 cup
1. garam halus 1/2 sdt
1. kecap asin 1 sdm
1. kaldu ayam atau jamur bubuk 2 sdt
1. daun pandan saya suka ganti dengan batang daun bawang kalau tidak ada daun pandan 2 lbr
1. Se ibu jari jahe memarkan 
1. bawang putih cacah halus atau 1 sdm minyak bawang putih 3 siung
1. air 2 3/4 cup
1. Kuah 
1. air 1 1/2 L
1. kepala ayam atau 56 buah ceker 2
1. bawang putih cacah halus 3 siung
1. kaldu ayam atau jamur bubuk 1 sdt
1. Garam dan merica secukupnya
1. sawi putih Irisan
1. daun bawang Irisan
1. Pelengkap 
1. Timun 
1. Optional telur masak kecap 
1. Saus bawang putih tumis parutan bawang putih dan jahe dengan api kecil hingga harum Beri garam dan sedikit kaldu bubuk 
1. Saus daun bawang saya tadi tambah cabai jadi sekalian jadi sambal httpcookingwsheilacomayampanggangcabaiijo 



<!--inarticleads2-->

## Langkah-langkah Untuk Menyiapkan Nasi Ayam Hainan Rice Cooker Presto (Ayam Kampung):

1. Di dalam presto, tumis ayam dengan sedikit minyak. Sebentar saja, jangan sampai berwarna cokelat. Tambahkan bawang putih dan jahe, tumis hingga harum. - Masukkan beras dan aduk rata. - Bumbuhi dengan kecap asin. Masak sebentar. - Tuang air ke dalam presto. Airnya harus di atas beras setinggi satu ruas jari kelingking. Karena menggunakan presto, saya suka kurangin sedikit. - Bumbuhi dengan garam dan kaldu bubuk juga tambahkan daun pandan. - Masak dalam presto selama 20 menit hingga matang.
1. Saya tadi menggunakan tombol “Chicken”. - Untuk kuah: buat kaldu dengan merebus kepala atau cakar. Tambahkan bawang putih dan rebus selama 1 jam. Bumbuhi dengan garam, merica, gula dan kaldu bubuk. Koreksi rasa. Terakhir tambahkan daun sawi dan daun bawang. Masak hingga layu dan matikan api. - Sajikan panas dengan kuah, saus bawang putih dan saus daun bawang.




Salah satu kuliner yang cukup praktis pembuatannya adalah  Nasi Ayam Hainan Rice Cooker Presto (Ayam Kampung). Selain itu  Nasi Ayam Hainan Rice Cooker Presto (Ayam Kampung)  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu ikuti 2 langkah, dan  Nasi Ayam Hainan Rice Cooker Presto (Ayam Kampung)  pun siap di hidangkan. selamat mencoba !
