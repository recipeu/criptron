---
description: "Cara Gampang Membuat Nasi + Ayam Hainan Kukus yang Lezat"
title: "Cara Gampang Membuat Nasi + Ayam Hainan Kukus yang Lezat"
slug: 443-cara-gampang-membuat-nasi-ayam-hainan-kukus-yang-lezat
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-03T21:19:30.278Z 
thumbnail: https://img-global.cpcdn.com/recipes/8b42ccb5988132e2/682x484cq65/nasi-ayam-hainan-kukus-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/8b42ccb5988132e2/682x484cq65/nasi-ayam-hainan-kukus-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/8b42ccb5988132e2/682x484cq65/nasi-ayam-hainan-kukus-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/8b42ccb5988132e2/682x484cq65/nasi-ayam-hainan-kukus-foto-resep-utama.webp
author: Janie Jacobs
ratingvalue: 4.2
reviewcount: 15
recipeingredient:
- " Bahan Air Kaldu Ayam untuk nasi  "
- "tulang dada ayam potong potong 1"
- "jeruk nipis 1/2 buah"
- "air untuk merebus secukupnya"
- " Bahan Untuk Nasi  "
- "beras cup magic com 5 cup"
- "bawang putih ukuran besar 3 siung"
- "jahe 1 potong"
- "minyak wijen 2-3 sdm"
- "garam secukupnya"
- "air kaldu ayam disesuaikan dengan beras yg dimasak secukupnya"
- " Bahan Ayam Hainan  "
- "ayam bagian paha paha atas bawah 4 potong"
- "jeruk nipis 1 buah"
- "bawang putih 5 siung"
- "jahe 1 potong"
- "daun bawang 8 batang"
- "kecap asin 3-4 sdm"
- "minyak wijen 2 sdm"
- "garam 1,5 sdt"
- "lada bubuk 1/2 sdt"
- "gula pasir 2 sdt"
- "air 100 ml"
- "kaldu jamur totole 1 sdt"
- " pelengkap  optional "
- "sambal kecap "
- "timun "
- "bawang merah goreng untuk taburan nasi "
recipeinstructions:
- "👉 membuat air kaldu ayam : cuci tulang ayam lalu beri perasan air jeruk nipis, diamkan sebentar.... didih air lalu masukkan tulang ayamnya....masak sampai keluar kaldu ayamnya, sisihkan."
- "👉 membuat nasi : siapkan bawang putih dan jahe......Cincang bawang putih dan geprek jahe nya.....masukkan minyak wijen dalam wajan."
- "Setelah panas, masukkan bawang putih cincang dan jahe nya....setelah wangi masukkan air kaldu ayamnya.....masak sampai mendidih, lalu beri garam aduk rata. Cek rasa, harus terasa ada rasa asinnya."
- "Tuang air kaldu tadi ke dalam beras yang sdh dicuci didalam wadah magic com (jumlah air kaldu di sesuaikan dgn kebutuhan air utk beras yang biasa dimasak).....nyalakan tombol masak....Bila Nasi sudah matang aduk rata."
- "👉 Membuat ayam Hainan, Cuci ayam lalu beri perasaan air jeruk nipis. Diamkan selama 15 menit....Siapkan bahan dan bumbu lainnya."
- "Iris iris daun bawang, cincang bawang putih dan iris iris jahe nya....Masukkan semua ke dalam mangkuk, lalu beri kecap asin...tambahkan minyak wijen."
- "Masukkan juga gula pasir....masukkan garam....serta masukkan juga lada bubuk."
- "Masukkan air, aduk rata. sisihkan....bilas ayam yang diberi perasan jeruk nipis tadi, lalu tusuk tusuk dengan garpu (agar nanti bumbu meresap ke dalam dagingnya)....tuang campuran bumbu tadi ke dalam ayam, aduk rata."
- "Remas remas ayam agar bumbu menyerap ke dagingnya.....tambahkan kaldu jamur, aduk rata kemudian diamkan selama 30 menit dalam kulkas."
- "Masukkan ayam ke dalam wadah untuk di kukus, masukkan beserta bumbu cairnya (saya kukus 2 potong ayam dulu).... Panaskan panci kukusan lalu masukkan wadah yang berisi ayam, kukus selama 30 menit....Jika sudah matang angkat ayam dari panci kukusan."
- "Hidangkan Nasi + ayam Hainan kukus nya...lengkapi dengan sambal kecap dan timun 👌"
- "Ayam Hainan empuk dan Wangi😍"
categories:
- Resep
tags:
- nasi
- 
- ayam

katakunci: nasi  ayam 
nutrition: 116 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT46M"
recipeyield: "2"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi + Ayam Hainan Kukus](https://img-global.cpcdn.com/recipes/8b42ccb5988132e2/682x484cq65/nasi-ayam-hainan-kukus-foto-resep-utama.webp)

Resep rahasia dan cara mengolah  Nasi + Ayam Hainan Kukus cocok banget jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Untuk Pembuatan Nasi + Ayam Hainan Kukus:

1.  Bahan Air Kaldu Ayam untuk nasi  
1. tulang dada ayam potong potong 1
1. jeruk nipis 1/2 buah
1. air untuk merebus secukupnya
1.  Bahan Untuk Nasi  
1. beras cup magic com 5 cup
1. bawang putih ukuran besar 3 siung
1. jahe 1 potong
1. minyak wijen 2-3 sdm
1. garam secukupnya
1. air kaldu ayam disesuaikan dengan beras yg dimasak secukupnya
1.  Bahan Ayam Hainan  
1. ayam bagian paha paha atas bawah 4 potong
1. jeruk nipis 1 buah
1. bawang putih 5 siung
1. jahe 1 potong
1. daun bawang 8 batang
1. kecap asin 3-4 sdm
1. minyak wijen 2 sdm
1. garam 1,5 sdt
1. lada bubuk 1/2 sdt
1. gula pasir 2 sdt
1. air 100 ml
1. kaldu jamur totole 1 sdt
1.  pelengkap  optional 
1. sambal kecap 
1. timun 
1. bawang merah goreng untuk taburan nasi 



<!--inarticleads2-->

## Cara Menyiapkan Nasi + Ayam Hainan Kukus:

1. 👉 membuat air kaldu ayam : cuci tulang ayam lalu beri perasan air jeruk nipis, diamkan sebentar.... didih air lalu masukkan tulang ayamnya....masak sampai keluar kaldu ayamnya, sisihkan.
1. 👉 membuat nasi : siapkan bawang putih dan jahe......Cincang bawang putih dan geprek jahe nya.....masukkan minyak wijen dalam wajan.
1. Setelah panas, masukkan bawang putih cincang dan jahe nya....setelah wangi masukkan air kaldu ayamnya.....masak sampai mendidih, lalu beri garam aduk rata. Cek rasa, harus terasa ada rasa asinnya.
1. Tuang air kaldu tadi ke dalam beras yang sdh dicuci didalam wadah magic com (jumlah air kaldu di sesuaikan dgn kebutuhan air utk beras yang biasa dimasak).....nyalakan tombol masak....Bila Nasi sudah matang aduk rata.
1. 👉 Membuat ayam Hainan, Cuci ayam lalu beri perasaan air jeruk nipis. Diamkan selama 15 menit....Siapkan bahan dan bumbu lainnya.
1. Iris iris daun bawang, cincang bawang putih dan iris iris jahe nya....Masukkan semua ke dalam mangkuk, lalu beri kecap asin...tambahkan minyak wijen.
1. Masukkan juga gula pasir....masukkan garam....serta masukkan juga lada bubuk.
1. Masukkan air, aduk rata. sisihkan....bilas ayam yang diberi perasan jeruk nipis tadi, lalu tusuk tusuk dengan garpu (agar nanti bumbu meresap ke dalam dagingnya)....tuang campuran bumbu tadi ke dalam ayam, aduk rata.
1. Remas remas ayam agar bumbu menyerap ke dagingnya.....tambahkan kaldu jamur, aduk rata kemudian diamkan selama 30 menit dalam kulkas.
1. Masukkan ayam ke dalam wadah untuk di kukus, masukkan beserta bumbu cairnya (saya kukus 2 potong ayam dulu).... Panaskan panci kukusan lalu masukkan wadah yang berisi ayam, kukus selama 30 menit....Jika sudah matang angkat ayam dari panci kukusan.
1. Hidangkan Nasi + ayam Hainan kukus nya...lengkapi dengan sambal kecap dan timun 👌
1. Ayam Hainan empuk dan Wangi😍




Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
