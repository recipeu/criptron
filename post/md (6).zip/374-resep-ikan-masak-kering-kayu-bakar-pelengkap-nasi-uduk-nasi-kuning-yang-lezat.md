---
description: "Resep Ikan Masak Kering Kayu Bakar Pelengkap Nasi Uduk/Nasi Kuning yang Lezat"
title: "Resep Ikan Masak Kering Kayu Bakar Pelengkap Nasi Uduk/Nasi Kuning yang Lezat"
slug: 374-resep-ikan-masak-kering-kayu-bakar-pelengkap-nasi-uduk-nasi-kuning-yang-lezat
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-12T00:41:53.355Z 
thumbnail: https://img-global.cpcdn.com/recipes/72a73871906c30c5/682x484cq65/ikan-masak-kering-kayu-bakar-pelengkap-nasi-uduknasi-kuning-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/72a73871906c30c5/682x484cq65/ikan-masak-kering-kayu-bakar-pelengkap-nasi-uduknasi-kuning-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/72a73871906c30c5/682x484cq65/ikan-masak-kering-kayu-bakar-pelengkap-nasi-uduknasi-kuning-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/72a73871906c30c5/682x484cq65/ikan-masak-kering-kayu-bakar-pelengkap-nasi-uduknasi-kuning-foto-resep-utama.webp
author: Mitchell Conner
ratingvalue: 4.1
reviewcount: 9
recipeingredient:
- "ikan tunacakalangtongkol kurang lebihnya ya karena dsini ikan dijual per ekor bukan per kg 1 kg"
- "air asamair jeruk nipis secukupnya"
- "bumbu halus "
- "bawang merah 5 siung"
- "bawang putih 3 siung"
- "kemiri sangrai 4 butir"
- "cabai merah besar 2 buah"
- "jinten bubuk 1/4 sdt"
- "ketumbar bubuk 1/4 sdt"
- "merica bubuk 1/4 sdt"
- "kunyit 2 cm"
- "jahe 2 cm"
- "bumbu pelengkap "
- "kecap 5-7 sdm"
- "gula merah 2 sdm"
- "garam kaldu bubuk secukupnya"
- "daun salam 3 lembar"
- "daun jeruk 2 lembar"
- "serai 2 batang"
- "kayu manis 3 cm"
- "air secukupnya"
recipeinstructions:
- "Potong potong ikan, beri perasan air jeruk nipis atau air asam supaya ikan kaku sisihkan"
- "Blender bumbu halus, kemudian tumis bumbu halus tambahkan bumbu pelengkap (kecuali kecap, garam, kaldu bubukdan gula merah)tumis sampai harum, tambahkan air, aduk, masukkan ikan,tambahkan kecap, gula, garam kaldu bubuk, koreksi rasa, masak sampai air mengering"
- "Panas pemanggang, panggang ikan, lakukan sampai habis"
categories:
- Resep
tags:
- ikan
- masak
- kering

katakunci: ikan masak kering 
nutrition: 102 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT57M"
recipeyield: "3"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Ikan Masak Kering Kayu Bakar Pelengkap Nasi Uduk/Nasi Kuning](https://img-global.cpcdn.com/recipes/72a73871906c30c5/682x484cq65/ikan-masak-kering-kayu-bakar-pelengkap-nasi-uduknasi-kuning-foto-resep-utama.webp)

3 langkah cepat dan mudah memasak  Ikan Masak Kering Kayu Bakar Pelengkap Nasi Uduk/Nasi Kuning cocok sekali jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Dalam Pembuatan Ikan Masak Kering Kayu Bakar Pelengkap Nasi Uduk/Nasi Kuning:

1. ikan tunacakalangtongkol kurang lebihnya ya karena dsini ikan dijual per ekor bukan per kg 1 kg
1. air asamair jeruk nipis secukupnya
1. bumbu halus 
1. bawang merah 5 siung
1. bawang putih 3 siung
1. kemiri sangrai 4 butir
1. cabai merah besar 2 buah
1. jinten bubuk 1/4 sdt
1. ketumbar bubuk 1/4 sdt
1. merica bubuk 1/4 sdt
1. kunyit 2 cm
1. jahe 2 cm
1. bumbu pelengkap 
1. kecap 5-7 sdm
1. gula merah 2 sdm
1. garam kaldu bubuk secukupnya
1. daun salam 3 lembar
1. daun jeruk 2 lembar
1. serai 2 batang
1. kayu manis 3 cm
1. air secukupnya



<!--inarticleads2-->

## Langkah-langkah Untuk Membuat Ikan Masak Kering Kayu Bakar Pelengkap Nasi Uduk/Nasi Kuning:

1. Potong potong ikan, beri perasan air jeruk nipis atau air asam supaya ikan kaku sisihkan
1. Blender bumbu halus, kemudian tumis bumbu halus tambahkan bumbu pelengkap (kecuali kecap, garam, kaldu bubukdan gula merah)tumis sampai harum, tambahkan air, aduk, masukkan ikan,tambahkan kecap, gula, garam kaldu bubuk, koreksi rasa, masak sampai air mengering
1. Panas pemanggang, panggang ikan, lakukan sampai habis
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/3b94712d6e9d85c3/160x128cq70/ikan-masak-kering-kayu-bakar-pelengkap-nasi-uduknasi-kuning-langkah-memasak-3-foto.webp" alt="Ikan Masak Kering Kayu Bakar Pelengkap Nasi Uduk/Nasi Kuning" width="340" height="340">
>



Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
