---
description: "Cara Gampang Menyiapkan Nasi Ayam Hainan Singapore| Versi Komplit dengan Ricecooker yang Bikin Ngiler"
title: "Cara Gampang Menyiapkan Nasi Ayam Hainan Singapore| Versi Komplit dengan Ricecooker yang Bikin Ngiler"
slug: 445-cara-gampang-menyiapkan-nasi-ayam-hainan-singapore-versi-komplit-dengan-ricecooker-yang-bikin-ngiler
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-06T21:15:26.564Z 
thumbnail: https://img-global.cpcdn.com/recipes/ffeb701be291e32e/682x484cq65/nasi-ayam-hainan-singapore-versi-komplit-dengan-ricecooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/ffeb701be291e32e/682x484cq65/nasi-ayam-hainan-singapore-versi-komplit-dengan-ricecooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/ffeb701be291e32e/682x484cq65/nasi-ayam-hainan-singapore-versi-komplit-dengan-ricecooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/ffeb701be291e32e/682x484cq65/nasi-ayam-hainan-singapore-versi-komplit-dengan-ricecooker-foto-resep-utama.webp
author: Alice Adams
ratingvalue: 3.2
reviewcount: 8
recipeingredient:
- "Bahan Nasi Hainan "
- "beras cuci dan rendam 30 menit 2 cup"
- "air kaldu ayam 2 cup"
- "minyak wijen 1 sdm"
- "saus tiram 1 sdm"
- "kecap asin 2 sdm"
- "garam 2 sdt"
- "gula pasir 1/2 sdm"
- "merica 1/2 sdt"
- "Bahan Garlic Oil "
- "minyak goreng 75 ml"
- "bawang putih cincang halus 12 siung"
- "jahe parut 2 ruas"
- "Bahan Ayam Hainan "
- "dada ayam fillet dengan kulit me  tanpa kulit 1 pasang"
- "garam 1/2 sdm"
- "gula pasir 1/2 sdm"
- "Bahan Scallion Oil "
- "daun bawang cincang halus 5 batang"
- "jahe parut 1 ruas"
- "bawang putih cincang halus 2 siung"
- "minyak goreng 40 ml"
- "saus tiram 1 sdm"
- "garam 1/2 sdt"
- "gula pasir 1 sdt"
- "merica bubuk 1/2 sdt"
- "Bahan Kuah Kaldu Ayam "
- "cekertulang ayam me 6 pasang ceker 500 gr"
- "air 4 liter"
- "bawang putih dengan kulit geprek 3 siung"
- "jahe geprek 1 ruas"
- "kol putih 150 gr"
- "daun bawang bagian putih potong 3 2 batang"
- "gula Secukupnya"
- "garam Secukupnya"
- "merica Secukupnya"
- "penyedap rasa non MSG Secukupnya"
- "Bahan "
- "cabai merah keriting 8 buah"
- "cabai rawit merah 8 buah"
- "bawang putih 6 siung"
- "gula pasir 1 sdm"
- "garam 1 sdt"
- "cuka 2 sdm"
- "air 80 ml"
recipeinstructions:
- "Rendam dada ayam fillet dengan garam,dan gula lalu diamkan selama 2 jam atau semalaman didalam kulkas."
- "Untuk kaldu, didihkan air lalu rebus ceker, tulang, bawang putih, dan jahe selama ±30 menit."
- "Untuk garlic oil, panaskan minyak lalu masukkan jahe dan bawang putih setelah setengah kering kecilkan api lalu aduk-aduk hingga coklat keemasan, sisihkan."
- "Cara membuat nasi hainan: masukkan beras yang sudah direndam sebelumnya, air kaldu, ½ garlic oil, kecap asin, minyak wijen, saus tiram, garam, dan merica lalu aduk dan letakkan dada ayam fillet  Di atasnya lalu taburi dengan gula kemudian masak dengan rice cooker hingga matang. Setelah matang, angkat ayam supaya tidak over cooker, lalu aduk nasi."
- "Untuk scallion oil, di dalam mangkuk campurkan daun bawang, jahe, bawang putih, minyak wijen,saus tiram, gula, garam, dan merica kemudian siram dengan minyak panas lalu aduk hingga rata."
- "Untuk kuah, tambahkan daun bawang bagian putih, kol, gula, garam, penyedap, dan merica sesuai selera ke dalam kaldu ayam lalu masak hingga kol menjadi layu dan kuah berubah warna menjadi putih."
- "Untuk sambal, blender bawang putih, cabai rawit, cabe merah keriting, dan air hingga halus lalu pindahkan ke dalam pan dan tambahkan cuka, gula garam,dan sedikit kuah ayam kemudian masak hingga air sedikit susut."
- "Taruh nasi hainan diatas piring lalu letakkan irisan ayam di atasnya kemudian siram dengan garlic dan scallion oil, beri daun ketumbar dan cabai di atasnya (me: skip). Lalu sajikan dengan sambal dan kuah sebagai pelengkap.  Selamat mencoba 💐"
categories:
- Resep
tags:
- nasi
- ayam
- hainan

katakunci: nasi ayam hainan 
nutrition: 213 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT34M"
recipeyield: "4"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Ayam Hainan Singapore| Versi Komplit dengan Ricecooker](https://img-global.cpcdn.com/recipes/ffeb701be291e32e/682x484cq65/nasi-ayam-hainan-singapore-versi-komplit-dengan-ricecooker-foto-resep-utama.webp)

Ingin membuat Nasi Ayam Hainan Singapore| Versi Komplit dengan Ricecooker ? Coba resep berikut ini. Cara memasaknya sangat praktis namun hasilnya gurih dan lezat cocok banget jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Dalam Menyiapkan Nasi Ayam Hainan Singapore| Versi Komplit dengan Ricecooker:

1. Bahan Nasi Hainan 
1. beras cuci dan rendam 30 menit 2 cup
1. air kaldu ayam 2 cup
1. minyak wijen 1 sdm
1. saus tiram 1 sdm
1. kecap asin 2 sdm
1. garam 2 sdt
1. gula pasir 1/2 sdm
1. merica 1/2 sdt
1. Bahan Garlic Oil 
1. minyak goreng 75 ml
1. bawang putih cincang halus 12 siung
1. jahe parut 2 ruas
1. Bahan Ayam Hainan 
1. dada ayam fillet dengan kulit me  tanpa kulit 1 pasang
1. garam 1/2 sdm
1. gula pasir 1/2 sdm
1. Bahan Scallion Oil 
1. daun bawang cincang halus 5 batang
1. jahe parut 1 ruas
1. bawang putih cincang halus 2 siung
1. minyak goreng 40 ml
1. saus tiram 1 sdm
1. garam 1/2 sdt
1. gula pasir 1 sdt
1. merica bubuk 1/2 sdt
1. Bahan Kuah Kaldu Ayam 
1. cekertulang ayam me 6 pasang ceker 500 gr
1. air 4 liter
1. bawang putih dengan kulit geprek 3 siung
1. jahe geprek 1 ruas
1. kol putih 150 gr
1. daun bawang bagian putih potong 3 2 batang
1. gula Secukupnya
1. garam Secukupnya
1. merica Secukupnya
1. penyedap rasa non MSG Secukupnya
1. Bahan 
1. cabai merah keriting 8 buah
1. cabai rawit merah 8 buah
1. bawang putih 6 siung
1. gula pasir 1 sdm
1. garam 1 sdt
1. cuka 2 sdm
1. air 80 ml



<!--inarticleads2-->

## Langkah-langkah Untuk Membuat Nasi Ayam Hainan Singapore| Versi Komplit dengan Ricecooker:

1. Rendam dada ayam fillet dengan garam,dan gula lalu diamkan selama 2 jam atau semalaman didalam kulkas.
1. Untuk kaldu, didihkan air lalu rebus ceker, tulang, bawang putih, dan jahe selama ±30 menit.
1. Untuk garlic oil, panaskan minyak lalu masukkan jahe dan bawang putih setelah setengah kering kecilkan api lalu aduk-aduk hingga coklat keemasan, sisihkan.
1. Cara membuat nasi hainan: masukkan beras yang sudah direndam sebelumnya, air kaldu, ½ garlic oil, kecap asin, minyak wijen, saus tiram, garam, dan merica lalu aduk dan letakkan dada ayam fillet  - Di atasnya lalu taburi dengan gula kemudian masak dengan rice cooker hingga matang. Setelah matang, angkat ayam supaya tidak over cooker, lalu aduk nasi.
1. Untuk scallion oil, di dalam mangkuk campurkan daun bawang, jahe, bawang putih, minyak wijen,saus tiram, gula, garam, dan merica kemudian siram dengan minyak panas lalu aduk hingga rata.
1. Untuk kuah, tambahkan daun bawang bagian putih, kol, gula, garam, penyedap, dan merica sesuai selera ke dalam kaldu ayam lalu masak hingga kol menjadi layu dan kuah berubah warna menjadi putih.
1. Untuk sambal, blender bawang putih, cabai rawit, cabe merah keriting, dan air hingga halus lalu pindahkan ke dalam pan dan tambahkan cuka, gula garam,dan sedikit kuah ayam kemudian masak hingga air sedikit susut.
1. Taruh nasi hainan diatas piring lalu letakkan irisan ayam di atasnya kemudian siram dengan garlic dan scallion oil, beri daun ketumbar dan cabai di atasnya (me: skip). Lalu sajikan dengan sambal dan kuah sebagai pelengkap. -  - Selamat mencoba 💐




Salah satu kuliner yang cukup praktis dalam pembuatannya adalah  Nasi Ayam Hainan Singapore| Versi Komplit dengan Ricecooker. Selain itu  Nasi Ayam Hainan Singapore| Versi Komplit dengan Ricecooker  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu lakukan 8 langkah, dan  Nasi Ayam Hainan Singapore| Versi Komplit dengan Ricecooker  pun siap di hidangkan. selamat mencoba !
