---
description: "Resep Nasi Bakar Ikan Suwir Pedas, Bisa Manjain Lidah"
title: "Resep Nasi Bakar Ikan Suwir Pedas, Bisa Manjain Lidah"
slug: 367-resep-nasi-bakar-ikan-suwir-pedas-bisa-manjain-lidah
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-22T02:47:49.410Z 
thumbnail: https://img-global.cpcdn.com/recipes/e7b6cbfe91e09d6b/682x484cq65/nasi-bakar-ikan-suwir-pedas-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/e7b6cbfe91e09d6b/682x484cq65/nasi-bakar-ikan-suwir-pedas-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/e7b6cbfe91e09d6b/682x484cq65/nasi-bakar-ikan-suwir-pedas-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/e7b6cbfe91e09d6b/682x484cq65/nasi-bakar-ikan-suwir-pedas-foto-resep-utama.webp
author: Lettie Morton
ratingvalue: 3.9
reviewcount: 13
recipeingredient:
- "beras 3 gelas 750 gr"
- "cabe merah keriting potong serong 5 bh"
- "bawang merah iris halus 6 btr"
- "bawang putih iris halus 3 siung"
- "garam 1,5 sdt"
- "kaldu bubuk 1/2 sdt"
- "serai geprek 2 btg"
- "daun salam 4 lbr"
- "minyak untuk menumis Sedikit"
- "air mendidih panas sesuaikan dgn jenis beras 1200 ml"
- "Daun pisang  tusuk gigi untuk membungkus "
- "Isi "
- "Tuna suwir pedas kali ini ikan tuna aku ganti ikan keranjang           lihat resep "
recipeinstructions:
- "Buat isiannya dulu. Ikan keranjang/ikan cue/ikan pindang dicuci, dibuang kotorannya dan kepalanya. Goreng jgn terlalu kering. Buang durinya, suwir2 dagingnya jgn terlalu lembut, nanti waktu dimasak akan semakin hancur. Masak spt Tuna Suwir Pedas.           (lihat resep)"
- "Siapkan bahan lainnya. Cuci beras smp bersih, taruh di bowl magicom. Sisihkan."
- "Panaskan minyak, tumis bawang merah dan bawang putih smp layu dan harum. Masukkan potongan cabe merah keriting, aduk2, tunggu smp cabe layu."
- "Tuang tumisan bumbu iris tadi (bawang merah, bawang putih, cabe merah keriting) ke dlm beras yg telah dicuci (tuang dgn minyaknya sekalian). Tambahkan serai dan daun salam."
- "Tuangi air panas mendidih. Beri garam dan kaldu bubuk."
- "Aduk rata. Tutup dan tekan tombol &#39;cook&#39;. Jika tombol sdh berpindah ke &#39;warm&#39; (nasi sdh matang), aduk2 nasinya. Tutup lagi, biarkan nasinya tanak."
- "Ambil sepiring nasi liwet tadi. Siapkan daun pisang dan tusuk gigi (untuk semat). Beri setengah piring nasi liwet di atasnya, ratakan. Beri isian di tengahnya, tutup kembali dgn sisa nasi (setengah piring)."
- "Gulung daun pisangnya, semat salah satu ujungnya dgn tusuk gigi. Berdirikan posisi daun (yg disemat berada di bawah). Dgn bantuan sendok tekan2 nasi dari atas."
- "Semat ujungnya yg lain. Lakukan smp selesai. Setiap mau membungkus, ukurannya satu piring nasi, jd ambil dulu satu piring nasi liwetnya, baru diisi dan dibungkus. Jadi 1 bungkus = 1 piring nasi."
- "Bakar nasi di atas teflon, bakar bolak-balik, bakar hanya sebatas memberi aroma daun pisang, tdk usah smp gosong, kalo terlalu gosong nanti nasinya juga terlalu kering."
- "Hidangkan dgn lalap mentimun dan daun kemangi."
categories:
- Resep
tags:
- nasi
- bakar
- ikan

katakunci: nasi bakar ikan 
nutrition: 191 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT56M"
recipeyield: "3"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Bakar Ikan Suwir Pedas](https://img-global.cpcdn.com/recipes/e7b6cbfe91e09d6b/682x484cq65/nasi-bakar-ikan-suwir-pedas-foto-resep-utama.webp)

Resep rahasia Nasi Bakar Ikan Suwir Pedas  anti gagal dengan 11 langkahmudah dan cepat cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Dalam Pembuatan Nasi Bakar Ikan Suwir Pedas:

1. beras 3 gelas 750 gr
1. cabe merah keriting potong serong 5 bh
1. bawang merah iris halus 6 btr
1. bawang putih iris halus 3 siung
1. garam 1,5 sdt
1. kaldu bubuk 1/2 sdt
1. serai geprek 2 btg
1. daun salam 4 lbr
1. minyak untuk menumis Sedikit
1. air mendidih panas sesuaikan dgn jenis beras 1200 ml
1. Daun pisang  tusuk gigi untuk membungkus 
1. Isi 
1. Tuna suwir pedas kali ini ikan tuna aku ganti ikan keranjang           lihat resep 

Penasaran seperti apa resep ikan tongkol suwir pedas bumbu enak? Untuk membuat ikan tongkol suwir, pertama setelah ikan didiamkan selama waktu yang telah ditentukan, silahkan panaskan minyak dalam wajan. Nasi bakar memang hanya menggunakan nasi pada umumnya. Keunikannya terletak pada daun pisang yang membungkus nasi, membuat aromanya lebih menggugah selera. 

<!--inarticleads2-->

## Langkah-langkah Untuk Menyiapkan Nasi Bakar Ikan Suwir Pedas:

1. Buat isiannya dulu. Ikan keranjang/ikan cue/ikan pindang dicuci, dibuang kotorannya dan kepalanya. Goreng jgn terlalu kering. Buang durinya, suwir2 dagingnya jgn terlalu lembut, nanti waktu dimasak akan semakin hancur. Masak spt Tuna Suwir Pedas. -           (lihat resep)
1. Siapkan bahan lainnya. Cuci beras smp bersih, taruh di bowl magicom. Sisihkan.
1. Panaskan minyak, tumis bawang merah dan bawang putih smp layu dan harum. Masukkan potongan cabe merah keriting, aduk2, tunggu smp cabe layu.
1. Tuang tumisan bumbu iris tadi (bawang merah, bawang putih, cabe merah keriting) ke dlm beras yg telah dicuci (tuang dgn minyaknya sekalian). Tambahkan serai dan daun salam.
1. Tuangi air panas mendidih. Beri garam dan kaldu bubuk.
1. Aduk rata. Tutup dan tekan tombol &#39;cook&#39;. Jika tombol sdh berpindah ke &#39;warm&#39; (nasi sdh matang), aduk2 nasinya. Tutup lagi, biarkan nasinya tanak.
1. Ambil sepiring nasi liwet tadi. Siapkan daun pisang dan tusuk gigi (untuk semat). Beri setengah piring nasi liwet di atasnya, ratakan. Beri isian di tengahnya, tutup kembali dgn sisa nasi (setengah piring).
1. Gulung daun pisangnya, semat salah satu ujungnya dgn tusuk gigi. Berdirikan posisi daun (yg disemat berada di bawah). Dgn bantuan sendok tekan2 nasi dari atas.
1. Semat ujungnya yg lain. Lakukan smp selesai. Setiap mau membungkus, ukurannya satu piring nasi, jd ambil dulu satu piring nasi liwetnya, baru diisi dan dibungkus. Jadi 1 bungkus = 1 piring nasi.
1. Bakar nasi di atas teflon, bakar bolak-balik, bakar hanya sebatas memberi aroma daun pisang, tdk usah smp gosong, kalo terlalu gosong nanti nasinya juga terlalu kering.
1. Hidangkan dgn lalap mentimun dan daun kemangi.


Apalagi, ditambahkan tongkol suwir di dalamnya, dijamin makin nagih. Nasi bakar ayam suwir pedas. foto: Instagram/@yoriakitchen. Cara Baru Masak Nasi Bakar Ayam Suwir Pedas, Nasi bakar praktis Resep nasi bakar ikan tongkol pedas. NASI BAKAR AYAM SUWIR KEMANGI PEDAS MANIS &amp; NASI KUCINGПодробнее. 

Demikian informasi  resep Nasi Bakar Ikan Suwir Pedas   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
