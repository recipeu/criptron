---
description: "Resep Nasi Liwet Bakar Ikan Tuna Suir Campur Pete Anti Gagal"
title: "Resep Nasi Liwet Bakar Ikan Tuna Suir Campur Pete Anti Gagal"
slug: 351-resep-nasi-liwet-bakar-ikan-tuna-suir-campur-pete-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-28T15:12:10.748Z 
thumbnail: https://img-global.cpcdn.com/recipes/687fa7cc90e9b734/682x484cq65/nasi-liwet-bakar-ikan-tuna-suir-campur-pete-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/687fa7cc90e9b734/682x484cq65/nasi-liwet-bakar-ikan-tuna-suir-campur-pete-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/687fa7cc90e9b734/682x484cq65/nasi-liwet-bakar-ikan-tuna-suir-campur-pete-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/687fa7cc90e9b734/682x484cq65/nasi-liwet-bakar-ikan-tuna-suir-campur-pete-foto-resep-utama.webp
author: Carolyn Rivera
ratingvalue: 3.5
reviewcount: 12
recipeingredient:
- "beras 1 setngah gelas takaran beras "
- "daun pisang stngah tua 3 lembar"
- "gigi 6 tusuk"
- "bawang Merah 5"
- "bawang Putih 4"
- "daun jeruk 3"
- "serai 2"
- "daun salam 2"
- "Bahan Isian "
- "ikan tuna yang udah di potong 6 potong"
- "Pete sesuai selere 2 tangkai"
- "cabe merah besar 6"
- "bawang merah 6"
- "bawang putih 4"
- "kunyit bubuk 1/2 sdt"
- "daun jeruk 3 lembar"
- "serai 2 batang"
- "gula pasir 1/2 sdt"
- "kaldu jamur 1 sdm"
- "garam 1/2 sdt"
recipeinstructions:
- "Cuci beras sampai bersih, masukkan daun jeruk (di sobek2 biar wanginya keluar).. iris tipis bawang merah bawang putih masukkan daun salam dn serai tumis smpe layu dan harum angkat tumisan td kemudian siram di beras yg sdah di cuci. (note: di sni sy memaki rice cooker untk membuat nasi liwetnya kurang lebih 30menit,)"
- "Siapkan daun pisang, jgan lupa untuk di lap biar daunnya bersih.. kemudian di jemur krang lebih 5mnit biar daunnya lemes."
- "Cuci bersih ikan tuna yg sudah di potong perasi jeruk nipis, kemudian rebus kurang lebih 15menit. stlah di rasa sdh stngah matang angkat ikan tuna tadi, tunggu dingin stlah dingin suir2 ikan tuna td."
- "Haluskan bawang merah, bawang putih, dan cabai merah. kemudian potong kecil2 pete sesuai selera."
- "Panaskan minyak, tumis bumbu yang sudah di haluskan tadi. masukkan daun jeruk, serai, kunyit bubuk, tumis smpe layu dan warna kecoklatan. masukkan ikan tuna yg sudah di suir2 tadi, aduk smpe merata. jgan lupa masukan pete, kaldu jamur, garam, dan gula."
- "Setelah nasi liwetnya matang, keluarkan dr rice cooker diamkan slma 15menit biar hawa panasnya hilang."
- "Siapakn daun pisang yang sudah di bersihkan td, dgan tusuk gigi. tuang 2sdm nasi liwet di atas daun pisang bersama ikan tuna tadi. kemudian bungkus seperti membungkus lemper. (note : jgn terllu ketat krna dapt menyebabkn gulungan pecah/robek pada saat di bakar)"
- "Setlah it panaskan bakaran kompor, olesi sedikit minyak. bakar dngan api sedang,. jgan lupa untuk di bolak2ikn agar bakarnya merata."
- "Angkat dan hidangkan selagi panas, slmat mencoba bunda."
categories:
- Resep
tags:
- nasi
- liwet
- bakar

katakunci: nasi liwet bakar 
nutrition: 110 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT31M"
recipeyield: "4"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Liwet Bakar Ikan Tuna Suir Campur Pete](https://img-global.cpcdn.com/recipes/687fa7cc90e9b734/682x484cq65/nasi-liwet-bakar-ikan-tuna-suir-campur-pete-foto-resep-utama.webp)

Resep dan cara mengolah  Nasi Liwet Bakar Ikan Tuna Suir Campur Pete cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Untuk Menyiapkan Nasi Liwet Bakar Ikan Tuna Suir Campur Pete:

1. beras 1 setngah gelas takaran beras 
1. daun pisang stngah tua 3 lembar
1. gigi 6 tusuk
1. bawang Merah 5
1. bawang Putih 4
1. daun jeruk 3
1. serai 2
1. daun salam 2
1. Bahan Isian 
1. ikan tuna yang udah di potong 6 potong
1. Pete sesuai selere 2 tangkai
1. cabe merah besar 6
1. bawang merah 6
1. bawang putih 4
1. kunyit bubuk 1/2 sdt
1. daun jeruk 3 lembar
1. serai 2 batang
1. gula pasir 1/2 sdt
1. kaldu jamur 1 sdm
1. garam 1/2 sdt



<!--inarticleads2-->

## Cara Membuat Nasi Liwet Bakar Ikan Tuna Suir Campur Pete:

1. Cuci beras sampai bersih, masukkan daun jeruk (di sobek2 biar wanginya keluar).. iris tipis bawang merah bawang putih masukkan daun salam dn serai tumis smpe layu dan harum angkat tumisan td kemudian siram di beras yg sdah di cuci. (note: di sni sy memaki rice cooker untk membuat nasi liwetnya kurang lebih 30menit,)
1. Siapkan daun pisang, jgan lupa untuk di lap biar daunnya bersih.. kemudian di jemur krang lebih 5mnit biar daunnya lemes.
1. Cuci bersih ikan tuna yg sudah di potong perasi jeruk nipis, kemudian rebus kurang lebih 15menit. stlah di rasa sdh stngah matang angkat ikan tuna tadi, tunggu dingin stlah dingin suir2 ikan tuna td.
1. Haluskan bawang merah, bawang putih, dan cabai merah. kemudian potong kecil2 pete sesuai selera.
1. Panaskan minyak, tumis bumbu yang sudah di haluskan tadi. masukkan daun jeruk, serai, kunyit bubuk, tumis smpe layu dan warna kecoklatan. masukkan ikan tuna yg sudah di suir2 tadi, aduk smpe merata. jgan lupa masukan pete, kaldu jamur, garam, dan gula.
1. Setelah nasi liwetnya matang, keluarkan dr rice cooker diamkan slma 15menit biar hawa panasnya hilang.
1. Siapakn daun pisang yang sudah di bersihkan td, dgan tusuk gigi. tuang 2sdm nasi liwet di atas daun pisang bersama ikan tuna tadi. kemudian bungkus seperti membungkus lemper. (note : jgn terllu ketat krna dapt menyebabkn gulungan pecah/robek pada saat di bakar)
1. Setlah it panaskan bakaran kompor, olesi sedikit minyak. bakar dngan api sedang,. jgan lupa untuk di bolak2ikn agar bakarnya merata.
1. Angkat dan hidangkan selagi panas, slmat mencoba bunda.




Terima kasih telah menggunakan resep yang kami tampilkan di sini. Selamat mencoba!
