---
description: "Resep Nasi Daun Jeruk yang Sempurna"
title: "Resep Nasi Daun Jeruk yang Sempurna"
slug: 318-resep-nasi-daun-jeruk-yang-sempurna
future: true
lang: id
language: id
languageCode: id
publishDate: 2022-01-03T11:08:50.131Z 
thumbnail: https://img-global.cpcdn.com/recipes/ebbe7c7138a0a3a3/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/ebbe7c7138a0a3a3/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/ebbe7c7138a0a3a3/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/ebbe7c7138a0a3a3/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
author: Lettie Moran
ratingvalue: 4.9
reviewcount: 6
recipeingredient:
- "beras 2 cangkir"
- "Air "
- "Bahan Daun Jeruk  "
- "daun jeruk iris cincang buang tangkai ditengah daun 8 lembar"
- "bawang putih iris cincang 2 siung"
- "mentega 1 sdm"
- "minyak goreng 1 sdm"
- "penyedap rasa 1 sdt"
recipeinstructions:
- "Cuci bersih beras. Lalu tambahkan air seruas jari. Masak pake rice cooker ajaa biar simple..hehehehhee"
- "Panas minyak goreng lalu kecilkan apinya. Masukan bawang putih tumis hingga harum (jgn sampe gosong yaah)."
- "Lalu masukan daun jeruk. Aduk rata tambahkan penyedap rasa, tumis hingga matang dan harum. Matikan api."
- "Tambahkan mentega. Aduk rata hingga meleleh."
- "Ambil nasi yang sudah matang ke dalam mangkok, lalu masukan bumbu daun jeruknya. Aduk rata. Sajikan 😘😘😘😘"
- "Bumbu daun jeruknya bisa sesuai selera yaaah mau semua dimasukan atau sebagian sebagian.."
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 103 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT40M"
recipeyield: "1"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk](https://img-global.cpcdn.com/recipes/ebbe7c7138a0a3a3/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp)

Resep dan cara mengolah  Nasi Daun Jeruk cocok sekali jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Dalam Menyiapkan Nasi Daun Jeruk:

1. beras 2 cangkir
1. Air 
1. Bahan Daun Jeruk  
1. daun jeruk iris cincang buang tangkai ditengah daun 8 lembar
1. bawang putih iris cincang 2 siung
1. mentega 1 sdm
1. minyak goreng 1 sdm
1. penyedap rasa 1 sdt

Nasi daun jeruk siap dihidangkan dengan. Nasi daun jeruk ini memang sedang tren di kalangan masyarakat Indonesia, banyak sekali kaum muda mudi yang berlomba-lomba membuat makanan nasi putih spesial ini. Nasi daun jeruk ala geprek bensu rekomended buat di coba. Geprek bensu nasi daun jeruk anti mainst. 

<!--inarticleads2-->

## Langkah-langkah Untuk Membuat Nasi Daun Jeruk:

1. Cuci bersih beras. Lalu tambahkan air seruas jari. Masak pake rice cooker ajaa biar simple..hehehehhee
1. Panas minyak goreng lalu kecilkan apinya. Masukan bawang putih tumis hingga harum (jgn sampe gosong yaah).
1. Lalu masukan daun jeruk. Aduk rata tambahkan penyedap rasa, tumis hingga matang dan harum. Matikan api.
1. Tambahkan mentega. Aduk rata hingga meleleh.
1. Ambil nasi yang sudah matang ke dalam mangkok, lalu masukan bumbu daun jeruknya. Aduk rata. Sajikan 😘😘😘😘
1. Bumbu daun jeruknya bisa sesuai selera yaaah mau semua dimasukan atau sebagian sebagian..


Gurih dan wangi dari daun jeruk menambah kelezatan nasi daun jeruk. Nasi dengan campuran daun jeruk yang wangi sedang tren. Hai selamat pagi sahabat CWS, pagi ini saya share resep Nasi Daun Jeruk. Praktis banget karena saya gunakan rice cooker. Rasanya mirip nasi uduk tapi wangiiii. 

Salah satu masakan yang cukup praktis pembuatannya adalah  Nasi Daun Jeruk. Selain itu  Nasi Daun Jeruk  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu ikuti 6 langkah, dan  Nasi Daun Jeruk  pun siap di hidangkan. selamat mencoba !
