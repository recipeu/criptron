---
description: "Resep Nasi Ayam Hainan Anti Gagal"
title: "Resep Nasi Ayam Hainan Anti Gagal"
slug: 442-resep-nasi-ayam-hainan-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-04T08:04:47.872Z 
thumbnail: https://img-global.cpcdn.com/recipes/be9156b6973c802f/682x484cq65/nasi-ayam-hainan-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/be9156b6973c802f/682x484cq65/nasi-ayam-hainan-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/be9156b6973c802f/682x484cq65/nasi-ayam-hainan-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/be9156b6973c802f/682x484cq65/nasi-ayam-hainan-foto-resep-utama.webp
author: Francisco Hardy
ratingvalue: 3.8
reviewcount: 4
recipeingredient:
- "beras 200 gr"
- "daun pandansimpulkan 2 lbr"
- "bwg putihhaluskan 2 siung"
- "jahehaluskan Sejempol"
- "saus tiram 1 sdm"
- "minyak wijen 1 sdm"
- "kecap ikan 1 sdt"
- "gula pasir 1 sdt"
- "kaldu bubuk 1/2 sdt"
- "garam 1/2 sdt"
- "Bahan rebusan ayam "
- "dada ayam 300 gr"
- "bwg putihgeprek 2 siung"
- "jahegeprek Sejempol"
- "serehgeprek 1 btg"
- "daun bwg prepotong 2 1 btg"
- "air 400 ml"
- "Bahan saus "
- "bwg bombay 1/2 buah"
- "bwg putihhaluskan 1 siung"
- "myk wijen 1 sdm"
- "kecap ikan 1 sdm"
- "saus tiram 1 sdt"
recipeinstructions:
- "Rebus ayam dgn semua bhn rebusan hingga ayam matang. Angkat dan tiriskan(air rebusan jgn dibuang)"
- "Panaskan sdkit minyak.Tumis bwg putih dan jahe yg sdh dihaluskan. Tambahkan beras dan bahan lainnya aduk rata"
- "Masukkan beras berbumbu ke dalam air rebusan ayam lalu masak bersama bhn lainnya spt memasak nasi biasa menggunakan rice cooker/ magic com (sy memakai dandang coz rice cooker lg ngambek jd berasnya diaron dulu di panci)"
- "Buat saus untuk ayamnya. Tumis bombay hingga harum lalu tambahkan bahan lainnya."
categories:
- Resep
tags:
- nasi
- ayam
- hainan

katakunci: nasi ayam hainan 
nutrition: 109 calories
recipecuisine: Indonesian
preptime: "PT39M"
cooktime: "PT32M"
recipeyield: "3"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Ayam Hainan](https://img-global.cpcdn.com/recipes/be9156b6973c802f/682x484cq65/nasi-ayam-hainan-foto-resep-utama.webp)

4 langkah mudah membuat  Nasi Ayam Hainan cocok sekali jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Dalam Menyiapkan Nasi Ayam Hainan:

1. beras 200 gr
1. daun pandansimpulkan 2 lbr
1. bwg putihhaluskan 2 siung
1. jahehaluskan Sejempol
1. saus tiram 1 sdm
1. minyak wijen 1 sdm
1. kecap ikan 1 sdt
1. gula pasir 1 sdt
1. kaldu bubuk 1/2 sdt
1. garam 1/2 sdt
1. Bahan rebusan ayam 
1. dada ayam 300 gr
1. bwg putihgeprek 2 siung
1. jahegeprek Sejempol
1. serehgeprek 1 btg
1. daun bwg prepotong 2 1 btg
1. air 400 ml
1. Bahan saus 
1. bwg bombay 1/2 buah
1. bwg putihhaluskan 1 siung
1. myk wijen 1 sdm
1. kecap ikan 1 sdm
1. saus tiram 1 sdt



<!--inarticleads2-->

## Cara Membuat Nasi Ayam Hainan:

1. Rebus ayam dgn semua bhn rebusan hingga ayam matang. Angkat dan tiriskan(air rebusan jgn dibuang)
1. Panaskan sdkit minyak.Tumis bwg putih dan jahe yg sdh dihaluskan. Tambahkan beras dan bahan lainnya aduk rata
1. Masukkan beras berbumbu ke dalam air rebusan ayam lalu masak bersama bhn lainnya spt memasak nasi biasa menggunakan rice cooker/ magic com (sy memakai dandang coz rice cooker lg ngambek jd berasnya diaron dulu di panci)
1. Buat saus untuk ayamnya. Tumis bombay hingga harum lalu tambahkan bahan lainnya.




Demikian informasi  resep Nasi Ayam Hainan   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
