---
description: "Cara Gampang Membuat NASI KUNING DAUN JERUK (Rice Cooker) yang Menggugah Selera"
title: "Cara Gampang Membuat NASI KUNING DAUN JERUK (Rice Cooker) yang Menggugah Selera"
slug: 345-cara-gampang-membuat-nasi-kuning-daun-jeruk-rice-cooker-yang-menggugah-selera
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-26T08:59:44.959Z 
thumbnail: https://img-global.cpcdn.com/recipes/c255313da4249d93/682x484cq65/nasi-kuning-daun-jeruk-rice-cooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/c255313da4249d93/682x484cq65/nasi-kuning-daun-jeruk-rice-cooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/c255313da4249d93/682x484cq65/nasi-kuning-daun-jeruk-rice-cooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/c255313da4249d93/682x484cq65/nasi-kuning-daun-jeruk-rice-cooker-foto-resep-utama.webp
author: Isaiah McKinney
ratingvalue: 3.3
reviewcount: 7
recipeingredient:
- "beras 300 gr"
- "bawang merah 4 siung"
- "bawang putih 3 siung"
- "daun bawang selera 1 tangkai"
- "kemiri 2 butir"
- "daun salam ukuran sedang 4 lembar"
- "daun jeruk ukuran sedang 5 lembar"
- "sirih 2 tangkai"
- "lengkuas selera "
- "garam 1 sdt"
- "gula pasir 1/2 sdt"
- "penyedap rasa "
- "bubuk lada selera "
- "bubuk ketumbar selera "
- "kunyit ukuran sedang 2 batang"
- "cabe rawit 4 biji"
- "Santan secukupnya"
- "tomat ukuran sedang selera 1/4"
recipeinstructions:
- "Cuci beras sampai bersih, tiriskan"
- "Haluskan bumbu2 (bawang putih, bawang merah, kemiri, kunyit dan tomat)"
- "Tumis irisan daun bawang sampai tercium harum, masukkan bumbu yang sudah di haluskan dan tambahkan santan yang sudah dicampur dengan air"
- "Masukkan sirih yang sudah digeprek, daun salam, lengkus dan irisan daun jeruk"
- "Masukkan garam, gula pasir, penyedap, bubuk lada dan bubuk ketumbar"
- "Tunggu sampai mendidih dan tercium harum"
- "Masukkan santan rebusan yang sudah dimasak ke dalam penanak nasi (rice cooker)"
- "Masak nasi kuning sampai matang di dalam rice cooker"
- "Nasi kuning daun jeruk siap dihidangkan..."
categories:
- Resep
tags:
- nasi
- kuning
- daun

katakunci: nasi kuning daun 
nutrition: 257 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT42M"
recipeyield: "3"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![NASI KUNING DAUN JERUK (Rice Cooker)](https://img-global.cpcdn.com/recipes/c255313da4249d93/682x484cq65/nasi-kuning-daun-jeruk-rice-cooker-foto-resep-utama.webp)

Ingin membuat NASI KUNING DAUN JERUK (Rice Cooker) ? Coba resep berikut ini. Cara memasaknya sangat praktis namun hasilnya gurih dan lezat cocok banget jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Untuk Menyiapkan NASI KUNING DAUN JERUK (Rice Cooker):

1. beras 300 gr
1. bawang merah 4 siung
1. bawang putih 3 siung
1. daun bawang selera 1 tangkai
1. kemiri 2 butir
1. daun salam ukuran sedang 4 lembar
1. daun jeruk ukuran sedang 5 lembar
1. sirih 2 tangkai
1. lengkuas selera 
1. garam 1 sdt
1. gula pasir 1/2 sdt
1. penyedap rasa 
1. bubuk lada selera 
1. bubuk ketumbar selera 
1. kunyit ukuran sedang 2 batang
1. cabe rawit 4 biji
1. Santan secukupnya
1. tomat ukuran sedang selera 1/4



<!--inarticleads2-->

## Tata Cara Membuat NASI KUNING DAUN JERUK (Rice Cooker):

1. Cuci beras sampai bersih, tiriskan
1. Haluskan bumbu2 (bawang putih, bawang merah, kemiri, kunyit dan tomat)
1. Tumis irisan daun bawang sampai tercium harum, masukkan bumbu yang sudah di haluskan dan tambahkan santan yang sudah dicampur dengan air
1. Masukkan sirih yang sudah digeprek, daun salam, lengkus dan irisan daun jeruk
1. Masukkan garam, gula pasir, penyedap, bubuk lada dan bubuk ketumbar
1. Tunggu sampai mendidih dan tercium harum
1. Masukkan santan rebusan yang sudah dimasak ke dalam penanak nasi (rice cooker)
1. Masak nasi kuning sampai matang di dalam rice cooker
1. Nasi kuning daun jeruk siap dihidangkan...




Terima kasih telah menggunakan resep yang kami tampilkan di sini. Semoga bermanfaat dan selamat mencoba!
