---
description: "Resep Nasi Daun Jeruk Magicom yang Bikin Ngiler"
title: "Resep Nasi Daun Jeruk Magicom yang Bikin Ngiler"
slug: 272-resep-nasi-daun-jeruk-magicom-yang-bikin-ngiler
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-29T04:06:09.236Z 
thumbnail: https://img-global.cpcdn.com/recipes/9835e0b91bddd238/682x484cq65/nasi-daun-jeruk-magicom-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/9835e0b91bddd238/682x484cq65/nasi-daun-jeruk-magicom-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/9835e0b91bddd238/682x484cq65/nasi-daun-jeruk-magicom-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/9835e0b91bddd238/682x484cq65/nasi-daun-jeruk-magicom-foto-resep-utama.webp
author: Luke Lambert
ratingvalue: 4.6
reviewcount: 4
recipeingredient:
- "beras cuci bersih 2 cup"
- "daun jeruk buang tulangnya dan di potong tipis2 10 lembar"
- "Bumbu Tumis "
- "Minyak secukupnya"
- "bawang putih 5 siung"
- "bawang merah 2 siung"
- "sereh yg kecil dipotong tipis2 1 btg"
- "cabe kriting cabe rawit sesuai selera optional 3 batang"
- "jeruk limau 1 bh"
- "santan kara 1 bgks"
- "daun pandan 2 lembar"
- "daun salam 1 lembar"
recipeinstructions:
- "Bersihkan beras, lalu potong2 daun jeruk ke dalam beras, sisakan sedikit air untuk direndam tp jgn terlalu banyak, sambil diaduk agar daun jeruk dan beras menyatu"
- "Iris tipis, sereh, bawang merah dan bawang putih, panaskan minyak, lalu tumis bahan2 yg telah di iris tipis, sampai harum, masukkan salam, perasan jeruk limau, dan santan. Tambakan air sesuai dengan bungkusan santan. Aduk2 hingga mendidih. Masukkan irisan cabai merah kriting/cabe rawit sesuai selera (optional, jika tidak suka juga tidak apa2). Tunggu sampai mendidih."
- "Masukkan tumisan santan di atas ke dalam rendaman beras serta daun jeruk. Tambahkan air dari wajan bekas tumisan agar bahan yg ada tidak terbuang. Masukkan daun pandan yg sudah diikat. Sesuaikan air rendaman dengan beras, seperti memasak nasi."
- "Letakkan di magicom dan tunggu hingga matang."
- "Untuk pelengkap yg ada di foto tunggu aku share di postingan resep berikutnya yaa..."
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 228 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT45M"
recipeyield: "3"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk Magicom](https://img-global.cpcdn.com/recipes/9835e0b91bddd238/682x484cq65/nasi-daun-jeruk-magicom-foto-resep-utama.webp)

Resep dan cara memasak  Nasi Daun Jeruk Magicom yang harus bunda coba dirumah

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Untuk Pembuatan Nasi Daun Jeruk Magicom:

1. beras cuci bersih 2 cup
1. daun jeruk buang tulangnya dan di potong tipis2 10 lembar
1. Bumbu Tumis 
1. Minyak secukupnya
1. bawang putih 5 siung
1. bawang merah 2 siung
1. sereh yg kecil dipotong tipis2 1 btg
1. cabe kriting cabe rawit sesuai selera optional 3 batang
1. jeruk limau 1 bh
1. santan kara 1 bgks
1. daun pandan 2 lembar
1. daun salam 1 lembar



<!--inarticleads2-->

## Cara Menyiapkan Nasi Daun Jeruk Magicom:

1. Bersihkan beras, lalu potong2 daun jeruk ke dalam beras, sisakan sedikit air untuk direndam tp jgn terlalu banyak, sambil diaduk agar daun jeruk dan beras menyatu
1. Iris tipis, sereh, bawang merah dan bawang putih, panaskan minyak, lalu tumis bahan2 yg telah di iris tipis, sampai harum, masukkan salam, perasan jeruk limau, dan santan. Tambakan air sesuai dengan bungkusan santan. Aduk2 hingga mendidih. Masukkan irisan cabai merah kriting/cabe rawit sesuai selera (optional, jika tidak suka juga tidak apa2). Tunggu sampai mendidih.
1. Masukkan tumisan santan di atas ke dalam rendaman beras serta daun jeruk. Tambahkan air dari wajan bekas tumisan agar bahan yg ada tidak terbuang. Masukkan daun pandan yg sudah diikat. Sesuaikan air rendaman dengan beras, seperti memasak nasi.
1. Letakkan di magicom dan tunggu hingga matang.
1. Untuk pelengkap yg ada di foto tunggu aku share di postingan resep berikutnya yaa...




Terima kasih telah menggunakan resep yang tim kami tampilkan di sini. Selamat mencoba!
