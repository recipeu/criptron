---
description: "Cara Gampang Menyiapkan Sambal Kacang Nasi Uduk Betawi Anti Gagal"
title: "Cara Gampang Menyiapkan Sambal Kacang Nasi Uduk Betawi Anti Gagal"
slug: 38-cara-gampang-menyiapkan-sambal-kacang-nasi-uduk-betawi-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-22T15:48:44.891Z 
thumbnail: https://img-global.cpcdn.com/recipes/8428bccddb730ef1/682x484cq65/sambal-kacang-nasi-uduk-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/8428bccddb730ef1/682x484cq65/sambal-kacang-nasi-uduk-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/8428bccddb730ef1/682x484cq65/sambal-kacang-nasi-uduk-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/8428bccddb730ef1/682x484cq65/sambal-kacang-nasi-uduk-betawi-foto-resep-utama.webp
author: Cynthia Young
ratingvalue: 4.5
reviewcount: 14
recipeingredient:
- "kacang tanah 50 gram"
- "cabai rawit domba 3"
- "cabai keriting 5"
- "bawang putih 1 siung"
- "gula pasir 1 sdt"
- "garam 1/2 sdt"
- "terasi bakar saya tidak pakai 1/4 sdt"
- "royco ayam tambahan saya boleh skip 1/2 sdt"
- "air jeruk nipis di kulkas sisa ini 1/2 sdm"
- "cuka makan tambahan dari saya boleh skip 1/2 sdm"
- "air panas 50 ml"
recipeinstructions:
- "Siapkan semua bahan."
- "Kacang tanah, cabai, dan bawang putih digoreng. Hati-hati kacang gosong seperti punya saya 🤭 Kemudian haluskan semua bahan, kecuali cuka dan air jeruk nipis ya. Masukkan air panas sedikit demi sedikit hingga kekentalannya pas."
- "Pindahkan ke mangkuk, dan tambahkan cuka makan + air jeruk nipis. Sambal kacang siap disajikan"
categories:
- Resep
tags:
- sambal
- kacang
- nasi

katakunci: sambal kacang nasi 
nutrition: 134 calories
recipecuisine: Indonesian
preptime: "PT39M"
cooktime: "PT56M"
recipeyield: "3"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Sambal Kacang Nasi Uduk Betawi](https://img-global.cpcdn.com/recipes/8428bccddb730ef1/682x484cq65/sambal-kacang-nasi-uduk-betawi-foto-resep-utama.webp)

Ingin membuat Sambal Kacang Nasi Uduk Betawi ? Coba resep berikut ini. Cara memasaknya sangat praktis namun jangan kaget jika hasilnya gurih dan lezat yang musti kamu coba segera

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Dalam Pembuatan Sambal Kacang Nasi Uduk Betawi:

1. kacang tanah 50 gram
1. cabai rawit domba 3
1. cabai keriting 5
1. bawang putih 1 siung
1. gula pasir 1 sdt
1. garam 1/2 sdt
1. terasi bakar saya tidak pakai 1/4 sdt
1. royco ayam tambahan saya boleh skip 1/2 sdt
1. air jeruk nipis di kulkas sisa ini 1/2 sdm
1. cuka makan tambahan dari saya boleh skip 1/2 sdm
1. air panas 50 ml

Buat Pelengkap Nasi Kuning, Nasi Uduk, dll. Nasi uduk yang cukup terkenal adalah nasi uduk betawi, ya tidak salah memang, hal ini dikarenakan nasi uduk sejatinya berasal dari betawi. Resep nasi uduk betawi sebenarnya cukup sederhana, cara membuatnya juga tidak terlalu sulit, bahan dan bumbunya mudah didapat, serta tidak butuh waktu. Nasi uduk betawi adalah salah satu dari varian nasi uduk yang merupakan makanan khas tanah air. 

<!--inarticleads2-->

## Tata Cara Membuat Sambal Kacang Nasi Uduk Betawi:

1. Siapkan semua bahan.
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/6dddf260a274168e/160x128cq70/sambal-kacang-nasi-uduk-betawi-langkah-memasak-1-foto.webp" alt="Sambal Kacang Nasi Uduk Betawi" width="340" height="340">
><img class="lazyload" data-src="https://img-global.cpcdn.com/steps/29d48f2363ad9b85/160x128cq70/sambal-kacang-nasi-uduk-betawi-langkah-memasak-1-foto.webp" alt="Sambal Kacang Nasi Uduk Betawi" width="340" height="340">
>1. Kacang tanah, cabai, dan bawang putih digoreng. Hati-hati kacang gosong seperti punya saya 🤭 Kemudian haluskan semua bahan, kecuali cuka dan air jeruk nipis ya. Masukkan air panas sedikit demi sedikit hingga kekentalannya pas.
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/54d8d88188cd8fbe/160x128cq70/sambal-kacang-nasi-uduk-betawi-langkah-memasak-2-foto.webp" alt="Sambal Kacang Nasi Uduk Betawi" width="340" height="340">
><img class="lazyload" data-src="https://img-global.cpcdn.com/steps/7efdb94c8ba2f399/160x128cq70/sambal-kacang-nasi-uduk-betawi-langkah-memasak-2-foto.webp" alt="Sambal Kacang Nasi Uduk Betawi" width="340" height="340">
>1. Pindahkan ke mangkuk, dan tambahkan cuka makan + air jeruk nipis. Sambal kacang siap disajikan


Salah satu nya adalah Nasi Uduk Betawi atau bisa juga disebut nasi uduk jakarta. Bagi anda yang hobi memasak, tidak ada salahnya untuk mencoba resep nasi uduk ini dirumah. Uduk (Javanese: segá uduk; Indonesian: &#34;nasi uduk&#34;) is an Indonesian style steamed rice cooked in coconut milk dish, which originated from Java. Buat kamu yang suka makan nasi uduk, pasti suka dengan nasi uduk Betawi dengan sambal kacang yang harum, gurih, dan enak banget. Kalau di Jakarta, nasi uduk disajikan dengan sambal kacang. 

Demikian informasi  resep Sambal Kacang Nasi Uduk Betawi   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
