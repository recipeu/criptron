---
description: "Langkah Mudah untuk Membuat Nasi Uduk yang Lezat Sekali"
title: "Langkah Mudah untuk Membuat Nasi Uduk yang Lezat Sekali"
slug: 175-langkah-mudah-untuk-membuat-nasi-uduk-yang-lezat-sekali
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-27T09:30:35.983Z 
thumbnail: https://img-global.cpcdn.com/recipes/4a02af9ae1af007a/682x484cq65/nasi-uduk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/4a02af9ae1af007a/682x484cq65/nasi-uduk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/4a02af9ae1af007a/682x484cq65/nasi-uduk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/4a02af9ae1af007a/682x484cq65/nasi-uduk-foto-resep-utama.webp
author: Walter Murray
ratingvalue: 3.4
reviewcount: 13
recipeingredient:
- "beras 2,5 cup"
- "santan 1 liter"
- "daun salam 5"
- "daun jeruk 5"
- "serai 3 batang"
- "bawang putih halus 2 siung"
- "laos 1 ruas besar"
- "jahe optional 1 ruas kecil"
- "kencur optional 1 ruas kecil"
- "garam Secukupnya"
- "kaldu jamur Sedikit"
- "minyak dari bawang merah Sedikit"
- "daun pandan 2 lembar"
recipeinstructions:
- "Beras dicuci bersih, ditiriskan, dan dikukus sekita 15 menit"
- "Masukan bahan2 dan minyak. Kemudian didihkan santan sebentar. Tambahkan garam dan kaldu secukupnya"
- "Setelah mendidih, beras tadi dicampur ke santan. Diamkan selama 15 menit sambil ditutup hingga santan meresap ke beras tersebut"
- "Beras tersebut di dikukus kembali selama 20 menit agar tanak"
categories:
- Resep
tags:
- nasi
- uduk

katakunci: nasi uduk 
nutrition: 138 calories
recipecuisine: Indonesian
preptime: "PT19M"
cooktime: "PT60M"
recipeyield: "4"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk](https://img-global.cpcdn.com/recipes/4a02af9ae1af007a/682x484cq65/nasi-uduk-foto-resep-utama.webp)

4 langkah cepat membuat  Nasi Uduk yang wajib ibu coba dirumah

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Dalam Pembuatan Nasi Uduk:

1. beras 2,5 cup
1. santan 1 liter
1. daun salam 5
1. daun jeruk 5
1. serai 3 batang
1. bawang putih halus 2 siung
1. laos 1 ruas besar
1. jahe optional 1 ruas kecil
1. kencur optional 1 ruas kecil
1. garam Secukupnya
1. kaldu jamur Sedikit
1. minyak dari bawang merah Sedikit
1. daun pandan 2 lembar



<!--inarticleads2-->

## Cara Menyiapkan Nasi Uduk:

1. Beras dicuci bersih, ditiriskan, dan dikukus sekita 15 menit
1. Masukan bahan2 dan minyak. Kemudian didihkan santan sebentar. Tambahkan garam dan kaldu secukupnya
1. Setelah mendidih, beras tadi dicampur ke santan. Diamkan selama 15 menit sambil ditutup hingga santan meresap ke beras tersebut
1. Beras tersebut di dikukus kembali selama 20 menit agar tanak




Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
