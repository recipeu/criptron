---
description: "Resep Nasi Uduk Betawi yang Bisa Manjain Lidah"
title: "Resep Nasi Uduk Betawi yang Bisa Manjain Lidah"
slug: 186-resep-nasi-uduk-betawi-yang-bisa-manjain-lidah
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-30T23:43:05.146Z 
thumbnail: https://img-global.cpcdn.com/recipes/262e7b5e553f0715/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/262e7b5e553f0715/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/262e7b5e553f0715/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/262e7b5e553f0715/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
author: Ina Hayes
ratingvalue: 4.8
reviewcount: 12
recipeingredient:
- "beras rendam semalaman 1 liter"
- "santan dari 1 butir kelapa 750 ml"
- "daun salam 5 lembar"
- "sereh geprek 2 batang"
- "jahe potongpotong 3 ruas"
- "kayu manis 2 batang"
- "garam 1 sdm munjung"
- "Bahan pelengkap  "
- "Emping goreng sesuai selera"
- "Bawang goreng sesuai selera"
- "Sambal kacang sesuai selera"
recipeinstructions:
- "Kukus beras selama kurang lebih 20 menit, angkat, sisihkan"
- "Masak santan bersama bahan lain dan garam hingga mendidih, matikan api"
- "Tuang beras yang sudah di kukus ke dalam santan tadi, aduk hingga rata"
- "Panaskan langseng, masukkan beras, masak hingga matang kurang lebih 40-50 menit."
- "Setelah matang angkat, aduk nasi sambil menyisihkan bahan rempah tadi."
- "Nasi uduk siap dihidangkan dengan lauk dan bahan pelengkap"
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 274 calories
recipecuisine: Indonesian
preptime: "PT38M"
cooktime: "PT38M"
recipeyield: "2"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Betawi](https://img-global.cpcdn.com/recipes/262e7b5e553f0715/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp)

Ingin membuat Nasi Uduk Betawi ? Coba resep berikut ini. Cara memasaknya sangat praktis namun jangan kaget jika hasilnya gurih dan lezat yang wajib ibu coba dirumah

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Dalam Pembuatan Nasi Uduk Betawi:

1. beras rendam semalaman 1 liter
1. santan dari 1 butir kelapa 750 ml
1. daun salam 5 lembar
1. sereh geprek 2 batang
1. jahe potongpotong 3 ruas
1. kayu manis 2 batang
1. garam 1 sdm munjung
1. Bahan pelengkap  
1. Emping goreng sesuai selera
1. Bawang goreng sesuai selera
1. Sambal kacang sesuai selera



<!--inarticleads2-->

## Langkah-langkah Untuk Membuat Nasi Uduk Betawi:

1. Kukus beras selama kurang lebih 20 menit, angkat, sisihkan
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/c19663cd0f81d99e/160x128cq70/nasi-uduk-betawi-langkah-memasak-1-foto.webp" alt="Nasi Uduk Betawi" width="340" height="340">
>1. Masak santan bersama bahan lain dan garam hingga mendidih, matikan api
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/7eacab02761da351/160x128cq70/nasi-uduk-betawi-langkah-memasak-2-foto.webp" alt="Nasi Uduk Betawi" width="340" height="340">
>1. Tuang beras yang sudah di kukus ke dalam santan tadi, aduk hingga rata
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/84adaca7cd3e9dea/160x128cq70/nasi-uduk-betawi-langkah-memasak-3-foto.webp" alt="Nasi Uduk Betawi" width="340" height="340">
>1. Panaskan langseng, masukkan beras, masak hingga matang kurang lebih 40-50 menit.
1. Setelah matang angkat, aduk nasi sambil menyisihkan bahan rempah tadi.
1. Nasi uduk siap dihidangkan dengan lauk dan bahan pelengkap




Demikian informasi  resep Nasi Uduk Betawi   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
