---
description: "Langkah Mudah untuk Menyiapkan Nasi Daun Jeruk + Kulit Crispy, Enak"
title: "Langkah Mudah untuk Menyiapkan Nasi Daun Jeruk + Kulit Crispy, Enak"
slug: 311-langkah-mudah-untuk-menyiapkan-nasi-daun-jeruk-kulit-crispy-enak
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-20T13:09:16.352Z 
thumbnail: https://img-global.cpcdn.com/recipes/1bb2b6f08150895e/682x484cq65/nasi-daun-jeruk-kulit-crispy-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/1bb2b6f08150895e/682x484cq65/nasi-daun-jeruk-kulit-crispy-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/1bb2b6f08150895e/682x484cq65/nasi-daun-jeruk-kulit-crispy-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/1bb2b6f08150895e/682x484cq65/nasi-daun-jeruk-kulit-crispy-foto-resep-utama.webp
author: Douglas Henderson
ratingvalue: 5
reviewcount: 10
recipeingredient:
- "Nasi Daun Jeruk  "
- "Beras 2 piring Nasi Putih 1 cup"
- "Daun Jeruk 10-12 lbr"
- "Bawang Putih 6 siung"
- "Margarin  mentega 1 sdm"
- "Kaldu Jamur Secukupnya"
- "Minyak Goreng Secukupnya"
- "Kulit Ayam Crispy  "
- "Kulit Ayam 500 gr"
- "Bawang Putih cincang 5 siung"
- "Garam 1/2 sdt"
- "Kaldu Jamur 1 sdt"
- "Cabe Bubuk me  boncabe 1/2 sdm"
recipeinstructions:
- "Cincang halus daun jeruk dan bawang putih."
- "Tumis bawang putih dengan sedikit minyak hingga harum, lalu masukkan daun jeruk. Aduk rata. Masak hingga bawang agak kecoklatan. Lalu matikan api dan masukkan mentega/margarin"
- "Masukkan pada rice cooker, aduk rata dengan nasi putih yg baru matang."
- "Kulit crispy : Cuci bersih kulit, buang bagian2 minyaknya, potong2 sesuai selera. Lalu keringkan dengan tissue dapur."
- "Marinasi kulit dengan bawang putih cincang, kaldu jamur, garam, dan cabe bubuk. (Aku semalaman)"
- "Masukkan kulit yg sudah di marinasi kedalam teflon. Lalu nyalakan api sedang ke besar, aduk2 kulit hingga kulit berubah warna."
- "Kecilkan api, masak hingga kulit golden brown.😍 dan tiriskan"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 228 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT48M"
recipeyield: "2"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk + Kulit Crispy](https://img-global.cpcdn.com/recipes/1bb2b6f08150895e/682x484cq65/nasi-daun-jeruk-kulit-crispy-foto-resep-utama.webp)

Resep Nasi Daun Jeruk + Kulit Crispy  sederhana dengan 7 langkahmudah dan cepat yang wajib kamu coba dirumah

<!--inarticleads1-->

## Bahan-bahan Yang Dibutuhkan Dalam Menyiapkan Nasi Daun Jeruk + Kulit Crispy:

1. Nasi Daun Jeruk  
1. Beras 2 piring Nasi Putih 1 cup
1. Daun Jeruk 10-12 lbr
1. Bawang Putih 6 siung
1. Margarin  mentega 1 sdm
1. Kaldu Jamur Secukupnya
1. Minyak Goreng Secukupnya
1. Kulit Ayam Crispy  
1. Kulit Ayam 500 gr
1. Bawang Putih cincang 5 siung
1. Garam 1/2 sdt
1. Kaldu Jamur 1 sdt
1. Cabe Bubuk me  boncabe 1/2 sdm



<!--inarticleads2-->

## Cara Mudah Membuat Nasi Daun Jeruk + Kulit Crispy:

1. Cincang halus daun jeruk dan bawang putih.
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/8fe5f95629508b1e/160x128cq70/nasi-daun-jeruk-kulit-crispy-langkah-memasak-1-foto.webp" alt="Nasi Daun Jeruk + Kulit Crispy" width="340" height="340">
>1. Tumis bawang putih dengan sedikit minyak hingga harum, lalu masukkan daun jeruk. Aduk rata. Masak hingga bawang agak kecoklatan. Lalu matikan api dan masukkan mentega/margarin
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/7ae10f8a5430b1f0/160x128cq70/nasi-daun-jeruk-kulit-crispy-langkah-memasak-2-foto.webp" alt="Nasi Daun Jeruk + Kulit Crispy" width="340" height="340">
>1. Masukkan pada rice cooker, aduk rata dengan nasi putih yg baru matang.
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/59a50e1dad11788f/160x128cq70/nasi-daun-jeruk-kulit-crispy-langkah-memasak-3-foto.webp" alt="Nasi Daun Jeruk + Kulit Crispy" width="340" height="340">
><img class="lazyload" data-src="https://img-global.cpcdn.com/steps/ecaad7b30ee0e77d/160x128cq70/nasi-daun-jeruk-kulit-crispy-langkah-memasak-3-foto.webp" alt="Nasi Daun Jeruk + Kulit Crispy" width="340" height="340">
>1. Kulit crispy : Cuci bersih kulit, buang bagian2 minyaknya, potong2 sesuai selera. Lalu keringkan dengan tissue dapur.
1. Marinasi kulit dengan bawang putih cincang, kaldu jamur, garam, dan cabe bubuk. (Aku semalaman)
1. Masukkan kulit yg sudah di marinasi kedalam teflon. Lalu nyalakan api sedang ke besar, aduk2 kulit hingga kulit berubah warna.
1. Kecilkan api, masak hingga kulit golden brown.😍 dan tiriskan




Terima kasih telah menggunakan resep yang kami tampilkan di halaman ini. Semoga bermanfaat dan selamat mencoba!
