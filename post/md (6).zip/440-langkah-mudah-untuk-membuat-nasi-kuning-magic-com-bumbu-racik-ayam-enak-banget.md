---
description: "Langkah Mudah untuk Membuat Nasi kuning magic com bumbu racik ayam, Enak Banget"
title: "Langkah Mudah untuk Membuat Nasi kuning magic com bumbu racik ayam, Enak Banget"
slug: 440-langkah-mudah-untuk-membuat-nasi-kuning-magic-com-bumbu-racik-ayam-enak-banget
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-09T12:36:42.988Z 
thumbnail: https://img-global.cpcdn.com/recipes/a3399fcb5111b6f1/682x484cq65/nasi-kuning-magic-com-bumbu-racik-ayam-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/a3399fcb5111b6f1/682x484cq65/nasi-kuning-magic-com-bumbu-racik-ayam-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/a3399fcb5111b6f1/682x484cq65/nasi-kuning-magic-com-bumbu-racik-ayam-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/a3399fcb5111b6f1/682x484cq65/nasi-kuning-magic-com-bumbu-racik-ayam-foto-resep-utama.webp
author: Garrett Wheeler
ratingvalue: 4.8
reviewcount: 11
recipeingredient:
- "Bahan nasi kuning  "
- "Beras 1/2 kg"
- "Bumbu racik ayam 1 sachet"
- "Kunyit bubuk 1/2 sdt"
- "Sereh "
- "Daun salam "
- "Air secukupnya"
- "Santan kara 1 yang kecil "
- "Bahan pelengkap  "
- "Tempe 1 papan yg 5rb an "
- "Kentang 1/2 kg"
- "Mie burung dara 3 yg sachet kecil "
- "Telor 1/4 kg"
- "Ati ampela 4 pasang"
- "Sosis ayam "
- "Sayuran kol sledry daun bawang "
- "Bumbu  "
- "Bawang Merah "
- "Bawang putih "
- "Kemiri "
- "Merica "
- "Garam "
- "Gula "
- "Penyedap rasa "
- "Santan kara "
- "Cabe merah "
- "Cabe rawit setan "
- "Daun salam "
- "Lengkuas "
- "Kecap manis "
- "Gula merah "
- "Asam jawa "
- "Saus tiram "
recipeinstructions:
- "Masak nasi kuning terlebih dahulu : Cuci bersih beras, kemudian tambahkan air, santan kara, kunyit bubuk, garam, bumbu racik, lengkuas dan daun salam. Masak di magic com seperti biasanya."
- "Bahan pelengkap :  Balado kentang : Potong dadu kentangnya, kemudian goreng sampai garing kecoklatan, tiriskan, potong2 juga ati ampela yg sudah direbus, kemudian sisihkan. Tumis bumbu yang sudah diblender (Bawang merah, bawang putih, cabe merah dan cabe rawit) tumis sampai harum, masukan juga lengkuas dan daun salamnya..kemudian masukan ati ampela, beri sedikit air. Kalo sudah setengah matang masukan kentang yang sudah kita goreng tadi.. tutup rapat, kalo sudah mendidih.. masukan santan kara"
- "Masak kentangnya sampai kuah menyusut. Kemudian test rasa."
- "Orek Tempe :  Potong tempe persegi panjang kecil,goreng sampai kering, tiriskan, kemudian Tumis bumbu yang sudah di iris (cabe merah, Bawang merah, Bawang putih) lengkuas dan salam, sampai harum, masukan gula merah dan air asam Jawa, setelah itu masukan tempe dan beri kecap manis..masak sampai air menyusut dan test rasa"
- "Mie goreng : Rebus mie burung dara sampai matang, lalu tiriskan, goreng sosis sampe agak kering lalu tiriskan,Tumis bumbu yang sudah di haluskan (bawang merah, bawang putih, merica, kemiri) sampai harum, masukan sayuran beri bumbu dan sedikit air, kemudian masukan mie dan sosisnya lalu beri sedikit kecap dan saus tiram, masak hingga matang dan test rasa."
- "Telor dadar : Kocok lepas telur,beri sedikit air dan garam, kemudian goreng tipis2 di teflon, kalo sudah digulung,lalu dipotong potong tipis kayak mie 😁"
- "Kalau nasi sudah matang, jangan lupa diaduk aduk ya Bun..😁"
- "Udah siaaap.. tinggal di tata dipiring kalau mau makan..sesuai selera ya buun... Terima kasiiihh..😇😇"
categories:
- Resep
tags:
- nasi
- kuning
- magic

katakunci: nasi kuning magic 
nutrition: 217 calories
recipecuisine: Indonesian
preptime: "PT39M"
cooktime: "PT52M"
recipeyield: "4"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi kuning magic com bumbu racik ayam](https://img-global.cpcdn.com/recipes/a3399fcb5111b6f1/682x484cq65/nasi-kuning-magic-com-bumbu-racik-ayam-foto-resep-utama.webp)

Resep dan cara mengolah  Nasi kuning magic com bumbu racik ayam yang bisa ibu coba dirumah

<!--inarticleads1-->

## Bahan-bahan Yang Dibutuhkan Untuk Menyiapkan Nasi kuning magic com bumbu racik ayam:

1. Bahan nasi kuning  
1. Beras 1/2 kg
1. Bumbu racik ayam 1 sachet
1. Kunyit bubuk 1/2 sdt
1. Sereh 
1. Daun salam 
1. Air secukupnya
1. Santan kara 1 yang kecil 
1. Bahan pelengkap  
1. Tempe 1 papan yg 5rb an 
1. Kentang 1/2 kg
1. Mie burung dara 3 yg sachet kecil 
1. Telor 1/4 kg
1. Ati ampela 4 pasang
1. Sosis ayam 
1. Sayuran kol sledry daun bawang 
1. Bumbu  
1. Bawang Merah 
1. Bawang putih 
1. Kemiri 
1. Merica 
1. Garam 
1. Gula 
1. Penyedap rasa 
1. Santan kara 
1. Cabe merah 
1. Cabe rawit setan 
1. Daun salam 
1. Lengkuas 
1. Kecap manis 
1. Gula merah 
1. Asam jawa 
1. Saus tiram 

Bumbu dan bahan Nasi Kuning Bumbu Tradisional Lezat Bumbu halus Tumis Tempe ayam pedas manis (lihat resep). Ikuti Tata cara Mengolah Nasi Kuning Bumbu Tradisional Enak. Hai teman² jangan bosan untuk mendukung channel @Dapur Herti ya. kita sama² belajar Dan berbagi resep mudah²an kalian suka Terima kasih. ° Usus ayam•° Daun jeruk•° Bumbu racik ayam goreng•° Tepung Terigu•° Garam•° Minyak goreng. usus ayam, bersihkan•tepung terigu pro tinggi•tepung maizena•soda kue•santan kental•air•garam, lada bubuk, dan kaldu bubuk•bumbu racik ikan goreng, Indofood. Buat sendiri saja Ayam Bakar Teflon &amp; Sate Sapi Bumbu Racik yang sederhana ala racikan rumah. 

<!--inarticleads2-->

## Cara Mudah Menyiapkan Nasi kuning magic com bumbu racik ayam:

1. Masak nasi kuning terlebih dahulu : - Cuci bersih beras, kemudian tambahkan air, santan kara, kunyit bubuk, garam, bumbu racik, lengkuas dan daun salam. Masak di magic com seperti biasanya.
1. Bahan pelengkap : -  Balado kentang : - Potong dadu kentangnya, kemudian goreng sampai garing kecoklatan, tiriskan, potong2 juga ati ampela yg sudah direbus, kemudian sisihkan. Tumis bumbu yang sudah diblender (Bawang merah, bawang putih, cabe merah dan cabe rawit) tumis sampai harum, masukan juga lengkuas dan daun salamnya..kemudian masukan ati ampela, beri sedikit air. Kalo sudah setengah matang masukan kentang yang sudah kita goreng tadi.. tutup rapat, kalo sudah mendidih.. masukan santan kara
1. Masak kentangnya sampai kuah menyusut. Kemudian test rasa.
1. Orek Tempe : -  Potong tempe persegi panjang kecil,goreng sampai kering, tiriskan, kemudian Tumis bumbu yang sudah di iris (cabe merah, Bawang merah, Bawang putih) lengkuas dan salam, sampai harum, masukan gula merah dan air asam Jawa, setelah itu masukan tempe dan beri kecap manis..masak sampai air menyusut dan test rasa
1. Mie goreng : - Rebus mie burung dara sampai matang, lalu tiriskan, goreng sosis sampe agak kering lalu tiriskan,Tumis bumbu yang sudah di haluskan (bawang merah, bawang putih, merica, kemiri) sampai harum, masukan sayuran beri bumbu dan sedikit air, kemudian masukan mie dan sosisnya lalu beri sedikit kecap dan saus tiram, masak hingga matang dan test rasa.
1. Telor dadar : - Kocok lepas telur,beri sedikit air dan garam, kemudian goreng tipis2 di teflon, kalo sudah digulung,lalu dipotong potong tipis kayak mie 😁
1. Kalau nasi sudah matang, jangan lupa diaduk aduk ya Bun..😁
1. Udah siaaap.. tinggal di tata dipiring kalau mau makan..sesuai selera ya buun... Terima kasiiihh..😇😇


Proses pembakaran ayam bakar juga membuat kulit ayam terkaramelisasi oleh kecap. Saat proses pembakaran, gunakan grilling pan atau teflon anti lengket agar agar makin mudah dan praktis. Anda dapat memasak Ayam Suwir Bumbu (bisa untuk isian lemper atau nasi bakar). Rebus ayam (atau mau goreng juga bisa) dan suwir suwir. Tumis bumbu halus dan serai sampai harum dan matang, masukkan ayam suwir dan daun jeruk. 

Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
