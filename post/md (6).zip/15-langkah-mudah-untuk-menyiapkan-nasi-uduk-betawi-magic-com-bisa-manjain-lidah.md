---
description: "Langkah Mudah untuk Menyiapkan Nasi Uduk Betawi (Magic Com), Bisa Manjain Lidah"
title: "Langkah Mudah untuk Menyiapkan Nasi Uduk Betawi (Magic Com), Bisa Manjain Lidah"
slug: 15-langkah-mudah-untuk-menyiapkan-nasi-uduk-betawi-magic-com-bisa-manjain-lidah
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-01T17:44:54.660Z 
thumbnail: https://img-global.cpcdn.com/recipes/7089863b14976a31/682x484cq65/nasi-uduk-betawi-magic-com-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/7089863b14976a31/682x484cq65/nasi-uduk-betawi-magic-com-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/7089863b14976a31/682x484cq65/nasi-uduk-betawi-magic-com-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/7089863b14976a31/682x484cq65/nasi-uduk-betawi-magic-com-foto-resep-utama.webp
author: Rachel Butler
ratingvalue: 3.6
reviewcount: 12
recipeingredient:
- "beras pulen saya pakai merk Pandan Wangi cuci bersih 6 cup"
- "santan disesuaikan dengan takaran magic com Secukupnya"
- "bumbu dasar putih           lihat resep 1 sdm"
- "daun salam sobek2 5 lembar"
- "daun jeruk sobek2 5 lembar"
- "sereh geprek 4 batang"
- "lengkuas iris kemudian geprek 1 ruas besar"
- "bawang merah iris halus goreng Minyaknya jangan dibuang 1 ons"
recipeinstructions:
- "Siapkan beras yang sudah dicuci, tuangkan santan sesuai dengan takaran magic com masing2. Campurkan juga semua bahan sisa. Kemudian aduk rata. Koreksi rasa."
- "Nyalakan magic com, masak nasi hingga matang. Buang rempahnya.   Setelah matang, tuangkan minyak bekas goreng bawang, aduk rata. Taburi juga dengan bawang gorengnya, aduk rata kembali."
- "Angkat dan sajikan dengan semur betawi, sambal kacang dan oblok betawi/ ayam serundeng."
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 235 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT32M"
recipeyield: "2"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Betawi (Magic Com)](https://img-global.cpcdn.com/recipes/7089863b14976a31/682x484cq65/nasi-uduk-betawi-magic-com-foto-resep-utama.webp)

Ingin membuat Nasi Uduk Betawi (Magic Com) ? Coba resep berikut ini. Cara memasaknya sangat praktis namun jangan kaget jika hasilnya gurih dan lezat yang harus kamu coba dirumah

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Dalam Menyiapkan Nasi Uduk Betawi (Magic Com):

1. beras pulen saya pakai merk Pandan Wangi cuci bersih 6 cup
1. santan disesuaikan dengan takaran magic com Secukupnya
1. bumbu dasar putih           lihat resep 1 sdm
1. daun salam sobek2 5 lembar
1. daun jeruk sobek2 5 lembar
1. sereh geprek 4 batang
1. lengkuas iris kemudian geprek 1 ruas besar
1. bawang merah iris halus goreng Minyaknya jangan dibuang 1 ons



<!--inarticleads2-->

## Cara Mudah Membuat Nasi Uduk Betawi (Magic Com):

1. Siapkan beras yang sudah dicuci, tuangkan santan sesuai dengan takaran magic com masing2. Campurkan juga semua bahan sisa. Kemudian aduk rata. Koreksi rasa.
1. Nyalakan magic com, masak nasi hingga matang. Buang rempahnya.  -  - Setelah matang, tuangkan minyak bekas goreng bawang, aduk rata. Taburi juga dengan bawang gorengnya, aduk rata kembali.
1. Angkat dan sajikan dengan semur betawi, sambal kacang dan oblok betawi/ ayam serundeng.




Salah satu masakan yang cukup praktis pembuatannya adalah  Nasi Uduk Betawi (Magic Com). Selain itu  Nasi Uduk Betawi (Magic Com)  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu lakukan 3 langkah, dan  Nasi Uduk Betawi (Magic Com)  pun siap di hidangkan. selamat mencoba !
