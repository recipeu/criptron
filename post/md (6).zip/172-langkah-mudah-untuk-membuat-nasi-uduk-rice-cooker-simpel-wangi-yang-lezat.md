---
description: "Langkah Mudah untuk Membuat Nasi uduk rice cooker simpel wangi yang Lezat"
title: "Langkah Mudah untuk Membuat Nasi uduk rice cooker simpel wangi yang Lezat"
slug: 172-langkah-mudah-untuk-membuat-nasi-uduk-rice-cooker-simpel-wangi-yang-lezat
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-11T23:02:48.535Z 
thumbnail: https://img-global.cpcdn.com/recipes/8fa07d995b71c13c/682x484cq65/nasi-uduk-rice-cooker-simpel-wangi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/8fa07d995b71c13c/682x484cq65/nasi-uduk-rice-cooker-simpel-wangi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/8fa07d995b71c13c/682x484cq65/nasi-uduk-rice-cooker-simpel-wangi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/8fa07d995b71c13c/682x484cq65/nasi-uduk-rice-cooker-simpel-wangi-foto-resep-utama.webp
author: Nora Rhodes
ratingvalue: 4.6
reviewcount: 12
recipeingredient:
- "beras 2,5 cup"
- "air 2-3 gelas"
- "santan kara 1 bungkus"
- "serai geprek 1 batang"
- "garam 1 sdt"
- "daun salam 4 lembar"
- "daun jeruk 1 lembar"
- "minyak goreng 1 sdm"
- "daun pandan tambahan dr sy 1 lembar"
- "Bumbu halus "
- "jahe 1/2 ruas"
- "lengkuas 1 ruas"
- "kencur 1 ruas"
- "bawang putih 4 siung"
recipeinstructions:
- "Cuci bersih beras, masukkan semua bahan aduk rata"
- "Masak dalam rice cooker sesekali dibuka aduk2 lalu tutup diamkan sampai matang"
- "Nasi uduk rice cooker siap dinikmati dengan lauk pendamping lainnya"
categories:
- Resep
tags:
- nasi
- uduk
- rice

katakunci: nasi uduk rice 
nutrition: 273 calories
recipecuisine: Indonesian
preptime: "PT26M"
cooktime: "PT39M"
recipeyield: "4"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi uduk rice cooker simpel wangi](https://img-global.cpcdn.com/recipes/8fa07d995b71c13c/682x484cq65/nasi-uduk-rice-cooker-simpel-wangi-foto-resep-utama.webp)

3 langkah cepat membuat  Nasi uduk rice cooker simpel wangi cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Dalam Pembuatan Nasi uduk rice cooker simpel wangi:

1. beras 2,5 cup
1. air 2-3 gelas
1. santan kara 1 bungkus
1. serai geprek 1 batang
1. garam 1 sdt
1. daun salam 4 lembar
1. daun jeruk 1 lembar
1. minyak goreng 1 sdm
1. daun pandan tambahan dr sy 1 lembar
1. Bumbu halus 
1. jahe 1/2 ruas
1. lengkuas 1 ruas
1. kencur 1 ruas
1. bawang putih 4 siung

Nasi uduk rice cooker super wangi pulen dan simpel bikinnyaПодробнее. Cara membuat nasi uduk cukup mudah dan simpel, lo! Bahkan, kamu juga bisa membuatnya menggunakan rice cooker. Nasi uduk merupakan menu khas Indonesia yang banyak disukai semua usia, baik anak-anak, remaja hingga dewasa. 

<!--inarticleads2-->

## Tata Cara Menyiapkan Nasi uduk rice cooker simpel wangi:

1. Cuci bersih beras, masukkan semua bahan aduk rata
1. Masak dalam rice cooker sesekali dibuka aduk2 lalu tutup diamkan sampai matang
1. Nasi uduk rice cooker siap dinikmati dengan lauk pendamping lainnya


Resep Nasi uduk rice cooker oleh Xander&#39;s Kitchen. RESEP NASI UDUK/ NASI GURIH RICE COOKER MUDAH PRAKTIS My favorite way of cooking nasi uduk is with a rice cooker or Instant Pot. PREPARE AND COOK THE RICE Place all the ingredients in the inner pot of the rice cooker. Close the lid and use the white rice setting. 

Selamat memasak dan menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
