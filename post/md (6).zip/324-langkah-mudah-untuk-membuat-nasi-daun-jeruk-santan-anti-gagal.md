---
description: "Langkah Mudah untuk Membuat Nasi daun jeruk santan Anti Gagal"
title: "Langkah Mudah untuk Membuat Nasi daun jeruk santan Anti Gagal"
slug: 324-langkah-mudah-untuk-membuat-nasi-daun-jeruk-santan-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-13T19:54:28.091Z 
thumbnail: https://img-global.cpcdn.com/recipes/3fcf60170a769629/682x484cq65/nasi-daun-jeruk-santan-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/3fcf60170a769629/682x484cq65/nasi-daun-jeruk-santan-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/3fcf60170a769629/682x484cq65/nasi-daun-jeruk-santan-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/3fcf60170a769629/682x484cq65/nasi-daun-jeruk-santan-foto-resep-utama.webp
author: Ellen Soto
ratingvalue: 3.8
reviewcount: 14
recipeingredient:
- "Beras 3 wadah bawaan rice cooker "
- "Santan sedang sesuaikan dgn biasa masak beras masing2 "
- "Serai 1 batang di geprek "
- "Daun Jeruk iris tipis bisa jg dihaluskan 15 lembar"
- "Daun salam 2 lembar"
- "Bawang merah 3 diiris "
- "Bawang Putih 3 dihaluskan "
- "Garam Gula pasir kaldu jamur secukupnya"
- "Butter secukupnya untuk menumis "
recipeinstructions:
- "Tumis bawang merah sampai setengah wangi, masuk bumbu lainnya sampai matang dan wangi"
- "Setelah matang bumbu2, masukan santan, masak hingga mendidih"
- "Masukkan santan berbumbu ke dalam beras yang sudah dicuci bersih, masak seperti biasa di rice cooker, tunggu sampai matang, setelah matang aduk di rice cooker dan diamkan sampai matang sempurna"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 145 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT41M"
recipeyield: "3"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi daun jeruk santan](https://img-global.cpcdn.com/recipes/3fcf60170a769629/682x484cq65/nasi-daun-jeruk-santan-foto-resep-utama.webp)

Resep dan cara mengolah  Nasi daun jeruk santan yang harus bunda coba segera

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Dalam Menyiapkan Nasi daun jeruk santan:

1. Beras 3 wadah bawaan rice cooker 
1. Santan sedang sesuaikan dgn biasa masak beras masing2 
1. Serai 1 batang di geprek 
1. Daun Jeruk iris tipis bisa jg dihaluskan 15 lembar
1. Daun salam 2 lembar
1. Bawang merah 3 diiris 
1. Bawang Putih 3 dihaluskan 
1. Garam Gula pasir kaldu jamur secukupnya
1. Butter secukupnya untuk menumis 

Nasi Daun Jeruk Magicom Tanpa Santan Cara Mudah Membuat Nasi Daun Jeruk. Nasi Uduk Rice Cooker tanpa SantanПодробнее. Resep Nasi uduk rice cooker tanpa santan. 

<!--inarticleads2-->

## Langkah-langkah Untuk Membuat Nasi daun jeruk santan:

1. Tumis bawang merah sampai setengah wangi, masuk bumbu lainnya sampai matang dan wangi
1. Setelah matang bumbu2, masukan santan, masak hingga mendidih
1. Masukkan santan berbumbu ke dalam beras yang sudah dicuci bersih, masak seperti biasa di rice cooker, tunggu sampai matang, setelah matang aduk di rice cooker dan diamkan sampai matang sempurna


Nasi Liwet Rice cooker Tanpa santan super gampangПодробнее. Nasi dengan aroma yang khas ini memang cocok dinikmati bersama keluarga. Selanjutnya, tuang santan, jika ingin lebih kuat rasanya, tambahkan santan sesuai selera. Kemudian tambahkan daun jeruk yang sudah diremas, daun pandan, daun salam, dan garam. Langkah membuat Nasi Daun Jeruk yang enak bisa menggunakan penanak nasi / rice cooker atau mengukusnya. 

Daripada   beli  Nasi daun jeruk santan  diluar terus, ibu  bisa membuatnya sendiri dirumah. Resep  Nasi daun jeruk santan  sederhana ini cukup praktis pembuatannya, cukup menggunakan bumbu-bumbu sederhana yang ada di dapur  Nasi daun jeruk santan  yang enak, bunda nikmati di rumah.
