---
description: "Cara Gampang Membuat Nasi Daun Jeruk simple Magiccom, Menggugah Selera"
title: "Cara Gampang Membuat Nasi Daun Jeruk simple Magiccom, Menggugah Selera"
slug: 273-cara-gampang-membuat-nasi-daun-jeruk-simple-magiccom-menggugah-selera
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-15T18:39:51.044Z 
thumbnail: https://img-global.cpcdn.com/recipes/c5f90b1b9f6ca934/682x484cq65/nasi-daun-jeruk-simple-magiccom-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/c5f90b1b9f6ca934/682x484cq65/nasi-daun-jeruk-simple-magiccom-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/c5f90b1b9f6ca934/682x484cq65/nasi-daun-jeruk-simple-magiccom-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/c5f90b1b9f6ca934/682x484cq65/nasi-daun-jeruk-simple-magiccom-foto-resep-utama.webp
author: Nelle Rivera
ratingvalue: 3.1
reviewcount: 3
recipeingredient:
- "Beras 1 ltr"
- "sereh 2 buah"
- "Bumbu Tumis "
- "bawang putih 6 siung"
- "Daun jeruk secukupnya"
- "Margarin 2 sdm"
- "Minyak 1 sdm"
- "Air secukupnya"
recipeinstructions:
- "Rajang halus Bawang putih &amp; Iris halus Daun jeruk (buang batang daun). Panaskan Margarin dan minyak kemudian masukkan rajangan bawang putih hingga kekuningan dan harum lalu masukan irisan Daun jeruk lalu tambahkan air sedikit"
- "Cuci bersih beras, lalu masukan sereh yg sudah di geprek dan tumisan bawang putih daun jeruk"
- "Tambahkan Garam, penyedap atau kaldu, air secukpnya kemudian aduk rata dan masak seperti memasak nasi biasanya."
- "Tambahkan lauk, ex : Sambal goreng kentang, Ayam Goreng serundeng, Abon dsb. Let’s Enjoy “Nasi Daun Jeruk” simple ala Dewo"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 172 calories
recipecuisine: Indonesian
preptime: "PT15M"
cooktime: "PT30M"
recipeyield: "3"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk simple Magiccom](https://img-global.cpcdn.com/recipes/c5f90b1b9f6ca934/682x484cq65/nasi-daun-jeruk-simple-magiccom-foto-resep-utama.webp)

Resep rahasia dan cara memasak  Nasi Daun Jeruk simple Magiccom yang bisa ibu coba segera

<!--inarticleads1-->

## Bahan-bahan Yang Dibutuhkan Untuk Pembuatan Nasi Daun Jeruk simple Magiccom:

1. Beras 1 ltr
1. sereh 2 buah
1. Bumbu Tumis 
1. bawang putih 6 siung
1. Daun jeruk secukupnya
1. Margarin 2 sdm
1. Minyak 1 sdm
1. Air secukupnya



<!--inarticleads2-->

## Langkah-langkah Untuk Menyiapkan Nasi Daun Jeruk simple Magiccom:

1. Rajang halus Bawang putih &amp; Iris halus Daun jeruk (buang batang daun). Panaskan Margarin dan minyak kemudian masukkan rajangan bawang putih hingga kekuningan dan harum lalu masukan irisan Daun jeruk lalu tambahkan air sedikit
1. Cuci bersih beras, lalu masukan sereh yg sudah di geprek dan tumisan bawang putih daun jeruk
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/049ffed19e99fd2e/160x128cq70/nasi-daun-jeruk-simple-magiccom-langkah-memasak-2-foto.webp" alt="Nasi Daun Jeruk simple Magiccom" width="340" height="340">
>1. Tambahkan Garam, penyedap atau kaldu, air secukpnya kemudian aduk rata dan masak seperti memasak nasi biasanya.
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/52955dbd81a99a6c/160x128cq70/nasi-daun-jeruk-simple-magiccom-langkah-memasak-3-foto.webp" alt="Nasi Daun Jeruk simple Magiccom" width="340" height="340">
>1. Tambahkan lauk, ex : Sambal goreng kentang, Ayam Goreng serundeng, Abon dsb. Let’s Enjoy “Nasi Daun Jeruk” simple ala Dewo
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/0ae3c4271c960b5a/160x128cq70/nasi-daun-jeruk-simple-magiccom-langkah-memasak-4-foto.webp" alt="Nasi Daun Jeruk simple Magiccom" width="340" height="340">
>



Demikian informasi  resep Nasi Daun Jeruk simple Magiccom   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
