---
description: "Resep Nasi Uduk Betawi, cara simple &amp;amp; dijamin menggoda 😍 Anti Gagal"
title: "Resep Nasi Uduk Betawi, cara simple &amp;amp; dijamin menggoda 😍 Anti Gagal"
slug: 103-resep-nasi-uduk-betawi-cara-simple-and-amp-dijamin-menggoda-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-05T17:34:11.970Z 
thumbnail: https://img-global.cpcdn.com/recipes/fd57c1cbb29e5107/682x484cq65/nasi-uduk-betawi-cara-simple-dijamin-menggoda-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/fd57c1cbb29e5107/682x484cq65/nasi-uduk-betawi-cara-simple-dijamin-menggoda-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/fd57c1cbb29e5107/682x484cq65/nasi-uduk-betawi-cara-simple-dijamin-menggoda-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/fd57c1cbb29e5107/682x484cq65/nasi-uduk-betawi-cara-simple-dijamin-menggoda-foto-resep-utama.webp
author: Erik Moody
ratingvalue: 4.1
reviewcount: 10
recipeingredient:
- "beras 1,5 L"
- "beras ketan biar pulen jika suka 1/4 kg"
- "daun jeruk 5 lbr"
- "daun salam 5 lbr"
- "daun pandan ikat simpul 2 lbr"
- "serai geprek 2 btg"
- "laos geprek 2 cm"
- "ketumbar bubuk 1/4 st"
- "Garam secukupnya"
- "Santan dari 1 butir kelapa "
- "Air sesuai takaran beras saat memasaknya "
recipeinstructions:
- "Campur beras yg sudah dicuci dg semua bumbu"
- "Tuang santan lalu air, sesuaikan dg kebiasaan memasak (saya biasanya menggunakan rice cooker utk memudahkan takaran airnya), aduk rata lalu koreksi rasa garamnya"
- "Saya menggunakan rice cooker. Biarkan hg mendidih dan airnya kering, lalu matangkan dg menggunakan kukusan agar nasi merata tanaknya, aduk sebentar lalu tutup kukusan. Masak lk 30 menitan. Biarkan nasi tetap dikukusan, klo mau dimakan panaskan sebentar biar lebih nikmat"
- "Sambal kuah kacang &gt;&gt; saya menggunakan sambel pecel siap pakai 2 pack yg ditambah air lalu direbus. Dibuat encer saja, koreksi rasanya sesuai selera"
- "Sajikan nasi uduknya dgn : ayam / ati ampela goreng kuning, tahu tempe goreng dan saya tambah lalapan biar ada segar²nya dimulut"
- "Kuah kacang biasanya disiramkan ke nasi. Jk terbiasa dg sambel bisa ditambah dg membuat sambel terasi... Mmmm, nikmatnya 👍"
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 211 calories
recipecuisine: Indonesian
preptime: "PT11M"
cooktime: "PT55M"
recipeyield: "3"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Betawi, cara simple &amp; dijamin menggoda 😍](https://img-global.cpcdn.com/recipes/fd57c1cbb29e5107/682x484cq65/nasi-uduk-betawi-cara-simple-dijamin-menggoda-foto-resep-utama.webp)

Resep rahasia dan cara mengolah  Nasi Uduk Betawi, cara simple &amp; dijamin menggoda 😍 cocok sekali jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Dalam Menyiapkan Nasi Uduk Betawi, cara simple &amp; dijamin menggoda 😍:

1. beras 1,5 L
1. beras ketan biar pulen jika suka 1/4 kg
1. daun jeruk 5 lbr
1. daun salam 5 lbr
1. daun pandan ikat simpul 2 lbr
1. serai geprek 2 btg
1. laos geprek 2 cm
1. ketumbar bubuk 1/4 st
1. Garam secukupnya
1. Santan dari 1 butir kelapa 
1. Air sesuai takaran beras saat memasaknya 



<!--inarticleads2-->

## Cara Mudah Membuat Nasi Uduk Betawi, cara simple &amp; dijamin menggoda 😍:

1. Campur beras yg sudah dicuci dg semua bumbu
1. Tuang santan lalu air, sesuaikan dg kebiasaan memasak (saya biasanya menggunakan rice cooker utk memudahkan takaran airnya), aduk rata lalu koreksi rasa garamnya
1. Saya menggunakan rice cooker. Biarkan hg mendidih dan airnya kering, lalu matangkan dg menggunakan kukusan agar nasi merata tanaknya, aduk sebentar lalu tutup kukusan. Masak lk 30 menitan. Biarkan nasi tetap dikukusan, klo mau dimakan panaskan sebentar biar lebih nikmat
1. Sambal kuah kacang &gt;&gt; saya menggunakan sambel pecel siap pakai 2 pack yg ditambah air lalu direbus. Dibuat encer saja, koreksi rasanya sesuai selera
1. Sajikan nasi uduknya dgn : ayam / ati ampela goreng kuning, tahu tempe goreng dan saya tambah lalapan biar ada segar²nya dimulut
1. Kuah kacang biasanya disiramkan ke nasi. Jk terbiasa dg sambel bisa ditambah dg membuat sambel terasi... Mmmm, nikmatnya 👍




Demikian informasi  resep Nasi Uduk Betawi, cara simple &amp; dijamin menggoda 😍   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
