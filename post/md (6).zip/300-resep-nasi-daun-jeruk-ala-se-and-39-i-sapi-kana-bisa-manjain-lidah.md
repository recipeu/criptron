---
description: "Resep Nasi Daun Jeruk (ala Se&amp;#39;i Sapi Kana), Bisa Manjain Lidah"
title: "Resep Nasi Daun Jeruk (ala Se&amp;#39;i Sapi Kana), Bisa Manjain Lidah"
slug: 300-resep-nasi-daun-jeruk-ala-se-and-39-i-sapi-kana-bisa-manjain-lidah
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-19T10:20:00.886Z 
thumbnail: https://img-global.cpcdn.com/recipes/81a7998b0d48c2a2/682x484cq65/nasi-daun-jeruk-ala-sei-sapi-kana-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/81a7998b0d48c2a2/682x484cq65/nasi-daun-jeruk-ala-sei-sapi-kana-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/81a7998b0d48c2a2/682x484cq65/nasi-daun-jeruk-ala-sei-sapi-kana-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/81a7998b0d48c2a2/682x484cq65/nasi-daun-jeruk-ala-sei-sapi-kana-foto-resep-utama.webp
author: Marion Scott
ratingvalue: 3.6
reviewcount: 14
recipeingredient:
- "nasi 2 cup"
- "bawang putih 2"
- "daun jeruk 10 lembar"
- "cabe merah kriting buang biji 1"
- "garam 1/2 sdt"
- "kaldu ayam 1/2 sdt"
- "kaldu jamur 1/2 sdt"
- "minyak goreng 1 sdm"
- "air untuk masak nasi Secukupnya"
recipeinstructions:
- "Siapkan bahan-bahan bumbu: cincang halus bawang putih, cincang cabe merah buang bijinya, iris tipis daun jeruk buang tukang tengahnya"
- "Cuci beras, siapkan air untuk takaran memasak pada umumnya"
- "Tumis bawang putih terlebih dahulu, lalu masukan cabe dan daun jeruk"
- "Tumis hingga matang"
- "Tuangkan bumbu tumisan ke dalam wadah ricecooker, beri garam, kaldu ayam, kaldu jamur. Aduk.tes rasa. Kemudian masak di rice cooker (seperti masak nasi biasa)"
- "Nasi daun jeruk sudah matang, jika mau lebih terasa daun jeruknya bisa di tambahkan lagi lebih banyak, tergantung selera saja yah"
- "Nasi daun jeruk siap disajikan. Selamat menikmati, selamat mencoba. Bisa nambah terus ni makannya hehe"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 236 calories
recipecuisine: Indonesian
preptime: "PT29M"
cooktime: "PT45M"
recipeyield: "4"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk (ala Se&#39;i Sapi Kana)](https://img-global.cpcdn.com/recipes/81a7998b0d48c2a2/682x484cq65/nasi-daun-jeruk-ala-sei-sapi-kana-foto-resep-utama.webp)

Ingin membuat Nasi Daun Jeruk (ala Se&#39;i Sapi Kana) ? Coba resep berikut ini. Cara memasaknya sangat praktis namun hasilnya gurih dan lezat yang harus kamu coba dirumah

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Untuk Pembuatan Nasi Daun Jeruk (ala Se&#39;i Sapi Kana):

1. nasi 2 cup
1. bawang putih 2
1. daun jeruk 10 lembar
1. cabe merah kriting buang biji 1
1. garam 1/2 sdt
1. kaldu ayam 1/2 sdt
1. kaldu jamur 1/2 sdt
1. minyak goreng 1 sdm
1. air untuk masak nasi Secukupnya



<!--inarticleads2-->

## Cara Membuat Nasi Daun Jeruk (ala Se&#39;i Sapi Kana):

1. Siapkan bahan-bahan bumbu: cincang halus bawang putih, cincang cabe merah buang bijinya, iris tipis daun jeruk buang tukang tengahnya
1. Cuci beras, siapkan air untuk takaran memasak pada umumnya
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/d0cd1f3719cc98a5/160x128cq70/nasi-daun-jeruk-ala-sei-sapi-kana-langkah-memasak-2-foto.webp" alt="Nasi Daun Jeruk (ala Se&#39;i Sapi Kana)" width="340" height="340">
>1. Tumis bawang putih terlebih dahulu, lalu masukan cabe dan daun jeruk
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/9d644bd0b34b1aee/160x128cq70/nasi-daun-jeruk-ala-sei-sapi-kana-langkah-memasak-3-foto.webp" alt="Nasi Daun Jeruk (ala Se&#39;i Sapi Kana)" width="340" height="340">
><img class="lazyload" data-src="https://img-global.cpcdn.com/steps/c553b6ec0b0f767e/160x128cq70/nasi-daun-jeruk-ala-sei-sapi-kana-langkah-memasak-3-foto.webp" alt="Nasi Daun Jeruk (ala Se&#39;i Sapi Kana)" width="340" height="340">
>1. Tumis hingga matang
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/29385d3e61fcdd56/160x128cq70/nasi-daun-jeruk-ala-sei-sapi-kana-langkah-memasak-4-foto.webp" alt="Nasi Daun Jeruk (ala Se&#39;i Sapi Kana)" width="340" height="340">
><img class="lazyload" data-src="https://img-global.cpcdn.com/steps/e97679246d81a07b/160x128cq70/nasi-daun-jeruk-ala-sei-sapi-kana-langkah-memasak-4-foto.webp" alt="Nasi Daun Jeruk (ala Se&#39;i Sapi Kana)" width="340" height="340">
>1. Tuangkan bumbu tumisan ke dalam wadah ricecooker, beri garam, kaldu ayam, kaldu jamur. Aduk.tes rasa. Kemudian masak di rice cooker (seperti masak nasi biasa)
1. Nasi daun jeruk sudah matang, jika mau lebih terasa daun jeruknya bisa di tambahkan lagi lebih banyak, tergantung selera saja yah
1. Nasi daun jeruk siap disajikan. Selamat menikmati, selamat mencoba. Bisa nambah terus ni makannya hehe




Demikian informasi  resep Nasi Daun Jeruk (ala Se&#39;i Sapi Kana)   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
