---
description: "Resep Nasi daun jeruk Anti Gagal"
title: "Resep Nasi daun jeruk Anti Gagal"
slug: 320-resep-nasi-daun-jeruk-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-12T06:44:58.174Z 
thumbnail: https://img-global.cpcdn.com/recipes/8997e54726c75841/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/8997e54726c75841/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/8997e54726c75841/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/8997e54726c75841/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
author: Scott Kennedy
ratingvalue: 3.8
reviewcount: 15
recipeingredient:
- "beras 2 cup"
- "bawang putih cincang kasar 5 siung"
- "daun jeruk iris panjang 8 lembar"
- "serai memarkan 2 buah"
- "cabai rawit potong sesuai selera 3 buah"
- "garam secukupnya"
- "gula secukupnya"
- "kaldu jamur secukupnya"
- "Air secukupnya"
recipeinstructions:
- "Tumis bawang putih hingga harum. Setelah itu masukan serai dan daun jeruk yang sudah dipotong2. Terakhir masukkan cabai rawit."
- "Setelah bewarna kecoklatan, angkat bumbu. Siapkan beras yang sudah dicuci bersih, tambahkan air secukupnya seperti masak nasi biasa."
- "Masukkan bumbu yang sudah ditumis ke dalam beras yang sudah disiapkan. Masak nasi menggunakan ricecooker seperti biasa dan tunggu hingga matang."
- "Aroma nya bakalan wangiii banget dan dijamin akan menambah nafsu makan anda 😋"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 286 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT52M"
recipeyield: "3"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi daun jeruk](https://img-global.cpcdn.com/recipes/8997e54726c75841/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp)

Resep rahasia dan cara memasak  Nasi daun jeruk cocok sekali jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Dalam Menyiapkan Nasi daun jeruk:

1. beras 2 cup
1. bawang putih cincang kasar 5 siung
1. daun jeruk iris panjang 8 lembar
1. serai memarkan 2 buah
1. cabai rawit potong sesuai selera 3 buah
1. garam secukupnya
1. gula secukupnya
1. kaldu jamur secukupnya
1. Air secukupnya

Nasi daun jeruk siap dihidangkan dengan. Nasi daun jeruk ini memang sedang tren di kalangan masyarakat Indonesia, banyak sekali kaum muda mudi yang berlomba-lomba membuat makanan nasi putih spesial ini. Nasi daun jeruk ala geprek bensu rekomended buat di coba. Geprek bensu nasi daun jeruk anti mainst. 

<!--inarticleads2-->

## Langkah-langkah Untuk Menyiapkan Nasi daun jeruk:

1. Tumis bawang putih hingga harum. Setelah itu masukan serai dan daun jeruk yang sudah dipotong2. Terakhir masukkan cabai rawit.
1. Setelah bewarna kecoklatan, angkat bumbu. Siapkan beras yang sudah dicuci bersih, tambahkan air secukupnya seperti masak nasi biasa.
1. Masukkan bumbu yang sudah ditumis ke dalam beras yang sudah disiapkan. Masak nasi menggunakan ricecooker seperti biasa dan tunggu hingga matang.
1. Aroma nya bakalan wangiii banget dan dijamin akan menambah nafsu makan anda 😋


Gurih dan wangi dari daun jeruk menambah kelezatan nasi daun jeruk. Nasi dengan campuran daun jeruk yang wangi sedang tren. Hai selamat pagi sahabat CWS, pagi ini saya share resep Nasi Daun Jeruk. Praktis banget karena saya gunakan rice cooker. Rasanya mirip nasi uduk tapi wangiiii. 

Demikian informasi  resep Nasi daun jeruk   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
