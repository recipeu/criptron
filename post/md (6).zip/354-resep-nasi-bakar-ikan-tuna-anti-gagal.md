---
description: "Resep Nasi Bakar Ikan Tuna Anti Gagal"
title: "Resep Nasi Bakar Ikan Tuna Anti Gagal"
slug: 354-resep-nasi-bakar-ikan-tuna-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-17T23:05:31.853Z 
thumbnail: https://img-global.cpcdn.com/recipes/01ea5e32a6fd47ae/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/01ea5e32a6fd47ae/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/01ea5e32a6fd47ae/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/01ea5e32a6fd47ae/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp
author: Edward Davidson
ratingvalue: 4.3
reviewcount: 5
recipeingredient:
- "beras cuci bersih 500 gr"
- "santan kental dari 1btr kelapa 750 ml"
- "sereh geprek bagian putihnya buat simpul 2 btg"
- "daun salam 2 lmbr"
- "daun pandan buat simpul 2 lmbr"
- "garam Secukupnya"
- "daun pisang Secukupnya"
- "lidi untuk menyemat optional saya tidak pakai Secukupnya"
- "Bahan isian tuna  "
- "tunarebussuwir 200 gr"
- "daun salam 2 lmbr"
- "daun jeruk memarkan 2 lmbr"
- "sereh memarkan 1 btg"
- "lengkuas memarkan 2 cm"
- "santan dengan kekentalan sedang dari 12btr kelapa 250 ml"
- "kemangi petiki daunnya cuci bersih 2 btg"
- "garam Secukupnya"
- "gula Secukupnya"
- "minyak goreng untuk menumis Secukupnya"
- "Bumbu halus  "
- "bawang merah 5 siung"
- "bawang putih 3 siung"
- "kunyit kupas bakar 1 cm"
- "kemiri sangrai 4 btr"
- "cabe keriting merah 5 bh"
- "cabe rawit merah 5 bh"
- "cabe merah besar 1 bh"
recipeinstructions:
- "Rebus santan sampai mendidih. Segera matikan api. Masukkan beras kedalam wadah rice cooker lalu masukkan santan yang direbus tadi, lalu masukkan garam, sereh, daun pandan &amp; daun salam. Masak seperti biasa di rice cooker sampai matang"
- "Panaskan sedikit minyak goreng, tumis bumbu halus dan daun jeruk sampai matang &amp; harum. Kemudian masukkan tuna yang sudah di suwir. Aduk rata."
- "Tambahkan santan, garam &amp; gula aduk rata &amp;cek rasa sampai pas. Masak sampai santan susut dan bumbu terserap sempurna. Masukkan daun kemangi, aduk sebentar. Matikan api, sisihkan."
- "Siapkan dua lembar daun pisang, taruh nasi lalu taruh bahan isian diatasnya, tutupi lagi dengan nasi."
- "Lipat daun pisang sambil dipadatkan isinya, kemudian lipat lagi kedua ujungnya seperti pada gambar. Atau bisa juga disematkan dengan lidi. Lakukan sampai nasi &amp; tuna habis."
- "Kemudian bakar diatas teflon /grillpan/alat pemanggang lainnya sampai daun pisang berubah warna dan mengeluarkan aroma harum. Angkat. Sajikan dengan bahan pelengkap lainnya sesuai selera. Atau tanpa bahan pelengkappun nasi ini sudah gurih &amp; nikmat."
categories:
- Resep
tags:
- nasi
- bakar
- ikan

katakunci: nasi bakar ikan 
nutrition: 290 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT54M"
recipeyield: "2"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Bakar Ikan Tuna](https://img-global.cpcdn.com/recipes/01ea5e32a6fd47ae/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp)

6 langkah mudah dan cepat membuat  Nasi Bakar Ikan Tuna cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Dalam Pembuatan Nasi Bakar Ikan Tuna:

1. beras cuci bersih 500 gr
1. santan kental dari 1btr kelapa 750 ml
1. sereh geprek bagian putihnya buat simpul 2 btg
1. daun salam 2 lmbr
1. daun pandan buat simpul 2 lmbr
1. garam Secukupnya
1. daun pisang Secukupnya
1. lidi untuk menyemat optional saya tidak pakai Secukupnya
1. Bahan isian tuna  
1. tunarebussuwir 200 gr
1. daun salam 2 lmbr
1. daun jeruk memarkan 2 lmbr
1. sereh memarkan 1 btg
1. lengkuas memarkan 2 cm
1. santan dengan kekentalan sedang dari 12btr kelapa 250 ml
1. kemangi petiki daunnya cuci bersih 2 btg
1. garam Secukupnya
1. gula Secukupnya
1. minyak goreng untuk menumis Secukupnya
1. Bumbu halus  
1. bawang merah 5 siung
1. bawang putih 3 siung
1. kunyit kupas bakar 1 cm
1. kemiri sangrai 4 btr
1. cabe keriting merah 5 bh
1. cabe rawit merah 5 bh
1. cabe merah besar 1 bh



<!--inarticleads2-->

## Langkah-langkah Untuk Membuat Nasi Bakar Ikan Tuna:

1. Rebus santan sampai mendidih. Segera matikan api. Masukkan beras kedalam wadah rice cooker lalu masukkan santan yang direbus tadi, lalu masukkan garam, sereh, daun pandan &amp; daun salam. Masak seperti biasa di rice cooker sampai matang
1. Panaskan sedikit minyak goreng, tumis bumbu halus dan daun jeruk sampai matang &amp; harum. Kemudian masukkan tuna yang sudah di suwir. Aduk rata.
1. Tambahkan santan, garam &amp; gula aduk rata &amp;cek rasa sampai pas. Masak sampai santan susut dan bumbu terserap sempurna. Masukkan daun kemangi, aduk sebentar. Matikan api, sisihkan.
1. Siapkan dua lembar daun pisang, taruh nasi lalu taruh bahan isian diatasnya, tutupi lagi dengan nasi.
1. Lipat daun pisang sambil dipadatkan isinya, kemudian lipat lagi kedua ujungnya seperti pada gambar. Atau bisa juga disematkan dengan lidi. Lakukan sampai nasi &amp; tuna habis.
1. Kemudian bakar diatas teflon /grillpan/alat pemanggang lainnya sampai daun pisang berubah warna dan mengeluarkan aroma harum. Angkat. Sajikan dengan bahan pelengkap lainnya sesuai selera. Atau tanpa bahan pelengkappun nasi ini sudah gurih &amp; nikmat.




Salah satu kuliner yang cukup praktis dalam pembuatannya adalah  Nasi Bakar Ikan Tuna. Selain itu  Nasi Bakar Ikan Tuna  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu ikuti 6 langkah, dan  Nasi Bakar Ikan Tuna  pun siap di hidangkan. selamat mencoba !
