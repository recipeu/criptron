---
description: "Resep Nasi Uduk Jakarta, Menggugah Selera"
title: "Resep Nasi Uduk Jakarta, Menggugah Selera"
slug: 24-resep-nasi-uduk-jakarta-menggugah-selera
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-23T19:50:20.728Z 
thumbnail: https://img-global.cpcdn.com/recipes/e148311f9c40ca07/682x484cq65/nasi-uduk-jakarta-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/e148311f9c40ca07/682x484cq65/nasi-uduk-jakarta-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/e148311f9c40ca07/682x484cq65/nasi-uduk-jakarta-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/e148311f9c40ca07/682x484cq65/nasi-uduk-jakarta-foto-resep-utama.webp
author: Kenneth Sanchez
ratingvalue: 4
reviewcount: 3
recipeingredient:
- "Nasi Uduj "
- "beras 1/2 kg"
- "sct santan cair 1"
- "Sereh "
- "Daun jeruk "
- "Daun salam "
- "Orek Tempe "
- "tempe 1 papan"
- "bawang merah 5"
- "bawang putih 3"
- "Cabe opsional "
- "Gula merah "
- "Telur Gulung "
- "telur 3 butir"
- "Bawang daun "
- "Garam "
- "Minyak untuk menggoreng "
- "Bihun mie "
- "bihun jagung 1 bungkus"
- "bawang putih 3"
- "Minyak wijen "
- "Kecap asin "
- "Kecap manis "
- "Gula garam dan merica "
- "Ayam Laos "
- "ayam 1/4 kg"
- "bawang putih 3"
- "Ketumbar "
- "Kunyit "
- "Garam "
- "Laos diparut "
- "Minyak untuk menggoreng "
- "Bala bala "
- "Tepung serba guna "
- "Wortel "
- "Kubis "
- "Bawang bombay "
- "Minyak untuk menggoreng "
- "Sambal "
- "Bawang merah "
- "Bawang putih "
- "Cabai "
- "Tomat "
- "Terasi "
recipeinstructions:
- "Nasi Uduk, cuci beras sampai bersih, tambahkan semua bahan dan sedikit air, masak dalam magic com"
- "Orek Tempe, potong2 tempe sesuai selera kemudian goreng, haluskan semua bumbu kemudian tumis hingga harum, masukan gula merah tambahkan sedikit air biar larut, setelah mengental matikan kompor dan masukan tempe yg sudah digoreng kemudian aduk rata"
- "Telur Gulung, kocok telur dan masukan semua bahan, goreng dan gulung"
- "Bihun Mie, rebus bihun smp setengah matang, semudian tumis bawang putih cincang, masukan bihun dan masukan semua bahan"
- "Ayam Laos, ukep ayam dengan bumbu kemudian goreng beserta parutan laos"
- "Sambal, goreng semua bahan dan ulek"
- "Palting sesuai selera bisa tambahkan bawang goreng"
categories:
- Resep
tags:
- nasi
- uduk
- jakarta

katakunci: nasi uduk jakarta 
nutrition: 108 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT33M"
recipeyield: "3"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Jakarta](https://img-global.cpcdn.com/recipes/e148311f9c40ca07/682x484cq65/nasi-uduk-jakarta-foto-resep-utama.webp)

7 langkah cepat membuat  Nasi Uduk Jakarta yang wajib kamu coba dirumah

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Dalam Menyiapkan Nasi Uduk Jakarta:

1. Nasi Uduj 
1. beras 1/2 kg
1. sct santan cair 1
1. Sereh 
1. Daun jeruk 
1. Daun salam 
1. Orek Tempe 
1. tempe 1 papan
1. bawang merah 5
1. bawang putih 3
1. Cabe opsional 
1. Gula merah 
1. Telur Gulung 
1. telur 3 butir
1. Bawang daun 
1. Garam 
1. Minyak untuk menggoreng 
1. Bihun mie 
1. bihun jagung 1 bungkus
1. bawang putih 3
1. Minyak wijen 
1. Kecap asin 
1. Kecap manis 
1. Gula garam dan merica 
1. Ayam Laos 
1. ayam 1/4 kg
1. bawang putih 3
1. Ketumbar 
1. Kunyit 
1. Garam 
1. Laos diparut 
1. Minyak untuk menggoreng 
1. Bala bala 
1. Tepung serba guna 
1. Wortel 
1. Kubis 
1. Bawang bombay 
1. Minyak untuk menggoreng 
1. Sambal 
1. Bawang merah 
1. Bawang putih 
1. Cabai 
1. Tomat 
1. Terasi 



<!--inarticleads2-->

## Cara Menyiapkan Nasi Uduk Jakarta:

1. Nasi Uduk, cuci beras sampai bersih, tambahkan semua bahan dan sedikit air, masak dalam magic com
1. Orek Tempe, potong2 tempe sesuai selera kemudian goreng, haluskan semua bumbu kemudian tumis hingga harum, masukan gula merah tambahkan sedikit air biar larut, setelah mengental matikan kompor dan masukan tempe yg sudah digoreng kemudian aduk rata
1. Telur Gulung, kocok telur dan masukan semua bahan, goreng dan gulung
1. Bihun Mie, rebus bihun smp setengah matang, semudian tumis bawang putih cincang, masukan bihun dan masukan semua bahan
1. Ayam Laos, ukep ayam dengan bumbu kemudian goreng beserta parutan laos
1. Sambal, goreng semua bahan dan ulek
1. Palting sesuai selera bisa tambahkan bawang goreng




Daripada bunda beli  Nasi Uduk Jakarta  diluar terus, ibu  bisa membuatnya sendiri dirumah. Resep  Nasi Uduk Jakarta  sederhana ini cukup praktis dalam proses pembuatannya, cukup menggunakan bumbu sederhana  Nasi Uduk Jakarta  yang enak, bunda nikmati di rumah.
