---
description: "Cara Gampang Menyiapkan Nasi goreng kemangi, Menggugah Selera"
title: "Cara Gampang Menyiapkan Nasi goreng kemangi, Menggugah Selera"
slug: 379-cara-gampang-menyiapkan-nasi-goreng-kemangi-menggugah-selera
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-19T23:24:00.823Z 
thumbnail: https://img-global.cpcdn.com/recipes/818a5e3e33cd1ade/682x484cq65/nasi-goreng-kemangi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/818a5e3e33cd1ade/682x484cq65/nasi-goreng-kemangi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/818a5e3e33cd1ade/682x484cq65/nasi-goreng-kemangi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/818a5e3e33cd1ade/682x484cq65/nasi-goreng-kemangi-foto-resep-utama.webp
author: Ola Sherman
ratingvalue: 4.7
reviewcount: 5
recipeingredient:
- "nasi 2 piring"
- "ikan tuna optional ya boleh ganti ayamtelur Secukupnya"
- "daun kemangi Secukupnya"
- "terasi udang bakar 1/4"
- "bawang putih haluskan 1 siung"
- "bawang merah haluskan 1 siung"
- "cabe merah besar haluskan 1 bh"
- "rawit merah iris 4 bh"
- "gula garam merica kaldu bubuk Secukupnya"
recipeinstructions:
- "Siapkan wajan beri sedikit minyak, tumis bumbu halus dan terasi sampai wangi"
- "Masukan tuna, juga nasi. Aduk sebentar"
- "Setelah tercampur masukan daun kemangi dan bumbu-bumbu"
- "Aduk sampai rata dan cek rasa."
- "Setelah pas, sajikan nasgor dengan irisan telur dan timun. Selamat mencoba ^^"
categories:
- Resep
tags:
- nasi
- goreng
- kemangi

katakunci: nasi goreng kemangi 
nutrition: 153 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT41M"
recipeyield: "2"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi goreng kemangi](https://img-global.cpcdn.com/recipes/818a5e3e33cd1ade/682x484cq65/nasi-goreng-kemangi-foto-resep-utama.webp)

Ingin membuat Nasi goreng kemangi ? Coba resep berikut ini. Cara memasaknya sangat praktis namun jangan kaget jika hasilnya gurih dan lezat cocok banget jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Bahan-bahan Yang Dibutuhkan Untuk Pembuatan Nasi goreng kemangi:

1. nasi 2 piring
1. ikan tuna optional ya boleh ganti ayamtelur Secukupnya
1. daun kemangi Secukupnya
1. terasi udang bakar 1/4
1. bawang putih haluskan 1 siung
1. bawang merah haluskan 1 siung
1. cabe merah besar haluskan 1 bh
1. rawit merah iris 4 bh
1. gula garam merica kaldu bubuk Secukupnya

Rasanya yang enak dan gurih serta praktis cara membuatnya menjadikan salah satu alasan kenapa. #asmr#asmrindonesia#friedrice#asmrnasigoreng#mukbang#eatingsound#eatingshow#mukbangindonesia. RESEP NASI GORENG - Nasi goreng, siapa yang tak kenal dengan jeis masakan yang satu ini. Terakhir, sajikan diatas piring selagi hangat. Masukan jagung dan kacang polong.aduk dan sajikan. nasi goreng kemangi hijau 

<!--inarticleads2-->

## Cara Mudah Membuat Nasi goreng kemangi:

1. Siapkan wajan beri sedikit minyak, tumis bumbu halus dan terasi sampai wangi
1. Masukan tuna, juga nasi. Aduk sebentar
1. Setelah tercampur masukan daun kemangi dan bumbu-bumbu
1. Aduk sampai rata dan cek rasa.
1. Setelah pas, sajikan nasgor dengan irisan telur dan timun. Selamat mencoba ^^


cara masak nasi oreng warna hijau Pertama mencoba nasi goreng ini di sebuah restoran. Saya kirain lucu juga yah nasi goreng pakai kemangi. Kebetulan hari ini om lagi berkunjung menginap di rumah. Resep Nasi Goreng Kemangi ini ternyata berjodoh dengan serai sehingga menimbulkan harum. 

Salah satu kuliner yang cukup praktis dalam pembuatannya adalah  Nasi goreng kemangi. Selain itu  Nasi goreng kemangi  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu lakukan 5 langkah, dan  Nasi goreng kemangi  pun siap di hidangkan. selamat mencoba !
