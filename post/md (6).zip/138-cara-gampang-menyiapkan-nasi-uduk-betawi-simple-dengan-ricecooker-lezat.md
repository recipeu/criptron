---
description: "Cara Gampang Menyiapkan Nasi Uduk Betawi Simple Dengan Ricecooker, Lezat"
title: "Cara Gampang Menyiapkan Nasi Uduk Betawi Simple Dengan Ricecooker, Lezat"
slug: 138-cara-gampang-menyiapkan-nasi-uduk-betawi-simple-dengan-ricecooker-lezat
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-29T21:02:03.723Z 
thumbnail: https://img-global.cpcdn.com/recipes/fbd3090590e03071/682x484cq65/nasi-uduk-betawi-simple-dengan-ricecooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/fbd3090590e03071/682x484cq65/nasi-uduk-betawi-simple-dengan-ricecooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/fbd3090590e03071/682x484cq65/nasi-uduk-betawi-simple-dengan-ricecooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/fbd3090590e03071/682x484cq65/nasi-uduk-betawi-simple-dengan-ricecooker-foto-resep-utama.webp
author: Marguerite Brock
ratingvalue: 4.8
reviewcount: 6
recipeingredient:
- "beras di cuci bersih 1 1/2 cup"
- "santan instan sun kara 65 ml"
- "daun salam 3 lembar"
- "sereh 1 buah"
- "jahe utuh 1 ruas"
- "lengkuas di geprek 1 ruas"
- "cengkeh 3 butir"
- "kayu manis 2 batang"
- "garam "
- "sambal kacang  "
- "kacang tanah di sangrai 100 gr"
- "cabe merah 50 gr"
- "gula merah sisir 1 sdm"
- "garam secukupnya"
- "air "
recipeinstructions:
- "Siapkan panci ricecooker, masukan beras, daun salam, sereh, cengkeh, jahe, lengkuas, dan santan, tambahkan air seperti biasa memasak nasi. Bila sudah matang, aduk-aduk nasi lalu tutup ricecooker kembali sebentar sebelum di sajikan."
- "Sambal kacang : haluskan kacang tanah dan cabe, lalu tumis, tambahkan gula merah dan garam, aduk merata, tambahkan air secukupnya, masak hingga mengental."
- "Sajikan nasi uduk bersama dengan bahan pelengkap lainnya."
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 200 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT51M"
recipeyield: "1"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Betawi Simple Dengan Ricecooker](https://img-global.cpcdn.com/recipes/fbd3090590e03071/682x484cq65/nasi-uduk-betawi-simple-dengan-ricecooker-foto-resep-utama.webp)

Ingin membuat Nasi Uduk Betawi Simple Dengan Ricecooker ? Coba resep berikut ini. Cara memasaknya sangat praktis namun jangan kaget jika hasilnya gurih dan lezat cocok sekali jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Bahan-bahan Yang Dibutuhkan Untuk Menyiapkan Nasi Uduk Betawi Simple Dengan Ricecooker:

1. beras di cuci bersih 1 1/2 cup
1. santan instan sun kara 65 ml
1. daun salam 3 lembar
1. sereh 1 buah
1. jahe utuh 1 ruas
1. lengkuas di geprek 1 ruas
1. cengkeh 3 butir
1. kayu manis 2 batang
1. garam 
1. sambal kacang  
1. kacang tanah di sangrai 100 gr
1. cabe merah 50 gr
1. gula merah sisir 1 sdm
1. garam secukupnya
1. air 

My Mom still use that method to make her nasi uduk. Make this easy and aromatic Betawi-style nasi uduk that goes with many main and side dishes. I&#39;m sharing how you can make it My favorite way of cooking nasi uduk is with a rice cooker or Instant Pot. It&#39;s a no brainer because I just need to put everything in there. 

<!--inarticleads2-->

## Langkah-langkah Untuk Membuat Nasi Uduk Betawi Simple Dengan Ricecooker:

1. Siapkan panci ricecooker, masukan beras, daun salam, sereh, cengkeh, jahe, lengkuas, dan santan, tambahkan air seperti biasa memasak nasi. Bila sudah matang, aduk-aduk nasi lalu tutup ricecooker kembali sebentar sebelum di sajikan.
1. Sambal kacang : haluskan kacang tanah dan cabe, lalu tumis, tambahkan gula merah dan garam, aduk merata, tambahkan air secukupnya, masak hingga mengental.
1. Sajikan nasi uduk bersama dengan bahan pelengkap lainnya.


Cara Bikin Nasi Uduk Betawi Simple. Siapkan panci rice cooker, masukan beras yang telah dicuci, lalu tambahkan daun salam, sereh, cengkeh, jahe, lengkuas, dan santan, serta tambahkan air seperti biasa memasak nasi. Jika sudah matang, aduk-aduk nasi lalu tutup ricecooker kembali, tunggu. Cara Membuat Nasi Uduk Rice Cooker. Tuangkan santan kedalam rice cooker lalu susul dengan memasukkan beras, aduk Cara Membuat Nasi Uduk Betawi. 

Demikian informasi  resep Nasi Uduk Betawi Simple Dengan Ricecooker   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
