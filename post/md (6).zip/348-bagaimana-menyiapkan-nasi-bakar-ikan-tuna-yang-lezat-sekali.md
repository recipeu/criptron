---
description: "Bagaimana Menyiapkan Nasi Bakar Ikan tuna yang Lezat Sekali"
title: "Bagaimana Menyiapkan Nasi Bakar Ikan tuna yang Lezat Sekali"
slug: 348-bagaimana-menyiapkan-nasi-bakar-ikan-tuna-yang-lezat-sekali
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-10T17:03:19.292Z 
thumbnail: https://img-global.cpcdn.com/recipes/fe1a1cb2c839b90d/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/fe1a1cb2c839b90d/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/fe1a1cb2c839b90d/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/fe1a1cb2c839b90d/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp
author: Glenn Knight
ratingvalue: 5
reviewcount: 10
recipeingredient:
- "ikan tuna fillet 250 g"
- "bumbu halus "
- "bawang merah 8 biji"
- "bawang putih 4 biji"
- "bawang bombai bisa skipp 1 biji"
- "cabai merah 5 biji"
- "cabe rawit 10 biji"
- "daun bawang sukupnya ambil batangx "
- "jahe 2 ruas"
- "pelengkap "
- "daun jeruk secukupnya"
- "daun pisang "
- "kecap 4 sdm"
- "garam secukupnya"
- "kaldu atau penyedap rasa secukupnya"
recipeinstructions:
- "Potong- potong dadu ikan tuna"
- "Haluskan bumbu dengan blender atau d ulek."
- "Tumis bumbu halus sampai wangi dan masak.kemudian beri irisan daun jeruk jika sudah di rasa wangi dan matang."
- "Masukkan ikan tuna campur dengan bumbu sampek bumbu meresap kemudian tambahkan 50 ml air dan beri kecap garam dan penyedap rasa."
- "Koreksi rasa dan biarkan ikan matang sampek air bener2 meresap"
- "Bungkus nasi dengan daun pisang tata rapi kemudian beri ikan tuna d atasnya dan lipat seperti melipat pepes atau lontong daun."
- "Jika sudah panggan selama 10 menit. hidangkan selagi hangat dengan cinta..."
- "Nb : bisa d kasih tambahan telur dadar atau lauk yg lain... selamat mencoba..."
categories:
- Resep
tags:
- nasi
- bakar
- ikan

katakunci: nasi bakar ikan 
nutrition: 146 calories
recipecuisine: Indonesian
preptime: "PT36M"
cooktime: "PT56M"
recipeyield: "3"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Bakar Ikan tuna](https://img-global.cpcdn.com/recipes/fe1a1cb2c839b90d/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp)

Resep rahasia Nasi Bakar Ikan tuna    dengan 8 langkahmudah dan cepat cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Untuk Menyiapkan Nasi Bakar Ikan tuna:

1. ikan tuna fillet 250 g
1. bumbu halus 
1. bawang merah 8 biji
1. bawang putih 4 biji
1. bawang bombai bisa skipp 1 biji
1. cabai merah 5 biji
1. cabe rawit 10 biji
1. daun bawang sukupnya ambil batangx 
1. jahe 2 ruas
1. pelengkap 
1. daun jeruk secukupnya
1. daun pisang 
1. kecap 4 sdm
1. garam secukupnya
1. kaldu atau penyedap rasa secukupnya



<!--inarticleads2-->

## Tata Cara Menyiapkan Nasi Bakar Ikan tuna:

1. Potong- potong dadu ikan tuna
1. Haluskan bumbu dengan blender atau d ulek.
1. Tumis bumbu halus sampai wangi dan masak.kemudian beri irisan daun jeruk jika sudah di rasa wangi dan matang.
1. Masukkan ikan tuna campur dengan bumbu sampek bumbu meresap kemudian tambahkan 50 ml air dan beri kecap garam dan penyedap rasa.
1. Koreksi rasa dan biarkan ikan matang sampek air bener2 meresap
1. Bungkus nasi dengan daun pisang tata rapi kemudian beri ikan tuna d atasnya dan lipat seperti melipat pepes atau lontong daun.
1. Jika sudah panggan selama 10 menit. hidangkan selagi hangat dengan cinta...
1. Nb : bisa d kasih tambahan telur dadar atau lauk yg lain... selamat mencoba...




Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
