---
description: "Resep NASI DAUN JERUK (Rice Cooker) Anti Gagal"
title: "Resep NASI DAUN JERUK (Rice Cooker) Anti Gagal"
slug: 274-resep-nasi-daun-jeruk-rice-cooker-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-29T17:15:49.654Z 
thumbnail: https://img-global.cpcdn.com/recipes/efd361ed28c4e46c/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/efd361ed28c4e46c/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/efd361ed28c4e46c/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/efd361ed28c4e46c/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
author: Carl Brooks
ratingvalue: 4
reviewcount: 13
recipeingredient:
- "Beras 2 cup"
- "Daun Jeruk 8 lbr"
- "Serai digeprek 1 btg"
- "Daun Salam Saya skip karena di Siem Reap tidak ada 2 lbr"
- "Garam 1/2 sdt"
- "Kaldu Ayam Bubuk 1/2 sdt"
- "Gula pasir sedikit saja "
- "Air sesuaikan dengan karakter beras Boleh ditambah santan agar gurih "
recipeinstructions:
- "Rajang halus daun jeruk."
- "Cuci bersih beras, tambahkan air dan masukkan rajangan daun jeruk, serai, daun salam, garam, kaldu bubuk, gula pasir. Aduk rata dan masak di Magic com / Rice cooker hingga matang."
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 269 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT60M"
recipeyield: "2"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![NASI DAUN JERUK (Rice Cooker)](https://img-global.cpcdn.com/recipes/efd361ed28c4e46c/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp)

Resep NASI DAUN JERUK (Rice Cooker)  enak dengan 2 langkahcepat dan mudah cocok sekali jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Dalam Menyiapkan NASI DAUN JERUK (Rice Cooker):

1. Beras 2 cup
1. Daun Jeruk 8 lbr
1. Serai digeprek 1 btg
1. Daun Salam Saya skip karena di Siem Reap tidak ada 2 lbr
1. Garam 1/2 sdt
1. Kaldu Ayam Bubuk 1/2 sdt
1. Gula pasir sedikit saja 
1. Air sesuaikan dengan karakter beras Boleh ditambah santan agar gurih 



<!--inarticleads2-->

## Cara Mudah Menyiapkan NASI DAUN JERUK (Rice Cooker):

1. Rajang halus daun jeruk.
1. Cuci bersih beras, tambahkan air dan masukkan rajangan daun jeruk, serai, daun salam, garam, kaldu bubuk, gula pasir. Aduk rata dan masak di Magic com / Rice cooker hingga matang.




Terima kasih telah menggunakan resep yang kami tampilkan di halaman ini. Semoga bermanfaat dan selamat mencoba!
