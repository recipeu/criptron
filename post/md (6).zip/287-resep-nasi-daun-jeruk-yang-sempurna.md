---
description: "Resep Nasi daun jeruk yang Sempurna"
title: "Resep Nasi daun jeruk yang Sempurna"
slug: 287-resep-nasi-daun-jeruk-yang-sempurna
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-09T05:06:07.309Z 
thumbnail: https://img-global.cpcdn.com/recipes/87967ef47dac563c/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/87967ef47dac563c/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/87967ef47dac563c/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/87967ef47dac563c/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
author: Lucile Henry
ratingvalue: 3.7
reviewcount: 14
recipeingredient:
- "beras 3 cup"
- "bawang merah cincang halus 5 siung"
- "bawang putihcincang halus 5 siung"
- "Air untuk masak beraspada umumnya biasa masak nasi buk ibuk "
- "Garam secukupnya"
- "Kaldu ayam secukupnya"
- "seraigeprek 1 batang"
- "daun jerukdaun y ajah tengah batang y buang 6/7 lembar"
- "Daun jeruk y di cincang sampe bner2 halus atau d blender dll "
recipeinstructions:
- "Cuci bersih beras seperti biasa"
- "Cincang halus duo bawang lalu goreng seperti biasa buk ibuk goreng bawang Jngn sampe item atau kecoklatan ya nnti takut ga enak.soal y bawang biasa y kalo udh d angkat ttp ajh dya akan ngegoreng sndri meskipun udh d angkat juga lalu sisihkan yah si duo bawang y"
- "Masukan duo bawang goreng,garam,kaldu,sereh,Daun jeruk,air(seperti biasa memasak nasi) lalu aduk hingga rata"
- "Lalu masukkan ke rice cooker jetreken dan tunggu sampe Mateng, pokoknya sambil rebahan boleh 🤭"
- "Sudah matang aduk2 biar Kya d akel tea nasi y 😂 pokoknya terserah kalo udh Mateng mah hehehe. Selamat mencoba 😇"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 173 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT48M"
recipeyield: "1"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi daun jeruk](https://img-global.cpcdn.com/recipes/87967ef47dac563c/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp)

5 langkah mudah dan cepat memasak  Nasi daun jeruk cocok banget jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Dalam Pembuatan Nasi daun jeruk:

1. beras 3 cup
1. bawang merah cincang halus 5 siung
1. bawang putihcincang halus 5 siung
1. Air untuk masak beraspada umumnya biasa masak nasi buk ibuk 
1. Garam secukupnya
1. Kaldu ayam secukupnya
1. seraigeprek 1 batang
1. daun jerukdaun y ajah tengah batang y buang 6/7 lembar
1. Daun jeruk y di cincang sampe bner2 halus atau d blender dll 

Nasi daun jeruk siap dihidangkan dengan. Nasi daun jeruk ini memang sedang tren di kalangan masyarakat Indonesia, banyak sekali kaum muda mudi yang berlomba-lomba membuat makanan nasi putih spesial ini. Nasi daun jeruk ala geprek bensu rekomended buat di coba. Geprek bensu nasi daun jeruk anti mainst. 

<!--inarticleads2-->

## Cara Mudah Membuat Nasi daun jeruk:

1. Cuci bersih beras seperti biasa
1. Cincang halus duo bawang lalu goreng seperti biasa buk ibuk goreng bawang Jngn sampe item atau kecoklatan ya nnti takut ga enak.soal y bawang biasa y kalo udh d angkat ttp ajh dya akan ngegoreng sndri meskipun udh d angkat juga lalu sisihkan yah si duo bawang y
1. Masukan duo bawang goreng,garam,kaldu,sereh,Daun jeruk,air(seperti biasa memasak nasi) lalu aduk hingga rata
1. Lalu masukkan ke rice cooker jetreken dan tunggu sampe Mateng, pokoknya sambil rebahan boleh 🤭
1. Sudah matang aduk2 biar Kya d akel tea nasi y 😂 pokoknya terserah kalo udh Mateng mah hehehe. Selamat mencoba 😇


Gurih dan wangi dari daun jeruk menambah kelezatan nasi daun jeruk. Nasi dengan campuran daun jeruk yang wangi sedang tren. Hai selamat pagi sahabat CWS, pagi ini saya share resep Nasi Daun Jeruk. Praktis banget karena saya gunakan rice cooker. Rasanya mirip nasi uduk tapi wangiiii. 

Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
