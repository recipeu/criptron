---
description: "Resep Nasi ayam hainam RICE COOKER, Sempurna"
title: "Resep Nasi ayam hainam RICE COOKER, Sempurna"
slug: 448-resep-nasi-ayam-hainam-rice-cooker-sempurna
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-25T03:53:10.592Z 
thumbnail: https://img-global.cpcdn.com/recipes/d2793a7e612ef61b/682x484cq65/nasi-ayam-hainam-rice-cooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/d2793a7e612ef61b/682x484cq65/nasi-ayam-hainam-rice-cooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/d2793a7e612ef61b/682x484cq65/nasi-ayam-hainam-rice-cooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/d2793a7e612ef61b/682x484cq65/nasi-ayam-hainam-rice-cooker-foto-resep-utama.webp
author: Gregory Patton
ratingvalue: 5
reviewcount: 15
recipeingredient:
- "ayam rebus dan kaldu ayam "
- "ayam kampung utuh ukuran 1kg cuci bersih potong kaki sampai dengkul balur dengan cuka makan dan sedikit garam urut dan bilas sampai bersih 1"
- "jahe geprak mekar 5 cm"
- "bawang putih berkulit geprak 3 siung"
- "daun salam 2 lembar"
- "air untuk merebus 1.5 l"
- "daun bawang batangan 3 batang"
- "garam 1 sdt"
- "minyak wijen 1 sdm"
- "nasi hainam "
- "beras cuci bilas hingga bersih 3 cup"
- "bawang putih press 1 siung"
- "jahe bersihkan iris tipis cincang halus 10 cm"
- "Seluruh kaldu ayam hasil rebusan ayam yang sudah ditiriskan "
- "Tambahan air jika kurang "
- "garam 2 sdt"
- "sari jamur 1 sdt"
- "saus tiram 1 sdm"
- "minyak wijen 2 sdm"
- "minyak untuk menumis 2 sdm"
- "ayam dan lemak yang disisihkan dari persiapan ayam Potongan"
- "Bahan Hidangan "
- "minyak wijen 1 sdm"
- "cabe merah besar buang biji cincang kasar 1/2"
- "cabe rawit 3"
- "daun bawang besar cincang kasar 1/2"
- "kecap asin encer 4-5 sdm"
- "daun ketumbar atau daun seledri untuk hiasan 1 genggam"
- "timun besar iris melintang miring tipis 1 bh"
recipeinstructions:
- "Ayam dipotong dari bagian-bagian yakni: kaki (potong bagian berkuku), leher, kepala, ruas sayap terakhir, sisihkan. Lumuri bagian dalam ayam dengan 1sdt garam, lalu sumpal dengan jahe, bawang putih dan daun bawang. Pijat bagian luar ayam dengan minyak wijen."
- "Masukkan ke dalam panci, ayam, air dan daun salam, rebus hingga empuk sekitar 40 menit.  Keluarkan ayam dari kaldu, sisihkan kaldu agar menjadi dingin. Ayam, buang rempah perutnya, cek jika banyak lemak di area perut, potong, sisihkan.  Rendam ayam dalam air es beberapa menit lalu tiriskan, sisihkan."
- "Panaskan wajan, masukkan minyak goreng, tumis jahe dan bawang putih dengan api sedang jangan sampai gosong, bila harum, segera masukkan beras yang telah dicuci bersih dan tiris kering, aduk sebentar matikan api. Masukkan minyak wijen, saus tiram, garam dan sari jamur ke dalam beras di wajan aduk rata.  Pindahkan dalam rice cooker, tuangkan kaldu ayam yang sudah suhu kamar, masukkan bagian2 ayam, tambahkan air sampai selevel biasanya menanak nasi. Biarkan rice cooker bekerja."
- "Siapkan ayam, potong2 sesuai selera, tata di piring, siram dengan minyak wijen, hias dengan daun seledri/ketumbar di atas, timun di sampingnya."
- "Dalam mangkok sambal kecil tuangkan kecap encer, masukkan cabe rawit, bejek dengan sendok hingga hancur dan benyek, masukkan cincangan daun bawang dan cabe merah iris, campur rata."
- "Hidangkan nasi hainam dengan ayam rebus potong dan kecap cocolan."
categories:
- Resep
tags:
- nasi
- ayam
- hainam

katakunci: nasi ayam hainam 
nutrition: 217 calories
recipecuisine: Indonesian
preptime: "PT24M"
cooktime: "PT58M"
recipeyield: "1"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi ayam hainam RICE COOKER](https://img-global.cpcdn.com/recipes/d2793a7e612ef61b/682x484cq65/nasi-ayam-hainam-rice-cooker-foto-resep-utama.webp)

Ingin membuat Nasi ayam hainam RICE COOKER ? Coba resep berikut ini. Cara memasaknya sangat praktis namun hasilnya gurih dan lezat yang musti bunda coba dirumah

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Untuk Menyiapkan Nasi ayam hainam RICE COOKER:

1. ayam rebus dan kaldu ayam 
1. ayam kampung utuh ukuran 1kg cuci bersih potong kaki sampai dengkul balur dengan cuka makan dan sedikit garam urut dan bilas sampai bersih 1
1. jahe geprak mekar 5 cm
1. bawang putih berkulit geprak 3 siung
1. daun salam 2 lembar
1. air untuk merebus 1.5 l
1. daun bawang batangan 3 batang
1. garam 1 sdt
1. minyak wijen 1 sdm
1. nasi hainam 
1. beras cuci bilas hingga bersih 3 cup
1. bawang putih press 1 siung
1. jahe bersihkan iris tipis cincang halus 10 cm
1. Seluruh kaldu ayam hasil rebusan ayam yang sudah ditiriskan 
1. Tambahan air jika kurang 
1. garam 2 sdt
1. sari jamur 1 sdt
1. saus tiram 1 sdm
1. minyak wijen 2 sdm
1. minyak untuk menumis 2 sdm
1. ayam dan lemak yang disisihkan dari persiapan ayam Potongan
1. Bahan Hidangan 
1. minyak wijen 1 sdm
1. cabe merah besar buang biji cincang kasar 1/2
1. cabe rawit 3
1. daun bawang besar cincang kasar 1/2
1. kecap asin encer 4-5 sdm
1. daun ketumbar atau daun seledri untuk hiasan 1 genggam
1. timun besar iris melintang miring tipis 1 bh

Nasi ayam Hainan adalah hidangan ayam rebus dan nasi berbumbu yang disajikan dengan saus sambal. Masakan ini awalnya dibuat oleh Anda sedang mencari ide resep nasi ayam ala hainam ricecooker yang unik? Cara menyiapkannya memang tidak terlalu sulit namun tidak gampang juga. You will need a bamboo rice steamer and a large saute pan. 

<!--inarticleads2-->

## Langkah-langkah Untuk Menyiapkan Nasi ayam hainam RICE COOKER:

1. Ayam dipotong dari bagian-bagian yakni: kaki (potong bagian berkuku), leher, kepala, ruas sayap terakhir, sisihkan. - Lumuri bagian dalam ayam dengan 1sdt garam, lalu sumpal dengan jahe, bawang putih dan daun bawang. - Pijat bagian luar ayam dengan minyak wijen.
1. Masukkan ke dalam panci, ayam, air dan daun salam, rebus hingga empuk sekitar 40 menit.  - Keluarkan ayam dari kaldu, sisihkan kaldu agar menjadi dingin. - Ayam, buang rempah perutnya, cek jika banyak lemak di area perut, potong, sisihkan.  - Rendam ayam dalam air es beberapa menit lalu tiriskan, sisihkan.
1. Panaskan wajan, masukkan minyak goreng, tumis jahe dan bawang putih dengan api sedang jangan sampai gosong, bila harum, segera masukkan beras yang telah dicuci bersih dan tiris kering, aduk sebentar matikan api. - Masukkan minyak wijen, saus tiram, garam dan sari jamur ke dalam beras di wajan aduk rata.  - Pindahkan dalam rice cooker, tuangkan kaldu ayam yang sudah suhu kamar, masukkan bagian2 ayam, tambahkan air sampai selevel biasanya menanak nasi. Biarkan rice cooker bekerja.
1. Siapkan ayam, potong2 sesuai selera, tata di piring, siram dengan minyak wijen, hias dengan daun seledri/ketumbar di atas, timun di sampingnya.
1. Dalam mangkok sambal kecil tuangkan kecap encer, masukkan cabe rawit, bejek dengan sendok hingga hancur dan benyek, masukkan cincangan daun bawang dan cabe merah iris, campur rata.
1. Hidangkan nasi hainam dengan ayam rebus potong dan kecap cocolan.


Prep the rice steamer and set it to low heat. Put the reserved chicken skin in the saute pan over medium-low heat to render the fat. Resep Nasi Ayam Hainan - Jika sebelumnya saya sudah berbagi mengenai Resep Ayam Hainan yang sering disebut ayam rebus Pek Cam Ke. Baca Juga : Resep Nasi Uduk Rice Cooker Komplit Khas Betawi Super Gampang, No Ribet dan Anti Gagal. Rasa nasi hainan umami tetapi ringan karena beras dimasak bersama kaldu ayam. 

Salah satu kuliner yang cukup praktis dalam pembuatannya adalah  Nasi ayam hainam RICE COOKER. Selain itu  Nasi ayam hainam RICE COOKER  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu lakukan 6 langkah, dan  Nasi ayam hainam RICE COOKER  pun siap di hidangkan. selamat mencoba !
