---
description: "Langkah Mudah untuk Membuat Nasi Uduk Betawi Anti Gagal"
title: "Langkah Mudah untuk Membuat Nasi Uduk Betawi Anti Gagal"
slug: 23-langkah-mudah-untuk-membuat-nasi-uduk-betawi-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-14T04:17:27.168Z 
thumbnail: https://img-global.cpcdn.com/recipes/12d4bff3b52b7597/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/12d4bff3b52b7597/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/12d4bff3b52b7597/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/12d4bff3b52b7597/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
author: Dora Carter
ratingvalue: 4.8
reviewcount: 4
recipeingredient:
- "beras cuci tiriskan 1 kg"
- "santan dari 12 butir kelapa 1200 ml"
- "6 lembar daun salam "
- "sereh geprek 2 batang"
- "jahe geprek Sejempol"
- "lengkuas geprek Sejempol"
- "pala ukuran kecil geprek 1 btr"
- "kayu manis ukuran kecil 1 btg"
- "cengkeh 6 btr"
- "garam 1 sdm"
recipeinstructions:
- "Tuang santan ke dalam wajan, masukkan semua bumbu. Masak sambil diaduk2 hingga mendidih, jangan sampai santan nya pecah ya"
- "Setelah santan mendidih masukkan beras. Masak sambil diaduk / di aron hingga santan terserap habis. Api nya jangan besar2 ya"
- "Panaskan kukusan. Pindahkan beras aron ke kukusan. Kukus sampai matang. Sy kukus 45 menit karena nasi nya banyak"
- "Nasi uduknya hangat2 dibungkus dg daun pisang, kasih bawang goreng. Haruum bangettt nasi uduk nya 😍, enakkknya makan pake Malbi 👍🏻👍🏻"
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 214 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT52M"
recipeyield: "2"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Betawi](https://img-global.cpcdn.com/recipes/12d4bff3b52b7597/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp)

Resep rahasia dan cara mengolah  Nasi Uduk Betawi yang wajib bunda coba segera

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Dalam Pembuatan Nasi Uduk Betawi:

1. beras cuci tiriskan 1 kg
1. santan dari 12 butir kelapa 1200 ml
1. 6 lembar daun salam 
1. sereh geprek 2 batang
1. jahe geprek Sejempol
1. lengkuas geprek Sejempol
1. pala ukuran kecil geprek 1 btr
1. kayu manis ukuran kecil 1 btg
1. cengkeh 6 btr
1. garam 1 sdm



<!--inarticleads2-->

## Tata Cara Membuat Nasi Uduk Betawi:

1. Tuang santan ke dalam wajan, masukkan semua bumbu. Masak sambil diaduk2 hingga mendidih, jangan sampai santan nya pecah ya
1. Setelah santan mendidih masukkan beras. Masak sambil diaduk / di aron hingga santan terserap habis. Api nya jangan besar2 ya
1. Panaskan kukusan. Pindahkan beras aron ke kukusan. Kukus sampai matang. Sy kukus 45 menit karena nasi nya banyak
1. Nasi uduknya hangat2 dibungkus dg daun pisang, kasih bawang goreng. Haruum bangettt nasi uduk nya 😍, enakkknya makan pake Malbi 👍🏻👍🏻




Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
