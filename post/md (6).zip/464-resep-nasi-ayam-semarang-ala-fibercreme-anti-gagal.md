---
description: "Resep Nasi ayam semarang ala fibercreme Anti Gagal"
title: "Resep Nasi ayam semarang ala fibercreme Anti Gagal"
slug: 464-resep-nasi-ayam-semarang-ala-fibercreme-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-10T00:19:01.453Z 
thumbnail: https://img-global.cpcdn.com/recipes/ba8769539e854288/682x484cq65/nasi-ayam-semarang-ala-fibercreme-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/ba8769539e854288/682x484cq65/nasi-ayam-semarang-ala-fibercreme-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/ba8769539e854288/682x484cq65/nasi-ayam-semarang-ala-fibercreme-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/ba8769539e854288/682x484cq65/nasi-ayam-semarang-ala-fibercreme-foto-resep-utama.webp
author: Alexander Maxwell
ratingvalue: 4.5
reviewcount: 3
recipeingredient:
- "bahan nasi gurih  "
- "nasi 3 cup"
- "fibercreme 2 sdm"
- "garam 1 sdt"
- "salam 4 lembar"
- "sereh geprek 1 batang"
- "bahan opor ayam  "
- "ayam 1/2 ekor"
- "bawang putih 4 siung"
- "bawang merah 8 siung"
- "jahe geprek 4 cm"
- "lengkuas 4 cm"
- "kemiri 3 butir"
- "fibercreme 4 sdm"
- "salam 4 lembar"
- "sereh geprek 2 batang"
- "garam 1 sdt"
- "gula pasir 1 sdt"
- "air secukupnya"
- "minyak untuk menumis "
- "sayur labu  "
- "labu siam potong korek api 1 buah"
- "bawang putih 4 siung"
- "bawang merah 6 siung"
- "kemiri 2 butir"
- "lengkuas 2 cm"
- "lombok rawit 10 biji"
- "kunyit bubuk sedikit"
- "garam gula secukupnya"
- "minyak untuk menumis "
- "telur pindang  "
- "telur 2 butir"
- "teh celup 1 buah"
- "daun salam 2 lembar"
- "bawang merah 2 butir"
- "telur pindang  "
recipeinstructions:
- "Nasi gurih : campurkan semua bahan jangan lupa koreksi rasa, lalu klik cook"
- "Ayam : haluskan baput, bamer, lengkuas, kemiri, jahe. lalu tumis bersama salam, sereh geprek. setelah wangi, tambahkan air dan ayam, masukan garam, gula, aduk hingga raya jangan lupa koreksi rasa. masak hingga matang. Setelah itu, tambahkan fibercreme lalu aduk hingga merata. masak hingga mendidih kembali."
- "Sayur labu : haluskan bamer, bapur, lengkuas, kemiri, kunyit, cabe. lalu tumis menggunakan minyak panas hingga wangi tambahkan pula daun salam. setelah itu masukan labu siam, air, garam, gula. setelah mendidih tambahkan fibercreme"
- "Telur pindang : rebus telur bersama teh, daun salam, dan bawang merah (di cuci, dan masukan langsung tidak perlu dikupas). setelah 10 menit, tiriskan telur, kupas kulitnya, rebus kembali kedalam air teh tadi. masak hingga warna telur coklak kehitaman jangan lupa di pindah sisinya agar warna merata."
categories:
- Resep
tags:
- nasi
- ayam
- semarang

katakunci: nasi ayam semarang 
nutrition: 280 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT59M"
recipeyield: "4"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi ayam semarang ala fibercreme](https://img-global.cpcdn.com/recipes/ba8769539e854288/682x484cq65/nasi-ayam-semarang-ala-fibercreme-foto-resep-utama.webp)

Ingin membuat Nasi ayam semarang ala fibercreme ? Coba resep berikut ini. Cara memasaknya sangat praktis namun hasilnya gurih dan lezat cocok sekali jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Dalam Pembuatan Nasi ayam semarang ala fibercreme:

1. bahan nasi gurih  
1. nasi 3 cup
1. fibercreme 2 sdm
1. garam 1 sdt
1. salam 4 lembar
1. sereh geprek 1 batang
1. bahan opor ayam  
1. ayam 1/2 ekor
1. bawang putih 4 siung
1. bawang merah 8 siung
1. jahe geprek 4 cm
1. lengkuas 4 cm
1. kemiri 3 butir
1. fibercreme 4 sdm
1. salam 4 lembar
1. sereh geprek 2 batang
1. garam 1 sdt
1. gula pasir 1 sdt
1. air secukupnya
1. minyak untuk menumis 
1. sayur labu  
1. labu siam potong korek api 1 buah
1. bawang putih 4 siung
1. bawang merah 6 siung
1. kemiri 2 butir
1. lengkuas 2 cm
1. lombok rawit 10 biji
1. kunyit bubuk sedikit
1. garam gula secukupnya
1. minyak untuk menumis 
1. telur pindang  
1. telur 2 butir
1. teh celup 1 buah
1. daun salam 2 lembar
1. bawang merah 2 butir
1. telur pindang  

Masukkan kol sawi putih dan caisim, sekaligus garam, kaldu ayam bubuk, aduk cepat. Cobain Lemper Roll Rendang Ayam ala @FiberCreme_TV ini aja yuk! Paduan lempernya yang gurih dengan isian rendang ayamnya dijamin bikin ketagihan deh. Kamu gak usah bikin isiannya kok kalau udah punya rendang ayam ready-to-eat dari @PawonOmWill. 

<!--inarticleads2-->

## Cara Mudah Menyiapkan Nasi ayam semarang ala fibercreme:

1. Nasi gurih : campurkan semua bahan jangan lupa koreksi rasa, lalu klik cook
1. Ayam : haluskan baput, bamer, lengkuas, kemiri, jahe. lalu tumis bersama salam, sereh geprek. setelah wangi, tambahkan air dan ayam, masukan garam, gula, aduk hingga raya jangan lupa koreksi rasa. masak hingga matang. Setelah itu, tambahkan fibercreme lalu aduk hingga merata. masak hingga mendidih kembali.
1. Sayur labu : haluskan bamer, bapur, lengkuas, kemiri, kunyit, cabe. lalu tumis menggunakan minyak panas hingga wangi tambahkan pula daun salam. setelah itu masukan labu siam, air, garam, gula. setelah mendidih tambahkan fibercreme
1. Telur pindang : rebus telur bersama teh, daun salam, dan bawang merah (di cuci, dan masukan langsung tidak perlu dikupas). setelah 10 menit, tiriskan telur, kupas kulitnya, rebus kembali kedalam air teh tadi. masak hingga warna telur coklak kehitaman jangan lupa di pindah sisinya agar warna merata.


Daun pisang untuk alas sajian - secukupnya. Beli bahan dan peralatan masak - DISINI JAMIN TERMURAH. Selain lumpia, kota Semarang juga terkenal dengan menu nasi ayam khas Semarang. Selain tahu gimbal, tahu pong, lumpia, dan wingko babad, ibukota Jawa Tengah ini juga dikenal dengan kuliner nasi ayam. Sekilas mirip nasi liwet tapi tentu rasanya berbeda dan tidak kalah enak. 

Terima kasih telah menggunakan resep yang kami tampilkan di halaman ini. Semoga bermanfaat dan selamat mencoba!
