---
description: "Resep Semur betawi ala penjual nasi uduk yang Bikin Ngiler"
title: "Resep Semur betawi ala penjual nasi uduk yang Bikin Ngiler"
slug: 86-resep-semur-betawi-ala-penjual-nasi-uduk-yang-bikin-ngiler
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-06T03:19:39.209Z 
thumbnail: https://img-global.cpcdn.com/recipes/911f7f7e08328a81/682x484cq65/semur-betawi-ala-penjual-nasi-uduk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/911f7f7e08328a81/682x484cq65/semur-betawi-ala-penjual-nasi-uduk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/911f7f7e08328a81/682x484cq65/semur-betawi-ala-penjual-nasi-uduk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/911f7f7e08328a81/682x484cq65/semur-betawi-ala-penjual-nasi-uduk-foto-resep-utama.webp
author: Wesley Greer
ratingvalue: 4.8
reviewcount: 11
recipeingredient:
- "Bahan Isi "
- "telur 4 butir"
- "tahu putih dibelah 2 5 buah"
- "kentang 14 kg dipotong jadi 4 bagian 3 butir"
- "Bumbu halus "
- "bawang putih 4 siung"
- "merica butiran 1/2 sdt"
- "jahe 2 cm"
- "kemiri sangrai 6 butir"
- "ketumbar 1 sdt"
- "jintan 1/4 sdt"
- "Bahan tambahan "
- "bawang merah diiris tipis 8 butir"
- "tomat dipotongpotong saya skip 2 buah"
- "pala bubuk 1/2 sdt"
- "cengkeh 3 butir"
- "kayu manis 3 cm"
- "kecap manis 4 sdm munjung"
- "garam 1 sdt"
- "air matang 1500 cc"
- "serai digeprek 1 batang"
- "daun salam 1 lembar"
- "minyak goreng untuk menumis Secukupnya"
- "bawang goreng untuk taburan saya skip Secukupnya"
recipeinstructions:
- "Rebus telur, kupas sisihkan. Lalu goreng tahu hingga matang. Tiriskan, sisihkan. Biarkan dingin."
- "Sangrai kemiri, sisihkan. Haluskan bumbu halus dengan blender."
- "Tumis bawang merah hingga harum dan layu, masukkan bumbu halus, tumis hingga matang dan harum."
- "Masukkan telur, tahu, aduk rata. Lalu tambahkan kentang yang sudah dikupas, dicuci dan dipotong-potong. Aduk rata."
- "Tambahkan air dan semua bahan tambahan. Aduk rata, Masak hingga mendidih dan air berkurang. Koreksi rasa. Sajikan dengan taburan bawang goreng dan nasi uduk atau sesuai selera."
categories:
- Resep
tags:
- semur
- betawi
- ala

katakunci: semur betawi ala 
nutrition: 100 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT42M"
recipeyield: "2"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Semur betawi ala penjual nasi uduk](https://img-global.cpcdn.com/recipes/911f7f7e08328a81/682x484cq65/semur-betawi-ala-penjual-nasi-uduk-foto-resep-utama.webp)

5 langkah mudah dan cepat membuat  Semur betawi ala penjual nasi uduk yang bisa ibu coba segera

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Untuk Menyiapkan Semur betawi ala penjual nasi uduk:

1. Bahan Isi 
1. telur 4 butir
1. tahu putih dibelah 2 5 buah
1. kentang 14 kg dipotong jadi 4 bagian 3 butir
1. Bumbu halus 
1. bawang putih 4 siung
1. merica butiran 1/2 sdt
1. jahe 2 cm
1. kemiri sangrai 6 butir
1. ketumbar 1 sdt
1. jintan 1/4 sdt
1. Bahan tambahan 
1. bawang merah diiris tipis 8 butir
1. tomat dipotongpotong saya skip 2 buah
1. pala bubuk 1/2 sdt
1. cengkeh 3 butir
1. kayu manis 3 cm
1. kecap manis 4 sdm munjung
1. garam 1 sdt
1. air matang 1500 cc
1. serai digeprek 1 batang
1. daun salam 1 lembar
1. minyak goreng untuk menumis Secukupnya
1. bawang goreng untuk taburan saya skip Secukupnya

Cocok disajikan bersama nasi putih hangat. Semur Daging Betawi ini dijamin lezat kalau kamu mengikuti takaran bumbu yang benar. Paduan kecap manis yang legit dengan aneka bumbu yang harum. Resep nasi uduk memang terkenal dari Betawi atau Jakarta. 

<!--inarticleads2-->

## Cara Mudah Menyiapkan Semur betawi ala penjual nasi uduk:

1. Rebus telur, kupas sisihkan. Lalu goreng tahu hingga matang. Tiriskan, sisihkan. Biarkan dingin.
1. Sangrai kemiri, sisihkan. Haluskan bumbu halus dengan blender.
1. Tumis bawang merah hingga harum dan layu, masukkan bumbu halus, tumis hingga matang dan harum.
1. Masukkan telur, tahu, aduk rata. Lalu tambahkan kentang yang sudah dikupas, dicuci dan dipotong-potong. Aduk rata.
1. Tambahkan air dan semua bahan tambahan. Aduk rata, Masak hingga mendidih dan air berkurang. Koreksi rasa. Sajikan dengan taburan bawang goreng dan nasi uduk atau sesuai selera.


Padahal di daerah lain pun ada jenis masakan nasi ini, Salah satunya yang disebut juga dengan nasi gurih di Jawa. Mungkin karena di Jakarta dan sekitarnya, penjual nasi uduk dekat dengan rumah lengkap dengan sambal nasi uduk. Saya tidak tahu siapa yang memberi nama nasi uduk. Setiap daerah punya menunya masing-masing dan ada yang diaduk. Kalau di Jakarta akan lebih nikmat dengan semur tahu dan semur jengkol. 

Salah satu kuliner yang cukup praktis dalam pembuatannya adalah  Semur betawi ala penjual nasi uduk. Selain itu  Semur betawi ala penjual nasi uduk  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu ikuti 5 langkah, dan  Semur betawi ala penjual nasi uduk  pun siap di hidangkan. selamat mencoba !
