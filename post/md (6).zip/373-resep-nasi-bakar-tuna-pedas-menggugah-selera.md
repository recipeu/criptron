---
description: "Resep Nasi Bakar Tuna Pedas, Menggugah Selera"
title: "Resep Nasi Bakar Tuna Pedas, Menggugah Selera"
slug: 373-resep-nasi-bakar-tuna-pedas-menggugah-selera
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-02T17:46:55.712Z 
thumbnail: https://img-global.cpcdn.com/recipes/20db1d8ae5c21518/682x484cq65/nasi-bakar-tuna-pedas-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/20db1d8ae5c21518/682x484cq65/nasi-bakar-tuna-pedas-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/20db1d8ae5c21518/682x484cq65/nasi-bakar-tuna-pedas-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/20db1d8ae5c21518/682x484cq65/nasi-bakar-tuna-pedas-foto-resep-utama.webp
author: Beulah Paul
ratingvalue: 4.7
reviewcount: 5
recipeingredient:
- "Bahan nasi "
- "beras cuci bersih 500 gr"
- "santan sedang 750 ml"
- "seraiambil putihnya 2 btg"
- "daun salam 2 lbr"
- "daun pandan 2 lbr"
- "gaaram secukupnya"
- "Pelengkap "
- "daun pisang dan lidi utk membungkus "
- "Bahan isi "
- "ikan tunarebussuwir2 1 ekor"
- "daun salam 2 lbr"
- "seraimemarkan 1 btg"
- "daun jeruk 2 lbr"
- "lengkuasmemarkan 2 cm"
- "santan kental 250 ml"
- "daun kemangipetik daunnya 2 ikat"
- "garamgula dan minyak utk menumis secukupnya"
- "Bumbu halus "
- "bawang merah 5 btr"
- "bawang putih 3 siung"
- "kemirisangrai 4 btr"
- "kunyitbakar 1 cm"
- "cabe merah keriting 5 buah"
- "cabe rawit 5 buah"
- "cabe merah besar 1 buah"
recipeinstructions:
- "Buat nasi:masak santan,tambahkan serai,pandan dan garam,masak hingga mendidih,masukkan beras,masak hingga mjd aron(santan terserap habis),matikan api"
- "Kukus nasi aron sampe matang,kurleb 30 menit,sisihkan"
- "Buat isi:panaskan minyak goreng,tumis bumbu halus,masukkan serai,salam,daun jeruk dan lengkuas,aduk sampe wangi,lalu masukkan ikan,tambahkan santan kental,bumbui garam dan gula,masak sampe santan menyusut dan bumbu meresap,masukkan daun kemangi,angkat"
- "Ambil daun pisang,taruh nasi,tambahkan bahan isian diatasnya,rapatkan dan rapikan,semat dgn lidi,bakar hingga aromanya wangi dan daun berubah warna,angkat,sajikan dgn lalapan"
categories:
- Resep
tags:
- nasi
- bakar
- tuna

katakunci: nasi bakar tuna 
nutrition: 127 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT50M"
recipeyield: "4"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Bakar Tuna Pedas](https://img-global.cpcdn.com/recipes/20db1d8ae5c21518/682x484cq65/nasi-bakar-tuna-pedas-foto-resep-utama.webp)

Resep rahasia dan cara mengolah  Nasi Bakar Tuna Pedas yang wajib ibu coba segera

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Dalam Pembuatan Nasi Bakar Tuna Pedas:

1. Bahan nasi 
1. beras cuci bersih 500 gr
1. santan sedang 750 ml
1. seraiambil putihnya 2 btg
1. daun salam 2 lbr
1. daun pandan 2 lbr
1. gaaram secukupnya
1. Pelengkap 
1. daun pisang dan lidi utk membungkus 
1. Bahan isi 
1. ikan tunarebussuwir2 1 ekor
1. daun salam 2 lbr
1. seraimemarkan 1 btg
1. daun jeruk 2 lbr
1. lengkuasmemarkan 2 cm
1. santan kental 250 ml
1. daun kemangipetik daunnya 2 ikat
1. garamgula dan minyak utk menumis secukupnya
1. Bumbu halus 
1. bawang merah 5 btr
1. bawang putih 3 siung
1. kemirisangrai 4 btr
1. kunyitbakar 1 cm
1. cabe merah keriting 5 buah
1. cabe rawit 5 buah
1. cabe merah besar 1 buah



<!--inarticleads2-->

## Tata Cara Menyiapkan Nasi Bakar Tuna Pedas:

1. Buat nasi:masak santan,tambahkan serai,pandan dan garam,masak hingga mendidih,masukkan beras,masak hingga mjd aron(santan terserap habis),matikan api
1. Kukus nasi aron sampe matang,kurleb 30 menit,sisihkan
1. Buat isi:panaskan minyak goreng,tumis bumbu halus,masukkan serai,salam,daun jeruk dan lengkuas,aduk sampe wangi,lalu masukkan ikan,tambahkan santan kental,bumbui garam dan gula,masak sampe santan menyusut dan bumbu meresap,masukkan daun kemangi,angkat
1. Ambil daun pisang,taruh nasi,tambahkan bahan isian diatasnya,rapatkan dan rapikan,semat dgn lidi,bakar hingga aromanya wangi dan daun berubah warna,angkat,sajikan dgn lalapan




Selamat memasak dan menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
