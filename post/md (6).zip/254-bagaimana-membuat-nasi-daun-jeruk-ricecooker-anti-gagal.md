---
description: "Bagaimana Membuat Nasi Daun Jeruk #RiceCooker Anti Gagal"
title: "Bagaimana Membuat Nasi Daun Jeruk #RiceCooker Anti Gagal"
slug: 254-bagaimana-membuat-nasi-daun-jeruk-ricecooker-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-24T11:41:48.521Z 
thumbnail: https://img-global.cpcdn.com/recipes/7a673e26f793b43b/682x484cq65/nasi-daun-jeruk-ricecooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/7a673e26f793b43b/682x484cq65/nasi-daun-jeruk-ricecooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/7a673e26f793b43b/682x484cq65/nasi-daun-jeruk-ricecooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/7a673e26f793b43b/682x484cq65/nasi-daun-jeruk-ricecooker-foto-resep-utama.webp
author: Eva Montgomery
ratingvalue: 4.9
reviewcount: 3
recipeingredient:
- "beras 2 cup"
- "daun jeruk iris2 me8lembar 15 lembar"
- "sereh ikat  geprek 1 btg"
- "daun salam 3 lmbr"
- "butter margarin 1 sdm"
- "kaldu jamur garam merica Secukupnya"
recipeinstructions:
- "Cuci bersih beras dan berikan air seperti takaran air mau masak nasi biasa"
- "Siapkan daun jeruk, daun salam, sereh, butter/ mentega, garam, kaldu jamur dan merica. Masukan semua bahan ke dalam wadah rice cooker dan aduk2 rata."
- "Masak beras di rice cooker sambil diaduk sesekali sebelum beras masak. Supaya rata semua bahan nya. Setelah matang nasi siap di santap."
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 205 calories
recipecuisine: Indonesian
preptime: "PT29M"
cooktime: "PT60M"
recipeyield: "4"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk #RiceCooker](https://img-global.cpcdn.com/recipes/7a673e26f793b43b/682x484cq65/nasi-daun-jeruk-ricecooker-foto-resep-utama.webp)

Resep rahasia Nasi Daun Jeruk #RiceCooker  enak dengan 3 langkahmudah dan cepat yang harus ibu coba segera

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Untuk Menyiapkan Nasi Daun Jeruk #RiceCooker:

1. beras 2 cup
1. daun jeruk iris2 me8lembar 15 lembar
1. sereh ikat  geprek 1 btg
1. daun salam 3 lmbr
1. butter margarin 1 sdm
1. kaldu jamur garam merica Secukupnya



<!--inarticleads2-->

## Cara Mudah Membuat Nasi Daun Jeruk #RiceCooker:

1. Cuci bersih beras dan berikan air seperti takaran air mau masak nasi biasa
1. Siapkan daun jeruk, daun salam, sereh, butter/ mentega, garam, kaldu jamur dan merica. Masukan semua bahan ke dalam wadah rice cooker dan aduk2 rata.
1. Masak beras di rice cooker sambil diaduk sesekali sebelum beras masak. Supaya rata semua bahan nya. Setelah matang nasi siap di santap.




Terima kasih telah membaca resep yang tim kami tampilkan di sini. Semoga bermanfaat dan selamat mencoba!
