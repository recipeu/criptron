---
description: "Langkah Mudah untuk Membuat Nasi daun jeruk rice cooker tanpa santan, Menggugah Selera"
title: "Langkah Mudah untuk Membuat Nasi daun jeruk rice cooker tanpa santan, Menggugah Selera"
slug: 242-langkah-mudah-untuk-membuat-nasi-daun-jeruk-rice-cooker-tanpa-santan-menggugah-selera
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-17T07:39:42.549Z 
thumbnail: https://img-global.cpcdn.com/recipes/bd0264b093dfe264/682x484cq65/nasi-daun-jeruk-rice-cooker-tanpa-santan-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/bd0264b093dfe264/682x484cq65/nasi-daun-jeruk-rice-cooker-tanpa-santan-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/bd0264b093dfe264/682x484cq65/nasi-daun-jeruk-rice-cooker-tanpa-santan-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/bd0264b093dfe264/682x484cq65/nasi-daun-jeruk-rice-cooker-tanpa-santan-foto-resep-utama.webp
author: Samuel Campbell
ratingvalue: 3.5
reviewcount: 12
recipeingredient:
- "beras 3 cangkir"
- "bawang putih 4 siung"
- "daun jeruk 10-15 lembar"
- "daun salam 2 lembar"
- "sereh 1 batang"
- "kaldu jamur 2 sendok teh"
recipeinstructions:
- "Geprek bawang putih sampai hancur agar rasanya lebih keluar, Dihancurkan dengan chopper atau diiris juga boleh tapi saya lebih suka digeprek agar rasa dan wanginya lebih keluar. Iris kecil daun jeruk yang sudah diambil batangnya dan geprek sereh"
- "Tumis semua bumbu sampai harum, usahakan bawang putih jangan terlalu gosong"
- "Cuci beras seperti biasa dan masukkan air ke berasa seperti biasanya. Setelah itu bumbu yang sudah ditumis dimasukkan ke beras yang sudah dicuci dan aduk. Beri kaldu jamur secukupnya, dirasa sedikit airnya jika sudah cukup beras bisa langsung dimasak"
- "Setelah jadi nasi wangi banget dan gurih 😍"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 119 calories
recipecuisine: Indonesian
preptime: "PT36M"
cooktime: "PT31M"
recipeyield: "1"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi daun jeruk rice cooker tanpa santan](https://img-global.cpcdn.com/recipes/bd0264b093dfe264/682x484cq65/nasi-daun-jeruk-rice-cooker-tanpa-santan-foto-resep-utama.webp)

4 langkah mudah mengolah  Nasi daun jeruk rice cooker tanpa santan cocok sekali jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Dalam Pembuatan Nasi daun jeruk rice cooker tanpa santan:

1. beras 3 cangkir
1. bawang putih 4 siung
1. daun jeruk 10-15 lembar
1. daun salam 2 lembar
1. sereh 1 batang
1. kaldu jamur 2 sendok teh

Nasi Uduk Rice Cooker tanpa SantanПодробнее. Resep Nasi uduk rice cooker tanpa santan. Nasi Liwet Rice cooker Tanpa santan super gampangПодробнее. Nasi daun jeruk ini termasuk ke dalam variasi masakan nasi berbumbu. 

<!--inarticleads2-->

## Cara Menyiapkan Nasi daun jeruk rice cooker tanpa santan:

1. Geprek bawang putih sampai hancur agar rasanya lebih keluar, Dihancurkan dengan chopper atau diiris juga boleh tapi saya lebih suka digeprek agar rasa dan wanginya lebih keluar. Iris kecil daun jeruk yang sudah diambil batangnya dan geprek sereh
1. Tumis semua bumbu sampai harum, usahakan bawang putih jangan terlalu gosong
1. Cuci beras seperti biasa dan masukkan air ke berasa seperti biasanya. Setelah itu bumbu yang sudah ditumis dimasukkan ke beras yang sudah dicuci dan aduk. Beri kaldu jamur secukupnya, dirasa sedikit airnya jika sudah cukup beras bisa langsung dimasak
1. Setelah jadi nasi wangi banget dan gurih 😍


Bumbu-bumbu yan digunakan sebagai bahannya tidak banyak, hanya santan, daun salam, serai, dan Cara memasak nasi daun jeruk ini terbilang praktis, kamu bisa masak nasi daun jeruk dengan rice cooker atau magic com. Penanak nasi (rice cooker) adalah pilihan yang mudah dan efektif digunakan untuk memasak nasi. Saat ini, ada banyak penanak nasi yang dilengkapi Memasukkan kembali nasi yang kurang matang ke penanak nasi tanpa menambahkan air yang cukup untuk merendamnya dapat menyebabkan nasi. Resep nasi daun jeruk ternyata dapat dibuat dengan mudah di rumah. Nasi daun jeruk kini menjadi salah satu makanan hits yang digemari banyak orang. 

Terima kasih telah membaca resep yang tim kami tampilkan di sini. Selamat mencoba!
