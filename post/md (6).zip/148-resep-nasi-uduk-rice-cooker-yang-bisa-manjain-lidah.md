---
description: "Resep Nasi uduk rice cooker yang Bisa Manjain Lidah"
title: "Resep Nasi uduk rice cooker yang Bisa Manjain Lidah"
slug: 148-resep-nasi-uduk-rice-cooker-yang-bisa-manjain-lidah
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-18T17:50:42.696Z 
thumbnail: https://img-global.cpcdn.com/recipes/d1468cc61dc0650a/682x484cq65/nasi-uduk-rice-cooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/d1468cc61dc0650a/682x484cq65/nasi-uduk-rice-cooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/d1468cc61dc0650a/682x484cq65/nasi-uduk-rice-cooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/d1468cc61dc0650a/682x484cq65/nasi-uduk-rice-cooker-foto-resep-utama.webp
author: Melvin Meyer
ratingvalue: 3.4
reviewcount: 11
recipeingredient:
- "beras yg sdh di cuci bersih 1 lt"
- "santan kara 65ml 2 bh"
- "sereh geprek 2 tangkai"
- "daun salam 2 lembar"
- "daun jeruk sobek 3 lembar"
- "lengkuas irisgeprek 1 ruas jari"
- "garam disesuaikan dgn selera masing 2-3 sdt"
- "air seperti masak nasi biasa Secukupnya"
recipeinstructions:
- "Cuci bersih beras,lalu masukkan kedalam rice cooker"
- "Masukkan air,santan dan garam lalu aduk²,icip rasa ya"
- "Lalu masukkan lengkuas,sereh,daun salam dan daun jeruk"
- "Masak hingga matang,bila sdh matang aduk² rata lalu tutup kembali rice cookernya diamkan sesaat agar lebih tanak matang sempurna"
- "Teman²nya nasi uduk....selamat mencoba"
categories:
- Resep
tags:
- nasi
- uduk
- rice

katakunci: nasi uduk rice 
nutrition: 267 calories
recipecuisine: Indonesian
preptime: "PT19M"
cooktime: "PT31M"
recipeyield: "2"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi uduk rice cooker](https://img-global.cpcdn.com/recipes/d1468cc61dc0650a/682x484cq65/nasi-uduk-rice-cooker-foto-resep-utama.webp)

Ingin membuat Nasi uduk rice cooker ? Coba resep berikut ini. Cara memasaknya sangat praktis namun jangan kaget jika hasilnya gurih dan lezat cocok banget jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Untuk Menyiapkan Nasi uduk rice cooker:

1. beras yg sdh di cuci bersih 1 lt
1. santan kara 65ml 2 bh
1. sereh geprek 2 tangkai
1. daun salam 2 lembar
1. daun jeruk sobek 3 lembar
1. lengkuas irisgeprek 1 ruas jari
1. garam disesuaikan dgn selera masing 2-3 sdt
1. air seperti masak nasi biasa Secukupnya

Selain dengan rice cooker, nasi uduk juga bisa dibuat menggunakan magic com. Baca episode terbaru Senior, Bekalmu! di LINE WEBTOON, gratis! Masak nasi uduk kian praktis karena bisa menggunakan rice cooker. Kamu hanya perlu mencuci beras seperti biasa dan menumis bumbu untuk memberi rasa serta aroma pada beras yang dimasak. 

<!--inarticleads2-->

## Tata Cara Membuat Nasi uduk rice cooker:

1. Cuci bersih beras,lalu masukkan kedalam rice cooker
1. Masukkan air,santan dan garam lalu aduk²,icip rasa ya
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/208c7f95bff20cf4/160x128cq70/nasi-uduk-rice-cooker-langkah-memasak-2-foto.webp" alt="Nasi uduk rice cooker" width="340" height="340">
>1. Lalu masukkan lengkuas,sereh,daun salam dan daun jeruk
1. Masak hingga matang,bila sdh matang aduk² rata lalu tutup kembali rice cookernya diamkan sesaat agar lebih tanak matang sempurna
1. Teman²nya nasi uduk....selamat mencoba


Sisanya, siapkan lauk untuk nasi uduk seperti dadar telur, bihun goreng, dan kering tempe. Nasi Uduk Rice Cooker - Dari semua nasi-nasian khas Indonesia yang paling sering dimasak ya ini, &#34;Nasi Uduk Betawi&#34;. Hasil dari olahan resep nasi uduk rice cooker ini menurut saya memang sedikit berair dibandingkan nasi uduk yang dimasak manual dengan cara dikukus. To make Nasi Uduk, rice is cooked in coconut milk, which gives it a rich and creamy texture. Aromatic lemongrass and salam leaves are added during To make Nasi Uduk, all you need to do is throw the ingredients into a rice cooker or pan. 

Terima kasih telah membaca resep yang tim kami tampilkan di sini. Selamat mencoba!
