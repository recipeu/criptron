---
description: "Langkah Mudah untuk Membuat Nasi bakar ayam suir pedas Anti Gagal"
title: "Langkah Mudah untuk Membuat Nasi bakar ayam suir pedas Anti Gagal"
slug: 427-langkah-mudah-untuk-membuat-nasi-bakar-ayam-suir-pedas-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-09T20:39:56.203Z 
thumbnail: https://img-global.cpcdn.com/recipes/090c14bb4e96fbfb/682x484cq65/nasi-bakar-ayam-suir-pedas-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/090c14bb4e96fbfb/682x484cq65/nasi-bakar-ayam-suir-pedas-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/090c14bb4e96fbfb/682x484cq65/nasi-bakar-ayam-suir-pedas-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/090c14bb4e96fbfb/682x484cq65/nasi-bakar-ayam-suir-pedas-foto-resep-utama.webp
author: Ola Byrd
ratingvalue: 3.3
reviewcount: 4
recipeingredient:
- "nasi sisa semalam yang masih bagus Secukupnya"
- "ayam rebus suir 250 gr"
- "Bumbu halus "
- "bawang putih 3 siung"
- "bawang merah 4 siung"
- "cabai merah 3 buah"
- "Beberapa cabai rawit merah optional "
- "Bumbu pelengkap "
- "lengkuas 1 cm"
- "daun salam 3 lembar"
- "daun jeruk 2 lembar"
- "bawang putih bubuk 2 sdt"
- "garam kaldu ayam dan sedikit gula pasir Secukupnya"
- "Alat bungkus "
- "Daun pisang yg sudah dilemaskan bakarjemur "
recipeinstructions:
- "Masukan garam, kaldu ayam dan bawang putih bubuk kedalam nasi. Aduk merata"
- "Haluskan bumbu halus"
- "Siapkan wajan beri sedikit minyak, nyalakan api kompor (sedang). Masukan bumbu halus bersama dengan lengkuas, daun salam dan daun jeruk. Tumis sampai harum. Lalu masukan jg secukupnya garam, kaldu ayam dan gulpas."
- "Masukan ayam suirnya, aduk merata sampai matang dan koreksi rasa. Lalu angkat dan tiriskan"
- "Siapkan daun pisang, lalu lemaskan agar tidak mudah robek. Tata nasi diatas daun pisang, masukan ayam diatas nasi. Lalu gulung dan rapikan sesuai selera           (lihat resep)"
- "Jika semua sudah selesai, siapkan teflon yg diolesi sedikit mentega, masukan nasi bakar keatasnya. Panggang hingga harum dan tekstur daun pisang kering. Bolak balik agar merata"
- "Nasi bakar ayam suir siap disajikan"
categories:
- Resep
tags:
- nasi
- bakar
- ayam

katakunci: nasi bakar ayam 
nutrition: 254 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT52M"
recipeyield: "4"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi bakar ayam suir pedas](https://img-global.cpcdn.com/recipes/090c14bb4e96fbfb/682x484cq65/nasi-bakar-ayam-suir-pedas-foto-resep-utama.webp)

Resep Nasi bakar ayam suir pedas    dengan 7 langkahcepat cocok banget jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Dalam Pembuatan Nasi bakar ayam suir pedas:

1. nasi sisa semalam yang masih bagus Secukupnya
1. ayam rebus suir 250 gr
1. Bumbu halus 
1. bawang putih 3 siung
1. bawang merah 4 siung
1. cabai merah 3 buah
1. Beberapa cabai rawit merah optional 
1. Bumbu pelengkap 
1. lengkuas 1 cm
1. daun salam 3 lembar
1. daun jeruk 2 lembar
1. bawang putih bubuk 2 sdt
1. garam kaldu ayam dan sedikit gula pasir Secukupnya
1. Alat bungkus 
1. Daun pisang yg sudah dilemaskan bakarjemur 

Salah satunya adalah tumis tuna pedas. Aroma harum daun pisang berpadu rasa tuna yang pedas-gurih bikin ingin nambah. Sajikan ayam bakar kecap dengan nasi hangat lengkap dengan sambal pedas dan juga lalaban seperti potongan mentimun, daun kemangi, kol dan juga leunca jika suka. Walaupun saat ini ada banyak olahan masakan ayam yang lezat seperti Ayam Goreng Saus Mentega, Ayam Bekakak Khas. 

<!--inarticleads2-->

## Tata Cara Membuat Nasi bakar ayam suir pedas:

1. Masukan garam, kaldu ayam dan bawang putih bubuk kedalam nasi. Aduk merata
1. Haluskan bumbu halus
1. Siapkan wajan beri sedikit minyak, nyalakan api kompor (sedang). Masukan bumbu halus bersama dengan lengkuas, daun salam dan daun jeruk. Tumis sampai harum. Lalu masukan jg secukupnya garam, kaldu ayam dan gulpas.
1. Masukan ayam suirnya, aduk merata sampai matang dan koreksi rasa. Lalu angkat dan tiriskan
1. Siapkan daun pisang, lalu lemaskan agar tidak mudah robek. Tata nasi diatas daun pisang, masukan ayam diatas nasi. Lalu gulung dan rapikan sesuai selera -           (lihat resep)
1. Jika semua sudah selesai, siapkan teflon yg diolesi sedikit mentega, masukan nasi bakar keatasnya. Panggang hingga harum dan tekstur daun pisang kering. Bolak balik agar merata
1. Nasi bakar ayam suir siap disajikan


Nasi bakar ayam dari dahulu kala adalah santapan yang menggiurkan saat makan siang. Baik bersama rekan kantor yang tengah merayakan ulang tahun ataupun ketika bersantap bersama keluarga, nasi bakar ayam yang gurih, pedas, dan bercampur dengan rasa segar herba serta cita. Tutug oncom juga sangat cocok dipadukan dengan nasi bakar. Ayam bakar bumbu rujak merupakan salah satu masakan yang mempunyai cita rasa khas pedas manis. Rasa nasi bakar tetap lezat, bahkan teksturnya lebih gurih serta menyehatkan. 

Daripada kamu beli  Nasi bakar ayam suir pedas  diluar terus, kamu  bisa membuatnya sendiri dirumah. Resep  Nasi bakar ayam suir pedas  sederhana ini cukup praktis dalam proses pembuatannya, serta cukup menggunakan bumbu sederhana  Nasi bakar ayam suir pedas  yang enak, bunda nikmati di rumah.
