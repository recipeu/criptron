---
description: "Bagaimana Membuat Nasi Uduk (Asli Betawi), Enak Banget"
title: "Bagaimana Membuat Nasi Uduk (Asli Betawi), Enak Banget"
slug: 105-bagaimana-membuat-nasi-uduk-asli-betawi-enak-banget
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-18T11:49:45.301Z 
thumbnail: https://img-global.cpcdn.com/recipes/e05ac8bef8c39eb7/682x484cq65/nasi-uduk-asli-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/e05ac8bef8c39eb7/682x484cq65/nasi-uduk-asli-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/e05ac8bef8c39eb7/682x484cq65/nasi-uduk-asli-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/e05ac8bef8c39eb7/682x484cq65/nasi-uduk-asli-betawi-foto-resep-utama.webp
author: Vera Fletcher
ratingvalue: 3
reviewcount: 9
recipeingredient:
- "Beras premium 4 mug"
- "Santan yg isi 65ml 1 saccet"
- "Sereh  geprek lalu ikat simpul 1 batang"
- "Daun Pandan  sobek2 lalu ikat simpul 3 lmbr"
- "Daun Salam 3 lmbr"
- "Masako rasa dgsapi 1 saccet"
- "Garam secukupnya"
- "Bumbu haluskan "
- "Bawang merah 5 siung"
- "kencur 1 ruas"
recipeinstructions:
- "Cuci bersih beras lalu masukkan santan saccet dan air masak secukupnya, ukur air seperti kita masak nasi biasanya lalu aduk rata dan nyalakan api kompor. Masukkan bumbu halus, bahan bumbu seperti sereh, daun salam, daun pandan. Aduk rata lalu tambahkan masako rasa sapi dan garam test rasanya (jangan takut keasinan biasanya kalo dah matang yg td kita rasa cukup asin pas masih beras blm nyerap air trnyata dah jd nasi jd kurang gurih). Aduk sesekali ya moms."
- "Setelah mulai mendidih jgn ditinggal aduk sesekali dgn api sedang ya moms kali sudah mulai meletup-letup matikan api kompor lalu angkat dan isi ke magic com atau rice cooker, nyalakan tombol masak dan tunggu sampai tombol jd hijau alias sdh matang selesai masak jangan langsung buka loh nunggu 5 menit baru buka ya."
- "Dah matang dibuka gitu wangiiii nasi uduknya...hmm...yummy rasa gurih and wangi jd makin lahap makannya dengan bawang goreng, lauk sambal dan tempe tepung aja dah mantep apalagi menu lengkap seperti Ayam bumbu bali/Ayam goreng ungkep, oreg tempe, telur dadar, sambal goreng kentang buncis, mie goreng dan sambal khusus nasi uduk...maknyooos 😋😋👍🏻👍🏻😄😄"
categories:
- Resep
tags:
- nasi
- uduk
- asli

katakunci: nasi uduk asli 
nutrition: 149 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT31M"
recipeyield: "4"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk (Asli Betawi)](https://img-global.cpcdn.com/recipes/e05ac8bef8c39eb7/682x484cq65/nasi-uduk-asli-betawi-foto-resep-utama.webp)

3 langkah cepat membuat  Nasi Uduk (Asli Betawi) yang harus kamu coba segera

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Dalam Pembuatan Nasi Uduk (Asli Betawi):

1. Beras premium 4 mug
1. Santan yg isi 65ml 1 saccet
1. Sereh  geprek lalu ikat simpul 1 batang
1. Daun Pandan  sobek2 lalu ikat simpul 3 lmbr
1. Daun Salam 3 lmbr
1. Masako rasa dgsapi 1 saccet
1. Garam secukupnya
1. Bumbu haluskan 
1. Bawang merah 5 siung
1. kencur 1 ruas



<!--inarticleads2-->

## Langkah-langkah Untuk Menyiapkan Nasi Uduk (Asli Betawi):

1. Cuci bersih beras lalu masukkan santan saccet dan air masak secukupnya, ukur air seperti kita masak nasi biasanya lalu aduk rata dan nyalakan api kompor. Masukkan bumbu halus, bahan bumbu seperti sereh, daun salam, daun pandan. Aduk rata lalu tambahkan masako rasa sapi dan garam test rasanya (jangan takut keasinan biasanya kalo dah matang yg td kita rasa cukup asin pas masih beras blm nyerap air trnyata dah jd nasi jd kurang gurih). Aduk sesekali ya moms.
1. Setelah mulai mendidih jgn ditinggal aduk sesekali dgn api sedang ya moms kali sudah mulai meletup-letup matikan api kompor lalu angkat dan isi ke magic com atau rice cooker, nyalakan tombol masak dan tunggu sampai tombol jd hijau alias sdh matang selesai masak jangan langsung buka loh nunggu 5 menit baru buka ya.
1. Dah matang dibuka gitu wangiiii nasi uduknya...hmm...yummy rasa gurih and wangi jd makin lahap makannya dengan bawang goreng, lauk sambal dan tempe tepung aja dah mantep apalagi menu lengkap seperti Ayam bumbu bali/Ayam goreng ungkep, oreg tempe, telur dadar, sambal goreng kentang buncis, mie goreng dan sambal khusus nasi uduk...maknyooos 😋😋👍🏻👍🏻😄😄




Daripada ibu beli  Nasi Uduk (Asli Betawi)  diluar terus, kamu  bisa membuatnya sendiri dirumah. Resep  Nasi Uduk (Asli Betawi)  sederhana ini cukup praktis pembuatannya, cukup menggunakan bumbu-bumbu sederhana yang ada di dapur  Nasi Uduk (Asli Betawi)  yang enak, ibu nikmati di rumah.
