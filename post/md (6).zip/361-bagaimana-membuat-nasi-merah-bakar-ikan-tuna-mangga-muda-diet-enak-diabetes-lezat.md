---
description: "Bagaimana Membuat Nasi Merah Bakar Ikan Tuna Mangga Muda (Diet Enak Diabetes), Lezat"
title: "Bagaimana Membuat Nasi Merah Bakar Ikan Tuna Mangga Muda (Diet Enak Diabetes), Lezat"
slug: 361-bagaimana-membuat-nasi-merah-bakar-ikan-tuna-mangga-muda-diet-enak-diabetes-lezat
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-23T23:40:14.631Z 
thumbnail: https://img-global.cpcdn.com/recipes/e068bf7dc2437d48/682x484cq65/nasi-merah-bakar-ikan-tuna-mangga-muda-diet-enak-diabetes-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/e068bf7dc2437d48/682x484cq65/nasi-merah-bakar-ikan-tuna-mangga-muda-diet-enak-diabetes-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/e068bf7dc2437d48/682x484cq65/nasi-merah-bakar-ikan-tuna-mangga-muda-diet-enak-diabetes-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/e068bf7dc2437d48/682x484cq65/nasi-merah-bakar-ikan-tuna-mangga-muda-diet-enak-diabetes-foto-resep-utama.webp
author: Ora Rogers
ratingvalue: 3.8
reviewcount: 11
recipeingredient:
- "nasi merah matang 3-4 porsi"
- "ikan tuna segar 350 gr"
- "mangga muda 1 buah"
- "cabe merah besar 4 buah"
- "bawang merah 10 siung"
- "daun jeruk purut 3 lembar"
- "cabe rawit 20 buah"
- "bawang putih 4 siung"
- "minyak goreng 1 sdm"
- "air 1 gelas"
- "garam dan merica Secukupnya"
- "gula diabtx 1 sachet"
- "daun pisang Secukupnya"
recipeinstructions:
- "Cuci bersih dan potong2 tuna."
- "Kupas dan serut mangga muda."
- "Haluskan cabe merah besar (buang bijinya) dan bawang merah."
- "Buang tangkainya cabe rawit. Klo suka pedas, cabe rawit bisa ditumbuk kasar."
- "Tumbuk bawang putih."
- "Panaskan minyak, tumis bawang putih hingga harum dan agak kering."
- "Masukkan bumbu halus, cabe rawit dan daun jeruk purut."
- "Tumis hingga harum dan bau langu hilang."
- "Masukkan ikan tuna. Aduk2 hingga berubah warna."
- "Tuangi air. Tunggu hingga mendidih."
- "Beri garam, merica dan gula diabtx. Tes rasa. Masak hingga kesat. Matikan api."
- "Siapkan wadah yang agak besar. Taruh nasi merah. Tambahkan tumisan tuna."
- "Masukkan mangga serut."
- "Buat campuran nasi merah, tumisan tuna dan mangga serut dengan komposisi yang seimbang/sesuai selera. Aduk rata."
- "Siapkan daun pisang. Taruh beberapa sendok campuran nasi merah di atas. Lalu gulung, semat ujungnya dengan tusuk gigi."
- "Bakar di atas api. Saya pakai tutup panci yang saya buat khusus untuk memanggang. Tutup agar panasnya menyebar rata."
- "Bakar hingga agak2 gosong daun pisangnya. Hmmm..wanginya menguarrr 😙😙"
- "Taraaa...! Jadi dehhh nasi bakar spesial yang sehat dan aman untuk penderita diabetes."
categories:
- Resep
tags:
- nasi
- merah
- bakar

katakunci: nasi merah bakar 
nutrition: 229 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT57M"
recipeyield: "3"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Merah Bakar Ikan Tuna Mangga Muda (Diet Enak Diabetes)](https://img-global.cpcdn.com/recipes/e068bf7dc2437d48/682x484cq65/nasi-merah-bakar-ikan-tuna-mangga-muda-diet-enak-diabetes-foto-resep-utama.webp)

Resep Nasi Merah Bakar Ikan Tuna Mangga Muda (Diet Enak Diabetes)    dengan 18 langkahmudah cocok sekali jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Dalam Pembuatan Nasi Merah Bakar Ikan Tuna Mangga Muda (Diet Enak Diabetes):

1. nasi merah matang 3-4 porsi
1. ikan tuna segar 350 gr
1. mangga muda 1 buah
1. cabe merah besar 4 buah
1. bawang merah 10 siung
1. daun jeruk purut 3 lembar
1. cabe rawit 20 buah
1. bawang putih 4 siung
1. minyak goreng 1 sdm
1. air 1 gelas
1. garam dan merica Secukupnya
1. gula diabtx 1 sachet
1. daun pisang Secukupnya



<!--inarticleads2-->

## Cara Mudah Membuat Nasi Merah Bakar Ikan Tuna Mangga Muda (Diet Enak Diabetes):

1. Cuci bersih dan potong2 tuna.
1. Kupas dan serut mangga muda.
1. Haluskan cabe merah besar (buang bijinya) dan bawang merah.
1. Buang tangkainya cabe rawit. Klo suka pedas, cabe rawit bisa ditumbuk kasar.
1. Tumbuk bawang putih.
1. Panaskan minyak, tumis bawang putih hingga harum dan agak kering.
1. Masukkan bumbu halus, cabe rawit dan daun jeruk purut.
1. Tumis hingga harum dan bau langu hilang.
1. Masukkan ikan tuna. Aduk2 hingga berubah warna.
1. Tuangi air. Tunggu hingga mendidih.
1. Beri garam, merica dan gula diabtx. Tes rasa. Masak hingga kesat. Matikan api.
1. Siapkan wadah yang agak besar. Taruh nasi merah. Tambahkan tumisan tuna.
1. Masukkan mangga serut.
1. Buat campuran nasi merah, tumisan tuna dan mangga serut dengan komposisi yang seimbang/sesuai selera. Aduk rata.
1. Siapkan daun pisang. Taruh beberapa sendok campuran nasi merah di atas. Lalu gulung, semat ujungnya dengan tusuk gigi.
1. Bakar di atas api. Saya pakai tutup panci yang saya buat khusus untuk memanggang. Tutup agar panasnya menyebar rata.
1. Bakar hingga agak2 gosong daun pisangnya. Hmmm..wanginya menguarrr 😙😙
1. Taraaa...! Jadi dehhh nasi bakar spesial yang sehat dan aman untuk penderita diabetes.




Selamat memasak dan menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
