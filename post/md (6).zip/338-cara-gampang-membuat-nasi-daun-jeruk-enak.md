---
description: "Cara Gampang Membuat Nasi Daun Jeruk, Enak"
title: "Cara Gampang Membuat Nasi Daun Jeruk, Enak"
slug: 338-cara-gampang-membuat-nasi-daun-jeruk-enak
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-24T07:29:14.053Z 
thumbnail: https://img-global.cpcdn.com/recipes/97c94ba68f419063/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/97c94ba68f419063/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/97c94ba68f419063/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/97c94ba68f419063/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
author: Mittie Thompson
ratingvalue: 4.7
reviewcount: 10
recipeingredient:
- "beras pandan wangi 4 cup"
- "santan kara 100 ml"
- "Garam secukupnya"
- "Kaldu jamur secukupnya"
- "daun jeruk buang tulangnya 4 lbr"
- "daun salam 2 lbr"
- "sereh geprek 1"
- "Bahan tambahan  "
- "daun jeruk buang tulangnya dan iris tipis tipis 10 lembar"
- "b "
recipeinstructions:
- "Cuci beras sampai bersih,lalu masukkan santan,garam, daun jeruk, daun salam dan sereh. Tambahkan air dgn takaran seperti saat kita menanak nasi."
- "Masak dengan menggunakan rice cooker sampai matang"
- "Setelah lampu rice cooker dari cook menjadi warm, ambil dan keluarkan daun salam,daun jeruk dan sereh."
- "Masukkan daun jeruknyg sudah diiris aduk rqta menggunakan sendok nasi. Lalu tutup kembali rice cooker."
- "Setelah 10 menit nasi daun jeruk siap dinikmati, sajikan dengan orek tempe teri dan juga tumis sei sapi 👌 yummy ⚘. Resep orek tempe teri dan juga tumis sei sapi ala MD saya tulis di resep terpisah ya moms."
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 272 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT51M"
recipeyield: "3"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk](https://img-global.cpcdn.com/recipes/97c94ba68f419063/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp)

Resep rahasia Nasi Daun Jeruk  anti gagal dengan 5 langkahcepat dan mudah yang harus bunda coba segera

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Dalam Pembuatan Nasi Daun Jeruk:

1. beras pandan wangi 4 cup
1. santan kara 100 ml
1. Garam secukupnya
1. Kaldu jamur secukupnya
1. daun jeruk buang tulangnya 4 lbr
1. daun salam 2 lbr
1. sereh geprek 1
1. Bahan tambahan  
1. daun jeruk buang tulangnya dan iris tipis tipis 10 lembar
1. b 

Nasi daun jeruk siap dihidangkan dengan. Nasi daun jeruk ini memang sedang tren di kalangan masyarakat Indonesia, banyak sekali kaum muda mudi yang berlomba-lomba membuat makanan nasi putih spesial ini. Nasi daun jeruk ala geprek bensu rekomended buat di coba. Geprek bensu nasi daun jeruk anti mainst. 

<!--inarticleads2-->

## Cara Mudah Membuat Nasi Daun Jeruk:

1. Cuci beras sampai bersih,lalu masukkan santan,garam, daun jeruk, daun salam dan sereh. Tambahkan air dgn takaran seperti saat kita menanak nasi.
1. Masak dengan menggunakan rice cooker sampai matang
1. Setelah lampu rice cooker dari cook menjadi warm, ambil dan keluarkan daun salam,daun jeruk dan sereh.
1. Masukkan daun jeruknyg sudah diiris aduk rqta menggunakan sendok nasi. Lalu tutup kembali rice cooker.
1. Setelah 10 menit nasi daun jeruk siap dinikmati, sajikan dengan orek tempe teri dan juga tumis sei sapi 👌 yummy ⚘. Resep orek tempe teri dan juga tumis sei sapi ala MD saya tulis di resep terpisah ya moms.


Gurih dan wangi dari daun jeruk menambah kelezatan nasi daun jeruk. Nasi dengan campuran daun jeruk yang wangi sedang tren. Hai selamat pagi sahabat CWS, pagi ini saya share resep Nasi Daun Jeruk. Praktis banget karena saya gunakan rice cooker. Rasanya mirip nasi uduk tapi wangiiii. 

Selamat memasak dan menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
