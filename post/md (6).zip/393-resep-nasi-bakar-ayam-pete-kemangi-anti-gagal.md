---
description: "Resep Nasi Bakar Ayam, Pete, kemangi Anti Gagal"
title: "Resep Nasi Bakar Ayam, Pete, kemangi Anti Gagal"
slug: 393-resep-nasi-bakar-ayam-pete-kemangi-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-10T23:43:34.431Z 
thumbnail: https://img-global.cpcdn.com/recipes/a33cc13a16d37587/682x484cq65/nasi-bakar-ayam-pete-kemangi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/a33cc13a16d37587/682x484cq65/nasi-bakar-ayam-pete-kemangi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/a33cc13a16d37587/682x484cq65/nasi-bakar-ayam-pete-kemangi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/a33cc13a16d37587/682x484cq65/nasi-bakar-ayam-pete-kemangi-foto-resep-utama.webp
author: Gregory Watson
ratingvalue: 3.7
reviewcount: 4
recipeingredient:
- "Bahan Nasi "
- "beras 2.5 cup"
- "santan kara 65 gr"
- "air sesuaikan dengan takaran masak biasanya 4 cup"
- "bawang merah haluskan 5"
- "serai geprek 1 batang"
- "daun pandan simpulkan 1"
- "daun jeruk 3 lembar"
- "daun salam 3 lembar"
- "garam secukupnya"
- "Bahan Ayam Suwir "
- "fillet ayam rebus lalu suwir2 250 gr"
- "kecap 1 sdm"
- "garam gula lada secukupnya"
- "lengkuas geprek 1 ruas"
- "serai geprek 1 batang"
- "daun jeruk 2 lembar"
- "daun salam 2 lembar"
- "air secukupnya"
- "Bumbu Halus "
- "cabai merah besar atau keriting 5"
- "cabai rawit secukupnya"
- "bawang merah 5"
- "bawang putih 5 siung"
- "kemiri sangrai 2 buah"
- "jahe kunyit secukupnya"
- "daun kemangi secukupnya"
- "pete bisa skip kalau tidak suka secukupnya"
- "Bahan Lainnya "
- "daun pisang secukupnya"
recipeinstructions:
- "Nasi: - Tumis Bawang merah dan bumbu lainnya hingga harum. - Tambahkan air plus santan. Aduk rata. - Cuci beras, masukkan ke rice cooker. Tambahkan campuran air dan bumbu tadi. Masak nasi seperti biasa."
- "Ayam suwir: - Tumis bumbu halus bersama serai, lengkuas, daun jeruk, daun salam sampai harum. - Tambahkan sedikit air. Lalu masukkan ayam suwir dan pete.  - Masukkan gula, garam, lada dan kecap manis."
- "Masak hingga bumbu meresap dan air menyusut cenderung kering. Sebelum diangkat masukkan kemangi. Aduk sebentar, angkat."
- "Ambil nasi dan campur dengan ayam suwir. Setelah itu ambil campuran nasi dan ayam secukupnya, taruh di atas daun pisan. Gulung dan sematkan ujung-ujungnya dengan tusuk gigi."
- "Kukus kurleb 10 menit lalu panggang sebentar di atas teflon. Bisa juga langsung panggang. Sesuai selera. Sajikan hangat"
categories:
- Resep
tags:
- nasi
- bakar
- ayam

katakunci: nasi bakar ayam 
nutrition: 167 calories
recipecuisine: Indonesian
preptime: "PT19M"
cooktime: "PT38M"
recipeyield: "3"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Bakar Ayam, Pete, kemangi](https://img-global.cpcdn.com/recipes/a33cc13a16d37587/682x484cq65/nasi-bakar-ayam-pete-kemangi-foto-resep-utama.webp)

Ingin membuat Nasi Bakar Ayam, Pete, kemangi ? Coba resep berikut ini. Cara memasaknya sangat praktis namun hasilnya gurih dan lezat cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Dibutuhkan Untuk Menyiapkan Nasi Bakar Ayam, Pete, kemangi:

1. Bahan Nasi 
1. beras 2.5 cup
1. santan kara 65 gr
1. air sesuaikan dengan takaran masak biasanya 4 cup
1. bawang merah haluskan 5
1. serai geprek 1 batang
1. daun pandan simpulkan 1
1. daun jeruk 3 lembar
1. daun salam 3 lembar
1. garam secukupnya
1. Bahan Ayam Suwir 
1. fillet ayam rebus lalu suwir2 250 gr
1. kecap 1 sdm
1. garam gula lada secukupnya
1. lengkuas geprek 1 ruas
1. serai geprek 1 batang
1. daun jeruk 2 lembar
1. daun salam 2 lembar
1. air secukupnya
1. Bumbu Halus 
1. cabai merah besar atau keriting 5
1. cabai rawit secukupnya
1. bawang merah 5
1. bawang putih 5 siung
1. kemiri sangrai 2 buah
1. jahe kunyit secukupnya
1. daun kemangi secukupnya
1. pete bisa skip kalau tidak suka secukupnya
1. Bahan Lainnya 
1. daun pisang secukupnya



<!--inarticleads2-->

## Langkah-langkah Untuk Membuat Nasi Bakar Ayam, Pete, kemangi:

1. Nasi: - - Tumis Bawang merah dan bumbu lainnya hingga harum. - - Tambahkan air plus santan. Aduk rata. - - Cuci beras, masukkan ke rice cooker. Tambahkan campuran air dan bumbu tadi. Masak nasi seperti biasa.
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/62d79600b54d0e6a/160x128cq70/nasi-bakar-ayam-pete-kemangi-langkah-memasak-1-foto.webp" alt="Nasi Bakar Ayam, Pete, kemangi" width="340" height="340">
><img class="lazyload" data-src="https://img-global.cpcdn.com/steps/212086fbcbe401f1/160x128cq70/nasi-bakar-ayam-pete-kemangi-langkah-memasak-1-foto.webp" alt="Nasi Bakar Ayam, Pete, kemangi" width="340" height="340">
>1. Ayam suwir: - - Tumis bumbu halus bersama serai, lengkuas, daun jeruk, daun salam sampai harum. - - Tambahkan sedikit air. Lalu masukkan ayam suwir dan pete.  - - Masukkan gula, garam, lada dan kecap manis.
1. Masak hingga bumbu meresap dan air menyusut cenderung kering. Sebelum diangkat masukkan kemangi. Aduk sebentar, angkat.
1. Ambil nasi dan campur dengan ayam suwir. Setelah itu ambil campuran nasi dan ayam secukupnya, taruh di atas daun pisan. Gulung dan sematkan ujung-ujungnya dengan tusuk gigi.
1. Kukus kurleb 10 menit lalu panggang sebentar di atas teflon. Bisa juga langsung panggang. Sesuai selera. Sajikan hangat




Terima kasih telah membaca resep yang kami tampilkan di halaman ini. Selamat mencoba!
