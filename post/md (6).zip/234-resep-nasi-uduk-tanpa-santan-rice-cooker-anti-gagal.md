---
description: "Resep Nasi uduk tanpa santan rice cooker Anti Gagal"
title: "Resep Nasi uduk tanpa santan rice cooker Anti Gagal"
slug: 234-resep-nasi-uduk-tanpa-santan-rice-cooker-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2022-01-07T09:13:43.777Z 
thumbnail: https://img-global.cpcdn.com/recipes/73e78ddc70bb66eb/682x484cq65/nasi-uduk-tanpa-santan-rice-cooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/73e78ddc70bb66eb/682x484cq65/nasi-uduk-tanpa-santan-rice-cooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/73e78ddc70bb66eb/682x484cq65/nasi-uduk-tanpa-santan-rice-cooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/73e78ddc70bb66eb/682x484cq65/nasi-uduk-tanpa-santan-rice-cooker-foto-resep-utama.webp
author: Mittie Jennings
ratingvalue: 3.5
reviewcount: 15
recipeingredient:
- "Beras 2 cup"
- "Ikan panjelanaq beli 2ribu "
- "bawang merah 4 siung"
- "bawang putih 2 siung"
- "daun salam 2 lembar"
- "daun jeruk 3 lembar"
- "lengkuas 1 ruas"
- "jahe 1 ruas"
- "sereh 1 batang"
- "Garam secukupnya"
- "Micin secukupnyaaq pake bio miwon "
- "roycorasa ayam secukupnya"
- "Minyak goreng secukupnya"
recipeinstructions:
- "Cuci bersih beras"
- "Iris bawang merah dan bawang putih"
- "Cuci daun salam,daun jeruk,sereh,lengkuas dan jahe"
- "Geprek sereh, lengkuas, dan jahe"
- "Panaskan minyak goreng lalu masukan irisan bawang merah,bawang putih,daun salam,daun jeruk,sereh,lengkuas,dan jahe tumis hingga harum lalu tiriskan"
- "Lalu goreng ikan panjelan setengah matang lalu tiriskan"
- "Masukan beras beri air secukupnya kedalam rice cooker lalu beri garam secukupnya,micin secukupnya,royco secukupny lalu aduk2 biar meresap"
- "Masukan bumbu dan ikan panjelan tadi kedalam beras yang sudah diberi air penyedap tadi kedalam rice cooker lalu klik&#34;cook&#34;"
- "Setelah matang aduk2 lalu siap disantap...  Selamat menikmati"
categories:
- Resep
tags:
- nasi
- uduk
- tanpa

katakunci: nasi uduk tanpa 
nutrition: 212 calories
recipecuisine: Indonesian
preptime: "PT39M"
cooktime: "PT59M"
recipeyield: "2"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi uduk tanpa santan rice cooker](https://img-global.cpcdn.com/recipes/73e78ddc70bb66eb/682x484cq65/nasi-uduk-tanpa-santan-rice-cooker-foto-resep-utama.webp)

9 langkah cepat dan mudah memasak  Nasi uduk tanpa santan rice cooker cocok banget jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Dalam Pembuatan Nasi uduk tanpa santan rice cooker:

1. Beras 2 cup
1. Ikan panjelanaq beli 2ribu 
1. bawang merah 4 siung
1. bawang putih 2 siung
1. daun salam 2 lembar
1. daun jeruk 3 lembar
1. lengkuas 1 ruas
1. jahe 1 ruas
1. sereh 1 batang
1. Garam secukupnya
1. Micin secukupnyaaq pake bio miwon 
1. roycorasa ayam secukupnya
1. Minyak goreng secukupnya

My Mom still use that method to make her nasi uduk. But a rice cooker and call it a day. Membuat nasi uduk dengan rice cooker merupakan cara memasak yang paling mudah dan praktis. Kamu juga bisa mencobanya sendiri di rumah! 

<!--inarticleads2-->

## Cara Mudah Menyiapkan Nasi uduk tanpa santan rice cooker:

1. Cuci bersih beras
1. Iris bawang merah dan bawang putih
1. Cuci daun salam,daun jeruk,sereh,lengkuas dan jahe
1. Geprek sereh, lengkuas, dan jahe
1. Panaskan minyak goreng lalu masukan irisan bawang merah,bawang putih,daun salam,daun jeruk,sereh,lengkuas,dan jahe tumis hingga harum lalu tiriskan
1. Lalu goreng ikan panjelan setengah matang lalu tiriskan
1. Masukan beras beri air secukupnya kedalam rice cooker lalu beri garam secukupnya,micin secukupnya,royco secukupny lalu aduk2 biar meresap
1. Masukan bumbu dan ikan panjelan tadi kedalam beras yang sudah diberi air penyedap tadi kedalam rice cooker lalu klik&#34;cook&#34;
1. Setelah matang aduk2 lalu siap disantap...  - Selamat menikmati


Masukkan kelapa parut ke dalam air hasil saringan untuk dijadikan santan (banyaknya air santan untuk membuat beras aron atau nasi uduk sama. Nasi uduk merupakan hidanga utama khas di Indonesia. Nasi uduk memiliki cita rasa yang enak, dilengkapi dengan lauk-pauk yang komplit dan juga membuatnya cukup mudah dengan menggunakan rice cooker. Nasi uduk yang berasal dari Betawi sangat terkenal, meskipun berwarna putih akan. Cara membuat nasi uduk dengan rice cooker sebenarnya sama seperti memasak nasi biasa. 

Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
