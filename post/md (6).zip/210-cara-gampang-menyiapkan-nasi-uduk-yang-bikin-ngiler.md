---
description: "Cara Gampang Menyiapkan Nasi Uduk yang Bikin Ngiler"
title: "Cara Gampang Menyiapkan Nasi Uduk yang Bikin Ngiler"
slug: 210-cara-gampang-menyiapkan-nasi-uduk-yang-bikin-ngiler
future: true
lang: id
language: id
languageCode: id
publishDate: 2022-01-05T01:25:41.212Z 
thumbnail: https://img-global.cpcdn.com/recipes/ccdf2d703936fb89/682x484cq65/nasi-uduk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/ccdf2d703936fb89/682x484cq65/nasi-uduk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/ccdf2d703936fb89/682x484cq65/nasi-uduk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/ccdf2d703936fb89/682x484cq65/nasi-uduk-foto-resep-utama.webp
author: Amy Sullivan
ratingvalue: 3.9
reviewcount: 5
recipeingredient:
- "beras 1 Liter"
- "santan kara 1 Sachet"
- "serai 1 Batang"
- "daun salam 3 Lembar"
- "bawang merah 5 Siung"
- "Kaldu ayam "
recipeinstructions:
- "Cuci bersih beras dan masukkan kedalam teflon rice cooker.."
- "Tambahkan kedalam teflon santan, daun salam, serai geprek dan air secukupnya sesuai takaran beras lalu aduk dan tekan tombol on rice cooker.."
- "Iris bawang merah.."
- "Panaskan wajan, tuang minyak secukupnya dan masukkan bawang merah hingga matang kecoklatan.."
- "Jika nasi sudah matang, tunggu beberapa menit dan aduk. Taburkan bawang yang sudah digoreng dan nasi uduk siap disantap dengan lauk tambahan lainnya.."
categories:
- Resep
tags:
- nasi
- uduk

katakunci: nasi uduk 
nutrition: 216 calories
recipecuisine: Indonesian
preptime: "PT16M"
cooktime: "PT38M"
recipeyield: "2"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk](https://img-global.cpcdn.com/recipes/ccdf2d703936fb89/682x484cq65/nasi-uduk-foto-resep-utama.webp)

Resep Nasi Uduk    dengan 5 langkahcepat cocok sekali jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Dibutuhkan Dalam Pembuatan Nasi Uduk:

1. beras 1 Liter
1. santan kara 1 Sachet
1. serai 1 Batang
1. daun salam 3 Lembar
1. bawang merah 5 Siung
1. Kaldu ayam 



<!--inarticleads2-->

## Tata Cara Membuat Nasi Uduk:

1. Cuci bersih beras dan masukkan kedalam teflon rice cooker..
1. Tambahkan kedalam teflon santan, daun salam, serai geprek dan air secukupnya sesuai takaran beras lalu aduk dan tekan tombol on rice cooker..
1. Iris bawang merah..
1. Panaskan wajan, tuang minyak secukupnya dan masukkan bawang merah hingga matang kecoklatan..
1. Jika nasi sudah matang, tunggu beberapa menit dan aduk. Taburkan bawang yang sudah digoreng dan nasi uduk siap disantap dengan lauk tambahan lainnya..




Terima kasih telah menggunakan resep yang tim kami tampilkan di halaman ini. Semoga bermanfaat dan selamat mencoba!
