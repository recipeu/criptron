---
description: "Bagaimana Menyiapkan Nasi Uduk Betawi Rice Cooker yang Bisa Manjain Lidah"
title: "Bagaimana Menyiapkan Nasi Uduk Betawi Rice Cooker yang Bisa Manjain Lidah"
slug: 12-bagaimana-menyiapkan-nasi-uduk-betawi-rice-cooker-yang-bisa-manjain-lidah
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-15T23:57:38.599Z 
thumbnail: https://img-global.cpcdn.com/recipes/4296b20cd3146f36/682x484cq65/nasi-uduk-betawi-rice-cooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/4296b20cd3146f36/682x484cq65/nasi-uduk-betawi-rice-cooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/4296b20cd3146f36/682x484cq65/nasi-uduk-betawi-rice-cooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/4296b20cd3146f36/682x484cq65/nasi-uduk-betawi-rice-cooker-foto-resep-utama.webp
author: Verna Rodgers
ratingvalue: 4
reviewcount: 11
recipeingredient:
- "beras 2 cup"
- "pasta santan segitiga saya pakai sasa 1 sachet"
- "Air sebanyak takaran biasa memasak nasi "
- "bawang merah iris tipis 8 siung"
- "jahe geprek 2 cm"
- "lengkuas geprek 2 cm"
- "serai geprek 2 batang"
- "kayu manis 6 cm"
- "daun salam 8 lembar"
- "garam 1 sdm"
- "Pendamping  optional "
- "Bihun goreng "
- "Semur tahutempejengkoldaging resep semur cek lampiran ya           lihat resep "
- "Bawang goreng "
- "Kerupuk "
recipeinstructions:
- "Cuci bersih beras lalu masukkan santan dan air sebanyak takaran memasak masi biasa."
- "Masukkan semua bumbu lalu masak hingga nasi matang."
- "Bila tombol nasi telah menunjukkan nasi matang, buka penutup rice cooker lalu aduk rata nasi. Tutup kembali lalu biarkan selama 15-20 menit."
- "Sajikan bersama pendamping lainnya."
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 182 calories
recipecuisine: Indonesian
preptime: "PT12M"
cooktime: "PT51M"
recipeyield: "2"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Betawi Rice Cooker](https://img-global.cpcdn.com/recipes/4296b20cd3146f36/682x484cq65/nasi-uduk-betawi-rice-cooker-foto-resep-utama.webp)

Resep dan cara mengolah  Nasi Uduk Betawi Rice Cooker yang bisa kamu coba dirumah

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Untuk Pembuatan Nasi Uduk Betawi Rice Cooker:

1. beras 2 cup
1. pasta santan segitiga saya pakai sasa 1 sachet
1. Air sebanyak takaran biasa memasak nasi 
1. bawang merah iris tipis 8 siung
1. jahe geprek 2 cm
1. lengkuas geprek 2 cm
1. serai geprek 2 batang
1. kayu manis 6 cm
1. daun salam 8 lembar
1. garam 1 sdm
1. Pendamping  optional 
1. Bihun goreng 
1. Semur tahutempejengkoldaging resep semur cek lampiran ya           lihat resep 
1. Bawang goreng 
1. Kerupuk 



<!--inarticleads2-->

## Tata Cara Menyiapkan Nasi Uduk Betawi Rice Cooker:

1. Cuci bersih beras lalu masukkan santan dan air sebanyak takaran memasak masi biasa.
1. Masukkan semua bumbu lalu masak hingga nasi matang.
1. Bila tombol nasi telah menunjukkan nasi matang, buka penutup rice cooker lalu aduk rata nasi. Tutup kembali lalu biarkan selama 15-20 menit.
1. Sajikan bersama pendamping lainnya.




Selamat memasak dan menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
