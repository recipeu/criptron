---
description: "Langkah Mudah untuk Menyiapkan Soto Semarang yang Enak"
title: "Langkah Mudah untuk Menyiapkan Soto Semarang yang Enak"
slug: 497-langkah-mudah-untuk-menyiapkan-soto-semarang-yang-enak
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-16T04:59:37.124Z 
thumbnail: https://img-global.cpcdn.com/recipes/99bca6807a735d0d/682x484cq65/soto-semarang-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/99bca6807a735d0d/682x484cq65/soto-semarang-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/99bca6807a735d0d/682x484cq65/soto-semarang-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/99bca6807a735d0d/682x484cq65/soto-semarang-foto-resep-utama.webp
author: Elsie Blake
ratingvalue: 3.2
reviewcount: 8
recipeingredient:
- "ayam 1/2 kg"
- "serai memarkan 2 batang"
- "daun salam 2 lembar"
- "daun jeruk 1 lembar"
- "lada bubuk 1/2 sdt"
- "air Secukupnya"
- "Bumbu Halus "
- "ketumbar 1/2 sdt"
- "bawang putih 4 siung"
- "kunyit 1 ruas"
- "jahe 1 ruas"
- "Bahan Pelengkap "
- "Nasi "
- "Sate kerang "
- "Tahu goreng "
- "Tempe goreng "
- "Daun bawang iris halus "
- "Seledri iris halus "
- "Bawang merah goreng "
- "Bawang putih goreng "
recipeinstructions:
- "Cuci bersih ayam. Rebus ayam sampai mengeluarkan buih. Buang airnya dan cuci kembali ayamnya. Rebus kembali ayam sampai empuk angkat tiriskan. Suir suir"
- "Tambahkan serai, daun salam, jeruk masak sampai mendidih"
- "Tumis bumbu halus sampai harum."
- "Masukkan kedalam air rebusan tambahkan garam, gula pasir, lada dan penyedap. Aduk rata. Cek rasa. Masak sampai mendidih. Matikan"
- "Tata di mangkok soun, toge, ayam Suir Suir, daun bawang, seledri, bawang goreng, bawang putih goreng. Siram dengan kuah soto. Sajikan dengan nasi hangat, sate kerang, tahu goreng, tempe goreng dan sambal."
categories:
- Resep
tags:
- soto
- semarang

katakunci: soto semarang 
nutrition: 284 calories
recipecuisine: Indonesian
preptime: "PT15M"
cooktime: "PT49M"
recipeyield: "4"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Soto Semarang](https://img-global.cpcdn.com/recipes/99bca6807a735d0d/682x484cq65/soto-semarang-foto-resep-utama.webp)

5 langkah cepat dan mudah membuat  Soto Semarang cocok sekali jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Untuk Pembuatan Soto Semarang:

1. ayam 1/2 kg
1. serai memarkan 2 batang
1. daun salam 2 lembar
1. daun jeruk 1 lembar
1. lada bubuk 1/2 sdt
1. air Secukupnya
1. Bumbu Halus 
1. ketumbar 1/2 sdt
1. bawang putih 4 siung
1. kunyit 1 ruas
1. jahe 1 ruas
1. Bahan Pelengkap 
1. Nasi 
1. Sate kerang 
1. Tahu goreng 
1. Tempe goreng 
1. Daun bawang iris halus 
1. Seledri iris halus 
1. Bawang merah goreng 
1. Bawang putih goreng 



<!--inarticleads2-->

## Cara Menyiapkan Soto Semarang:

1. Cuci bersih ayam. Rebus ayam sampai mengeluarkan buih. Buang airnya dan cuci kembali ayamnya. Rebus kembali ayam sampai empuk angkat tiriskan. Suir suir
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/2ec54623f4f2fcfb/160x128cq70/soto-semarang-langkah-memasak-1-foto.webp" alt="Soto Semarang" width="340" height="340">
>1. Tambahkan serai, daun salam, jeruk masak sampai mendidih
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/32884d01457f6cc0/160x128cq70/soto-semarang-langkah-memasak-2-foto.webp" alt="Soto Semarang" width="340" height="340">
>1. Tumis bumbu halus sampai harum.
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/9d913616dfe5b678/160x128cq70/soto-semarang-langkah-memasak-3-foto.webp" alt="Soto Semarang" width="340" height="340">
>1. Masukkan kedalam air rebusan tambahkan garam, gula pasir, lada dan penyedap. Aduk rata. Cek rasa. Masak sampai mendidih. Matikan
1. Tata di mangkok soun, toge, ayam Suir Suir, daun bawang, seledri, bawang goreng, bawang putih goreng. Siram dengan kuah soto. Sajikan dengan nasi hangat, sate kerang, tahu goreng, tempe goreng dan sambal.




Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
