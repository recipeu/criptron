---
description: "Bagaimana Membuat Nasi Uduk Betawi Rice Cooker yang Menggugah Selera"
title: "Bagaimana Membuat Nasi Uduk Betawi Rice Cooker yang Menggugah Selera"
slug: 2-bagaimana-membuat-nasi-uduk-betawi-rice-cooker-yang-menggugah-selera
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-20T03:04:42.344Z 
thumbnail: https://img-global.cpcdn.com/recipes/a2e9af0c2820af4a/682x484cq65/nasi-uduk-betawi-rice-cooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/a2e9af0c2820af4a/682x484cq65/nasi-uduk-betawi-rice-cooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/a2e9af0c2820af4a/682x484cq65/nasi-uduk-betawi-rice-cooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/a2e9af0c2820af4a/682x484cq65/nasi-uduk-betawi-rice-cooker-foto-resep-utama.webp
author: Fred Banks
ratingvalue: 4
reviewcount: 11
recipeingredient:
- "takaran beras yg sdh dicuci sekitar 1 liter ya Lebih enak beras pera tapi saya pakai yg pulen jg enak kokk 2"
- "santan kara 65 ml 2 bks"
- "bawang merah 7 siung"
- "bawang putih 5 siung"
- "sereh geprek 3 batang"
- "daun salam 5 lembar"
- "garam Secukupnya"
- "kaldu bubuk optional Secukupnya"
- "air 500 ml"
- "minyak utk menumis Secukupnya"
recipeinstructions:
- "Haluskan bawang merah bawang putih."
- "Panaskan minyak. Tumis geng bawang."
- "Masukkan sereh dan salam. Tumis hingga wangi dan agak lengket di wajan."
- "Masukkan santan yg sudah diaduk dengan air. Aduk2."
- "Tambahkan garam (dan kaldu). Aduk sampai mendidih. Jangan sampai pecah ya!"
- "Masukkan beras ke rice cooker. Tambahkan air santan."
- "Tunggu sampai matang. Jangan lupa dinyalakan yaa rice cookernya 🤭😂 —setelah matang, jangan langsung dibuka, setergoda apapun kalian dengan wanginya😂. Tunggu 15 menit, aduk, tutup lagi sekitar 15 menit."
- "Nasi uduk betawi siap dihidangkan."
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 225 calories
recipecuisine: Indonesian
preptime: "PT13M"
cooktime: "PT44M"
recipeyield: "2"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Betawi Rice Cooker](https://img-global.cpcdn.com/recipes/a2e9af0c2820af4a/682x484cq65/nasi-uduk-betawi-rice-cooker-foto-resep-utama.webp)

Resep dan cara memasak  Nasi Uduk Betawi Rice Cooker cocok banget jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Untuk Pembuatan Nasi Uduk Betawi Rice Cooker:

1. takaran beras yg sdh dicuci sekitar 1 liter ya Lebih enak beras pera tapi saya pakai yg pulen jg enak kokk 2
1. santan kara 65 ml 2 bks
1. bawang merah 7 siung
1. bawang putih 5 siung
1. sereh geprek 3 batang
1. daun salam 5 lembar
1. garam Secukupnya
1. kaldu bubuk optional Secukupnya
1. air 500 ml
1. minyak utk menumis Secukupnya



<!--inarticleads2-->

## Tata Cara Menyiapkan Nasi Uduk Betawi Rice Cooker:

1. Haluskan bawang merah bawang putih.
1. Panaskan minyak. Tumis geng bawang.
1. Masukkan sereh dan salam. Tumis hingga wangi dan agak lengket di wajan.
1. Masukkan santan yg sudah diaduk dengan air. Aduk2.
1. Tambahkan garam (dan kaldu). Aduk sampai mendidih. Jangan sampai pecah ya!
1. Masukkan beras ke rice cooker. Tambahkan air santan.
1. Tunggu sampai matang. Jangan lupa dinyalakan yaa rice cookernya 🤭😂 —setelah matang, jangan langsung dibuka, setergoda apapun kalian dengan wanginya😂. Tunggu 15 menit, aduk, tutup lagi sekitar 15 menit.
1. Nasi uduk betawi siap dihidangkan.




Demikian informasi  resep Nasi Uduk Betawi Rice Cooker   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
