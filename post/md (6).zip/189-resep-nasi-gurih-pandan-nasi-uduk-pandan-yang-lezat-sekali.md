---
description: "Resep Nasi gurih pandan / Nasi uduk pandan yang Lezat Sekali"
title: "Resep Nasi gurih pandan / Nasi uduk pandan yang Lezat Sekali"
slug: 189-resep-nasi-gurih-pandan-nasi-uduk-pandan-yang-lezat-sekali
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-09T01:31:06.315Z 
thumbnail: https://img-global.cpcdn.com/recipes/319402501328e405/682x484cq65/nasi-gurih-pandan-nasi-uduk-pandan-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/319402501328e405/682x484cq65/nasi-gurih-pandan-nasi-uduk-pandan-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/319402501328e405/682x484cq65/nasi-gurih-pandan-nasi-uduk-pandan-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/319402501328e405/682x484cq65/nasi-gurih-pandan-nasi-uduk-pandan-foto-resep-utama.webp
author: Ina Gibbs
ratingvalue: 3.8
reviewcount: 5
recipeingredient:
- "beras 400 gr"
- "santan instant me  ss 65 ml"
- "daun pandan blender dengan sedikit air 5 lbr"
- "garam 1/4 sdt"
- "kaldu jamur 1/4 sdt"
- "daun pandan simpul 2 helai"
- "daun salam 2 lbr"
- "serei geprek dan simpul 2 btg"
recipeinstructions:
- "Cuci bersih beras.. kemudian masukkan santan..aduk rata."
- "Blender daun pandan dengan sedikit air..kemudian saring dan peres..tuang airnya ke beras..aduk merata.."
- "Kemudian beri garam,kaldu jamur dan air sesuai takaran memasak nasi biasanya. Tambahkan daun pandan,daun salam dan serei.. kemudian masukkan pot ke rice cooker..kemudian cook hingga matang..begitu matang langsung diaduk dan tutup kembali. biarkan +/- 30menit (lebih jg Gpp) baru keluarkan dan sajikan. Selamat mencoba 🙏🙏🤗🤗🥰🥰💪😁"
categories:
- Resep
tags:
- nasi
- gurih
- pandan

katakunci: nasi gurih pandan 
nutrition: 273 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT51M"
recipeyield: "3"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi gurih pandan / Nasi uduk pandan](https://img-global.cpcdn.com/recipes/319402501328e405/682x484cq65/nasi-gurih-pandan-nasi-uduk-pandan-foto-resep-utama.webp)

Resep rahasia Nasi gurih pandan / Nasi uduk pandan  enak dengan 3 langkahcepat yang harus bunda coba segera

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Untuk Pembuatan Nasi gurih pandan / Nasi uduk pandan:

1. beras 400 gr
1. santan instant me  ss 65 ml
1. daun pandan blender dengan sedikit air 5 lbr
1. garam 1/4 sdt
1. kaldu jamur 1/4 sdt
1. daun pandan simpul 2 helai
1. daun salam 2 lbr
1. serei geprek dan simpul 2 btg

Nasinya yang gurih dan lauk telur dadar, ayam goreng, kering tempe, dan perkedel menjadi kombinasi nikmat Cara membuat nasi uduk dengan rice cooker sebenarnya sama seperti memasak nasi biasa. Resep nasi uduk enak dan gurih yang bisa dibuat di rumah. Nasi putih yang dimasak dengan berbagai macam rempah ini memiliki rasa gurih. Bahkan, Anda bisa mengkreasikan nasi uduk dengan bayam, pandan, hingga ubi ungu. 

<!--inarticleads2-->

## Cara Mudah Menyiapkan Nasi gurih pandan / Nasi uduk pandan:

1. Cuci bersih beras.. kemudian masukkan santan..aduk rata.
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/1064dd47220bd099/160x128cq70/nasi-gurih-pandan-nasi-uduk-pandan-langkah-memasak-1-foto.webp" alt="Nasi gurih pandan / Nasi uduk pandan" width="340" height="340">
>1. Blender daun pandan dengan sedikit air..kemudian saring dan peres..tuang airnya ke beras..aduk merata..
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/838921d810f6933a/160x128cq70/nasi-gurih-pandan-nasi-uduk-pandan-langkah-memasak-2-foto.webp" alt="Nasi gurih pandan / Nasi uduk pandan" width="340" height="340">
><img class="lazyload" data-src="https://img-global.cpcdn.com/steps/c6a73fbb997c2da2/160x128cq70/nasi-gurih-pandan-nasi-uduk-pandan-langkah-memasak-2-foto.webp" alt="Nasi gurih pandan / Nasi uduk pandan" width="340" height="340">
>1. Kemudian beri garam,kaldu jamur dan air sesuai takaran memasak nasi biasanya. Tambahkan daun pandan,daun salam dan serei.. kemudian masukkan pot ke rice cooker..kemudian cook hingga matang..begitu matang langsung diaduk dan tutup kembali. biarkan +/- 30menit (lebih jg Gpp) baru keluarkan dan sajikan. Selamat mencoba 🙏🙏🤗🤗🥰🥰💪😁
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/3ee5c8854e9f0efd/160x128cq70/nasi-gurih-pandan-nasi-uduk-pandan-langkah-memasak-3-foto.webp" alt="Nasi gurih pandan / Nasi uduk pandan" width="340" height="340">
><img class="lazyload" data-src="https://img-global.cpcdn.com/steps/b38a3978c900693f/160x128cq70/nasi-gurih-pandan-nasi-uduk-pandan-langkah-memasak-3-foto.webp" alt="Nasi gurih pandan / Nasi uduk pandan" width="340" height="340">
>

Kali ini, jika tertarik membuat nasi uduk enak dan lezat. Merdeka.com - Nasi uduk merupakan salah satu jenis kuliner yang banyak digemari masyarakat Indonesia. Rasanya yang gurih semakin menambah Biasanya nasi uduk dikreasikan dengan warna tampilan baru. Seperti Nasi uduk berwarna hijau dari daun pandan, ungu dari ubi jalar, maupun biru. Nasi uduk memang terlihat sama seperti nasi pada umumnya. 

Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
