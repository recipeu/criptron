---
description: "Resep Nasi daun jeruk tongkol suwir yang Bisa Manjain Lidah"
title: "Resep Nasi daun jeruk tongkol suwir yang Bisa Manjain Lidah"
slug: 279-resep-nasi-daun-jeruk-tongkol-suwir-yang-bisa-manjain-lidah
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-30T07:54:33.651Z 
thumbnail: https://img-global.cpcdn.com/recipes/d4df706468704bbf/682x484cq65/nasi-daun-jeruk-tongkol-suwir-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/d4df706468704bbf/682x484cq65/nasi-daun-jeruk-tongkol-suwir-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/d4df706468704bbf/682x484cq65/nasi-daun-jeruk-tongkol-suwir-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/d4df706468704bbf/682x484cq65/nasi-daun-jeruk-tongkol-suwir-foto-resep-utama.webp
author: Edith Fields
ratingvalue: 4.3
reviewcount: 14
recipeingredient:
- "Nasi daun jeruk "
- "Beras 2-3 cup"
- "Daun jeruk 15 lembar sebagai remas sebagian buang tulang iris kecil "
- "sereh 1-2 batang"
- "Bawang putih 34siung geprek cincang "
- "Air secukupnya"
- "Garam sedikit"
- "Tumis Tongkol suwir "
- "ikan tongkol kukus suwir 500 gr"
- "sereh 1 batang"
- "Daun jeruk "
- "Bumbu halus "
- "bawang merah 5 buah"
- "bawang putih 4 siung"
- "Cabe keriting secukupnya"
- "jahe 1 ruas jari"
- "kunyit 1/2 ruas jari"
- "Garam dan kaldu secukupnya"
- "Gula sedikit aja "
recipeinstructions:
- "Masak beras yg sudah dicuci, tambahkan semua bahan untuk nasi, aduk², dan masak di rice cooker seperti biasa"
- "Tumis bumbu halus hingga harum, masukkan daun jeruk dan sereh,, tunggu bentar, lalu masukkan ikan tongkol yg sudah disuwir..  Tambah kan gram dan kaldu, tes rasa,, tunggu bbrpa menit.. angkat.."
- "Ambil nasi dipiring, tambahkan tumis tongkol suwir, taburi bawang goreng.. eenaaak... Maa syaa Allaah ❤️"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 292 calories
recipecuisine: Indonesian
preptime: "PT38M"
cooktime: "PT52M"
recipeyield: "2"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi daun jeruk tongkol suwir](https://img-global.cpcdn.com/recipes/d4df706468704bbf/682x484cq65/nasi-daun-jeruk-tongkol-suwir-foto-resep-utama.webp)

Resep dan cara mengolah  Nasi daun jeruk tongkol suwir yang harus bunda coba segera

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Untuk Pembuatan Nasi daun jeruk tongkol suwir:

1. Nasi daun jeruk 
1. Beras 2-3 cup
1. Daun jeruk 15 lembar sebagai remas sebagian buang tulang iris kecil 
1. sereh 1-2 batang
1. Bawang putih 34siung geprek cincang 
1. Air secukupnya
1. Garam sedikit
1. Tumis Tongkol suwir 
1. ikan tongkol kukus suwir 500 gr
1. sereh 1 batang
1. Daun jeruk 
1. Bumbu halus 
1. bawang merah 5 buah
1. bawang putih 4 siung
1. Cabe keriting secukupnya
1. jahe 1 ruas jari
1. kunyit 1/2 ruas jari
1. Garam dan kaldu secukupnya
1. Gula sedikit aja 

Apalagi, ditambahkan tongkol suwir di dalamnya, dijamin makin nagih. Nah, kamu bisa bikin sendiri kreasi nasi bakar yang. Suwir-suwir daging ikan tongkol, buang duri dan kulitnya. Panaskan minyak, lalu tumis bumbu halus hingga harum, tambahkan daun salam, daun jeruk Cara Membuat Tongkol Suwir Kemangi: Cuci ikan tongkol hingga bersih, lalu kucuri dengan perasan air jeruk nipis dan sedikit garam, diamkan. 

<!--inarticleads2-->

## Tata Cara Membuat Nasi daun jeruk tongkol suwir:

1. Masak beras yg sudah dicuci, tambahkan semua bahan untuk nasi, aduk², dan masak di rice cooker seperti biasa
1. Tumis bumbu halus hingga harum, masukkan daun jeruk dan sereh,, tunggu bentar, lalu masukkan ikan tongkol yg sudah disuwir.. -  - Tambah kan gram dan kaldu, tes rasa,, tunggu bbrpa menit.. angkat..
1. Ambil nasi dipiring, tambahkan tumis tongkol suwir, taburi bawang goreng.. eenaaak... Maa syaa Allaah ❤️


Nasi Daun Jeruk Tongkol Suwir Pedas Ala Chef Martin Morning Show. Selanjutnya tata nasi, tongkol diatas daun pisang kemudian bungkus, sematkan tusuk gigi pada pinggirnya. Resep pindang tongkol suwir sambal kecombrang yang tidak saja pedas tapi juga menyegarkan. Bunga kecombrang juga memberikan aroma khas, sehingga membuat olahan tongkol. Kita bisa menggunakan ikan tongkol segar atau ikan tongkol pindang yang banyak dijual di pasaran. 

Selamat memasak dan menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
