---
description: "Bagaimana Menyiapkan Tumini Nasi Uduk Ungu, Bikin Ngiler"
title: "Bagaimana Menyiapkan Tumini Nasi Uduk Ungu, Bikin Ngiler"
slug: 188-bagaimana-menyiapkan-tumini-nasi-uduk-ungu-bikin-ngiler
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-14T09:18:55.303Z 
thumbnail: https://img-global.cpcdn.com/recipes/9ece592a03079a60/682x484cq65/tumini-nasi-uduk-ungu-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/9ece592a03079a60/682x484cq65/tumini-nasi-uduk-ungu-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/9ece592a03079a60/682x484cq65/tumini-nasi-uduk-ungu-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/9ece592a03079a60/682x484cq65/tumini-nasi-uduk-ungu-foto-resep-utama.webp
author: Ophelia Cobb
ratingvalue: 3.4
reviewcount: 3
recipeingredient:
- "Bahan Nasi Uduk Ungu  "
- "beras putih 2.5 gelas belimbing"
- "santan kara dicairin dengan air 250ml 65 ml"
- "pewarna makanan ungu 2 tetes"
- "sereh geprek 1 buah"
- "daun salam 2 buah"
- "daun jeruk iris tipis 4 buah"
- "lengkuas geprek 3 ruas"
- "royco 1 sdt"
- "garam 1 sdt"
- "Bahan Telor Dadar Rawis  "
- "telor ayam kocok lepas 2 butir"
- "garam 2 jumput"
- "Bahan Ayam Goreng  "
- "ayam bagian paha 1/2 kg"
- "bumbu dasar putih           lihat resep 1 sdm"
- "ketumbar bubuk 1 sdt"
- "daun salam 1 buah"
- "daun jeruk 1 buah"
- "gula garam Secukupnya"
- "Topping  "
- "Bihun Goreng "
- "Srundeng Kelapa "
- "Daun Selada "
- "Brambang Goreng "
recipeinstructions:
- "Nasi Uduk :  Cuci bersih beras nya dulu, beri air santan, taruh di rice cooker beri daun salam, daun jeruk, lengkuas, sereh, pewarna, lalu bumbui. Masak selama 30 menit. Tiriskan."
- "Telor Dadar Rawis :  Kocok lepas telor ayam beri garam. Lalu dadar tipis2 aja. Angkat tiriskan. Potong tipis2."
- "Ayam Goreng :  Tumis bumbu dasar putih dan ketumbar, beri daun salam dan daun jeruk. Aduk rata beri air secukupnya. Masukkan ayam ungkep sampai matang. Siap utk digoreng ya."
- "Untuk Bihun Goreng &amp; Srundeng resepnya ida ada di CP ku ya scroll aja."
categories:
- Resep
tags:
- tumini
- nasi
- uduk

katakunci: tumini nasi uduk 
nutrition: 294 calories
recipecuisine: Indonesian
preptime: "PT36M"
cooktime: "PT42M"
recipeyield: "1"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Tumini Nasi Uduk Ungu](https://img-global.cpcdn.com/recipes/9ece592a03079a60/682x484cq65/tumini-nasi-uduk-ungu-foto-resep-utama.webp)

4 langkah mudah membuat  Tumini Nasi Uduk Ungu cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Untuk Pembuatan Tumini Nasi Uduk Ungu:

1. Bahan Nasi Uduk Ungu  
1. beras putih 2.5 gelas belimbing
1. santan kara dicairin dengan air 250ml 65 ml
1. pewarna makanan ungu 2 tetes
1. sereh geprek 1 buah
1. daun salam 2 buah
1. daun jeruk iris tipis 4 buah
1. lengkuas geprek 3 ruas
1. royco 1 sdt
1. garam 1 sdt
1. Bahan Telor Dadar Rawis  
1. telor ayam kocok lepas 2 butir
1. garam 2 jumput
1. Bahan Ayam Goreng  
1. ayam bagian paha 1/2 kg
1. bumbu dasar putih           lihat resep 1 sdm
1. ketumbar bubuk 1 sdt
1. daun salam 1 buah
1. daun jeruk 1 buah
1. gula garam Secukupnya
1. Topping  
1. Bihun Goreng 
1. Srundeng Kelapa 
1. Daun Selada 
1. Brambang Goreng 



<!--inarticleads2-->

## Langkah-langkah Untuk Menyiapkan Tumini Nasi Uduk Ungu:

1. Nasi Uduk :  - Cuci bersih beras nya dulu, beri air santan, taruh di rice cooker beri daun salam, daun jeruk, lengkuas, sereh, pewarna, lalu bumbui. Masak selama 30 menit. Tiriskan.
1. Telor Dadar Rawis :  - Kocok lepas telor ayam beri garam. Lalu dadar tipis2 aja. Angkat tiriskan. Potong tipis2.
1. Ayam Goreng :  - Tumis bumbu dasar putih dan ketumbar, beri daun salam dan daun jeruk. Aduk rata beri air secukupnya. Masukkan ayam ungkep sampai matang. Siap utk digoreng ya.
1. Untuk Bihun Goreng &amp; Srundeng resepnya ida ada di CP ku ya scroll aja.




Terima kasih telah menggunakan resep yang tim kami tampilkan di sini. Semoga bermanfaat dan selamat mencoba!
