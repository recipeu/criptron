---
description: "Cara Gampang Membuat Nasi uduk betawi, Lezat Sekali"
title: "Cara Gampang Membuat Nasi uduk betawi, Lezat Sekali"
slug: 98-cara-gampang-membuat-nasi-uduk-betawi-lezat-sekali
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-20T22:33:24.477Z 
thumbnail: https://img-global.cpcdn.com/recipes/25c7097251647274/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/25c7097251647274/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/25c7097251647274/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/25c7097251647274/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
author: Lucinda Flowers
ratingvalue: 3.6
reviewcount: 15
recipeingredient:
- "beras cuci bersih 3 kg"
- "santan kental 1500-2000 ml"
- "Bumbu halus "
- "kemiri 5 buah"
- "merica 1 sdt"
- "Bumbu pelengkap "
- "daun jeruk purut 6"
- "serai digeprek 6"
- "daun salam 10-15"
- "Garam royco ayam secukupnya"
- "Sambel kacang "
- "bawang putih 2-3 siung"
- "cabe rawit 8"
- "Kacang tanah air secukupnya"
recipeinstructions:
- "Bumbu halus &amp; bumbu pelengkap, direbus dg santan kental, beri royco,garam. Aduk2 trs jgn smp santan pecah ya moms (tdk perlu smp mendidih)"
- "Beras yg sdh dicuci, kukus smp mjd beras aron, kmdn angkat, pindah kan kedalam wadah, beri santan td, aduk2 rata, diamkan sebentar smp meresap. Koreksi rasa asin nya"
- "Panaskan kembali dandang, masukkan beras aron. Kukus hingga nasi matang."
- "Note: klo nasi dirasa msh keras, bs dituangi sisa santannya."
- "Sambel kacang: bawang putih,cabe digoreng, kmdn diulek campur dg kacang tanah, beri air sedikit."
- "Sajikan dg ayam goreng, oreg tempe &amp; sambal👌"
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 102 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT57M"
recipeyield: "2"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi uduk betawi](https://img-global.cpcdn.com/recipes/25c7097251647274/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp)

Resep dan cara mengolah  Nasi uduk betawi yang wajib ibu coba dirumah

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Untuk Pembuatan Nasi uduk betawi:

1. beras cuci bersih 3 kg
1. santan kental 1500-2000 ml
1. Bumbu halus 
1. kemiri 5 buah
1. merica 1 sdt
1. Bumbu pelengkap 
1. daun jeruk purut 6
1. serai digeprek 6
1. daun salam 10-15
1. Garam royco ayam secukupnya
1. Sambel kacang 
1. bawang putih 2-3 siung
1. cabe rawit 8
1. Kacang tanah air secukupnya

Menu siap saji, tinggal goreng dan siap disantap dengan. There are no reviews for Nasi Uduk Betawi Bang Acim, Indonesia yet. Be the first to write a review! Cara membuat nasi uduk betawi bisa dibikin mudah, cukup gunakan magic com. 

<!--inarticleads2-->

## Tata Cara Membuat Nasi uduk betawi:

1. Bumbu halus &amp; bumbu pelengkap, direbus dg santan kental, beri royco,garam. Aduk2 trs jgn smp santan pecah ya moms (tdk perlu smp mendidih)
1. Beras yg sdh dicuci, kukus smp mjd beras aron, kmdn angkat, pindah kan kedalam wadah, beri santan td, aduk2 rata, diamkan sebentar smp meresap. Koreksi rasa asin nya
1. Panaskan kembali dandang, masukkan beras aron. Kukus hingga nasi matang.
1. Note: klo nasi dirasa msh keras, bs dituangi sisa santannya.
1. Sambel kacang: bawang putih,cabe digoreng, kmdn diulek campur dg kacang tanah, beri air sedikit.
1. Sajikan dg ayam goreng, oreg tempe &amp; sambal👌


Berikut resep nasi uduk betawi sederhana yang bisa untuk dijual. Resep Nasi Uduk Betawi - Makanan khas Betawi ini cocok sekali dijadikan menu sarapan. Uhh, sajian nasi uduk betawi ini akan semakin lezat dan komplit. Baca Juga : Resep Mie Aceh Tumis. Nasi uduk Betawi memiliki kekhasannya sendiri dan sudah memiliki citra tersendiri. 

Daripada bunda beli  Nasi uduk betawi  diluar terus, ibu  bisa membuatnya sendiri dirumah. Resep  Nasi uduk betawi  sederhana ini cukup praktis pembuatannya, cukup menggunakan bumbu sederhana  Nasi uduk betawi  yang enak, ibu nikmati di rumah.
