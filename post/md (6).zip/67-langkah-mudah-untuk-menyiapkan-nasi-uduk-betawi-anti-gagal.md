---
description: "Langkah Mudah untuk Menyiapkan Nasi Uduk Betawi Anti Gagal"
title: "Langkah Mudah untuk Menyiapkan Nasi Uduk Betawi Anti Gagal"
slug: 67-langkah-mudah-untuk-menyiapkan-nasi-uduk-betawi-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2022-01-07T07:15:59.462Z 
thumbnail: https://img-global.cpcdn.com/recipes/34747e87c6ebd2c8/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/34747e87c6ebd2c8/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/34747e87c6ebd2c8/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/34747e87c6ebd2c8/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
author: Sophia Lowe
ratingvalue: 4.1
reviewcount: 12
recipeingredient:
- "Beras 2 gelas belimbing"
- "Bumbu  bumbu secukupnya  "
- "Jahe 3 ruas"
- "Lengkuas 3ruas buku "
- "Kencur 2 buah"
- "Sereh 3 lembar"
- "Daun salam 3 lembar"
- "Daun Jeruk 4 lembat "
- "Santan Pake kara yg kecil "
- "Garam secukupnya"
recipeinstructions:
- "Siapkan beras yg akan dipergunakan, cuci lalu kukus."
- "Bumbu2 yang disebutkan diatas cuci bersih lalu iris2 (jangan terlalu halus/kecil)."
- "Rebus air+bumbu2+santan+ garam sampai mendidih koreksi rasa."
- "Beras yang telah tanak(selesai dikukus) di masukkan kedalam rebusan santan. Diamkan hingga meresap hingga jadi aron. Sisihkan.(difoto ada uapnya jd berkabut)☺"
- "Disisilain kita jerang dandang(kukusan) hingga mendidih, setelah itu masukkan aron nasi uduk. Kukus hingga matang -/+ 20 menit. Angkat, siangi bumbunya, sajikan dengan temen2 nya 🤤"
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 167 calories
recipecuisine: Indonesian
preptime: "PT12M"
cooktime: "PT33M"
recipeyield: "3"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Betawi](https://img-global.cpcdn.com/recipes/34747e87c6ebd2c8/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp)

Ingin membuat Nasi Uduk Betawi ? Coba resep berikut ini. Cara memasaknya sangat praktis namun jangan kaget jika hasilnya gurih dan lezat cocok sekali jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Dalam Menyiapkan Nasi Uduk Betawi:

1. Beras 2 gelas belimbing
1. Bumbu  bumbu secukupnya  
1. Jahe 3 ruas
1. Lengkuas 3ruas buku 
1. Kencur 2 buah
1. Sereh 3 lembar
1. Daun salam 3 lembar
1. Daun Jeruk 4 lembat 
1. Santan Pake kara yg kecil 
1. Garam secukupnya



<!--inarticleads2-->

## Cara Mudah Menyiapkan Nasi Uduk Betawi:

1. Siapkan beras yg akan dipergunakan, cuci lalu kukus.
1. Bumbu2 yang disebutkan diatas cuci bersih lalu iris2 (jangan terlalu halus/kecil).
1. Rebus air+bumbu2+santan+ garam sampai mendidih koreksi rasa.
1. Beras yang telah tanak(selesai dikukus) di masukkan kedalam rebusan santan. Diamkan hingga meresap hingga jadi aron. Sisihkan.(difoto ada uapnya jd berkabut)☺
1. Disisilain kita jerang dandang(kukusan) hingga mendidih, setelah itu masukkan aron nasi uduk. Kukus hingga matang -/+ 20 menit. Angkat, siangi bumbunya, sajikan dengan temen2 nya 🤤




Daripada bunda beli  Nasi Uduk Betawi  diluar terus, bunda  bisa membuatnya sendiri dirumah. Resep  Nasi Uduk Betawi  sederhana ini cukup praktis dalam proses pembuatannya, cukup menggunakan bumbu-bumbu sederhana yang ada di dapur  Nasi Uduk Betawi  yang enak, bunda nikmati di rumah.
