---
description: "Cara Gampang Menyiapkan Nasi Ayam Hainan Rice cooker, Sempurna"
title: "Cara Gampang Menyiapkan Nasi Ayam Hainan Rice cooker, Sempurna"
slug: 441-cara-gampang-menyiapkan-nasi-ayam-hainan-rice-cooker-sempurna
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-23T03:23:51.963Z 
thumbnail: https://img-global.cpcdn.com/recipes/bf9147c56224dc07/682x484cq65/nasi-ayam-hainan-rice-cooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/bf9147c56224dc07/682x484cq65/nasi-ayam-hainan-rice-cooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/bf9147c56224dc07/682x484cq65/nasi-ayam-hainan-rice-cooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/bf9147c56224dc07/682x484cq65/nasi-ayam-hainan-rice-cooker-foto-resep-utama.webp
author: Myra Wood
ratingvalue: 4.2
reviewcount: 12
recipeingredient:
- "Bahan Nasi Hainan  "
- "Beras cuci dan rendam 30 menit 2 Cup"
- "Air Kaldu Ayam dari rebusan ayam 2 cup"
- "Minyak Wijen 1 sdm"
- "Saus Tiram 1 sdm"
- "Kecap Asin 2 sdm"
- "Garam 2 sdt"
- "Gula 1/2 sdm"
- "Lada Bubuk 1/2 sdt"
- "Bahan Minyak Bawang putih  "
- "Minyak Goreng 75 ml"
- "Bawang Putih 12 siung"
- "Russ Jahe parut 2"
- "Bahan Ayam Hainan  "
- "Secukpnya Ayam bagian apa saja "
- "Garam 1/2 sdm"
- "Gula 1/2 sdm"
- "Bahan Minyak Daun Bawang  "
- "Daun Bawang cincang halus 2 batang"
- "Jahe Parut 1 ruas"
- "Bawang Putih cincang 2 siung"
- "Minyak Goreng 40 ml"
- "Saus Tiram 1 sdm"
- "Garam 1/2 sdm"
- "Gula Pasir 1 sdt"
- "Merica Bubuk 1/2 sdt"
- "Bahan Kuah Kaldu Ayam "
- "Ceker atau tulang ayam 250 gr"
- "Air 2 liter"
- "Bawang Putih 3 siung"
- "Gula garam merica  kaldu bubuk Secukupnya"
- "Bahan Sambal  "
- "Cabai Merah Keriting 8 buah"
- "Cabai Rawit Merah 8 buah"
- "Bawang Putih 6 siung"
- "Gula garam cuka dan air Secukupnya"
- "Pelengkap  "
- "Bawang Goreng Secukupnya"
- "Pokcoy yang direbus sebentar Sesuai Selera"
- "Irisan cabai Secukupnya"
recipeinstructions:
- "Siapkan bahan utama."
- "Rendam dada ayam dengan garam, gula dimakan min 2 jam."
- "Untuk kaldu didihkan air lalu rebus Ceker, tulang, bawang putih dan jahe selama 30 menit."
- "Untuk minyak bawang putih: panaskan minyak lalu masukan jahe bawang putih. Setelah 1/2 kering kecilkan api lalu aduk hingga coklat keemasan. Sisihkan."
- "Cara membuat nasi hainan. Masukan beras yang sudah direndam sebelumnya, air kaldu 1/2 garlic oil, kecap asin, minyak wijen, saus tiram, garam dan merica lalu aduk masak dengan rice cooker hingga matang. Setelah matang, angkat ayam supaya tidak over cook, lalu aduk nasi."
- "Untuk minyak daun bawang, dalam mangkuk campurkan daun bawang, jahe, bawang putih, minyak wijen, saus tiram, gula garam dan merica kemudian siram dengan minyak panas lalu aduk hingga rata."
- "Untuk kuah, tambahkan daun bawang bagian putih, kol, gula, garam, penyedap, merica secukupnya ke dalam kaldu ayam masak hingga kol layu dan kuah berubah menjadi putih."
- "Untuk sambal, blender bawang putih, cabai rawit, cabe merah keriting dan air hingga halus kemudian pindahkan ke dalam pan dan tambahkan cuka, gula garam dan sedikit kuat ayam kemudian masak hingga air sedikit susut."
- "Letakan nasi hainan diatas piring lalu letakan irisan ayam diatasnya kemudian siram dengan minyak bawang putih dan minyak daun bawang. Beri irisan Cabai, bawang goreng diatasnya. Sajikan dengan sambal dan kuah sebagai pelengkap."
categories:
- Resep
tags:
- nasi
- ayam
- hainan

katakunci: nasi ayam hainan 
nutrition: 100 calories
recipecuisine: Indonesian
preptime: "PT36M"
cooktime: "PT44M"
recipeyield: "3"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Ayam Hainan Rice cooker](https://img-global.cpcdn.com/recipes/bf9147c56224dc07/682x484cq65/nasi-ayam-hainan-rice-cooker-foto-resep-utama.webp)

Ingin membuat Nasi Ayam Hainan Rice cooker ? Coba resep berikut ini. Cara memasaknya sangat praktis namun hasilnya gurih dan lezat cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Untuk Pembuatan Nasi Ayam Hainan Rice cooker:

1. Bahan Nasi Hainan  
1. Beras cuci dan rendam 30 menit 2 Cup
1. Air Kaldu Ayam dari rebusan ayam 2 cup
1. Minyak Wijen 1 sdm
1. Saus Tiram 1 sdm
1. Kecap Asin 2 sdm
1. Garam 2 sdt
1. Gula 1/2 sdm
1. Lada Bubuk 1/2 sdt
1. Bahan Minyak Bawang putih  
1. Minyak Goreng 75 ml
1. Bawang Putih 12 siung
1. Russ Jahe parut 2
1. Bahan Ayam Hainan  
1. Secukpnya Ayam bagian apa saja 
1. Garam 1/2 sdm
1. Gula 1/2 sdm
1. Bahan Minyak Daun Bawang  
1. Daun Bawang cincang halus 2 batang
1. Jahe Parut 1 ruas
1. Bawang Putih cincang 2 siung
1. Minyak Goreng 40 ml
1. Saus Tiram 1 sdm
1. Garam 1/2 sdm
1. Gula Pasir 1 sdt
1. Merica Bubuk 1/2 sdt
1. Bahan Kuah Kaldu Ayam 
1. Ceker atau tulang ayam 250 gr
1. Air 2 liter
1. Bawang Putih 3 siung
1. Gula garam merica  kaldu bubuk Secukupnya
1. Bahan Sambal  
1. Cabai Merah Keriting 8 buah
1. Cabai Rawit Merah 8 buah
1. Bawang Putih 6 siung
1. Gula garam cuka dan air Secukupnya
1. Pelengkap  
1. Bawang Goreng Secukupnya
1. Pokcoy yang direbus sebentar Sesuai Selera
1. Irisan cabai Secukupnya

Baca juga: Nasi Hainan, Nasi Gurih Khas Singapura yang Menggugah Selera. Ikuti cara membuat nasi ayam hainan ala Sisca Soewitomo dalam buku &#34;Hidangan Nasi ala Sisca Soewitomo&#34; terbitan Gramedia Pustaka Utama berikut. Resep nasi ayam hainan super simple masak pakai rice cooker. Resep nasi ayam hainan yang selama ini ingin sekali saya buat, akhirnya buat juga dengan versi rice cooker dan rendah lemak (harapannya.he he he). 

<!--inarticleads2-->

## Tata Cara Menyiapkan Nasi Ayam Hainan Rice cooker:

1. Siapkan bahan utama.
1. Rendam dada ayam dengan garam, gula dimakan min 2 jam.
1. Untuk kaldu didihkan air lalu rebus Ceker, tulang, bawang putih dan jahe selama 30 menit.
1. Untuk minyak bawang putih: panaskan minyak lalu masukan jahe bawang putih. Setelah 1/2 kering kecilkan api lalu aduk hingga coklat keemasan. Sisihkan.
1. Cara membuat nasi hainan. Masukan beras yang sudah direndam sebelumnya, air kaldu 1/2 garlic oil, kecap asin, minyak wijen, saus tiram, garam dan merica lalu aduk masak dengan rice cooker hingga matang. Setelah matang, angkat ayam supaya tidak over cook, lalu aduk nasi.
1. Untuk minyak daun bawang, dalam mangkuk campurkan daun bawang, jahe, bawang putih, minyak wijen, saus tiram, gula garam dan merica kemudian siram dengan minyak panas lalu aduk hingga rata.
1. Untuk kuah, tambahkan daun bawang bagian putih, kol, gula, garam, penyedap, merica secukupnya ke dalam kaldu ayam masak hingga kol layu dan kuah berubah menjadi putih.
1. Untuk sambal, blender bawang putih, cabai rawit, cabe merah keriting dan air hingga halus kemudian pindahkan ke dalam pan dan tambahkan cuka, gula garam dan sedikit kuat ayam kemudian masak hingga air sedikit susut.
1. Letakan nasi hainan diatas piring lalu letakan irisan ayam diatasnya kemudian siram dengan minyak bawang putih dan minyak daun bawang. Beri irisan Cabai, bawang goreng diatasnya. Sajikan dengan sambal dan kuah sebagai pelengkap.


Kalau melihat resep-resep yang beredar ya memasak nasi ayam hainan ya menggunakan ayam utuh (tanpa kepala, leher, ceker). Nasi Hainan: Tumis bawang putih, jahe &amp; bombay dengan minyak. Campur tumisan dengan semua bahan nasi (kecuali minyak wijen). Combine sautéed ingredients with all of the rice ingredients (with the exception of sesame oil) &amp; then cook it in a rice cooker. Nasi Ayam Hainan Simple Versi Rice Cooker Dapur Ngepul. 

Selamat memasak dan menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
