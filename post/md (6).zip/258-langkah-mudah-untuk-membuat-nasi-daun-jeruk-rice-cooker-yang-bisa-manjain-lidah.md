---
description: "Langkah Mudah untuk Membuat Nasi Daun Jeruk Rice Cooker yang Bisa Manjain Lidah"
title: "Langkah Mudah untuk Membuat Nasi Daun Jeruk Rice Cooker yang Bisa Manjain Lidah"
slug: 258-langkah-mudah-untuk-membuat-nasi-daun-jeruk-rice-cooker-yang-bisa-manjain-lidah
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-29T10:37:26.170Z 
thumbnail: https://img-global.cpcdn.com/recipes/6b10133cf9e8f26b/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/6b10133cf9e8f26b/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/6b10133cf9e8f26b/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/6b10133cf9e8f26b/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
author: Nancy Hill
ratingvalue: 4
reviewcount: 8
recipeingredient:
- "beras 2 cup"
- "daun jeruk kalo kecil pakai 16 lembar 12 lembar"
- "sereh di memarkan 1 batang"
- "daun salam 3 lembar"
- "margarin  butter 2 sdm"
- "bawang putih saya pakai yg ukurannya lumayan besar 2 buah"
- "Kaldu bubuk secukupnya"
- "Garam secukupnya"
recipeinstructions:
- "Cuci beras seperti hendak memasak nasi biasa, beri airnya sedikit lebih banyak dari biasanya"
- "Iris daun jeruk, buang batangnya"
- "Cincang kasar bawang putih, lalu tumis dengan margarin hingga setengah kering"
- "Masukan tumisan bawang putih bersama margarinnya kedalam rendaman beras, masukan juga daun jeruk, daun salam, sereh, garam, dan kaldu bubuk ke dalam beras, aduk rata, koreksi rasa"
- "Masukan kedalam rice cooker, masak sampai matang, aduk, lalu pencet cook kembali sampai matang lagi"
- "Nasi daun jeruk siap di hidangkan"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 120 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT44M"
recipeyield: "4"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk Rice Cooker](https://img-global.cpcdn.com/recipes/6b10133cf9e8f26b/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp)

Resep rahasia dan cara mengolah  Nasi Daun Jeruk Rice Cooker yang bisa ibu coba dirumah

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Dalam Pembuatan Nasi Daun Jeruk Rice Cooker:

1. beras 2 cup
1. daun jeruk kalo kecil pakai 16 lembar 12 lembar
1. sereh di memarkan 1 batang
1. daun salam 3 lembar
1. margarin  butter 2 sdm
1. bawang putih saya pakai yg ukurannya lumayan besar 2 buah
1. Kaldu bubuk secukupnya
1. Garam secukupnya



<!--inarticleads2-->

## Cara Menyiapkan Nasi Daun Jeruk Rice Cooker:

1. Cuci beras seperti hendak memasak nasi biasa, beri airnya sedikit lebih banyak dari biasanya
1. Iris daun jeruk, buang batangnya
1. Cincang kasar bawang putih, lalu tumis dengan margarin hingga setengah kering
1. Masukan tumisan bawang putih bersama margarinnya kedalam rendaman beras, masukan juga daun jeruk, daun salam, sereh, garam, dan kaldu bubuk ke dalam beras, aduk rata, koreksi rasa
1. Masukan kedalam rice cooker, masak sampai matang, aduk, lalu pencet cook kembali sampai matang lagi
1. Nasi daun jeruk siap di hidangkan




Salah satu kuliner yang cukup praktis dalam pembuatannya adalah  Nasi Daun Jeruk Rice Cooker. Selain itu  Nasi Daun Jeruk Rice Cooker  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu ikuti 6 langkah, dan  Nasi Daun Jeruk Rice Cooker  pun siap di hidangkan. selamat mencoba !
