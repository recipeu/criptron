---
description: "Bagaimana Membuat Nasi daun jeruk magic com yang Lezat"
title: "Bagaimana Membuat Nasi daun jeruk magic com yang Lezat"
slug: 261-bagaimana-membuat-nasi-daun-jeruk-magic-com-yang-lezat
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-10T01:14:57.064Z 
thumbnail: https://img-global.cpcdn.com/recipes/88a2c5b110aa893c/682x484cq65/nasi-daun-jeruk-magic-com-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/88a2c5b110aa893c/682x484cq65/nasi-daun-jeruk-magic-com-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/88a2c5b110aa893c/682x484cq65/nasi-daun-jeruk-magic-com-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/88a2c5b110aa893c/682x484cq65/nasi-daun-jeruk-magic-com-foto-resep-utama.webp
author: Jeremiah Taylor
ratingvalue: 3.6
reviewcount: 6
recipeingredient:
- "beras cuci bersih 1 gelas"
- "daun salam 1 lembar"
- "sereh 1 batang"
- "mentega Secukupnya"
- "garam Secukupnya"
- "kaldu jamur Secukupnya"
- "air Secukupnya"
- "santan kara Sedikit"
- "Bahan iris "
- "bawang putih 1 siung"
- "bawang merah 3 siung"
- "daun jeruk 5 lembar"
recipeinstructions:
- "Tumis bawang putih...bawang merah... Salam..daun jeruk... Lengkuas... Tumis bumbu dengan mentega... Jika sudah wangi... Tambahkan air"
- "Campurkan ke dalam beras yg sudah di bersihkan..tambahkan kaldu jamur, garam dan santan.. Aduk2..."
- "Lalu tutup magic com... Dan tunggu hingga matang"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 114 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT50M"
recipeyield: "4"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi daun jeruk magic com](https://img-global.cpcdn.com/recipes/88a2c5b110aa893c/682x484cq65/nasi-daun-jeruk-magic-com-foto-resep-utama.webp)

Resep dan cara mengolah  Nasi daun jeruk magic com yang wajib ibu coba dirumah

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Dalam Menyiapkan Nasi daun jeruk magic com:

1. beras cuci bersih 1 gelas
1. daun salam 1 lembar
1. sereh 1 batang
1. mentega Secukupnya
1. garam Secukupnya
1. kaldu jamur Secukupnya
1. air Secukupnya
1. santan kara Sedikit
1. Bahan iris 
1. bawang putih 1 siung
1. bawang merah 3 siung
1. daun jeruk 5 lembar

Pada umumnya kita tidak tahu manfaat kandungan daun jeruk,tetapi sangat banya sekali manfaat dan kandungan yang terdapat didalamnya. Secara alami jeruk nipis ini bermanfaat untu obat batuk, menghilangkan dahak (mukolitik), memperlancar kencing (diuretik) dan keringat. Tahu cabe daun jeruk: Karena bosen aja pengen buat masakan tahu yang seger. Disini saya sedang mengurangi konsumsi garam ya bund. 

<!--inarticleads2-->

## Tata Cara Membuat Nasi daun jeruk magic com:

1. Tumis bawang putih...bawang merah... Salam..daun jeruk... Lengkuas... Tumis bumbu dengan mentega... Jika sudah wangi... Tambahkan air
1. Campurkan ke dalam beras yg sudah di bersihkan..tambahkan kaldu jamur, garam dan santan.. Aduk2...
1. Lalu tutup magic com... Dan tunggu hingga matang


COM - Nasi Kuning merupakan olahan nasi yang diberi pewarna alami yang berasal dari kunyit (kuning) warna kunyit yang kuning membuat nasi putih menjadi berwarna kuning, sehingga dinamakan nasi kuning. Nasi kuning biasa di santap dengan pendamping beraneka. Tuang air rebusan ayam yang sudah dipisahkan ke dalam magic com, tambahkan daun salam dan garam secukupnya. Apabila sementara ini kamu cuma mampu membuahkan sebagian dialog saja dalam cerpen tidak masalah kok! Bule ini baru pertamakali liat makanan di bungkus daun sampai dicium 

Terima kasih telah membaca resep yang kami tampilkan di sini. Semoga bermanfaat dan selamat mencoba!
