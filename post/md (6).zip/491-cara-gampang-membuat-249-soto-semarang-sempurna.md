---
description: "Cara Gampang Membuat 249. Soto Semarang, Sempurna"
title: "Cara Gampang Membuat 249. Soto Semarang, Sempurna"
slug: 491-cara-gampang-membuat-249-soto-semarang-sempurna
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-19T07:33:27.993Z 
thumbnail: https://img-global.cpcdn.com/recipes/fc17975d01855c49/682x484cq65/249-soto-semarang-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/fc17975d01855c49/682x484cq65/249-soto-semarang-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/fc17975d01855c49/682x484cq65/249-soto-semarang-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/fc17975d01855c49/682x484cq65/249-soto-semarang-foto-resep-utama.webp
author: Maud Edwards
ratingvalue: 4
reviewcount: 5
recipeingredient:
- "Ayam 250 gram"
- "Air 2 liter"
- "Daun Jeruk 4 lembar"
- "Daun Salam 2 lembar"
- "Sereh geprek 1 batang"
- "Bumbu Halus "
- "Bawang Putih 4 siung"
- "Kunyit 1 ruas"
- "Jahe 1 ruas"
- "Bumbu Lain "
- "Kecap Manis 1 sdm"
- "Daun Bawang potongpotong 1 batang"
- "Bawang Putih Goreng 2 sdm"
- "Bumbu Seasoning "
- "Garam 1 sdm"
- "Gula Jawa 1 sdm"
- "Ketumbar Bubuk 3/4 sdt"
- "Lada 1/2 sdt"
- "Pala Bubuk 1/4 sdt"
- "Kaldu Jamur 1/4 sdt"
- "Sambal "
- "Cabe Rawit rebus 5 buah"
- "Bawang Putih rebus 1 siung"
- "Nasi Putih "
- "Soun seduh air panas "
- "Taoge Pendek seduh air panas "
- "Kubis iris tipis "
- "Jeruk Nipis "
- "Tempe Goreng Garit           lihat resep "
recipeinstructions:
- "Panaskan air sampai mendidih kemudian masukkan ayam. Masukkan bumbu aromatik. Tutup panci, rebus dengan metode 7.30.7.           (lihat tips)"
- "Tumis bumbu halus hingga harum. Tambahkan kecap manis, tumis kembali hingga bumbu matang. Angkat."
- "Masukkan bumbu halus ke dalam air rebusan ayam, aduk rata. Beri seasoning, aduk rata. Masak hingga mendidih. Jangan lupa cek rasa ya Moms :) Jika sudah pas, angkat ayam untuk disuwir. Terakhir, masukkan daun bawang dan bawang putih goreng. Masak sebentar saja, angkat."
- "Ulek bahan sambal. Sisihkan. Siapkan mangkuk saji, tata nasi putih, bihun, kubis, taoge, dan suwiran ayam. Tuang kuah soto."
- "Soto Semarang siap disajikan hangat-hangat dengan sambal, jeruk nipis, dan tempe goreng gurat"
categories:
- Resep
tags:
- 249
- soto
- semarang

katakunci: 249 soto semarang 
nutrition: 174 calories
recipecuisine: Indonesian
preptime: "PT15M"
cooktime: "PT53M"
recipeyield: "3"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![249. Soto Semarang](https://img-global.cpcdn.com/recipes/fc17975d01855c49/682x484cq65/249-soto-semarang-foto-resep-utama.webp)

Ingin membuat 249. Soto Semarang ? Coba resep berikut ini. Cara memasaknya sangat praktis namun jangan kaget jika hasilnya gurih dan lezat yang harus ibu coba dirumah

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Dalam Menyiapkan 249. Soto Semarang:

1. Ayam 250 gram
1. Air 2 liter
1. Daun Jeruk 4 lembar
1. Daun Salam 2 lembar
1. Sereh geprek 1 batang
1. Bumbu Halus 
1. Bawang Putih 4 siung
1. Kunyit 1 ruas
1. Jahe 1 ruas
1. Bumbu Lain 
1. Kecap Manis 1 sdm
1. Daun Bawang potongpotong 1 batang
1. Bawang Putih Goreng 2 sdm
1. Bumbu Seasoning 
1. Garam 1 sdm
1. Gula Jawa 1 sdm
1. Ketumbar Bubuk 3/4 sdt
1. Lada 1/2 sdt
1. Pala Bubuk 1/4 sdt
1. Kaldu Jamur 1/4 sdt
1. Sambal 
1. Cabe Rawit rebus 5 buah
1. Bawang Putih rebus 1 siung
1. Nasi Putih 
1. Soun seduh air panas 
1. Taoge Pendek seduh air panas 
1. Kubis iris tipis 
1. Jeruk Nipis 
1. Tempe Goreng Garit           lihat resep 



<!--inarticleads2-->

## Langkah-langkah Untuk Membuat 249. Soto Semarang:

1. Panaskan air sampai mendidih kemudian masukkan ayam. Masukkan bumbu aromatik. Tutup panci, rebus dengan metode 7.30.7. -           (lihat tips)
1. Tumis bumbu halus hingga harum. Tambahkan kecap manis, tumis kembali hingga bumbu matang. Angkat.
1. Masukkan bumbu halus ke dalam air rebusan ayam, aduk rata. - Beri seasoning, aduk rata. Masak hingga mendidih. Jangan lupa cek rasa ya Moms :) - Jika sudah pas, angkat ayam untuk disuwir. - Terakhir, masukkan daun bawang dan bawang putih goreng. Masak sebentar saja, angkat.
1. Ulek bahan sambal. Sisihkan. Siapkan mangkuk saji, tata nasi putih, bihun, kubis, taoge, dan suwiran ayam. Tuang kuah soto.
1. Soto Semarang siap disajikan hangat-hangat dengan sambal, jeruk nipis, dan tempe goreng gurat




Daripada kamu beli  249. Soto Semarang  diluar terus, ibu  bisa membuatnya sendiri dirumah. Resep  249. Soto Semarang  sederhana ini cukup praktis dalam proses pembuatannya, serta cukup menggunakan bumbu sederhana  249. Soto Semarang  yang enak, bunda nikmati di rumah.
