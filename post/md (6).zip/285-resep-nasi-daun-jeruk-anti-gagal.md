---
description: "Resep Nasi Daun Jeruk Anti Gagal"
title: "Resep Nasi Daun Jeruk Anti Gagal"
slug: 285-resep-nasi-daun-jeruk-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-18T04:50:06.714Z 
thumbnail: https://img-global.cpcdn.com/recipes/012989ebd70ed23e/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/012989ebd70ed23e/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/012989ebd70ed23e/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/012989ebd70ed23e/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
author: Essie Jimenez
ratingvalue: 4.6
reviewcount: 8
recipeingredient:
- "beras 1.5 lt"
- "sereh 1 btg"
- "daun jeruk irisiris 11 lbr"
- "daun pandan 2 lbr"
- "santan kemasan 1 bh"
- "Royco dan garam secukupnya"
recipeinstructions:
- "Cuci bersih beras, lalu masukan sereh, daun jeruk yg sdh di iris-iris, santan, royco dan garam. Lalu colokan rice cooker nya. Tunggu smp bnr2 matang, kl sdh matang bs lgsg diangkat"
- "Masak bahan pelengkap lainnya utk disajikan (kalo saya pakai ayam suwir, sambel goreng kentang ati ayam, soun mangkok cabai hijau dan sambalnya"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 147 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT41M"
recipeyield: "3"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk](https://img-global.cpcdn.com/recipes/012989ebd70ed23e/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp)

Resep Nasi Daun Jeruk  anti gagal dengan 2 langkahmudah dan cepat cocok sekali jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Untuk Menyiapkan Nasi Daun Jeruk:

1. beras 1.5 lt
1. sereh 1 btg
1. daun jeruk irisiris 11 lbr
1. daun pandan 2 lbr
1. santan kemasan 1 bh
1. Royco dan garam secukupnya



<!--inarticleads2-->

## Tata Cara Menyiapkan Nasi Daun Jeruk:

1. Cuci bersih beras, lalu masukan sereh, daun jeruk yg sdh di iris-iris, santan, royco dan garam. Lalu colokan rice cooker nya. Tunggu smp bnr2 matang, kl sdh matang bs lgsg diangkat
1. Masak bahan pelengkap lainnya utk disajikan (kalo saya pakai ayam suwir, sambel goreng kentang ati ayam, soun mangkok cabai hijau dan sambalnya




Daripada ibu beli  Nasi Daun Jeruk  diluar terus, kamu  bisa membuatnya sendiri dirumah. Resep  Nasi Daun Jeruk  sederhana ini cukup praktis dalam proses pembuatannya, serta cukup menggunakan bumbu-bumbu sederhana yang ada di dapur  Nasi Daun Jeruk  yang enak, bunda nikmati di rumah.
