---
description: "Cara Gampang Membuat Nasi Daun Jeruk yang Lezat Sekali"
title: "Cara Gampang Membuat Nasi Daun Jeruk yang Lezat Sekali"
slug: 331-cara-gampang-membuat-nasi-daun-jeruk-yang-lezat-sekali
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-30T01:12:08.646Z 
thumbnail: https://img-global.cpcdn.com/recipes/f2e6a4a0c03e2a36/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/f2e6a4a0c03e2a36/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/f2e6a4a0c03e2a36/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/f2e6a4a0c03e2a36/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
author: Victor Newman
ratingvalue: 4
reviewcount: 7
recipeingredient:
- "beras 2 gelas takar"
- "santan kental 100 ml"
- "garam 1 sdm"
- "sereh geprek 1 batang"
- "daun jeruk sobeksobek 4 lembar"
- "daun jeruk buang tulang daunnya iris tipis 12 lembar"
- "daun salam 2 lembar"
- "Air secukupnya"
recipeinstructions:
- "Cuci bersih beras. Masukkan daun salam, sereh, daun jeruk kemudian tambahkan garam"
- "Tuangkan santan ke dalam beras tadi kemudian tambahkan air sebanyak 2 buku jari dari permukaan beras"
- "Masak hingga matang nasi menggunakan magic com. Setelah nasi matang, tambahkan daun jeruk iris kemudian aduk rata. Tutup kembali tutupnya, biarkan hingga nasi tanak"
- "Ini penampakan nasi setelah tanak. Enak dimakan tanpa lauk juga 😁. Lebih enak dan wangi lagi jika daun jeruknya ditambahkan dari jumlah resep"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 271 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT38M"
recipeyield: "1"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk](https://img-global.cpcdn.com/recipes/f2e6a4a0c03e2a36/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp)

4 langkah cepat memasak  Nasi Daun Jeruk yang harus kamu coba segera

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Dalam Menyiapkan Nasi Daun Jeruk:

1. beras 2 gelas takar
1. santan kental 100 ml
1. garam 1 sdm
1. sereh geprek 1 batang
1. daun jeruk sobeksobek 4 lembar
1. daun jeruk buang tulang daunnya iris tipis 12 lembar
1. daun salam 2 lembar
1. Air secukupnya

Nasi daun jeruk siap dihidangkan dengan. Nasi daun jeruk ini memang sedang tren di kalangan masyarakat Indonesia, banyak sekali kaum muda mudi yang berlomba-lomba membuat makanan nasi putih spesial ini. Nasi daun jeruk ala geprek bensu rekomended buat di coba. Geprek bensu nasi daun jeruk anti mainst. 

<!--inarticleads2-->

## Langkah-langkah Untuk Membuat Nasi Daun Jeruk:

1. Cuci bersih beras. Masukkan daun salam, sereh, daun jeruk kemudian tambahkan garam
1. Tuangkan santan ke dalam beras tadi kemudian tambahkan air sebanyak 2 buku jari dari permukaan beras
1. Masak hingga matang nasi menggunakan magic com. Setelah nasi matang, tambahkan daun jeruk iris kemudian aduk rata. Tutup kembali tutupnya, biarkan hingga nasi tanak
1. Ini penampakan nasi setelah tanak. Enak dimakan tanpa lauk juga 😁. Lebih enak dan wangi lagi jika daun jeruknya ditambahkan dari jumlah resep


Gurih dan wangi dari daun jeruk menambah kelezatan nasi daun jeruk. Nasi dengan campuran daun jeruk yang wangi sedang tren. Hai selamat pagi sahabat CWS, pagi ini saya share resep Nasi Daun Jeruk. Praktis banget karena saya gunakan rice cooker. Rasanya mirip nasi uduk tapi wangiiii. 

Daripada kamu beli  Nasi Daun Jeruk  diluar terus, ibu  bisa membuatnya sendiri dirumah. Resep  Nasi Daun Jeruk  sederhana ini cukup praktis dalam proses pembuatannya, cukup menggunakan bumbu-bumbu sederhana yang ada di dapur  Nasi Daun Jeruk  yang enak, bunda nikmati di rumah.
