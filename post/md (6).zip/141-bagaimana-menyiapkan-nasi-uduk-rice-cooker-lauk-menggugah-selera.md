---
description: "Bagaimana Menyiapkan Nasi Uduk Rice Cooker + Lauk, Menggugah Selera"
title: "Bagaimana Menyiapkan Nasi Uduk Rice Cooker + Lauk, Menggugah Selera"
slug: 141-bagaimana-menyiapkan-nasi-uduk-rice-cooker-lauk-menggugah-selera
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-25T15:34:16.437Z 
thumbnail: https://img-global.cpcdn.com/recipes/5c75a5cecffc3c42/682x484cq65/nasi-uduk-rice-cooker-lauk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/5c75a5cecffc3c42/682x484cq65/nasi-uduk-rice-cooker-lauk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/5c75a5cecffc3c42/682x484cq65/nasi-uduk-rice-cooker-lauk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/5c75a5cecffc3c42/682x484cq65/nasi-uduk-rice-cooker-lauk-foto-resep-utama.webp
author: Flora Hawkins
ratingvalue: 3.6
reviewcount: 15
recipeingredient:
- " Nasi Uduk  "
- "beras 3 cup"
- "air 5 cup"
- "santan instan  sedikit garam atau disesuaikan selera 100 ml"
- "sereh potong lalu geprek 2 batang"
- "daun salam 5 lembar"
- "bawang merah haluskan 4 butir"
- "bawang putih haluskan 2 siung"
- "minyak goreng untuk menumis Secukupnya"
- " Bihun Goreng  "
- "bihun jagung rendam sebentar dengan air panas 1 bungkus"
- "bawang putih iris tipis 2 siung"
- "bawang merah iris tipis 3 siung"
- "bawang putih haluskan 4 siung"
- "bawang merah haluskan 7 siung"
- "telur kocok lepas 2 butir"
- "merica haluskan 1 sdt"
- "kol wortel daun bawang dan seledri rajang halus Secukupnya"
- "air kecap asin gula garam dan kaldu bubuk Secukupnya"
- "minyak sayur untuk menumis Secukupnya"
- " Telur Dadar  "
- "telur kocok lepas 2 butir"
- "air 2 sdm"
- "garam dan sedikit penyedap rasa Secukupnya"
- " Orek Tempe  "
- "tempe iris sesuai selera lalu goreng sebentar 1 papan"
- "bawang putih iris tipis 3 siung"
- "bawang merah iris tipis 5 siung"
- "cabe merah besar iris tipis menyerong 2 buah"
- "cabe merah rawit iris tipis menyerong 5 buah"
- "lengkuas geprek 2 cm"
- "daun salam 4 lembar"
- "air kecap manis gula jawa gula pasir Secukupnya"
- "garam kaldu bubuk air asam jawa Secukupnya"
- " Sambal Tomat Terasi  "
- "bawang merah 5 siung"
- "bawang putih 1 siung"
- "cabe merah besar atau sesuai selera 5 buah"
- "cabe merah rawit atau sesuai selera 9 buah"
- "tomat merah belah menjadi 4 1 buah"
- "terasi sachetan bakar lagi 2 bungkus"
- "gula garam dan penyedap rasa Secukupnya"
- " Tempe Goreng Tepung  "
- "tempe iris tipis sesuai selera 1 papan"
- "bawang putih haluskan 2 siung"
- "ketumbar haluskan 1/2 sdt"
- "lada bubuk 1/2 sdt"
- "telur kocok lepas 1 butir"
- "tepung terigu 125 gr"
- "tepung beras 25 gr"
- "air sedikit gula garam dan kaldu bubuk Secukupnya"
- "minyak sayur untuk menggoreng Secukupnya"
- " Pelengkap  "
- "bawang merah goreng Secukupnya"
recipeinstructions:
- "Untuk nasi uduknya, tumis bawang merah dan bawang putih yang telah di haluskan hingga harum, lalu tambkan air kemudian masukan sereh yang telah di geprek, daun salam, santan + sedikit garam. Aduk hingga tercampur rata dan mendidih. Kemudian tuang rebusan air santan tadi pada beras yang telah di cuci dan di taruh pada ricecooker. Lalu masak hingga matang sambil sesekali di aduk supaya tidak lengket dan santan merata."
- "Untuk bihun goreng tumis bumbu iris hingga harum kemudian masukan bumbu yang telah di haluskan. Aduk hingga tercampur rata dan tanak. Lalu masukan telur, buat orak arik, kemudian tambahkan sedikit air, masukan sayur² an dan aduk hingga sedikit layu. Kemudian masukan bihun jagung yang telah di seduh tadi, aduk cepat sambil tambahkan kecap asin, gula, garam, dan kaldu bubuk. Tes rasa lalu taburi bawang merah goreng. Angkat, sisihkan."
- "Untuk telur dadar, kocok telur, tambahkan sedikit air, garam dan penyedap rasa. Dadar tipis², lalu potong sesuai selera"
- "Untuk orek tempe, tumis bumbu iris hingga harum, tambahkan lengkuas dan daun salam sambil di aduk² masukan potongan tempe. Beri sedikit air, lalu tambahkan kecap manis, gula jawa + pasir, garam, kaldu bubuk, dan sedikit air asam jawa. Aduk semua bahan hingga tercampur rata dan air menyusut."
- "Untuk sambal tomat terasi, goreng duo bawang, duo cabe, dan tomat hingga sedikit layu, lalu pindahkan ke atas cobek, tambahkan terasi, dan secukupnha gula, garam, serta penyedap rasa. Uleg hingga halus dan tes rasa."
- "Untuk tempe goreng tepung, iris tipis tempe sesuai selera lalu sisihkan dulu, lalu haluskan bawang putih dan ketumbar kemudian tambahkan tepung terigu, tepung beras, lada bubuk, kaldu bubuk, garam, sedikit gula, kocokan telur, dan air. Aduk semua bahan hingga tercampur rata dan mengental. Kemudian panaskan minyak, celupkan tempe pada adonan tepung lalu goreng hingga golden brown."
- "▶️ penyelesaian : Taruh nasi uduk pada piring saji lalu taburi bawang merah goreng, beri aneka lauk sesuai selera. Sajikan"
categories:
- Resep
tags:
- nasi
- uduk
- rice

katakunci: nasi uduk rice 
nutrition: 129 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT32M"
recipeyield: "4"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Rice Cooker + Lauk](https://img-global.cpcdn.com/recipes/5c75a5cecffc3c42/682x484cq65/nasi-uduk-rice-cooker-lauk-foto-resep-utama.webp)

Resep dan cara mengolah  Nasi Uduk Rice Cooker + Lauk yang musti kamu coba segera

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Dalam Menyiapkan Nasi Uduk Rice Cooker + Lauk:

1.  Nasi Uduk  
1. beras 3 cup
1. air 5 cup
1. santan instan  sedikit garam atau disesuaikan selera 100 ml
1. sereh potong lalu geprek 2 batang
1. daun salam 5 lembar
1. bawang merah haluskan 4 butir
1. bawang putih haluskan 2 siung
1. minyak goreng untuk menumis Secukupnya
1.  Bihun Goreng  
1. bihun jagung rendam sebentar dengan air panas 1 bungkus
1. bawang putih iris tipis 2 siung
1. bawang merah iris tipis 3 siung
1. bawang putih haluskan 4 siung
1. bawang merah haluskan 7 siung
1. telur kocok lepas 2 butir
1. merica haluskan 1 sdt
1. kol wortel daun bawang dan seledri rajang halus Secukupnya
1. air kecap asin gula garam dan kaldu bubuk Secukupnya
1. minyak sayur untuk menumis Secukupnya
1.  Telur Dadar  
1. telur kocok lepas 2 butir
1. air 2 sdm
1. garam dan sedikit penyedap rasa Secukupnya
1.  Orek Tempe  
1. tempe iris sesuai selera lalu goreng sebentar 1 papan
1. bawang putih iris tipis 3 siung
1. bawang merah iris tipis 5 siung
1. cabe merah besar iris tipis menyerong 2 buah
1. cabe merah rawit iris tipis menyerong 5 buah
1. lengkuas geprek 2 cm
1. daun salam 4 lembar
1. air kecap manis gula jawa gula pasir Secukupnya
1. garam kaldu bubuk air asam jawa Secukupnya
1.  Sambal Tomat Terasi  
1. bawang merah 5 siung
1. bawang putih 1 siung
1. cabe merah besar atau sesuai selera 5 buah
1. cabe merah rawit atau sesuai selera 9 buah
1. tomat merah belah menjadi 4 1 buah
1. terasi sachetan bakar lagi 2 bungkus
1. gula garam dan penyedap rasa Secukupnya
1.  Tempe Goreng Tepung  
1. tempe iris tipis sesuai selera 1 papan
1. bawang putih haluskan 2 siung
1. ketumbar haluskan 1/2 sdt
1. lada bubuk 1/2 sdt
1. telur kocok lepas 1 butir
1. tepung terigu 125 gr
1. tepung beras 25 gr
1. air sedikit gula garam dan kaldu bubuk Secukupnya
1. minyak sayur untuk menggoreng Secukupnya
1.  Pelengkap  
1. bawang merah goreng Secukupnya



<!--inarticleads2-->

## Langkah-langkah Untuk Membuat Nasi Uduk Rice Cooker + Lauk:

1. Untuk nasi uduknya, tumis bawang merah dan bawang putih yang telah di haluskan hingga harum, lalu tambkan air kemudian masukan sereh yang telah di geprek, daun salam, santan + sedikit garam. Aduk hingga tercampur rata dan mendidih. Kemudian tuang rebusan air santan tadi pada beras yang telah di cuci dan di taruh pada ricecooker. Lalu masak hingga matang sambil sesekali di aduk supaya tidak lengket dan santan merata.
1. Untuk bihun goreng tumis bumbu iris hingga harum kemudian masukan bumbu yang telah di haluskan. Aduk hingga tercampur rata dan tanak. Lalu masukan telur, buat orak arik, kemudian tambahkan sedikit air, masukan sayur² an dan aduk hingga sedikit layu. Kemudian masukan bihun jagung yang telah di seduh tadi, aduk cepat sambil tambahkan kecap asin, gula, garam, dan kaldu bubuk. Tes rasa lalu taburi bawang merah goreng. Angkat, sisihkan.
1. Untuk telur dadar, kocok telur, tambahkan sedikit air, garam dan penyedap rasa. Dadar tipis², lalu potong sesuai selera
1. Untuk orek tempe, tumis bumbu iris hingga harum, tambahkan lengkuas dan daun salam sambil di aduk² masukan potongan tempe. Beri sedikit air, lalu tambahkan kecap manis, gula jawa + pasir, garam, kaldu bubuk, dan sedikit air asam jawa. Aduk semua bahan hingga tercampur rata dan air menyusut.
1. Untuk sambal tomat terasi, goreng duo bawang, duo cabe, dan tomat hingga sedikit layu, lalu pindahkan ke atas cobek, tambahkan terasi, dan secukupnha gula, garam, serta penyedap rasa. Uleg hingga halus dan tes rasa.
1. Untuk tempe goreng tepung, iris tipis tempe sesuai selera lalu sisihkan dulu, lalu haluskan bawang putih dan ketumbar kemudian tambahkan tepung terigu, tepung beras, lada bubuk, kaldu bubuk, garam, sedikit gula, kocokan telur, dan air. Aduk semua bahan hingga tercampur rata dan mengental. Kemudian panaskan minyak, celupkan tempe pada adonan tepung lalu goreng hingga golden brown.
1. ▶️ penyelesaian : Taruh nasi uduk pada piring saji lalu taburi bawang merah goreng, beri aneka lauk sesuai selera. Sajikan




Salah satu masakan yang cukup praktis dalam pembuatannya adalah  Nasi Uduk Rice Cooker + Lauk. Selain itu  Nasi Uduk Rice Cooker + Lauk  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu ikuti 7 langkah, dan  Nasi Uduk Rice Cooker + Lauk  pun siap di hidangkan. selamat mencoba !
