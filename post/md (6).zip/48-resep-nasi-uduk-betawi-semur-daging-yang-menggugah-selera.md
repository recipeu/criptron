---
description: "Resep Nasi uduk betawi semur daging yang Menggugah Selera"
title: "Resep Nasi uduk betawi semur daging yang Menggugah Selera"
slug: 48-resep-nasi-uduk-betawi-semur-daging-yang-menggugah-selera
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-19T05:49:08.282Z 
thumbnail: https://img-global.cpcdn.com/recipes/57d82d597c6fffb7/682x484cq65/nasi-uduk-betawi-semur-daging-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/57d82d597c6fffb7/682x484cq65/nasi-uduk-betawi-semur-daging-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/57d82d597c6fffb7/682x484cq65/nasi-uduk-betawi-semur-daging-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/57d82d597c6fffb7/682x484cq65/nasi-uduk-betawi-semur-daging-foto-resep-utama.webp
author: Florence Reese
ratingvalue: 5
reviewcount: 6
recipeingredient:
- "beras me merk cap koki 1 1/2 kg"
- "kelapa parut total air dan perasan kelapa 1500ml peras pisah yang kental dan encer 1 1/2 butir"
- "5 batang serai geprek bagian putih "
- "Daun salam 8 lembar"
- "lengkuas 3 jempol"
- "jahe 2 jempol"
- "garam 2 sdm"
- "Bihun goreng "
- "bihun cap jagung 1 bungkus"
- "kol Irisan"
- "air untuk merebus 1000 ml"
- "bawang putih haluskan 4 siung"
- "bawang merah haluskan 6 siung"
- "merica haluskanpakai yg bubuk 1/2 sdt"
- "kaldu jamur Secukupnya"
- "garam Secukupnya"
- "kecap manis sesuaikan ingin warna cokelat atau gelap Secukupnya"
- "Minyak untuk menumis "
- "Pelengkap "
- "Bawang goreng "
- "Orek tempe kering me skip "
- "Sambel kacang resep menyusul "
- "Bakwan sayur crispy "
- "Emping goreng "
recipeinstructions:
- "Cara nasi uduk: Cuci bersih beras, lalu tiriskan. Siapkan panci menanak nasi didihkan, setelah mendidih masukkan beras kukus kurang lebih 24menit hingga kaku."
- "Didihkan perasan santan&amp;air 1500ml, masukkan serai,daun salam lengkuas, jahe, dan garam. Api sedang aduk terus hingga mendidih, koreksi rasa (hingga asin, karena beras/nasi itu kan manis ya jd sesuaikan tingkat kegurihan nasi uduknya)."
- "Setelah mendidih dan wangi, ambil santan 350ml sisihkan. Masukkan beras yg sudah dikukus, aduk merata bersamaan dengan santan. Hingga menyusut, jika dirasa kurang air tambahkan sisa santan yg tadi disisihkan. Lalu kukus kembali, dengan kukusan dan air dipanci sesuaikan ya. Kukus hingga matang kurang lebih 30menit. Nasi uduk wangi siap dihidangkan😋"
- "Bihun goreng: Rebus air dan beri 2sdm minyak, masukkan bihun rebus hingga lunak angkat dan tiriskan. Panaskan minyak, tumis bumbu halus hingga wangi. Tambahkan irisan ko dan beri air putih, lalu tambahkan garam kaldu dan kecap aduk hingga kol layu. Air menyusut dan koreksi rasa lalu hidangkan dengan nasi uduk😋 Penampakan foto dengan orek (tempe, ini pembuatan sebelumnya😬)"
- "Cara penyajian: Tata nasi pada piring yang sdh diberi alas daun, beri bihun goreng, semur daging, bakwan sayur, sambel kacang dan emping. (Biasanya aku pakai orek tempe, kali ini mau yg cpt aja masaknya jadi skip orek tempenya😃). Selamat mencoba😋❣️"
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 261 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT36M"
recipeyield: "3"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi uduk betawi semur daging](https://img-global.cpcdn.com/recipes/57d82d597c6fffb7/682x484cq65/nasi-uduk-betawi-semur-daging-foto-resep-utama.webp)

Resep rahasia Nasi uduk betawi semur daging  sederhana dengan 5 langkahmudah dan cepat yang wajib ibu coba segera

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Untuk Pembuatan Nasi uduk betawi semur daging:

1. beras me merk cap koki 1 1/2 kg
1. kelapa parut total air dan perasan kelapa 1500ml peras pisah yang kental dan encer 1 1/2 butir
1. 5 batang serai geprek bagian putih 
1. Daun salam 8 lembar
1. lengkuas 3 jempol
1. jahe 2 jempol
1. garam 2 sdm
1. Bihun goreng 
1. bihun cap jagung 1 bungkus
1. kol Irisan
1. air untuk merebus 1000 ml
1. bawang putih haluskan 4 siung
1. bawang merah haluskan 6 siung
1. merica haluskanpakai yg bubuk 1/2 sdt
1. kaldu jamur Secukupnya
1. garam Secukupnya
1. kecap manis sesuaikan ingin warna cokelat atau gelap Secukupnya
1. Minyak untuk menumis 
1. Pelengkap 
1. Bawang goreng 
1. Orek tempe kering me skip 
1. Sambel kacang resep menyusul 
1. Bakwan sayur crispy 
1. Emping goreng 

Sedangkan untuk lauk pauk pelengkapnya dapat pula. Semur daging Betawi adalah varian semur asli Nusantara yang kaya rasa. Selain manis, ada rasa gurih, serta rasa yang khas dari jintan dan kemiri. Anda bisa menyajikannya untuk kumpul keluarga di rumah terlebih di bulan Ramadan ini. 

<!--inarticleads2-->

## Langkah-langkah Untuk Menyiapkan Nasi uduk betawi semur daging:

1. Cara nasi uduk: Cuci bersih beras, lalu tiriskan. Siapkan panci menanak nasi didihkan, setelah mendidih masukkan beras kukus kurang lebih 24menit hingga kaku.
1. Didihkan perasan santan&amp;air 1500ml, masukkan serai,daun salam lengkuas, jahe, dan garam. Api sedang aduk terus hingga mendidih, koreksi rasa (hingga asin, karena beras/nasi itu kan manis ya jd sesuaikan tingkat kegurihan nasi uduknya).
1. Setelah mendidih dan wangi, ambil santan 350ml sisihkan. Masukkan beras yg sudah dikukus, aduk merata bersamaan dengan santan. Hingga menyusut, jika dirasa kurang air tambahkan sisa santan yg tadi disisihkan. Lalu kukus kembali, dengan kukusan dan air dipanci sesuaikan ya. Kukus hingga matang kurang lebih 30menit. Nasi uduk wangi siap dihidangkan😋
1. Bihun goreng: Rebus air dan beri 2sdm minyak, masukkan bihun rebus hingga lunak angkat dan tiriskan. Panaskan minyak, tumis bumbu halus hingga wangi. Tambahkan irisan ko dan beri air putih, lalu tambahkan garam kaldu dan kecap aduk hingga kol layu. Air menyusut dan koreksi rasa lalu hidangkan dengan nasi uduk😋 Penampakan foto dengan orek (tempe, ini pembuatan sebelumnya😬)
1. Cara penyajian: Tata nasi pada piring yang sdh diberi alas daun, beri bihun goreng, semur daging, bakwan sayur, sambel kacang dan emping. (Biasanya aku pakai orek tempe, kali ini mau yg cpt aja masaknya jadi skip orek tempenya😃). Selamat mencoba😋❣️


Sajikan menu ini dengan nasi uduk sebagai paduan sempurna. Nasi Uduk Betawi - Betawi merupakan suku asli warga jakarta, Betawi terkenal dengan budaya serta makanan nya, salah satu makanan khas betawi yang Selain untuk di konsumsi sendiri, resep nasi uduk betawi bisa juga dipergunakan untuk jualan. Hal ini dikarenakan rasanya yang tidak diragukan. Uduk (Javanese: segá uduk; Indonesian: &#34;nasi uduk&#34;) is an Indonesian style steamed rice cooked in coconut milk dish, which originated from Java. Tahu putih•Kentang•Bawang bombay cincang•kayu manis•Cengkeh•Jinten•Bubuk pala•Kecap manis. 

Selamat memasak dan menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
