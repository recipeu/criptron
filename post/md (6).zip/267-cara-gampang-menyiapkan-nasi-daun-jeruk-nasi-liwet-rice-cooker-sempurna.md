---
description: "Cara Gampang Menyiapkan Nasi Daun Jeruk/Nasi Liwet Rice Cooker, Sempurna"
title: "Cara Gampang Menyiapkan Nasi Daun Jeruk/Nasi Liwet Rice Cooker, Sempurna"
slug: 267-cara-gampang-menyiapkan-nasi-daun-jeruk-nasi-liwet-rice-cooker-sempurna
future: true
lang: id
language: id
languageCode: id
publishDate: 2022-01-03T12:45:58.777Z 
thumbnail: https://img-global.cpcdn.com/recipes/2eafaacd40924097/682x484cq65/nasi-daun-jeruknasi-liwet-rice-cooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/2eafaacd40924097/682x484cq65/nasi-daun-jeruknasi-liwet-rice-cooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/2eafaacd40924097/682x484cq65/nasi-daun-jeruknasi-liwet-rice-cooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/2eafaacd40924097/682x484cq65/nasi-daun-jeruknasi-liwet-rice-cooker-foto-resep-utama.webp
author: Rebecca Hunt
ratingvalue: 3.2
reviewcount: 12
recipeingredient:
- "Beras 1,5 cup"
- "Santan 1 gelas"
- "mentega 1/2 sdm"
- "Bahan lainnya "
- "Bawang putih 2 siung"
- "Lengkuas Geprek 3 cm"
- "sereh geprek 2 batang"
- "daun salam 2 lembar"
- "daun jeruk buang tulang daun 6 lembar"
- "Garam secukupnya"
- "Penyedap rasa secukupnya"
recipeinstructions:
- "Cincang bawang putih, dan siapkan bahan lainnya"
- "Tumis bawang putih bersama mentega, masukkan Lengkuas dan Sereh. Tumis jgn sampai gosong. Hanya sampai wangi.Lalu beri Air"
- "Cuci Beras sampai bersih"
- "Masukkan bahan yg sudah ditumis beserta minyak dr mentega, daun salam dan daun jeruk yang dibuang tulang daunnya. Beri santan. Perhatikan batas takaran air (seperti masak nasi biasa, disesuaikan dengan jenis beras)"
- "Masukkan penyedap rasa (me : royco rasa sapi) dan garam. Koreksi rasa."
- "Lalu masak nasi dengan rice cooker hingga matang. Saat setelah matang jgn lupa diaduk perlahan. Tutup kembali rice cooker hinggal matang sempurna"
categories:
- Resep
tags:
- nasi
- daun
- jeruknasi

katakunci: nasi daun jeruknasi 
nutrition: 102 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT58M"
recipeyield: "3"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk/Nasi Liwet Rice Cooker](https://img-global.cpcdn.com/recipes/2eafaacd40924097/682x484cq65/nasi-daun-jeruknasi-liwet-rice-cooker-foto-resep-utama.webp)

Ingin membuat Nasi Daun Jeruk/Nasi Liwet Rice Cooker ? Coba resep berikut ini. Cara memasaknya sangat praktis namun hasilnya gurih dan lezat yang bisa ibu coba segera

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Untuk Menyiapkan Nasi Daun Jeruk/Nasi Liwet Rice Cooker:

1. Beras 1,5 cup
1. Santan 1 gelas
1. mentega 1/2 sdm
1. Bahan lainnya 
1. Bawang putih 2 siung
1. Lengkuas Geprek 3 cm
1. sereh geprek 2 batang
1. daun salam 2 lembar
1. daun jeruk buang tulang daun 6 lembar
1. Garam secukupnya
1. Penyedap rasa secukupnya



<!--inarticleads2-->

## Cara Mudah Menyiapkan Nasi Daun Jeruk/Nasi Liwet Rice Cooker:

1. Cincang bawang putih, dan siapkan bahan lainnya
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/5811700468452afd/160x128cq70/nasi-daun-jeruknasi-liwet-rice-cooker-langkah-memasak-1-foto.webp" alt="Nasi Daun Jeruk/Nasi Liwet Rice Cooker" width="340" height="340">
>1. Tumis bawang putih bersama mentega, masukkan Lengkuas dan Sereh. Tumis jgn sampai gosong. Hanya sampai wangi.Lalu beri Air
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/9f40e72a708b4d63/160x128cq70/nasi-daun-jeruknasi-liwet-rice-cooker-langkah-memasak-2-foto.webp" alt="Nasi Daun Jeruk/Nasi Liwet Rice Cooker" width="340" height="340">
>1. Cuci Beras sampai bersih
1. Masukkan bahan yg sudah ditumis beserta minyak dr mentega, daun salam dan daun jeruk yang dibuang tulang daunnya. Beri santan. Perhatikan batas takaran air (seperti masak nasi biasa, disesuaikan dengan jenis beras)
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/c1e6d55f20487df2/160x128cq70/nasi-daun-jeruknasi-liwet-rice-cooker-langkah-memasak-4-foto.webp" alt="Nasi Daun Jeruk/Nasi Liwet Rice Cooker" width="340" height="340">
>1. Masukkan penyedap rasa (me : royco rasa sapi) dan garam. Koreksi rasa.
1. Lalu masak nasi dengan rice cooker hingga matang. Saat setelah matang jgn lupa diaduk perlahan. Tutup kembali rice cooker hinggal matang sempurna
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/4846576fd0c53656/160x128cq70/nasi-daun-jeruknasi-liwet-rice-cooker-langkah-memasak-6-foto.webp" alt="Nasi Daun Jeruk/Nasi Liwet Rice Cooker" width="340" height="340">
>



Selamat memasak dan menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
