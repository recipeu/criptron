---
description: "Resep Nasi uduk dan soto tangkar, berasa balik ke Jakarta 😋, Bisa Manjain Lidah"
title: "Resep Nasi uduk dan soto tangkar, berasa balik ke Jakarta 😋, Bisa Manjain Lidah"
slug: 33-resep-nasi-uduk-dan-soto-tangkar-berasa-balik-ke-jakarta-bisa-manjain-lidah
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-22T20:34:41.546Z 
thumbnail: https://img-global.cpcdn.com/recipes/7ba04ffa12c82996/682x484cq65/nasi-uduk-dan-soto-tangkar-berasa-balik-ke-jakarta-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/7ba04ffa12c82996/682x484cq65/nasi-uduk-dan-soto-tangkar-berasa-balik-ke-jakarta-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/7ba04ffa12c82996/682x484cq65/nasi-uduk-dan-soto-tangkar-berasa-balik-ke-jakarta-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/7ba04ffa12c82996/682x484cq65/nasi-uduk-dan-soto-tangkar-berasa-balik-ke-jakarta-foto-resep-utama.webp
author: Claudia Horton
ratingvalue: 3.1
reviewcount: 3
recipeingredient:
- "daging sapi potong dady 500 gr"
- "santan kental 200 ml"
- "susu 500 ml"
- "air 500 ml"
- "tomat potong 1-2 buah"
- "Bumbu halus soto "
- "lengkuas iris atau geprek 2 cm"
- "jahe iris 2 cm"
- "bawang merah uk Besar 6 butir"
- "bawang putih 4 siung"
- "cabe merah besar buang biji 2 buah"
- "kunyit bubuk 1 sdt"
- "kemiri sangrai 5 butir"
- "ketumbar 2 sdt"
- "Bumbu Tumis soto "
- "serai geprek dan ikat simpul 1 buah"
- "daun salam 3 lembar"
- "daun jeruk 5 lembar"
- "kayu manis 5cm 1 batang"
- "Bumbu soto "
- "gula 1 sdm"
- "garam 1/2 sdm"
- "lada putih 1/2 sdt"
- "kaldu sapi bubuk 1 sdt"
- "Pelengkap "
- "Nasi uduk           lihat resep "
- "Sambal cabe bawang putih resep nyusul "
- "Jeruk limau "
- "Bawang goreng "
- "Kecap manis "
recipeinstructions:
- "Rebus daging sapi selama 5 menit dengan air mendidih lalu buang airnya. Lalu kita slow cook selama 3 jam (atau gunakan pressure cooker 30 menit). Tuang air dan daging sapi ke panci lain setelah 3 jam."
- "Haluskan bumbu (aku pake hand mixer) dengan 100 ml air lalu kita tumis sampai harum dengan 2 sdm minyak. Saat ditumis masukkan kayu manis, daun jeruk, daun salam dan serai. Tumis sampai matang (sekitar 10 menit) dengan api kecil"
- "Masukkan bumbu halus, santan, air kaldu sapi dan susu ke rebusan daging sapi. Biarkan sampai mendidih lalu kecilkan api, lalu diamkan selama 25 menit. Masukkan tomat terakhir dan biarkan selama 5 menit."
- "Matikan api, baru kasih garam, gula, dll. Cicipi rasanya."
- "Tuang ke mangkok lalu beri perasan jeruk nipis, kecap dan taburan bawang goreng"
- "Sajikan sama nasi uduk, ditaburi bawang goreng"
categories:
- Resep
tags:
- nasi
- uduk
- dan

katakunci: nasi uduk dan 
nutrition: 176 calories
recipecuisine: Indonesian
preptime: "PT38M"
cooktime: "PT50M"
recipeyield: "4"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi uduk dan soto tangkar, berasa balik ke Jakarta 😋](https://img-global.cpcdn.com/recipes/7ba04ffa12c82996/682x484cq65/nasi-uduk-dan-soto-tangkar-berasa-balik-ke-jakarta-foto-resep-utama.webp)

Ingin membuat Nasi uduk dan soto tangkar, berasa balik ke Jakarta 😋 ? Coba resep berikut ini. Cara memasaknya sangat praktis namun hasilnya gurih dan lezat cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Untuk Menyiapkan Nasi uduk dan soto tangkar, berasa balik ke Jakarta 😋:

1. daging sapi potong dady 500 gr
1. santan kental 200 ml
1. susu 500 ml
1. air 500 ml
1. tomat potong 1-2 buah
1. Bumbu halus soto 
1. lengkuas iris atau geprek 2 cm
1. jahe iris 2 cm
1. bawang merah uk Besar 6 butir
1. bawang putih 4 siung
1. cabe merah besar buang biji 2 buah
1. kunyit bubuk 1 sdt
1. kemiri sangrai 5 butir
1. ketumbar 2 sdt
1. Bumbu Tumis soto 
1. serai geprek dan ikat simpul 1 buah
1. daun salam 3 lembar
1. daun jeruk 5 lembar
1. kayu manis 5cm 1 batang
1. Bumbu soto 
1. gula 1 sdm
1. garam 1/2 sdm
1. lada putih 1/2 sdt
1. kaldu sapi bubuk 1 sdt
1. Pelengkap 
1. Nasi uduk           lihat resep 
1. Sambal cabe bawang putih resep nyusul 
1. Jeruk limau 
1. Bawang goreng 
1. Kecap manis 

Selain soto betawi, kota Jakarta juga memiliki soto tangkar yang tak kalah lezat. Santan yang dipakai juga tidak sekental soto Betawi, sehingga rasanya jauh lebih ringan dan tidak. Aplikasi Mobilitas Perkotaan Paling Populer di Jakarta. Semua opsi mobilitas lokal dalam satu aplikasi. 

<!--inarticleads2-->

## Cara Membuat Nasi uduk dan soto tangkar, berasa balik ke Jakarta 😋:

1. Rebus daging sapi selama 5 menit dengan air mendidih lalu buang airnya. Lalu kita slow cook selama 3 jam (atau gunakan pressure cooker 30 menit). Tuang air dan daging sapi ke panci lain setelah 3 jam.
1. Haluskan bumbu (aku pake hand mixer) dengan 100 ml air lalu kita tumis sampai harum dengan 2 sdm minyak. Saat ditumis masukkan kayu manis, daun jeruk, daun salam dan serai. Tumis sampai matang (sekitar 10 menit) dengan api kecil
1. Masukkan bumbu halus, santan, air kaldu sapi dan susu ke rebusan daging sapi. Biarkan sampai mendidih lalu kecilkan api, lalu diamkan selama 25 menit. Masukkan tomat terakhir dan biarkan selama 5 menit.
1. Matikan api, baru kasih garam, gula, dll. Cicipi rasanya.
1. Tuang ke mangkok lalu beri perasan jeruk nipis, kecap dan taburan bawang goreng
1. Sajikan sama nasi uduk, ditaburi bawang goreng


Transportasi Umum ke Soto tangkar bang edi Moovit menyediakan peta gratis dan panduan langsung untuk membantumu bepergian di kotamu. Melihat jadwal, rute, jadwal waktu dan mencari. Soto tangkar ada sejak zaman penjajahan Belanda, lahir karena daging berkualitas untuk penjajah, tetapi tangkar dan jeroan untuk penduduk Indonesia. Tak itu saja, soto tangkar sebagai bagian dari kuliner Betawi juga mengalami percampuran budaya antara banyak bangsa yang datang ke Betawi. HIDANGAN soto tangkar pas sekali disantap untuk makan siang atau makan malam dengan teman kantor. 

Demikian informasi  resep Nasi uduk dan soto tangkar, berasa balik ke Jakarta 😋   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
