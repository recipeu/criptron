---
description: "Resep Nasi Uduk Rice Cooker yang Lezat"
title: "Resep Nasi Uduk Rice Cooker yang Lezat"
slug: 197-resep-nasi-uduk-rice-cooker-yang-lezat
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-10T06:05:51.780Z 
thumbnail: https://img-global.cpcdn.com/recipes/e5492402b426fa2f/682x484cq65/nasi-uduk-rice-cooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/e5492402b426fa2f/682x484cq65/nasi-uduk-rice-cooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/e5492402b426fa2f/682x484cq65/nasi-uduk-rice-cooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/e5492402b426fa2f/682x484cq65/nasi-uduk-rice-cooker-foto-resep-utama.webp
author: Ollie Singleton
ratingvalue: 3.1
reviewcount: 11
recipeingredient:
- "beras aslinya 4 cup 3 cup"
- "santan aslinya 3 cangkir 4 cup"
- "serai memarkan 3 batang"
- "daun salam 5 lembar"
- "daun pandan simpulkan 2 lembar"
- "garam 1 sdt"
- "kaldu jamur 1/2 sdt"
- "bunga telang 25 kuntum"
recipeinstructions:
- "Seduh bunga Telang bersama air panas. Saring Sisihkan.(Air +- 500ml)"
- "Cuci beras. Siapkan daun salam, daun pandan, serai, garam dan kaldu jamur. Masukan kedalam beras."
- "Campurkan air Telang dengan santan instan. Kemudian tuangkan dalam wadah rice cooker sesuai kebutuhan ya. Saya dengan takaran biasa 3 cup beras airnya 4 cup, dengan cup yang sama. Nyalakan rice cooker tunggu matang. Setelah matang aduk, kemudian tes rasa."
- "Biarkan rice cooker dalam mode warm sekitar 15 menit. Buka kembali kemudian ambil daun-daun nya. Sajikan dengan pelengkap."
categories:
- Resep
tags:
- nasi
- uduk
- rice

katakunci: nasi uduk rice 
nutrition: 299 calories
recipecuisine: Indonesian
preptime: "PT20M"
cooktime: "PT30M"
recipeyield: "2"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Rice Cooker](https://img-global.cpcdn.com/recipes/e5492402b426fa2f/682x484cq65/nasi-uduk-rice-cooker-foto-resep-utama.webp)

4 langkah cepat mengolah  Nasi Uduk Rice Cooker cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Dalam Pembuatan Nasi Uduk Rice Cooker:

1. beras aslinya 4 cup 3 cup
1. santan aslinya 3 cangkir 4 cup
1. serai memarkan 3 batang
1. daun salam 5 lembar
1. daun pandan simpulkan 2 lembar
1. garam 1 sdt
1. kaldu jamur 1/2 sdt
1. bunga telang 25 kuntum



<!--inarticleads2-->

## Tata Cara Menyiapkan Nasi Uduk Rice Cooker:

1. Seduh bunga Telang bersama air panas. Saring Sisihkan.(Air +- 500ml)
1. Cuci beras. Siapkan daun salam, daun pandan, serai, garam dan kaldu jamur. Masukan kedalam beras.
1. Campurkan air Telang dengan santan instan. Kemudian tuangkan dalam wadah rice cooker sesuai kebutuhan ya. Saya dengan takaran biasa 3 cup beras airnya 4 cup, dengan cup yang sama. Nyalakan rice cooker tunggu matang. Setelah matang aduk, kemudian tes rasa.
1. Biarkan rice cooker dalam mode warm sekitar 15 menit. Buka kembali kemudian ambil daun-daun nya. Sajikan dengan pelengkap.




Terima kasih telah membaca resep yang kami tampilkan di sini. Selamat mencoba!
