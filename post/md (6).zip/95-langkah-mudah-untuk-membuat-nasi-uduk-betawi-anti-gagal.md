---
description: "Langkah Mudah untuk Membuat Nasi Uduk Betawi Anti Gagal"
title: "Langkah Mudah untuk Membuat Nasi Uduk Betawi Anti Gagal"
slug: 95-langkah-mudah-untuk-membuat-nasi-uduk-betawi-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-20T04:12:10.544Z 
thumbnail: https://img-global.cpcdn.com/recipes/0b02f9d62b2229d6/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/0b02f9d62b2229d6/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/0b02f9d62b2229d6/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/0b02f9d62b2229d6/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
author: Effie Ramos
ratingvalue: 3.8
reviewcount: 11
recipeingredient:
- "beras cuci bersih 800 gr"
- "kara 65ml lebih bagus lagi santan fresh dari kelapa tua 1 sachet"
- "bawang merah 8 siung"
- "bawang putih 3 siung"
- "sereh geprek bagian putihnya biat simpul 2 btg"
- "ruas lengkuas geprek 3 iris"
- "daun salam 3 lmbr"
- "daun jeruk sobek2 6 lmbr"
- "garam Secukupnya"
- "kaldu jamur  bubuk Secukupnya"
- "air masak Secukupnya"
recipeinstructions:
- "Haluskan bawang merah &amp; putih."
- "Siapkan panci rice cooker, bisa juga dengan panci biasa. masukkan semua bahan. Tambahkan air masak 1ruas jari, dari atas permukaan beras. Sesuaikan air dengan beras masing2 ya. Karena setiap beras beda kebutuhan airnya."
- "Tambahkan air masak dengan ketinggian sampai 1ruas jari diatas beras. Sesuaikan beras masing2 &amp; keperluan air saat memasak nasi ya, karena setiap beras. Masak sampai matang. Sajikan dengan menu pelengkap sesuai selera."
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 243 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT59M"
recipeyield: "4"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Betawi](https://img-global.cpcdn.com/recipes/0b02f9d62b2229d6/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp)

3 langkah mudah membuat  Nasi Uduk Betawi yang musti bunda coba dirumah

<!--inarticleads1-->

## Bahan-bahan Yang Dibutuhkan Untuk Pembuatan Nasi Uduk Betawi:

1. beras cuci bersih 800 gr
1. kara 65ml lebih bagus lagi santan fresh dari kelapa tua 1 sachet
1. bawang merah 8 siung
1. bawang putih 3 siung
1. sereh geprek bagian putihnya biat simpul 2 btg
1. ruas lengkuas geprek 3 iris
1. daun salam 3 lmbr
1. daun jeruk sobek2 6 lmbr
1. garam Secukupnya
1. kaldu jamur  bubuk Secukupnya
1. air masak Secukupnya



<!--inarticleads2-->

## Tata Cara Menyiapkan Nasi Uduk Betawi:

1. Haluskan bawang merah &amp; putih.
1. Siapkan panci rice cooker, bisa juga dengan panci biasa. masukkan semua bahan. Tambahkan air masak 1ruas jari, dari atas permukaan beras. Sesuaikan air dengan beras masing2 ya. Karena setiap beras beda kebutuhan airnya.
1. Tambahkan air masak dengan ketinggian sampai 1ruas jari diatas beras. Sesuaikan beras masing2 &amp; keperluan air saat memasak nasi ya, karena setiap beras. Masak sampai matang. Sajikan dengan menu pelengkap sesuai selera.




Demikian informasi  resep Nasi Uduk Betawi   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
