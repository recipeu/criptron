---
description: "Bagaimana Membuat Rice Bowl Ayam Gongso, Bikin Ngiler"
title: "Bagaimana Membuat Rice Bowl Ayam Gongso, Bikin Ngiler"
slug: 474-bagaimana-membuat-rice-bowl-ayam-gongso-bikin-ngiler
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-12T23:16:15.422Z 
thumbnail: https://img-global.cpcdn.com/recipes/490db79f45b52317/682x484cq65/rice-bowl-ayam-gongso-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/490db79f45b52317/682x484cq65/rice-bowl-ayam-gongso-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/490db79f45b52317/682x484cq65/rice-bowl-ayam-gongso-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/490db79f45b52317/682x484cq65/rice-bowl-ayam-gongso-foto-resep-utama.webp
author: Claudia Haynes
ratingvalue: 3.3
reviewcount: 10
recipeingredient:
- "dada ayam 300 gr"
- "kol potongpotong 50 gr"
- "tomat kecil potongpotong 2 buah"
- "cabe rawit utuh sesuai selera 5 buah"
- "cabe merah iris serong 2 buah"
- "Nasi putih 1 mangkuk"
- "telur ceplok 12 matang 1 butir"
- "daun salam 2 lembar"
- "lengkuas geprek 1 ruas"
- "lada bubuk 1 sdt"
- "garam 1/2 sdt"
- "kaldu jamurpenyedap 1 sdt"
- "kecap manis 3 sdm"
- "air 200 ml"
- "Minyak goreng "
- "Bumbu halus "
- "bawang putih 4 siung"
- "bawang merah 2 siung"
- "kemiri 2 butir"
- "cabe rawit 1 buah"
recipeinstructions:
- "Bersihkan dada ayam, rebus selama 10 menit, angkat dan tiriskan, potong dadu/suwir-suwir, sisihkan."
- "Tumis bumbu halus sampai wangi, tambahkan salam dan lengkuas, masukkan ayam suwir aduk, bumbui kecap, garam, lada dan penyedap."
- "Tuang air, masukkan kol, cabe rawit dan tomat aduk rata, masak sampai bumbu meresap dan kuah menyusut. Koreksi rasa."
- "Sajikan dengan nasi hangat dan telur ceplok 1/2 matang. Selamat menikmati. 😊"
categories:
- Resep
tags:
- rice
- bowl
- ayam

katakunci: rice bowl ayam 
nutrition: 285 calories
recipecuisine: Indonesian
preptime: "PT24M"
cooktime: "PT49M"
recipeyield: "2"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Rice Bowl Ayam Gongso](https://img-global.cpcdn.com/recipes/490db79f45b52317/682x484cq65/rice-bowl-ayam-gongso-foto-resep-utama.webp)

4 langkah cepat dan mudah mengolah  Rice Bowl Ayam Gongso cocok sekali jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Dalam Pembuatan Rice Bowl Ayam Gongso:

1. dada ayam 300 gr
1. kol potongpotong 50 gr
1. tomat kecil potongpotong 2 buah
1. cabe rawit utuh sesuai selera 5 buah
1. cabe merah iris serong 2 buah
1. Nasi putih 1 mangkuk
1. telur ceplok 12 matang 1 butir
1. daun salam 2 lembar
1. lengkuas geprek 1 ruas
1. lada bubuk 1 sdt
1. garam 1/2 sdt
1. kaldu jamurpenyedap 1 sdt
1. kecap manis 3 sdm
1. air 200 ml
1. Minyak goreng 
1. Bumbu halus 
1. bawang putih 4 siung
1. bawang merah 2 siung
1. kemiri 2 butir
1. cabe rawit 1 buah



<!--inarticleads2-->

## Langkah-langkah Untuk Menyiapkan Rice Bowl Ayam Gongso:

1. Bersihkan dada ayam, rebus selama 10 menit, angkat dan tiriskan, potong dadu/suwir-suwir, sisihkan.
1. Tumis bumbu halus sampai wangi, tambahkan salam dan lengkuas, masukkan ayam suwir aduk, bumbui kecap, garam, lada dan penyedap.
1. Tuang air, masukkan kol, cabe rawit dan tomat aduk rata, masak sampai bumbu meresap dan kuah menyusut. Koreksi rasa.
1. Sajikan dengan nasi hangat dan telur ceplok 1/2 matang. Selamat menikmati. 😊




Selamat memasak dan menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
