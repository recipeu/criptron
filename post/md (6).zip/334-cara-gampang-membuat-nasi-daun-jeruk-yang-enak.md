---
description: "Cara Gampang Membuat Nasi daun jeruk yang Enak"
title: "Cara Gampang Membuat Nasi daun jeruk yang Enak"
slug: 334-cara-gampang-membuat-nasi-daun-jeruk-yang-enak
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-18T09:12:27.773Z 
thumbnail: https://img-global.cpcdn.com/recipes/31e23fe7e0925b93/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/31e23fe7e0925b93/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/31e23fe7e0925b93/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/31e23fe7e0925b93/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
author: Herbert Moore
ratingvalue: 4.8
reviewcount: 3
recipeingredient:
- "Bahan "
- "beras 1 kg"
- "Santan 200 cc"
- "bawang putih kecil 5"
- "bawang merah kecil 4"
- "daun salam 2"
- "daun jeruk blender 10"
- "daun jeruk iris tipis 10"
- "Daun suci secukupnya blender ambil sarinya sbg pewarna "
- "Garam "
recipeinstructions:
- "Cuci beras sampai bersih. Set di magic com, masukkan bawang merah bawang putih, salam, serai, daun jeruk yg diblender, n air daun suci, trs masukkan santan n tambah air dikit, n garam sesuai selera. Takaran air n santan satu ruas jari lebih dikit. Tutup magic com, jgn lupa di ceklekin... (aq pernah lupa, hahaha) Kl uda matang, aduk2, icipi, trs tabur daun jeruk irisan tipis, aduk2 lagi, trs tutup lagi."
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 243 calories
recipecuisine: Indonesian
preptime: "PT39M"
cooktime: "PT40M"
recipeyield: "2"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi daun jeruk](https://img-global.cpcdn.com/recipes/31e23fe7e0925b93/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp)

Ingin membuat Nasi daun jeruk ? Coba resep berikut ini. Cara memasaknya sangat praktis namun hasilnya gurih dan lezat cocok sekali jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Untuk Pembuatan Nasi daun jeruk:

1. Bahan 
1. beras 1 kg
1. Santan 200 cc
1. bawang putih kecil 5
1. bawang merah kecil 4
1. daun salam 2
1. daun jeruk blender 10
1. daun jeruk iris tipis 10
1. Daun suci secukupnya blender ambil sarinya sbg pewarna 
1. Garam 

Nasi daun jeruk siap dihidangkan dengan. Nasi daun jeruk ini memang sedang tren di kalangan masyarakat Indonesia, banyak sekali kaum muda mudi yang berlomba-lomba membuat makanan nasi putih spesial ini. Nasi daun jeruk ala geprek bensu rekomended buat di coba. Geprek bensu nasi daun jeruk anti mainst. 

<!--inarticleads2-->

## Cara Membuat Nasi daun jeruk:

1. Cuci beras sampai bersih. Set di magic com, masukkan bawang merah bawang putih, salam, serai, daun jeruk yg diblender, n air daun suci, trs masukkan santan n tambah air dikit, n garam sesuai selera. Takaran air n santan satu ruas jari lebih dikit. Tutup magic com, jgn lupa di ceklekin... (aq pernah lupa, hahaha) - Kl uda matang, aduk2, icipi, trs tabur daun jeruk irisan tipis, aduk2 lagi, trs tutup lagi.


Gurih dan wangi dari daun jeruk menambah kelezatan nasi daun jeruk. Nasi dengan campuran daun jeruk yang wangi sedang tren. Hai selamat pagi sahabat CWS, pagi ini saya share resep Nasi Daun Jeruk. Praktis banget karena saya gunakan rice cooker. Rasanya mirip nasi uduk tapi wangiiii. 

Terima kasih telah menggunakan resep yang tim kami tampilkan di sini. Semoga bermanfaat dan selamat mencoba!
