---
description: "Bagaimana Membuat Tumini Nasi Uduk Betawi, Bikin Ngiler"
title: "Bagaimana Membuat Tumini Nasi Uduk Betawi, Bikin Ngiler"
slug: 14-bagaimana-membuat-tumini-nasi-uduk-betawi-bikin-ngiler
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-08T12:10:44.153Z 
thumbnail: https://img-global.cpcdn.com/recipes/5856da1eb7b05360/682x484cq65/tumini-nasi-uduk-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/5856da1eb7b05360/682x484cq65/tumini-nasi-uduk-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/5856da1eb7b05360/682x484cq65/tumini-nasi-uduk-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/5856da1eb7b05360/682x484cq65/tumini-nasi-uduk-betawi-foto-resep-utama.webp
author: Owen Thomas
ratingvalue: 4
reviewcount: 6
recipeingredient:
- "Nasi Uduk "
- "Beras cuci bersih 4 cup"
- "Santan 130 ml Santan Instan  Air 800 ml"
- "Bawang Merah haluskan 5 siung"
- "Jahe haluskan 2 cm"
- "Laos geprek 2 cm"
- "Kayumanis 3 cm"
- "Sereh geprek 3 batang"
- "Daun Salam 5 lembar"
- "Garam Halus 2 sdt"
- "Pewarna Makanan Merah Tua 1/4 sdt"
- "Bihun Goreng "
- "Bihun Jagung rendam air hangat hingga mengembang 175 gram"
- "Telur Ayam buat orakarik 2 butir"
- "Daun Bawang potong serong 1 batang"
- "Bawang Merah 3 siung"
- "Bawang Putih 3 siung"
- "Kemiri Sangrai 1 butir"
- "Ebi 1 sdt"
- "Kecap Manis 3 sdm"
- "Saus Tiram 1 sdm"
- "Garam 1/2 sdt"
- "Kaldu Jamur 1/2 sdt"
- "Lada 1/2 sdt"
- "Air 50 ml"
- "Minyak Goreng untuk menumis bumbu halus 3 sdm"
- "Sambal Kacang "
- "Cabe Keriting Merah Goreng 2 buah"
- "Bawang Putih Goreng 1 siung"
- "Gula Pasir 1 sdt"
- "Garam Halus 1/2 sdt"
- "Terasi Sangrai 1/4 sdt"
- "Kacang Tanah Goreng 50 gram"
- "Air Hangat 100 ml"
- "Air Perasan Jeruk Nipis 1/2 sdt"
- "Pelengkap "
- "Semur Betawi           lihat resep "
- "Telur Dadar iris "
- "Tempe Goreng "
- "Bawang Merah Goreng "
- "Emping Goreng "
- "Timun "
recipeinstructions:
- "Nasi Uduk:  ✔️Bumbu Halus: Ulek bawang merah dan jahe hingga halus. ✔️Masukkan semua bahan nasi uduk + bumbu halus, aduk rata, lalu masak seperti biasa dengan rice cooker. ✔️Saat sudah matang (warm), tambahkan pewarna merah ke dalam nasi dan aduk rata. Biarkan hingga benar-benar matang."
- "Bihun Goreng: ✔️Bumbu Halus: Ulek halus bawang merah, bawang putih, kemiri, dan ebi.  ✔️Siapkan juga telur orak-arik dan bihun yang telah direndam air hangat."
- "Panaskan minyak goreng, tumis bumbu halus hingga harum.   Tambahkan air, sawi putih dan kubis, aduk rata."
- "Masukkan semua seasoning dan telur orak-arik, aduk rata.  Masukkan juga bihun dan daun bawang, aduk rata kembali. Tes rasa lalu angkat."
- "Sambal Kacang: Ulek halus cabe, bawang putih, gula pasir, dan garam.  Masukkan kacang tanah goreng, ulek kembali.  Tambahkan air, dan beri air perasan jeruk nipis, aduk rata."
- "Cetak nasi dengan bentuk tumpeng kerucut, sambil dipadatkan.  Tata di piring saji, sajikan bersama semua pelengkap, bihun goreng, dan sambal kacangnya.           (lihat resep)"
- "Tumini Nasi Uduk Betawi siap disajikan ♥️♥️."
categories:
- Resep
tags:
- tumini
- nasi
- uduk

katakunci: tumini nasi uduk 
nutrition: 208 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT51M"
recipeyield: "1"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Tumini Nasi Uduk Betawi](https://img-global.cpcdn.com/recipes/5856da1eb7b05360/682x484cq65/tumini-nasi-uduk-betawi-foto-resep-utama.webp)

Ingin membuat Tumini Nasi Uduk Betawi ? Coba resep berikut ini. Cara memasaknya sangat praktis namun hasilnya gurih dan lezat cocok sekali jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Dalam Menyiapkan Tumini Nasi Uduk Betawi:

1. Nasi Uduk 
1. Beras cuci bersih 4 cup
1. Santan 130 ml Santan Instan  Air 800 ml
1. Bawang Merah haluskan 5 siung
1. Jahe haluskan 2 cm
1. Laos geprek 2 cm
1. Kayumanis 3 cm
1. Sereh geprek 3 batang
1. Daun Salam 5 lembar
1. Garam Halus 2 sdt
1. Pewarna Makanan Merah Tua 1/4 sdt
1. Bihun Goreng 
1. Bihun Jagung rendam air hangat hingga mengembang 175 gram
1. Telur Ayam buat orakarik 2 butir
1. Daun Bawang potong serong 1 batang
1. Bawang Merah 3 siung
1. Bawang Putih 3 siung
1. Kemiri Sangrai 1 butir
1. Ebi 1 sdt
1. Kecap Manis 3 sdm
1. Saus Tiram 1 sdm
1. Garam 1/2 sdt
1. Kaldu Jamur 1/2 sdt
1. Lada 1/2 sdt
1. Air 50 ml
1. Minyak Goreng untuk menumis bumbu halus 3 sdm
1. Sambal Kacang 
1. Cabe Keriting Merah Goreng 2 buah
1. Bawang Putih Goreng 1 siung
1. Gula Pasir 1 sdt
1. Garam Halus 1/2 sdt
1. Terasi Sangrai 1/4 sdt
1. Kacang Tanah Goreng 50 gram
1. Air Hangat 100 ml
1. Air Perasan Jeruk Nipis 1/2 sdt
1. Pelengkap 
1. Semur Betawi           lihat resep 
1. Telur Dadar iris 
1. Tempe Goreng 
1. Bawang Merah Goreng 
1. Emping Goreng 
1. Timun 



<!--inarticleads2-->

## Langkah-langkah Untuk Membuat Tumini Nasi Uduk Betawi:

1. Nasi Uduk:  - ✔️Bumbu Halus: Ulek bawang merah dan jahe hingga halus. - ✔️Masukkan semua bahan nasi uduk + bumbu halus, aduk rata, lalu masak seperti biasa dengan rice cooker. - ✔️Saat sudah matang (warm), tambahkan pewarna merah ke dalam nasi dan aduk rata. Biarkan hingga benar-benar matang.
1. Bihun Goreng: - ✔️Bumbu Halus: Ulek halus bawang merah, bawang putih, kemiri, dan ebi. -  - ✔️Siapkan juga telur orak-arik dan bihun yang telah direndam air hangat.
1. Panaskan minyak goreng, tumis bumbu halus hingga harum.  -  - Tambahkan air, sawi putih dan kubis, aduk rata.
1. Masukkan semua seasoning dan telur orak-arik, aduk rata. -  - Masukkan juga bihun dan daun bawang, aduk rata kembali. Tes rasa lalu angkat.
1. Sambal Kacang: Ulek halus cabe, bawang putih, gula pasir, dan garam. -  - Masukkan kacang tanah goreng, ulek kembali. -  - Tambahkan air, dan beri air perasan jeruk nipis, aduk rata.
1. Cetak nasi dengan bentuk tumpeng kerucut, sambil dipadatkan. -  - Tata di piring saji, sajikan bersama semua pelengkap, bihun goreng, dan sambal kacangnya. -           (lihat resep)
1. Tumini Nasi Uduk Betawi siap disajikan ♥️♥️.




Salah satu kuliner yang cukup praktis dalam pembuatannya adalah  Tumini Nasi Uduk Betawi. Selain itu  Tumini Nasi Uduk Betawi  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu ikuti 7 langkah, dan  Tumini Nasi Uduk Betawi  pun siap di hidangkan. selamat mencoba !
