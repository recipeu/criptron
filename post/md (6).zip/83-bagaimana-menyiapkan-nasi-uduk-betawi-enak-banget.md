---
description: "Bagaimana Menyiapkan Nasi Uduk Betawi, Enak Banget"
title: "Bagaimana Menyiapkan Nasi Uduk Betawi, Enak Banget"
slug: 83-bagaimana-menyiapkan-nasi-uduk-betawi-enak-banget
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-14T09:47:48.883Z 
thumbnail: https://img-global.cpcdn.com/recipes/dcace08899ed476f/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/dcace08899ed476f/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/dcace08899ed476f/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/dcace08899ed476f/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
author: Verna Russell
ratingvalue: 4
reviewcount: 11
recipeingredient:
- "beras putih 5 gelas belimbing"
- "ketumbar halus 1 sdt"
- "garam 1 sdt"
- "jahe iris tipis 3 ruas jari"
- "lengkuas iris halus kemudian keprek 3 ruas jari"
- "serai memarkan 3 batang"
- "daun salam 3 lembar"
- "cengkeh 10 buah"
- "minyak zaitun kalau tidak ada bisa diganti minyak goreng 2 sdm"
- "santan kurang lebih 1 liter"
recipeinstructions:
- "Campurkan semua bahan jadi satu, aduk sebentar,nyalakan kompor"
- "Aron beras dalam api sedang, sambil sekali-kali diaduk, ketika air santannya sudah kering, matikan apinya, icip rasa asinnya, kalau kurang asin bisa ditambah garam, aduk-aduk kembali, kemudian kukus beras yg sudah di aron sampai matang (kurang lebih 1/2 jam) rasakan apabila nasi sudah tanak dan tidak keras tandanya sudah matang"
- "Sajikan dengan bahan pelengkap seperti ayam goreng, bawang goreng, bakwan, sambal kacang dan kerupuk"
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 102 calories
recipecuisine: Indonesian
preptime: "PT29M"
cooktime: "PT55M"
recipeyield: "1"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Betawi](https://img-global.cpcdn.com/recipes/dcace08899ed476f/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp)

Resep rahasia Nasi Uduk Betawi  sederhana dengan 3 langkahcepat cocok sekali jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Bahan-bahan Yang Dibutuhkan Dalam Pembuatan Nasi Uduk Betawi:

1. beras putih 5 gelas belimbing
1. ketumbar halus 1 sdt
1. garam 1 sdt
1. jahe iris tipis 3 ruas jari
1. lengkuas iris halus kemudian keprek 3 ruas jari
1. serai memarkan 3 batang
1. daun salam 3 lembar
1. cengkeh 10 buah
1. minyak zaitun kalau tidak ada bisa diganti minyak goreng 2 sdm
1. santan kurang lebih 1 liter



<!--inarticleads2-->

## Cara Mudah Menyiapkan Nasi Uduk Betawi:

1. Campurkan semua bahan jadi satu, aduk sebentar,nyalakan kompor
1. Aron beras dalam api sedang, sambil sekali-kali diaduk, ketika air santannya sudah kering, matikan apinya, icip rasa asinnya, kalau kurang asin bisa ditambah garam, aduk-aduk kembali, kemudian kukus beras yg sudah di aron sampai matang (kurang lebih 1/2 jam) rasakan apabila nasi sudah tanak dan tidak keras tandanya sudah matang
1. Sajikan dengan bahan pelengkap seperti ayam goreng, bawang goreng, bakwan, sambal kacang dan kerupuk




Terima kasih telah membaca resep yang tim kami tampilkan di halaman ini. Semoga bermanfaat dan selamat mencoba!
