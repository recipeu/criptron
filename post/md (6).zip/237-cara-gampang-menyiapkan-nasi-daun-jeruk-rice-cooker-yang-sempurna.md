---
description: "Cara Gampang Menyiapkan Nasi Daun Jeruk (Rice Cooker) yang Sempurna"
title: "Cara Gampang Menyiapkan Nasi Daun Jeruk (Rice Cooker) yang Sempurna"
slug: 237-cara-gampang-menyiapkan-nasi-daun-jeruk-rice-cooker-yang-sempurna
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-18T04:39:42.158Z 
thumbnail: https://img-global.cpcdn.com/recipes/b50a7dfe9631ddb4/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/b50a7dfe9631ddb4/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/b50a7dfe9631ddb4/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/b50a7dfe9631ddb4/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
author: Iva Ortiz
ratingvalue: 3.4
reviewcount: 14
recipeingredient:
- "beras 3 cup"
- "daun jeruk 10"
- "sereh 1 buah"
- "salam 2 buah"
- "bawang merah 2 siung"
- "bawang putih 3 siung"
- "margarin 2 sdm"
- "santan instan 65 ml"
- "Air secukupnya"
recipeinstructions:
- "Cuci bersih beras dan tiriskan."
- "Iris kasar bawang merah, bawang putih, dan daun jeruk, serta geprek 1 buah sereh."
- "Campurkan bahan-bahan tersebut dengan beras dan air, kemudian aduk rata."
- "Masak dengan rice cooker hingga matang."
- "Nasi daun jeruk siap disajikan dengan lauk sesuai selera."
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 209 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT46M"
recipeyield: "3"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk (Rice Cooker)](https://img-global.cpcdn.com/recipes/b50a7dfe9631ddb4/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp)

Ingin membuat Nasi Daun Jeruk (Rice Cooker) ? Coba resep berikut ini. Cara memasaknya sangat praktis namun jangan kaget jika hasilnya gurih dan lezat yang wajib bunda coba dirumah

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Dalam Menyiapkan Nasi Daun Jeruk (Rice Cooker):

1. beras 3 cup
1. daun jeruk 10
1. sereh 1 buah
1. salam 2 buah
1. bawang merah 2 siung
1. bawang putih 3 siung
1. margarin 2 sdm
1. santan instan 65 ml
1. Air secukupnya



<!--inarticleads2-->

## Cara Membuat Nasi Daun Jeruk (Rice Cooker):

1. Cuci bersih beras dan tiriskan.
1. Iris kasar bawang merah, bawang putih, dan daun jeruk, serta geprek 1 buah sereh.
1. Campurkan bahan-bahan tersebut dengan beras dan air, kemudian aduk rata.
1. Masak dengan rice cooker hingga matang.
1. Nasi daun jeruk siap disajikan dengan lauk sesuai selera.




Demikian informasi  resep Nasi Daun Jeruk (Rice Cooker)   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
