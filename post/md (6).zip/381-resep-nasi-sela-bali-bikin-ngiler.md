---
description: "Resep Nasi Sela Bali, Bikin Ngiler"
title: "Resep Nasi Sela Bali, Bikin Ngiler"
slug: 381-resep-nasi-sela-bali-bikin-ngiler
future: true
lang: id
language: id
languageCode: id
publishDate: 2022-01-07T01:49:51.419Z 
thumbnail: https://img-global.cpcdn.com/recipes/c0c10e07f43a2eaf/682x484cq65/nasi-sela-bali-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/c0c10e07f43a2eaf/682x484cq65/nasi-sela-bali-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/c0c10e07f43a2eaf/682x484cq65/nasi-sela-bali-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/c0c10e07f43a2eaf/682x484cq65/nasi-sela-bali-foto-resep-utama.webp
author: Todd Salazar
ratingvalue: 4.6
reviewcount: 13
recipeingredient:
- "serai memarkan 1 batang"
- "daun salam 1 lembar"
- "daun jeruk purut buang tulang daun dan iris tipis 5 lembar"
- "Bahan Nasi Sela  "
- "beras putih 200 gram"
- "ubi potong dadu kecil 150 gram"
- "air 450 cc"
- "Bumbu Halus  "
- "bawang merah 10 butir"
- "bawang putih 5 siung"
- "cabe merah 6 buah"
- "kemiri sangrai 5 butir"
- "terasi bakar 1 sendok teh"
- "kunyit bakar 2 cm"
- "kencur 1 cm"
- "garam 1 sendok teh"
- "gula merah 2 sendok makan"
- "Bahan Lawar Kacang Panjang  "
- "kacang panjang 100 gram"
- "cambah 100 gram"
- "kelapa setengah tua parut 80 gram"
- "air panas Secukupnya"
- "minyak untuk menggoreng secukupnya"
- "Bahan Sate Lilit  "
- "daging ikan tongkol lebih enak ikan tuna 200 gram"
- "kelapa parut 50 gram"
- "jahe haluskan 1 cm"
- "Bahan Sambal Matah "
- "bawang merah 8 butir"
- "bawang putih 2 siung"
- "cabe rawit 8"
- "serai ambil bagian putihnya 2 batang"
- "daun jeruk buang biji lalu iris tipis 2 lembar"
- "terasi bakar 1/2 sendok teh"
- "air jeruk nipis 1/2 sendok makan"
- "minyak kelapa panas 3 sendok makan"
- "garam 1/4 sendok teh"
- "gula pasir 1/4 sendok teh"
recipeinstructions:
- "🌼Nasi Sela:🌼 Cuci bersih beras putih, masak bersama air hingga air menyusut sambil sesekali diaduk. Angkat. Campur dengan potongan ubi, aduk rata."
- "Kukus nasi aron dan ubi hingga matang kurang lebih selama 20 menit. Angkat dan sisihkan."
- "🌼Lawar Kacang Panjang :🌼 Siangi cambah hingga bersih lalu seduh dengan air panas. Diamkan selama 10 menit, tiriskan. Kacang panjang diiris dengan lebar kurang lebih 1 cm. Seduh dengan air panas selama kurang lebih 10 menit. Tiriskan."
- "Tumis bumbu halus bersama serai, daun jeruk dan daun salam hingga wangi. Ambil 2/3 bagian bumbu untuk kemudian disisihkan."
- "Sementara itu, sisa bumbu dalam wajan tetap dimasak. Tambahkan kelapa parut. Aduk-aduk hingga setengah matang."
- "Masukkan kacang panjang, masak sambil diaduk hingga benar2 matang. Matikan api. Tambahkan cambah, aduk rata sebentar. Sisihkan."
- "🌼Sate Lilit :🌼 Campur dan aduk rata daging ikan tongkol, kelapa parut, jahe halus dan bumbu tumis yang tadi disisihkan. Ambil tusuk sate, kepal adonan di salah satu ujung tusuk sate secukupnya. Sisihkan. Lakukan hingga seluruh adonan dikepal."
- "Panaskan alat pembakar, olesi dengan sedikit minyak agar tidak lengket. Bakar sate lilit hingga kedua sisinya matang."
- "🌼Sambal matah :🌼 Iris tipis bawang merah, bawang putih, cabe rawit dan serai. Tambahkan daun jeruk purut, terasi bakar, garam, gula pasir dan air jeruk nipis. Lalu siram dengan minyak kelapa panas. Aduk rata."
- "Minyak kelapa dapat dibuat sendiri dengan memeras kelapa parut menjadi santan dan dibiarkan seharian disuhu ruang. Maka akan terlihat minyak berada dilapisan atas santan."
- "Sajikan nasi sela beserta lawar kacang panjang, sate lilit dan sambal matah."
categories:
- Resep
tags:
- nasi
- sela
- bali

katakunci: nasi sela bali 
nutrition: 218 calories
recipecuisine: Indonesian
preptime: "PT24M"
cooktime: "PT53M"
recipeyield: "4"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Sela Bali](https://img-global.cpcdn.com/recipes/c0c10e07f43a2eaf/682x484cq65/nasi-sela-bali-foto-resep-utama.webp)

Resep rahasia dan cara memasak  Nasi Sela Bali cocok sekali jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Untuk Pembuatan Nasi Sela Bali:

1. serai memarkan 1 batang
1. daun salam 1 lembar
1. daun jeruk purut buang tulang daun dan iris tipis 5 lembar
1. Bahan Nasi Sela  
1. beras putih 200 gram
1. ubi potong dadu kecil 150 gram
1. air 450 cc
1. Bumbu Halus  
1. bawang merah 10 butir
1. bawang putih 5 siung
1. cabe merah 6 buah
1. kemiri sangrai 5 butir
1. terasi bakar 1 sendok teh
1. kunyit bakar 2 cm
1. kencur 1 cm
1. garam 1 sendok teh
1. gula merah 2 sendok makan
1. Bahan Lawar Kacang Panjang  
1. kacang panjang 100 gram
1. cambah 100 gram
1. kelapa setengah tua parut 80 gram
1. air panas Secukupnya
1. minyak untuk menggoreng secukupnya
1. Bahan Sate Lilit  
1. daging ikan tongkol lebih enak ikan tuna 200 gram
1. kelapa parut 50 gram
1. jahe haluskan 1 cm
1. Bahan Sambal Matah 
1. bawang merah 8 butir
1. bawang putih 2 siung
1. cabe rawit 8
1. serai ambil bagian putihnya 2 batang
1. daun jeruk buang biji lalu iris tipis 2 lembar
1. terasi bakar 1/2 sendok teh
1. air jeruk nipis 1/2 sendok makan
1. minyak kelapa panas 3 sendok makan
1. garam 1/4 sendok teh
1. gula pasir 1/4 sendok teh



<!--inarticleads2-->

## Cara Mudah Membuat Nasi Sela Bali:

1. 🌼Nasi Sela:🌼 Cuci bersih beras putih, masak bersama air hingga air menyusut sambil sesekali diaduk. Angkat. Campur dengan potongan ubi, aduk rata.
1. Kukus nasi aron dan ubi hingga matang kurang lebih selama 20 menit. Angkat dan sisihkan.
1. 🌼Lawar Kacang Panjang :🌼 Siangi cambah hingga bersih lalu seduh dengan air panas. Diamkan selama 10 menit, tiriskan. Kacang panjang diiris dengan lebar kurang lebih 1 cm. Seduh dengan air panas selama kurang lebih 10 menit. Tiriskan.
1. Tumis bumbu halus bersama serai, daun jeruk dan daun salam hingga wangi. Ambil 2/3 bagian bumbu untuk kemudian disisihkan.
1. Sementara itu, sisa bumbu dalam wajan tetap dimasak. Tambahkan kelapa parut. Aduk-aduk hingga setengah matang.
1. Masukkan kacang panjang, masak sambil diaduk hingga benar2 matang. Matikan api. Tambahkan cambah, aduk rata sebentar. Sisihkan.
1. 🌼Sate Lilit :🌼 Campur dan aduk rata daging ikan tongkol, kelapa parut, jahe halus dan bumbu tumis yang tadi disisihkan. Ambil tusuk sate, kepal adonan di salah satu ujung tusuk sate secukupnya. Sisihkan. Lakukan hingga seluruh adonan dikepal.
1. Panaskan alat pembakar, olesi dengan sedikit minyak agar tidak lengket. Bakar sate lilit hingga kedua sisinya matang.
1. 🌼Sambal matah :🌼 Iris tipis bawang merah, bawang putih, cabe rawit dan serai. Tambahkan daun jeruk purut, terasi bakar, garam, gula pasir dan air jeruk nipis. Lalu siram dengan minyak kelapa panas. Aduk rata.
1. Minyak kelapa dapat dibuat sendiri dengan memeras kelapa parut menjadi santan dan dibiarkan seharian disuhu ruang. Maka akan terlihat minyak berada dilapisan atas santan.
1. Sajikan nasi sela beserta lawar kacang panjang, sate lilit dan sambal matah.




Demikian informasi  resep Nasi Sela Bali   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
