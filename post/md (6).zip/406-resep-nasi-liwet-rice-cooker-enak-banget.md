---
description: "Resep Nasi Liwet Rice Cooker, Enak Banget"
title: "Resep Nasi Liwet Rice Cooker, Enak Banget"
slug: 406-resep-nasi-liwet-rice-cooker-enak-banget
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-20T21:34:04.344Z 
thumbnail: https://img-global.cpcdn.com/recipes/57c91ff0080356dd/682x484cq65/nasi-liwet-rice-cooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/57c91ff0080356dd/682x484cq65/nasi-liwet-rice-cooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/57c91ff0080356dd/682x484cq65/nasi-liwet-rice-cooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/57c91ff0080356dd/682x484cq65/nasi-liwet-rice-cooker-foto-resep-utama.webp
author: Lucile Sparks
ratingvalue: 3.3
reviewcount: 3
recipeingredient:
- "beras  air sesuai takaran memasak nasi biasa 4 cup"
- "bawang merah iris tipis 8 siung"
- "bawang putih iris tipis 5 siung"
- "cabe keriting merah iris serong 3"
- "cabe keriting hijau iris serong 3"
- "daun salam 5 lembar"
- "daun jeruk tambahan dari aku 3 lembar"
- "serai geprek 3 batang"
- "petai kupas cuci bersih 1 papan"
- "Teri goreng secukupnya aku pakai teri medan goreng "
- "Ikan asin secukupnya aku skip "
- "Cumi asin secukupnya aku skip "
- "garam 1 sdt"
- "Bawang goreng sesuai selera"
- "minyak untuk menumis 2 sdm"
recipeinstructions:
- "Cuci bersih beras, masukkan rice cooker dan beri takaran sesuai takaran biasa memasak nasi. Beri garam dan aduk sebentar saja."
- "Tumis bumbu2 : bawang merah, bawang putih, serai, daun salam, daun jeruk, cabe, hingga harum. Masukkan ke dalam rice cooker. Masukkan sebagian teri, ikan asin, cumi asin. Masak hingga nasi matang."
- "Setelah nasi matang, aduk rata kemudian koreksi rasa. Jika kurang asin bisa ditambah sesuai selera. Sajikan dengan taburan bawang merah goreng, ayam goreng dan sambal bawang. Dijamin nambah 😋😋"
- "Sambal bawang merah : 100 gr bawang merah + 100 gr rawit merah, goreng hingga sedikit layu. Chopper atau ulek kasar kemudian goreng kembali hingga matang, tambahkan kaldu bubuk, garam dan gula. Koreksi rasa. Simpan di toples kaca bersih. Bisa tahan lebih dari 3 hari atau simpan di kulkas."
categories:
- Resep
tags:
- nasi
- liwet
- rice

katakunci: nasi liwet rice 
nutrition: 137 calories
recipecuisine: Indonesian
preptime: "PT29M"
cooktime: "PT45M"
recipeyield: "1"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Liwet Rice Cooker](https://img-global.cpcdn.com/recipes/57c91ff0080356dd/682x484cq65/nasi-liwet-rice-cooker-foto-resep-utama.webp)

4 langkah mudah memasak  Nasi Liwet Rice Cooker yang bisa kamu coba segera

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Untuk Menyiapkan Nasi Liwet Rice Cooker:

1. beras  air sesuai takaran memasak nasi biasa 4 cup
1. bawang merah iris tipis 8 siung
1. bawang putih iris tipis 5 siung
1. cabe keriting merah iris serong 3
1. cabe keriting hijau iris serong 3
1. daun salam 5 lembar
1. daun jeruk tambahan dari aku 3 lembar
1. serai geprek 3 batang
1. petai kupas cuci bersih 1 papan
1. Teri goreng secukupnya aku pakai teri medan goreng 
1. Ikan asin secukupnya aku skip 
1. Cumi asin secukupnya aku skip 
1. garam 1 sdt
1. Bawang goreng sesuai selera
1. minyak untuk menumis 2 sdm



<!--inarticleads2-->

## Langkah-langkah Untuk Membuat Nasi Liwet Rice Cooker:

1. Cuci bersih beras, masukkan rice cooker dan beri takaran sesuai takaran biasa memasak nasi. Beri garam dan aduk sebentar saja.
1. Tumis bumbu2 : bawang merah, bawang putih, serai, daun salam, daun jeruk, cabe, hingga harum. Masukkan ke dalam rice cooker. Masukkan sebagian teri, ikan asin, cumi asin. Masak hingga nasi matang.
1. Setelah nasi matang, aduk rata kemudian koreksi rasa. Jika kurang asin bisa ditambah sesuai selera. Sajikan dengan taburan bawang merah goreng, ayam goreng dan sambal bawang. Dijamin nambah 😋😋
1. Sambal bawang merah : 100 gr bawang merah + 100 gr rawit merah, goreng hingga sedikit layu. Chopper atau ulek kasar kemudian goreng kembali hingga matang, tambahkan kaldu bubuk, garam dan gula. Koreksi rasa. Simpan di toples kaca bersih. Bisa tahan lebih dari 3 hari atau simpan di kulkas.




Demikian informasi  resep Nasi Liwet Rice Cooker   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
