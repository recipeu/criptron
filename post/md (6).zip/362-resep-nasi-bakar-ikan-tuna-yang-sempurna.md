---
description: "Resep Nasi Bakar Ikan Tuna yang Sempurna"
title: "Resep Nasi Bakar Ikan Tuna yang Sempurna"
slug: 362-resep-nasi-bakar-ikan-tuna-yang-sempurna
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-20T22:28:54.229Z 
thumbnail: https://img-global.cpcdn.com/recipes/091efb93df1eaad2/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/091efb93df1eaad2/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/091efb93df1eaad2/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/091efb93df1eaad2/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp
author: Jay Kennedy
ratingvalue: 3.8
reviewcount: 6
recipeingredient:
- "Nasi matang "
- "beras 3 cup"
- "Bahan Ikan "
- "ikan tuna  bisa jg tongkol suirsuir 3 ekor"
- "jamur kuping iris 5 lembar"
- "kemangi 2 ikat"
- "Bumbu halus "
- "cabe rawit merah cengek setan 5 butir"
- "cabe merah kriting 3 butir"
- "bawang merah 3 siung"
- "bawang putih 3 siung"
- "jahe lengkoas Seruas"
- "sereh 2 batang"
- "daun salam irisiris 2 lembar"
- "daun jeruk irisiris 2 lembar"
- "gula garam lada ketumbar Secukupnya"
- "daun pisang untuk membungkus Secukupnya"
recipeinstructions:
- "Masak nasi seperti biasa (saya menggunakan magicjar)"
- "Suir-suir ikan hingga halus"
- "Haluskan bumbu-bumbu halus (bawang merah, bawang putih, cabe rawit cabe merah, lada, ketumbar, sereh, gula garam)"
- "Panaskan minyak untuk menumis bumbu"
- "Tumis bumbu hingga harum, masukan jamur dan masukan daging ikan lanjutkan menumis hingga meresap. Kecilkan api masukan nasi yg telah matang campur hingga menyatu"
- "Terakhir masukan irisan daun salam, daun jeruk, kemangi dan jangan lupa koreksi rasa"
- "Tata nasi tuna di atas daun pisang (sebelumnya daun pisa g di layukan dahulu di atas api) ikat ujungnya seperti lontong lalu panggang"
- "Panggang diatas teflon dengan api sangat kecil. Jika daun nampak mengering (terlihat sedikit angusnya) angkat dan nasi bakar tuna siap di santap."
categories:
- Resep
tags:
- nasi
- bakar
- ikan

katakunci: nasi bakar ikan 
nutrition: 242 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT36M"
recipeyield: "1"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Bakar Ikan Tuna](https://img-global.cpcdn.com/recipes/091efb93df1eaad2/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp)

Resep rahasia Nasi Bakar Ikan Tuna    dengan 8 langkahcepat dan mudah yang bisa bunda coba segera

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Untuk Menyiapkan Nasi Bakar Ikan Tuna:

1. Nasi matang 
1. beras 3 cup
1. Bahan Ikan 
1. ikan tuna  bisa jg tongkol suirsuir 3 ekor
1. jamur kuping iris 5 lembar
1. kemangi 2 ikat
1. Bumbu halus 
1. cabe rawit merah cengek setan 5 butir
1. cabe merah kriting 3 butir
1. bawang merah 3 siung
1. bawang putih 3 siung
1. jahe lengkoas Seruas
1. sereh 2 batang
1. daun salam irisiris 2 lembar
1. daun jeruk irisiris 2 lembar
1. gula garam lada ketumbar Secukupnya
1. daun pisang untuk membungkus Secukupnya



<!--inarticleads2-->

## Cara Mudah Membuat Nasi Bakar Ikan Tuna:

1. Masak nasi seperti biasa (saya menggunakan magicjar)
1. Suir-suir ikan hingga halus
1. Haluskan bumbu-bumbu halus (bawang merah, bawang putih, cabe rawit cabe merah, lada, ketumbar, sereh, gula garam)
1. Panaskan minyak untuk menumis bumbu
1. Tumis bumbu hingga harum, masukan jamur dan masukan daging ikan lanjutkan menumis hingga meresap. Kecilkan api masukan nasi yg telah matang campur hingga menyatu
1. Terakhir masukan irisan daun salam, daun jeruk, kemangi dan jangan lupa koreksi rasa
1. Tata nasi tuna di atas daun pisang (sebelumnya daun pisa g di layukan dahulu di atas api) ikat ujungnya seperti lontong lalu panggang
1. Panggang diatas teflon dengan api sangat kecil. Jika daun nampak mengering (terlihat sedikit angusnya) angkat dan nasi bakar tuna siap di santap.




Terima kasih telah menggunakan resep yang tim kami tampilkan di sini. Semoga bermanfaat dan selamat mencoba!
