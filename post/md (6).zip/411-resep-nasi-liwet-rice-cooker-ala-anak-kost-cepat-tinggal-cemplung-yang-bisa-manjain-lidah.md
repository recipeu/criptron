---
description: "Resep Nasi Liwet Rice Cooker ala anak Kost (cepat tinggal cemplung) yang Bisa Manjain Lidah"
title: "Resep Nasi Liwet Rice Cooker ala anak Kost (cepat tinggal cemplung) yang Bisa Manjain Lidah"
slug: 411-resep-nasi-liwet-rice-cooker-ala-anak-kost-cepat-tinggal-cemplung-yang-bisa-manjain-lidah
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-29T11:13:32.305Z 
thumbnail: https://img-global.cpcdn.com/recipes/b298e66a2b9d1657/682x484cq65/nasi-liwet-rice-cooker-ala-anak-kost-cepat-tinggal-cemplung-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/b298e66a2b9d1657/682x484cq65/nasi-liwet-rice-cooker-ala-anak-kost-cepat-tinggal-cemplung-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/b298e66a2b9d1657/682x484cq65/nasi-liwet-rice-cooker-ala-anak-kost-cepat-tinggal-cemplung-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/b298e66a2b9d1657/682x484cq65/nasi-liwet-rice-cooker-ala-anak-kost-cepat-tinggal-cemplung-foto-resep-utama.webp
author: Mabelle Benson
ratingvalue: 3.5
reviewcount: 6
recipeingredient:
- "Beras 250 gr"
- "bawang merah 4 siung"
- "bawang putih 3 siung"
- "cabe rawit optional 8 buah"
- "lengkuas 1 cm"
- "daun salam 2 lembar"
- "daun jeruk 2 lembar"
- "kemangi 2 tangkai"
- "Pete 2 tangkai"
- "teri nasi kering 50 gr"
- "minyak goreng Secukupnya"
- "bawang goreng Secukupnya"
- "garam Secukupnya"
recipeinstructions:
- "Rebus air hingga mendidih, sambil menunggu mendidih. Cuci beras hingga bersih. Cuci teri nasi kering."
- "Tumis bawang merah, bawang putih, lengkuas, daun salam, daun jeruk, cabe rawit hingga harum. Masukkan teri nasi dan pete, tumis sebentar."
- "Masukkan air mendidih kedalam wadah rice cooker yg berisi beras yg sudah dicuci. Masukkan tumisan bumbu tari. Beri kemangi. Dan taburi garam sesuai selera. Aduk rata. Klik rice cooker seperti masak nasi biasanya. Jika sudah matang, taburi bawang goreng."
categories:
- Resep
tags:
- nasi
- liwet
- rice

katakunci: nasi liwet rice 
nutrition: 203 calories
recipecuisine: Indonesian
preptime: "PT24M"
cooktime: "PT38M"
recipeyield: "2"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Liwet Rice Cooker ala anak Kost (cepat tinggal cemplung)](https://img-global.cpcdn.com/recipes/b298e66a2b9d1657/682x484cq65/nasi-liwet-rice-cooker-ala-anak-kost-cepat-tinggal-cemplung-foto-resep-utama.webp)

3 langkah cepat membuat  Nasi Liwet Rice Cooker ala anak Kost (cepat tinggal cemplung) cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Dibutuhkan Dalam Menyiapkan Nasi Liwet Rice Cooker ala anak Kost (cepat tinggal cemplung):

1. Beras 250 gr
1. bawang merah 4 siung
1. bawang putih 3 siung
1. cabe rawit optional 8 buah
1. lengkuas 1 cm
1. daun salam 2 lembar
1. daun jeruk 2 lembar
1. kemangi 2 tangkai
1. Pete 2 tangkai
1. teri nasi kering 50 gr
1. minyak goreng Secukupnya
1. bawang goreng Secukupnya
1. garam Secukupnya



<!--inarticleads2-->

## Tata Cara Membuat Nasi Liwet Rice Cooker ala anak Kost (cepat tinggal cemplung):

1. Rebus air hingga mendidih, sambil menunggu mendidih. Cuci beras hingga bersih. Cuci teri nasi kering.
1. Tumis bawang merah, bawang putih, lengkuas, daun salam, daun jeruk, cabe rawit hingga harum. Masukkan teri nasi dan pete, tumis sebentar.
1. Masukkan air mendidih kedalam wadah rice cooker yg berisi beras yg sudah dicuci. Masukkan tumisan bumbu tari. Beri kemangi. Dan taburi garam sesuai selera. Aduk rata. Klik rice cooker seperti masak nasi biasanya. Jika sudah matang, taburi bawang goreng.




Daripada ibu beli  Nasi Liwet Rice Cooker ala anak Kost (cepat tinggal cemplung)  diluar terus, kamu  bisa membuatnya sendiri dirumah. Resep  Nasi Liwet Rice Cooker ala anak Kost (cepat tinggal cemplung)  sederhana ini cukup praktis pembuatannya, serta cukup menggunakan bumbu sederhana  Nasi Liwet Rice Cooker ala anak Kost (cepat tinggal cemplung)  yang enak, kamu nikmati di rumah.
