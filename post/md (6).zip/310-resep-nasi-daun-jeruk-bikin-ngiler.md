---
description: "Resep Nasi Daun Jeruk, Bikin Ngiler"
title: "Resep Nasi Daun Jeruk, Bikin Ngiler"
slug: 310-resep-nasi-daun-jeruk-bikin-ngiler
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-06T23:41:30.098Z 
thumbnail: https://img-global.cpcdn.com/recipes/75dd33990ae3e703/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/75dd33990ae3e703/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/75dd33990ae3e703/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/75dd33990ae3e703/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
author: Delia Murphy
ratingvalue: 3.2
reviewcount: 13
recipeingredient:
- "bawang merah 5 butir"
- "bawang putih 4 butir"
- "serai 1 batang"
- "lengkuas 2,5 cm"
- "daun jeruk 10 lembar"
- "cabai rawit 5 buah"
- "garam 1/2 sdm"
- "air 300 ml"
- "beras 250 g"
- "santan 100 ml"
recipeinstructions:
- "Haluskan 5 butir bawang merah &amp; 4 butir bawang putih dengan cara diulek"
- "Tumis bumbu halus, 1 batang serai yang sudah digeprek, 2,5cm lengkuas yang sudah digeprek,10 lembar daun jeruk yang sudah diiris tipis, 5 buah cabai rawit, &amp; 1/2 sdm garam"
- "Masukkan 100ml air kemudian matikan api"
- "Campur 250g beras yang sudah dibersihkan, 100ml santan, 200ml air, &amp; bumbu yang sudah ditumis"
- "Masak dalam rice cooker hingga matang"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 137 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT56M"
recipeyield: "4"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk](https://img-global.cpcdn.com/recipes/75dd33990ae3e703/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp)

Resep dan cara mengolah  Nasi Daun Jeruk cocok sekali jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Dalam Pembuatan Nasi Daun Jeruk:

1. bawang merah 5 butir
1. bawang putih 4 butir
1. serai 1 batang
1. lengkuas 2,5 cm
1. daun jeruk 10 lembar
1. cabai rawit 5 buah
1. garam 1/2 sdm
1. air 300 ml
1. beras 250 g
1. santan 100 ml

Nasi daun jeruk siap dihidangkan dengan. Nasi daun jeruk ini memang sedang tren di kalangan masyarakat Indonesia, banyak sekali kaum muda mudi yang berlomba-lomba membuat makanan nasi putih spesial ini. Nasi daun jeruk ala geprek bensu rekomended buat di coba. Geprek bensu nasi daun jeruk anti mainst. 

<!--inarticleads2-->

## Langkah-langkah Untuk Menyiapkan Nasi Daun Jeruk:

1. Haluskan 5 butir bawang merah &amp; 4 butir bawang putih dengan cara diulek
1. Tumis bumbu halus, 1 batang serai yang sudah digeprek, 2,5cm lengkuas yang sudah digeprek,10 lembar daun jeruk yang sudah diiris tipis, 5 buah cabai rawit, &amp; 1/2 sdm garam
1. Masukkan 100ml air kemudian matikan api
1. Campur 250g beras yang sudah dibersihkan, 100ml santan, 200ml air, &amp; bumbu yang sudah ditumis
1. Masak dalam rice cooker hingga matang


Gurih dan wangi dari daun jeruk menambah kelezatan nasi daun jeruk. Nasi dengan campuran daun jeruk yang wangi sedang tren. Hai selamat pagi sahabat CWS, pagi ini saya share resep Nasi Daun Jeruk. Praktis banget karena saya gunakan rice cooker. Rasanya mirip nasi uduk tapi wangiiii. 

Daripada kamu beli  Nasi Daun Jeruk  diluar terus, kamu  bisa membuatnya sendiri dirumah. Resep  Nasi Daun Jeruk  sederhana ini cukup praktis pembuatannya, cukup menggunakan bumbu-bumbu sederhana yang ada di dapur  Nasi Daun Jeruk  yang enak, kamu nikmati di rumah.
