---
description: "Resep Nasi liwet Ricecooker, Menggugah Selera"
title: "Resep Nasi liwet Ricecooker, Menggugah Selera"
slug: 409-resep-nasi-liwet-ricecooker-menggugah-selera
future: true
lang: id
language: id
languageCode: id
publishDate: 2022-01-06T05:38:28.206Z 
thumbnail: https://img-global.cpcdn.com/recipes/92b29a024440555a/682x484cq65/nasi-liwet-ricecooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/92b29a024440555a/682x484cq65/nasi-liwet-ricecooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/92b29a024440555a/682x484cq65/nasi-liwet-ricecooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/92b29a024440555a/682x484cq65/nasi-liwet-ricecooker-foto-resep-utama.webp
author: Gregory McGee
ratingvalue: 3
reviewcount: 13
recipeingredient:
- "beras 2 cup"
- "sereh di geprek dan di simpulkan 1 btg"
- "bawang merah iris 5 bh"
- "bawang putih iris 3 bh"
- "cabe rawit iris serong 3 bh"
- "cabe merah keriting iris serong 2 bh"
- "Teri Medan secukupnya Teri apa aja sesuai selera "
- "daun salam 2 lbr"
- "daun jeruk Sobek buang tulang Optional 2 lbr"
- "garam Secukupnya"
- "kaldu bubuk Secukupnya"
recipeinstructions:
- "Cuci bersih beras seperti biasa memasak nasi lalu masukan ke wadahnya"
- "Goreng teri hingga kecoklatan, lalu sisihkan"
- "Tumis bawang dan cabe merah hingga harum dengan minyak bekasan goreng teri tadi, lalu tambahkan sere yang sudah di geprek, daun salam dan daun jeruk"
- "Kemudian masukan tumisan tadi kedalam beras yang sudah di cuci bersih dan teri yang sudah di goreng"
- "Tambahkan air sebanyak takaran ketika memasak nasi biasanya, saya di lebihin sedikit agar nasi menjadi tanak"
- "Tambahkan garam dan kaldu bubuk, aduk lalu test rasa"
- "Jika sudah pas, tinggal tekan cook pada ricecooker"
- "Setelah matang, bisa langsung di aduk supaya rasa lebih merata"
- "Nasi liwet siap disajikan, selamat mencoba🥰"
categories:
- Resep
tags:
- nasi
- liwet
- ricecooker

katakunci: nasi liwet ricecooker 
nutrition: 299 calories
recipecuisine: Indonesian
preptime: "PT15M"
cooktime: "PT49M"
recipeyield: "2"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi liwet Ricecooker](https://img-global.cpcdn.com/recipes/92b29a024440555a/682x484cq65/nasi-liwet-ricecooker-foto-resep-utama.webp)

Resep rahasia Nasi liwet Ricecooker    dengan 9 langkahmudah dan cepat cocok banget jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Dalam Menyiapkan Nasi liwet Ricecooker:

1. beras 2 cup
1. sereh di geprek dan di simpulkan 1 btg
1. bawang merah iris 5 bh
1. bawang putih iris 3 bh
1. cabe rawit iris serong 3 bh
1. cabe merah keriting iris serong 2 bh
1. Teri Medan secukupnya Teri apa aja sesuai selera 
1. daun salam 2 lbr
1. daun jeruk Sobek buang tulang Optional 2 lbr
1. garam Secukupnya
1. kaldu bubuk Secukupnya

Nasi Liwet Sunda is one of my favorite rice dishes. There are many rice dishes in Indonesia that use coconut milk and spices and they This nasi liwet Sunda can be made on stove-top, rice cooker or instant pot. My favorite ways are rice cooker and instant pot. Nasi liwet identik dengan aroma yang wangi dan tekstur yang pulen. 

<!--inarticleads2-->

## Langkah-langkah Untuk Menyiapkan Nasi liwet Ricecooker:

1. Cuci bersih beras seperti biasa memasak nasi lalu masukan ke wadahnya
1. Goreng teri hingga kecoklatan, lalu sisihkan
1. Tumis bawang dan cabe merah hingga harum dengan minyak bekasan goreng teri tadi, lalu tambahkan sere yang sudah di geprek, daun salam dan daun jeruk
1. Kemudian masukan tumisan tadi kedalam beras yang sudah di cuci bersih dan teri yang sudah di goreng
1. Tambahkan air sebanyak takaran ketika memasak nasi biasanya, saya di lebihin sedikit agar nasi menjadi tanak
1. Tambahkan garam dan kaldu bubuk, aduk lalu test rasa
1. Jika sudah pas, tinggal tekan cook pada ricecooker
1. Setelah matang, bisa langsung di aduk supaya rasa lebih merata
1. Nasi liwet siap disajikan, selamat mencoba🥰


Jika menggunakan rice cooker berkerak, akan timbul bau gosong dari dasar nasi. Selain itu, nasi jadi tidak matang merata alias keras. Akhirnya, nasi liwet yang dihasilkan pun tidak sesuai harapan. Resep Nasi Liwet Sunda - Nasi liwet merupakan salah satu hidangan berupa nasi gurih yang khas dari Jawa Barat. Namun nasi liwet juga bisa dimasak dengan rice cooker / magic com untuk proses yang lebih mudah dan praktis. 

Terima kasih telah membaca resep yang kami tampilkan di sini. Selamat mencoba!
