---
description: "Langkah Mudah untuk Membuat Nasi Daun Jeruk, Enak"
title: "Langkah Mudah untuk Membuat Nasi Daun Jeruk, Enak"
slug: 314-langkah-mudah-untuk-membuat-nasi-daun-jeruk-enak
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-16T04:58:15.001Z 
thumbnail: https://img-global.cpcdn.com/recipes/d32ab629b029008e/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/d32ab629b029008e/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/d32ab629b029008e/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/d32ab629b029008e/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
author: Mamie Griffith
ratingvalue: 4.1
reviewcount: 15
recipeingredient:
- "Nasi Daun Jeruk "
- "beras 4 cup"
- "Santan kara yg 65 ml dicairkan untuk memasak nasi sesuai takaran "
- "sereh memarkan 2 batang"
- "daun salam 3 lembar"
- "daun jeruk iris tipis 15 lembar"
- "Ayam Goreng Lengkuas "
- "ayam potong 10 1 ekor"
- "bumbu ayam goreng royco 1 sachet"
- "sereh geprek 1"
- "lengkuas di parut 5 ruas"
- "Orek Tempe Basah "
- "tempe 1 papan"
- "bawang merah 6 siung"
- "bawang putih 4 siung"
- "merica 1/4 sdt"
- "bawang putih iris tipis 3 siung"
- "cabe keriting merah iris serong 5"
- "cabe keriting ijo iris serong 3"
- "daun salam 2 lembar"
- "lengkuas geprek 1 ruas"
- "garam Secukupnya"
- "kaldu jamur Secukupnya"
- "gula merah 3 iris"
- "kecap manis 3 sdm"
- "Bihun Goreng "
- "bihun jagung berat kering 100 gram"
- "sawi hijau potong sesuai selera 6 lembar"
- "kol potong sesuai selera 1/4 bagian"
- "wortel saya di parut pake parutan keju yg besar 1 buah"
- "daun bawang iris tipis 1 batang"
- "kecap manis Secukupnya"
- "garam  gula Secukupnya"
- "Bumbu Halus "
- "bawang merah 6 siung"
- "bawang putih 3 siung"
- "merica 1 sdt"
- "kemiri 3 butir"
- "ebi rendam air hangat sebentar 1 sdm"
- "Telor dadar tipis "
- "telor dadar 1 butir"
- "garam Secukupnya"
recipeinstructions:
- "Nasi Daun Jeruk : cuci beras, masukkan beras ke dalam rice cooker, kasi santan yg sudah dicairkan sesuai takaran masak nasi biasa, tambahkan daun salam,sereh garam dan kaldu jamur secukupnya"
- "Ayam Goreng Lengkuas: karena pake bumbu instant jadi effortless bgt, tinggal pas goreng aja lengkuas sama ayam nya jgn digoreng barengan biar lengkuas ga keburu gosong, aku lengkuas nya agak gosong gara2 goreng barengan😅"
- "Orek Tempe Basah : goreng tempe setengah matang, selagi menunggu tempe matang siapkan bumbu, tumis irisan bawang putih hingga harum, lalu masukkan semua bumbu berturut2 bumbu halus, lengkuas daun salam dan cabe iris, masukkan tempe tambahkan sedikit air kasi garam, gula merah dan kaldu jamur, test rasa lalu masukkan kecap manis tunggu sampe air mengering"
- "Bihun Goreng : rendam bihun dengan air panas, biarkan sampai lembut, klo sudah dingin campur kecap, saya kasi kecap duluan karena ga punya wajan gede dan biar kecap nya rata tercampur. tumis bumbu halus bersama daun bawang yg sudah diiris sampai wangi, masukkan wortel, masak sampai layu lalu masukkan sisa sayuran. Masukkan bihun, garam &amp; gula aduk rata"
- "Telor dadar tipis, kocok telor lalu goreng di atas pan anti lengket dengan sedikt minyak, biar merata puter2 pan nya klo sudah matang tinggal di potong2 memanjang"
- "Tips: biar pembagian waktu efektif, yg pertama aku buat yg makan waktu paling lama, ungkep ayam, terus masak nasi, sambil menunggu 2 masakan itu mateng aku masak orek tempe &amp; bihunnya terakhir bikin telor dadar nya deh"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 193 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT58M"
recipeyield: "4"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk](https://img-global.cpcdn.com/recipes/d32ab629b029008e/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp)

6 langkah mudah mengolah  Nasi Daun Jeruk yang harus bunda coba dirumah

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Untuk Menyiapkan Nasi Daun Jeruk:

1. Nasi Daun Jeruk 
1. beras 4 cup
1. Santan kara yg 65 ml dicairkan untuk memasak nasi sesuai takaran 
1. sereh memarkan 2 batang
1. daun salam 3 lembar
1. daun jeruk iris tipis 15 lembar
1. Ayam Goreng Lengkuas 
1. ayam potong 10 1 ekor
1. bumbu ayam goreng royco 1 sachet
1. sereh geprek 1
1. lengkuas di parut 5 ruas
1. Orek Tempe Basah 
1. tempe 1 papan
1. bawang merah 6 siung
1. bawang putih 4 siung
1. merica 1/4 sdt
1. bawang putih iris tipis 3 siung
1. cabe keriting merah iris serong 5
1. cabe keriting ijo iris serong 3
1. daun salam 2 lembar
1. lengkuas geprek 1 ruas
1. garam Secukupnya
1. kaldu jamur Secukupnya
1. gula merah 3 iris
1. kecap manis 3 sdm
1. Bihun Goreng 
1. bihun jagung berat kering 100 gram
1. sawi hijau potong sesuai selera 6 lembar
1. kol potong sesuai selera 1/4 bagian
1. wortel saya di parut pake parutan keju yg besar 1 buah
1. daun bawang iris tipis 1 batang
1. kecap manis Secukupnya
1. garam  gula Secukupnya
1. Bumbu Halus 
1. bawang merah 6 siung
1. bawang putih 3 siung
1. merica 1 sdt
1. kemiri 3 butir
1. ebi rendam air hangat sebentar 1 sdm
1. Telor dadar tipis 
1. telor dadar 1 butir
1. garam Secukupnya

Nasi daun jeruk siap dihidangkan dengan. Nasi daun jeruk ini memang sedang tren di kalangan masyarakat Indonesia, banyak sekali kaum muda mudi yang berlomba-lomba membuat makanan nasi putih spesial ini. Nasi daun jeruk ala geprek bensu rekomended buat di coba. Geprek bensu nasi daun jeruk anti mainst. 

<!--inarticleads2-->

## Cara Membuat Nasi Daun Jeruk:

1. Nasi Daun Jeruk : cuci beras, masukkan beras ke dalam rice cooker, kasi santan yg sudah dicairkan sesuai takaran masak nasi biasa, tambahkan daun salam,sereh garam dan kaldu jamur secukupnya
1. Ayam Goreng Lengkuas: karena pake bumbu instant jadi effortless bgt, tinggal pas goreng aja lengkuas sama ayam nya jgn digoreng barengan biar lengkuas ga keburu gosong, aku lengkuas nya agak gosong gara2 goreng barengan😅
1. Orek Tempe Basah : goreng tempe setengah matang, selagi menunggu tempe matang siapkan bumbu, tumis irisan bawang putih hingga harum, lalu masukkan semua bumbu berturut2 bumbu halus, lengkuas daun salam dan cabe iris, masukkan tempe tambahkan sedikit air kasi garam, gula merah dan kaldu jamur, test rasa lalu masukkan kecap manis tunggu sampe air mengering
1. Bihun Goreng : rendam bihun dengan air panas, biarkan sampai lembut, klo sudah dingin campur kecap, saya kasi kecap duluan karena ga punya wajan gede dan biar kecap nya rata tercampur. tumis bumbu halus bersama daun bawang yg sudah diiris sampai wangi, masukkan wortel, masak sampai layu lalu masukkan sisa sayuran. Masukkan bihun, garam &amp; gula aduk rata
1. Telor dadar tipis, kocok telor lalu goreng di atas pan anti lengket dengan sedikt minyak, biar merata puter2 pan nya klo sudah matang tinggal di potong2 memanjang
1. Tips: biar pembagian waktu efektif, yg pertama aku buat yg makan waktu paling lama, ungkep ayam, terus masak nasi, sambil menunggu 2 masakan itu mateng aku masak orek tempe &amp; bihunnya terakhir bikin telor dadar nya deh


Gurih dan wangi dari daun jeruk menambah kelezatan nasi daun jeruk. Nasi dengan campuran daun jeruk yang wangi sedang tren. Hai selamat pagi sahabat CWS, pagi ini saya share resep Nasi Daun Jeruk. Praktis banget karena saya gunakan rice cooker. Rasanya mirip nasi uduk tapi wangiiii. 

Salah satu masakan yang cukup praktis dalam pembuatannya adalah  Nasi Daun Jeruk. Selain itu  Nasi Daun Jeruk  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu lakukan 6 langkah, dan  Nasi Daun Jeruk  pun siap di hidangkan. selamat mencoba !
