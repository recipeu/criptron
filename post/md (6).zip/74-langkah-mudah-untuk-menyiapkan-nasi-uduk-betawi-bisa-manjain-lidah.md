---
description: "Langkah Mudah untuk Menyiapkan Nasi Uduk Betawi, Bisa Manjain Lidah"
title: "Langkah Mudah untuk Menyiapkan Nasi Uduk Betawi, Bisa Manjain Lidah"
slug: 74-langkah-mudah-untuk-menyiapkan-nasi-uduk-betawi-bisa-manjain-lidah
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-05T10:29:42.167Z 
thumbnail: https://img-global.cpcdn.com/recipes/6e0e75deb291d8da/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/6e0e75deb291d8da/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/6e0e75deb291d8da/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/6e0e75deb291d8da/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
author: Virgie Walton
ratingvalue: 4.7
reviewcount: 11
recipeingredient:
- "beras me  cup nya pake skm kaleng bekas 3 cup"
- "santan kara 125ml jadi 2  air jadi 800cc 2 bh"
- "Bumbu yg dihaluskan  "
- "bawang merah yg besar 4 siung"
- "bawang putih yg besar 3 buah"
- "lengkuas geprek 3 ruas"
- "jahe 2 ruas"
- "Rempah2nya  "
- "daun salam sedang 4"
- "daun jeruk 4"
- "sereh geprek pangkalnya 1 batang"
- "garam secukupnya"
- "kaldu jamur secukupnya"
- "minyak goreng utk menumis "
recipeinstructions:
- "Siapkan bahan2nya... Haluskan bawang merah, bawang putih dan jahe lalu tumis tambahkan lengkuas, sereh, daun salam, daun jeruk sampai wangi."
- "Cuci beras sampai bersih. siapkan wajan lalu masukkan beras, santan yg sdh ditambah air dan tumisannya tadi. Aduk2 rata dengan api sedang sampai menyusut. Matikan kompor."
- "Siapkan dandang yg sudah diisi air secukupnya untuk meng aronkan beras tadi dgn api sedang. Sesekali aduk2 spy matangnya nasi rata ya... tunggu sampai wangi dan cek kematangan nasi dgn icip2 sedikit nasinya..😁"
- "Sajikan nasi uduk dgn lauk sesuai selera ya... Selamat makan 😁"
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 265 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT56M"
recipeyield: "1"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Betawi](https://img-global.cpcdn.com/recipes/6e0e75deb291d8da/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp)

Resep rahasia Nasi Uduk Betawi  sederhana dengan 4 langkahcepat dan mudah cocok sekali jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Untuk Pembuatan Nasi Uduk Betawi:

1. beras me  cup nya pake skm kaleng bekas 3 cup
1. santan kara 125ml jadi 2  air jadi 800cc 2 bh
1. Bumbu yg dihaluskan  
1. bawang merah yg besar 4 siung
1. bawang putih yg besar 3 buah
1. lengkuas geprek 3 ruas
1. jahe 2 ruas
1. Rempah2nya  
1. daun salam sedang 4
1. daun jeruk 4
1. sereh geprek pangkalnya 1 batang
1. garam secukupnya
1. kaldu jamur secukupnya
1. minyak goreng utk menumis 



<!--inarticleads2-->

## Tata Cara Membuat Nasi Uduk Betawi:

1. Siapkan bahan2nya... Haluskan bawang merah, bawang putih dan jahe lalu tumis tambahkan lengkuas, sereh, daun salam, daun jeruk sampai wangi.
1. Cuci beras sampai bersih. siapkan wajan lalu masukkan beras, santan yg sdh ditambah air dan tumisannya tadi. Aduk2 rata dengan api sedang sampai menyusut. Matikan kompor.
1. Siapkan dandang yg sudah diisi air secukupnya untuk meng aronkan beras tadi dgn api sedang. Sesekali aduk2 spy matangnya nasi rata ya... tunggu sampai wangi dan cek kematangan nasi dgn icip2 sedikit nasinya..😁
1. Sajikan nasi uduk dgn lauk sesuai selera ya... Selamat makan 😁




Terima kasih telah menggunakan resep yang kami tampilkan di halaman ini. Semoga bermanfaat dan selamat mencoba!
