---
description: "Cara Gampang Membuat Nasi Ayam Khas Semarang Anti Gagal"
title: "Cara Gampang Membuat Nasi Ayam Khas Semarang Anti Gagal"
slug: 467-cara-gampang-membuat-nasi-ayam-khas-semarang-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-29T02:38:47.045Z 
thumbnail: https://img-global.cpcdn.com/recipes/b821d3625031bed2/682x484cq65/nasi-ayam-khas-semarang-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/b821d3625031bed2/682x484cq65/nasi-ayam-khas-semarang-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/b821d3625031bed2/682x484cq65/nasi-ayam-khas-semarang-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/b821d3625031bed2/682x484cq65/nasi-ayam-khas-semarang-foto-resep-utama.webp
author: Beatrice Harmon
ratingvalue: 3.4
reviewcount: 14
recipeingredient:
- "ayam kampung 1/2 ekor"
- "daun salam 2 lembar"
- "lengkuas 2 cm"
- "daun jeruk 3 lembar"
- "serai 1 batang"
- "santan kental dari 1 butir kelapa 500 ml"
- "santan encer sisa perasan santan kental 500 ml"
- "Bumbu halus  "
- "bawang putih 3 buah"
- "bawang merah 7 buah"
- "kemiri sangrai 4 buah"
- "kunyit dibakar 1 cm"
- "ketumbar 1/4 sdt"
- "Gula merah garam kaldu ayam secukupnya"
- "Nasi Gurih  "
- "beras 500 gram"
- "daun salam 3 lembar"
- "daun sereh 2 lembar"
- "garam 1 sdm"
- "Santan secukupnya ukuran memasak nasi ukuran ruas jari "
recipeinstructions:
- "Siapkan bahan bahan dan bumbu bumbunya"
- "Tumis bumbu halus hingga matang dan harum"
- "Tuang santan encer tunggu mendidih masukkan ayam masak hingga meresap dengan api kecil dan santan menyusut."
- "Tuang santan kental masak jangan sampai santan pecah ya, test rasa manis gurihnya siap disajikan dengan nasi gurih dan sayur labu krecek serta telur pindang sedappp"
- "Memasak nasi gurih dengan magic com, beras masak semua dengan santan, garam, daun salam, sereh tekan tombol cook"
- "Setelah masak klik warm, tekan sekali lagi agar tanak, siap disajikan nasi dan pelengkapnya"
categories:
- Resep
tags:
- nasi
- ayam
- khas

katakunci: nasi ayam khas 
nutrition: 116 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT41M"
recipeyield: "4"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Ayam Khas Semarang](https://img-global.cpcdn.com/recipes/b821d3625031bed2/682x484cq65/nasi-ayam-khas-semarang-foto-resep-utama.webp)

6 langkah cepat dan mudah memasak  Nasi Ayam Khas Semarang yang wajib ibu coba dirumah

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Dalam Pembuatan Nasi Ayam Khas Semarang:

1. ayam kampung 1/2 ekor
1. daun salam 2 lembar
1. lengkuas 2 cm
1. daun jeruk 3 lembar
1. serai 1 batang
1. santan kental dari 1 butir kelapa 500 ml
1. santan encer sisa perasan santan kental 500 ml
1. Bumbu halus  
1. bawang putih 3 buah
1. bawang merah 7 buah
1. kemiri sangrai 4 buah
1. kunyit dibakar 1 cm
1. ketumbar 1/4 sdt
1. Gula merah garam kaldu ayam secukupnya
1. Nasi Gurih  
1. beras 500 gram
1. daun salam 3 lembar
1. daun sereh 2 lembar
1. garam 1 sdm
1. Santan secukupnya ukuran memasak nasi ukuran ruas jari 



<!--inarticleads2-->

## Langkah-langkah Untuk Membuat Nasi Ayam Khas Semarang:

1. Siapkan bahan bahan dan bumbu bumbunya
1. Tumis bumbu halus hingga matang dan harum
1. Tuang santan encer tunggu mendidih masukkan ayam masak hingga meresap dengan api kecil dan santan menyusut.
1. Tuang santan kental masak jangan sampai santan pecah ya, test rasa manis gurihnya siap disajikan dengan nasi gurih dan sayur labu krecek serta telur pindang sedappp
1. Memasak nasi gurih dengan magic com, beras masak semua dengan santan, garam, daun salam, sereh tekan tombol cook
1. Setelah masak klik warm, tekan sekali lagi agar tanak, siap disajikan nasi dan pelengkapnya




Daripada bunda beli  Nasi Ayam Khas Semarang  diluar terus, bunda  bisa membuatnya sendiri dirumah. Resep  Nasi Ayam Khas Semarang  sederhana ini cukup praktis pembuatannya, cukup menggunakan bumbu-bumbu sederhana yang ada di dapur  Nasi Ayam Khas Semarang  yang enak, kamu nikmati di rumah.
