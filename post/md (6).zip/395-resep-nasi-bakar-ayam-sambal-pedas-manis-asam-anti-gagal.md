---
description: "Resep Nasi Bakar Ayam Sambal Pedas Manis Asam Anti Gagal"
title: "Resep Nasi Bakar Ayam Sambal Pedas Manis Asam Anti Gagal"
slug: 395-resep-nasi-bakar-ayam-sambal-pedas-manis-asam-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-22T03:15:02.742Z 
thumbnail: https://img-global.cpcdn.com/recipes/8eb091cd922d5d6e/682x484cq65/nasi-bakar-ayam-sambal-pedas-manis-asam-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/8eb091cd922d5d6e/682x484cq65/nasi-bakar-ayam-sambal-pedas-manis-asam-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/8eb091cd922d5d6e/682x484cq65/nasi-bakar-ayam-sambal-pedas-manis-asam-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/8eb091cd922d5d6e/682x484cq65/nasi-bakar-ayam-sambal-pedas-manis-asam-foto-resep-utama.webp
author: Douglas Greene
ratingvalue: 3.6
reviewcount: 15
recipeingredient:
- "Bahan Nasi "
- "Nasi 1/2 kg"
- "Santan 1/4 kg"
- "santan cair 1/4 kg"
- "sereh 1 batang"
- "Daun salam 1 lembar"
- "Garam secukupnya"
- "Daun pandan 1 lembar"
- "Daun yang sudah dipanaskan di atas api "
- "Ayam sambal "
- "Ayam 1/4 kg"
- "Bawang 2 buah"
- "Bawang putih 2 siung"
- "Cabai 10 buah"
- "Tomat 1 buah"
- "Jeruk nipis 1/4 sdt"
- "Gula 1 sendok"
- "Garam 1 sdt"
- "Minyak untuk menggoreng ayam secukupnya"
recipeinstructions:
- "Cuci bersih beras, masukkan 1/4 kg santan kental, 1/4 kg santan cair masukkan daun salam, sereh masukkan garam 1 sendok teh masak diatas kompor hingga mendidih  Setelah mendidih kecilkan api tunggu sampai nasi matang"
- "Untuk Isian Basi Bakar Goreng ayam setelah itu suwir suwir, lalu ulek kasar sambal masukkan dalam wajan yang sudah diisi minyak campurkan gula, garam, air jeruk nipis masak sampai sambal matang sambil di aduk-aduk"
- "Tuang nasi 2 centong kedalam daun lalu tambahkan ayam sambalnya  Lakukan sampai nasi habis (sampai 5 porsi)  Taraaaaa Nasi ayam bakarnya siap dinikmati bersama orang spesial"
categories:
- Resep
tags:
- nasi
- bakar
- ayam

katakunci: nasi bakar ayam 
nutrition: 100 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT38M"
recipeyield: "3"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Bakar Ayam Sambal Pedas Manis Asam](https://img-global.cpcdn.com/recipes/8eb091cd922d5d6e/682x484cq65/nasi-bakar-ayam-sambal-pedas-manis-asam-foto-resep-utama.webp)

Resep Nasi Bakar Ayam Sambal Pedas Manis Asam  sederhana dengan 3 langkahcepat dan mudah yang bisa bunda coba dirumah

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Untuk Pembuatan Nasi Bakar Ayam Sambal Pedas Manis Asam:

1. Bahan Nasi 
1. Nasi 1/2 kg
1. Santan 1/4 kg
1. santan cair 1/4 kg
1. sereh 1 batang
1. Daun salam 1 lembar
1. Garam secukupnya
1. Daun pandan 1 lembar
1. Daun yang sudah dipanaskan di atas api 
1. Ayam sambal 
1. Ayam 1/4 kg
1. Bawang 2 buah
1. Bawang putih 2 siung
1. Cabai 10 buah
1. Tomat 1 buah
1. Jeruk nipis 1/4 sdt
1. Gula 1 sendok
1. Garam 1 sdt
1. Minyak untuk menggoreng ayam secukupnya



<!--inarticleads2-->

## Cara Mudah Membuat Nasi Bakar Ayam Sambal Pedas Manis Asam:

1. Cuci bersih beras, masukkan 1/4 kg santan kental, 1/4 kg santan cair masukkan daun salam, sereh masukkan garam 1 sendok teh masak diatas kompor hingga mendidih  - Setelah mendidih kecilkan api tunggu sampai nasi matang
1. Untuk Isian Basi Bakar - Goreng ayam setelah itu suwir suwir, lalu ulek kasar sambal masukkan dalam wajan yang sudah diisi minyak campurkan gula, garam, air jeruk nipis masak sampai sambal matang sambil di aduk-aduk
1. Tuang nasi 2 centong kedalam daun lalu tambahkan ayam sambalnya  - Lakukan sampai nasi habis (sampai 5 porsi) -  - Taraaaaa Nasi ayam bakarnya siap dinikmati bersama orang spesial




Selamat memasak dan menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
