---
description: "Bagaimana Membuat Nasi Uduk/Nasi lemak (basic) yang Bikin Ngiler"
title: "Bagaimana Membuat Nasi Uduk/Nasi lemak (basic) yang Bikin Ngiler"
slug: 120-bagaimana-membuat-nasi-uduk-nasi-lemak-basic-yang-bikin-ngiler
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-23T03:12:43.276Z 
thumbnail: https://img-global.cpcdn.com/recipes/4527bee9aae53466/682x484cq65/nasi-uduknasi-lemak-basic-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/4527bee9aae53466/682x484cq65/nasi-uduknasi-lemak-basic-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/4527bee9aae53466/682x484cq65/nasi-uduknasi-lemak-basic-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/4527bee9aae53466/682x484cq65/nasi-uduknasi-lemak-basic-foto-resep-utama.webp
author: Carl Butler
ratingvalue: 4.8
reviewcount: 14
recipeingredient:
- "beras 1 kg"
- "santan kelapa kental unt mengaron smp setengah matang 1 butir"
- "sereh 2 lbr daun salam 2 batang"
- "garam penyedap me  totole 1 sdm"
- "baceman bawang           lihat resep 1 sdm"
recipeinstructions:
- "Cuci bersih beras, tempatkan dlm panci, tuang santan dan semua bumbu sambil dimasak aduk² smp setengah matang/asat."
- "Siapkan kukusan/dandang yg sudah mendidih airnya, masukan aronan nasi, kukus smp sekiranya matang (kurang lbh 15-20 menit) Jadi deh nasi uduk/nasi lemak, siap sajikan dg pelengkapnya👏"
categories:
- Resep
tags:
- nasi
- uduknasi
- lemak

katakunci: nasi uduknasi lemak 
nutrition: 253 calories
recipecuisine: Indonesian
preptime: "PT11M"
cooktime: "PT50M"
recipeyield: "2"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk/Nasi lemak (basic)](https://img-global.cpcdn.com/recipes/4527bee9aae53466/682x484cq65/nasi-uduknasi-lemak-basic-foto-resep-utama.webp)

2 langkah mudah mengolah  Nasi Uduk/Nasi lemak (basic) cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Untuk Menyiapkan Nasi Uduk/Nasi lemak (basic):

1. beras 1 kg
1. santan kelapa kental unt mengaron smp setengah matang 1 butir
1. sereh 2 lbr daun salam 2 batang
1. garam penyedap me  totole 1 sdm
1. baceman bawang           lihat resep 1 sdm



<!--inarticleads2-->

## Tata Cara Membuat Nasi Uduk/Nasi lemak (basic):

1. Cuci bersih beras, tempatkan dlm panci, tuang santan dan semua bumbu sambil dimasak aduk² smp setengah matang/asat.
1. Siapkan kukusan/dandang yg sudah mendidih airnya, masukan aronan nasi, kukus smp sekiranya matang (kurang lbh 15-20 menit) - Jadi deh nasi uduk/nasi lemak, siap sajikan dg pelengkapnya👏




Selamat memasak dan menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
