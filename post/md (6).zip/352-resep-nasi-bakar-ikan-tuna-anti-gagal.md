---
description: "Resep Nasi Bakar Ikan Tuna Anti Gagal"
title: "Resep Nasi Bakar Ikan Tuna Anti Gagal"
slug: 352-resep-nasi-bakar-ikan-tuna-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-19T08:57:03.609Z 
thumbnail: https://img-global.cpcdn.com/recipes/adfdd7f1f00484cc/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/adfdd7f1f00484cc/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/adfdd7f1f00484cc/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/adfdd7f1f00484cc/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp
author: Lucile Harris
ratingvalue: 4.9
reviewcount: 6
recipeingredient:
- "Isian "
- "ikan tuna goreng suir 300-400 g"
- "daun jeruk 3 lbr"
- "kemangi Segenggam"
- "serai 1 buah"
- "Garam kaldu sesuai selera"
- "Bumbu halus "
- "bawang merah 7 siung"
- "bawang putih 4 siung"
- "cabai rawit merah 10 buah"
- "cabai rawit hijau 10 buah"
- "kunyit 1 telunjuk"
- "Nasi "
- "Nasi untuk 4 porsi"
- "Kaldu jamur "
recipeinstructions:
- "Tumis bumbu yang sudah dihaluskan dengan 6-7 sdm minyak. Hingga harum. Masukkan daun jeruk, serai Dan ikan suir. Masak sebentar, beri garam/Lada/kaldu, terakhir masukkan daun kemangi. Matikan kompor."
- "Siapkan daun pisang (bakar sebentar diatas kompor sampai daun layu agar mudah dibentuk) isikan nasi yang sudah dicampur kaldu jamur, pipihkan, lalu berikan isian."
- "Lipat Dan tusuk ujung2nya dengan lidi. Panggang hingga bungkus pisang layu atau agak mengering"
categories:
- Resep
tags:
- nasi
- bakar
- ikan

katakunci: nasi bakar ikan 
nutrition: 215 calories
recipecuisine: Indonesian
preptime: "PT26M"
cooktime: "PT51M"
recipeyield: "2"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Bakar Ikan Tuna](https://img-global.cpcdn.com/recipes/adfdd7f1f00484cc/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp)

Ingin membuat Nasi Bakar Ikan Tuna ? Coba resep berikut ini. Cara memasaknya sangat praktis namun jangan kaget jika hasilnya gurih dan lezat cocok sekali jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Untuk Menyiapkan Nasi Bakar Ikan Tuna:

1. Isian 
1. ikan tuna goreng suir 300-400 g
1. daun jeruk 3 lbr
1. kemangi Segenggam
1. serai 1 buah
1. Garam kaldu sesuai selera
1. Bumbu halus 
1. bawang merah 7 siung
1. bawang putih 4 siung
1. cabai rawit merah 10 buah
1. cabai rawit hijau 10 buah
1. kunyit 1 telunjuk
1. Nasi 
1. Nasi untuk 4 porsi
1. Kaldu jamur 



<!--inarticleads2-->

## Cara Mudah Membuat Nasi Bakar Ikan Tuna:

1. Tumis bumbu yang sudah dihaluskan dengan 6-7 sdm minyak. Hingga harum. Masukkan daun jeruk, serai Dan ikan suir. Masak sebentar, beri garam/Lada/kaldu, terakhir masukkan daun kemangi. Matikan kompor.
1. Siapkan daun pisang (bakar sebentar diatas kompor sampai daun layu agar mudah dibentuk) isikan nasi yang sudah dicampur kaldu jamur, pipihkan, lalu berikan isian.
1. Lipat Dan tusuk ujung2nya dengan lidi. Panggang hingga bungkus pisang layu atau agak mengering




Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
