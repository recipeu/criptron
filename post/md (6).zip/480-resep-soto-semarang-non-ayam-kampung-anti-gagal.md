---
description: "Resep Soto Semarang (non ayam kampung) Anti Gagal"
title: "Resep Soto Semarang (non ayam kampung) Anti Gagal"
slug: 480-resep-soto-semarang-non-ayam-kampung-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-04T12:03:57.840Z 
thumbnail: https://img-global.cpcdn.com/recipes/43d1602a320bdfbc/682x484cq65/soto-semarang-non-ayam-kampung-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/43d1602a320bdfbc/682x484cq65/soto-semarang-non-ayam-kampung-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/43d1602a320bdfbc/682x484cq65/soto-semarang-non-ayam-kampung-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/43d1602a320bdfbc/682x484cq65/soto-semarang-non-ayam-kampung-foto-resep-utama.webp
author: Ola Fisher
ratingvalue: 3.8
reviewcount: 9
recipeingredient:
- "ayam kampung saya pakai ayam broiler 250 gr"
- "air 2 liter"
- "daun salam 1 lembar"
- "daun bawang potong panjang 1 batang"
- "bawang putih goreng 2 sdm"
- "Bumbu halus "
- "bawang putih 4 siung"
- "kunyit 1 ruas"
- "jahe 1 ruas"
- "kecap manis 1 sdm"
- "Bumbu Cemplung "
- "serai memarkan 1 batang"
- "daun salam 2 lembar"
- "daun jeruk 4 lembar"
- "Seasoning "
- "garam 1 sdm"
- "gula merah iris 1 sdm"
- "merica bubuk 1/2 sdt"
- "pala bubuk saya skip 1/2 sdt"
- "kaldu jamur 1/2 sdt"
- "ketumbar bubuk 3/4 sdt"
- "Bahan Sambal "
- "cabe rawit 5"
- "bawang putih 1 siung"
- "Semua diulek hingga halus "
- "Pelengkap "
- "Nasi putih "
- "Kol iris halus seduh air panas "
- "Toge seduh air panas "
- "Soun seduh air panas "
- "Daun bawang iris"
- "Bawang goreng "
- "jeruk nipis Irisan"
recipeinstructions:
- "Rebus ayam dengan daun salam sampai empuk. Tumis bumbu halus bersama bumbu cemplung hingga harum. Tambahkan kecap manis, lanjut tumis sampai matang."
- "Masukkan tumisan bumbu ke dalam rebusan ayam. Tambahkan seasoning. Koreksi rasa. Jika dirasa sudah pas, angkat ayam untuk disuwir-suwir. Terakhir, masukkan daun bawang potong dan bawang putih goreng. Masak sebentar lalu matikan api."
- "Di mangkok, tata nasi putih, soun, kol, toge, dan suwiran ayam. Siramkan kuah soto. Taburi daun bawang dan bawang goreng. Sajikan dengan sambal dan tempe garit goreng. Jangan lupa kucurkan air jeruk nipis"
categories:
- Resep
tags:
- soto
- semarang
- non

katakunci: soto semarang non 
nutrition: 195 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT39M"
recipeyield: "4"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Soto Semarang (non ayam kampung)](https://img-global.cpcdn.com/recipes/43d1602a320bdfbc/682x484cq65/soto-semarang-non-ayam-kampung-foto-resep-utama.webp)

Resep rahasia dan cara memasak  Soto Semarang (non ayam kampung) cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Dalam Pembuatan Soto Semarang (non ayam kampung):

1. ayam kampung saya pakai ayam broiler 250 gr
1. air 2 liter
1. daun salam 1 lembar
1. daun bawang potong panjang 1 batang
1. bawang putih goreng 2 sdm
1. Bumbu halus 
1. bawang putih 4 siung
1. kunyit 1 ruas
1. jahe 1 ruas
1. kecap manis 1 sdm
1. Bumbu Cemplung 
1. serai memarkan 1 batang
1. daun salam 2 lembar
1. daun jeruk 4 lembar
1. Seasoning 
1. garam 1 sdm
1. gula merah iris 1 sdm
1. merica bubuk 1/2 sdt
1. pala bubuk saya skip 1/2 sdt
1. kaldu jamur 1/2 sdt
1. ketumbar bubuk 3/4 sdt
1. Bahan Sambal 
1. cabe rawit 5
1. bawang putih 1 siung
1. Semua diulek hingga halus 
1. Pelengkap 
1. Nasi putih 
1. Kol iris halus seduh air panas 
1. Toge seduh air panas 
1. Soun seduh air panas 
1. Daun bawang iris
1. Bawang goreng 
1. jeruk nipis Irisan



<!--inarticleads2-->

## Cara Mudah Membuat Soto Semarang (non ayam kampung):

1. Rebus ayam dengan daun salam sampai empuk. Tumis bumbu halus bersama bumbu cemplung hingga harum. Tambahkan kecap manis, lanjut tumis sampai matang.
1. Masukkan tumisan bumbu ke dalam rebusan ayam. Tambahkan seasoning. Koreksi rasa. Jika dirasa sudah pas, angkat ayam untuk disuwir-suwir. Terakhir, masukkan daun bawang potong dan bawang putih goreng. Masak sebentar lalu matikan api.
1. Di mangkok, tata nasi putih, soun, kol, toge, dan suwiran ayam. Siramkan kuah soto. Taburi daun bawang dan bawang goreng. Sajikan dengan sambal dan tempe garit goreng. Jangan lupa kucurkan air jeruk nipis




Terima kasih telah menggunakan resep yang tim kami tampilkan di halaman ini. Selamat mencoba!
