---
description: "Cara Gampang Membuat Nasi Uduk Rice cooker / Magic com yang Bikin Ngiler"
title: "Cara Gampang Membuat Nasi Uduk Rice cooker / Magic com yang Bikin Ngiler"
slug: 201-cara-gampang-membuat-nasi-uduk-rice-cooker-magic-com-yang-bikin-ngiler
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-29T00:42:24.050Z 
thumbnail: https://img-global.cpcdn.com/recipes/619dba810fd5145c/682x484cq65/nasi-uduk-rice-cooker-magic-com-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/619dba810fd5145c/682x484cq65/nasi-uduk-rice-cooker-magic-com-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/619dba810fd5145c/682x484cq65/nasi-uduk-rice-cooker-magic-com-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/619dba810fd5145c/682x484cq65/nasi-uduk-rice-cooker-magic-com-foto-resep-utama.webp
author: Leon Cross
ratingvalue: 4.6
reviewcount: 7
recipeingredient:
- "Beras 5 cup"
- "Daun salam 5-6 lbr"
- "Sereh geprek 3 btg"
- "Santan 300-400 ml"
- "Garam secukupnya  15sdt "
- "penyedap rasa ayam boleh skip 1 sdt"
- "Air secukupnya"
recipeinstructions:
- "Cuci bersih beras, masukkan semua bahan, aduk rata. Bole di tes rasa, jika kurang asin tambah. Sesuaikan takaran air dengan takaran spt biasa (lebihkan sedikit saja)"
- "Masak nasi seperti biasa. Siap dihidangkan ☺️"
categories:
- Resep
tags:
- nasi
- uduk
- rice

katakunci: nasi uduk rice 
nutrition: 244 calories
recipecuisine: Indonesian
preptime: "PT16M"
cooktime: "PT32M"
recipeyield: "2"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Rice cooker / Magic com](https://img-global.cpcdn.com/recipes/619dba810fd5145c/682x484cq65/nasi-uduk-rice-cooker-magic-com-foto-resep-utama.webp)

2 langkah mudah memasak  Nasi Uduk Rice cooker / Magic com yang musti kamu coba dirumah

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Untuk Menyiapkan Nasi Uduk Rice cooker / Magic com:

1. Beras 5 cup
1. Daun salam 5-6 lbr
1. Sereh geprek 3 btg
1. Santan 300-400 ml
1. Garam secukupnya  15sdt 
1. penyedap rasa ayam boleh skip 1 sdt
1. Air secukupnya



<!--inarticleads2-->

## Cara Menyiapkan Nasi Uduk Rice cooker / Magic com:

1. Cuci bersih beras, masukkan semua bahan, aduk rata. Bole di tes rasa, jika kurang asin tambah. Sesuaikan takaran air dengan takaran spt biasa (lebihkan sedikit saja)
1. Masak nasi seperti biasa. Siap dihidangkan ☺️




Selamat memasak dan menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
