---
description: "Resep Nasi uduk khas betawi yang Menggugah Selera"
title: "Resep Nasi uduk khas betawi yang Menggugah Selera"
slug: 79-resep-nasi-uduk-khas-betawi-yang-menggugah-selera
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-28T17:34:58.049Z 
thumbnail: https://img-global.cpcdn.com/recipes/8c177c5a893dbe96/682x484cq65/nasi-uduk-khas-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/8c177c5a893dbe96/682x484cq65/nasi-uduk-khas-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/8c177c5a893dbe96/682x484cq65/nasi-uduk-khas-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/8c177c5a893dbe96/682x484cq65/nasi-uduk-khas-betawi-foto-resep-utama.webp
author: Harriett McKinney
ratingvalue: 3.4
reviewcount: 15
recipeingredient:
- "beras 1/2 kg"
- "Bumbu masi uduk "
- "santan kara 65 ml 1 bungkus"
- "air 600 ml"
- "serai memar kan 1 Batang"
- "daun salam 2 lembar"
- "garam 1/2 sdt"
- "lada bubuk 1/2 sdt"
- "bawang merah iris tipis 4 siung"
- "Bahan bihun goreng "
- "bihun rose brand 1 keping"
- "kol di iris 2 lembar"
- "daun bawang di iris 1 Batang"
- "cabe merah di iris 1 buah"
- "nya garam dn kaldu bubuk Secukup"
- "kecap manis 1 sdm"
- "minyak untuk menumis 2 sdm"
- "Halus kan bumbu "
- "bawang putih 2 siung"
- "bawang merah 4 siung"
- "merica 1/4 sdt"
- "Telur dadar "
- "telur 2 buah"
- "margarin 2 sdm"
- "Lauk tambahan "
- "Krupuk goreng "
recipeinstructions:
- "Nasi uduk:Cuci bersih beras lalu tiris kan, tuang 600 ml air dlm pnci, tmbhkn 1 bungkus santan 65 ml dn bumbu lain nya, aduk sampe rata, dn masak supaya santan larut kmudian matikan api, dn tuang dlm pnci yg berisi beras yg sdh di cuci bersih, lalu masak sampe air mnyusut mnjdi nasi aron, lalu pindah ke pnci kukusan, dn kukus slma 30 mnit, setelah matang angkat dn sisih kn"
- "Bihun goreng: rebus bihun dlm air mndidih slma 5 mnit lalu tiris kan, iris kol daun bawang dn cabe merah, ulek bahan bumbu halus, dlm minyak pnas tumis bumbu halus dn cabe merah iris sampe harum, kmudian tmbah kn kol dn daun bawang iris aduk2 sampe layu, kmudian masukan bihun tambh kn kecap, garam dn kaldu bubuk, aduk aduk sampe rata kmudian mati kn api, dn sisih kn"
- "Telur dadar: kocok telur dlm mangkuk, kmudian pnas kn margarin dlm pnggorengn, kmudian dadar telur sampe matang, klau sdah dingin lalu potong2 dn sisih kan, Goreng jga krupuk nya dlm minyak panas sampe matang lalu tiris kan"
- "Penyelesaian: ambil nasi dn taruh dpiring, dn tambah kn lauk pelengkap nya, sajikan hangat2"
- "😋😋😋"
categories:
- Resep
tags:
- nasi
- uduk
- khas

katakunci: nasi uduk khas 
nutrition: 163 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT50M"
recipeyield: "2"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi uduk khas betawi](https://img-global.cpcdn.com/recipes/8c177c5a893dbe96/682x484cq65/nasi-uduk-khas-betawi-foto-resep-utama.webp)

Resep rahasia dan cara mengolah  Nasi uduk khas betawi cocok sekali jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Dibutuhkan Dalam Pembuatan Nasi uduk khas betawi:

1. beras 1/2 kg
1. Bumbu masi uduk 
1. santan kara 65 ml 1 bungkus
1. air 600 ml
1. serai memar kan 1 Batang
1. daun salam 2 lembar
1. garam 1/2 sdt
1. lada bubuk 1/2 sdt
1. bawang merah iris tipis 4 siung
1. Bahan bihun goreng 
1. bihun rose brand 1 keping
1. kol di iris 2 lembar
1. daun bawang di iris 1 Batang
1. cabe merah di iris 1 buah
1. nya garam dn kaldu bubuk Secukup
1. kecap manis 1 sdm
1. minyak untuk menumis 2 sdm
1. Halus kan bumbu 
1. bawang putih 2 siung
1. bawang merah 4 siung
1. merica 1/4 sdt
1. Telur dadar 
1. telur 2 buah
1. margarin 2 sdm
1. Lauk tambahan 
1. Krupuk goreng 

Nasi uduk terbuat dari beras yang dimasak dengan santan, garam juga bumbu rempah lainnya hingga menghasilkan nasi yang gurih dan memiliki aroma khas yang menggugah selera. Masih tentang nasi favorit saya, Nasi Uduk Gondangdia juga merupakan salah satu dari sekian jenis nasi yang saya suka. Jika beberapa waktu lalu saya sudah memposting Nasi Ayam Hainan, Nasi Krawu, Nasi Bakar Isi Ayam dan Teri. Cara Membuat Nasi Uduk Betawi: Tuang santan dalam wajan. 

<!--inarticleads2-->

## Cara Membuat Nasi uduk khas betawi:

1. Nasi uduk:Cuci bersih beras lalu tiris kan, tuang 600 ml air dlm pnci, tmbhkn 1 bungkus santan 65 ml dn bumbu lain nya, aduk sampe rata, dn masak supaya santan larut kmudian matikan api, dn tuang dlm pnci yg berisi beras yg sdh di cuci bersih, lalu masak sampe air mnyusut mnjdi nasi aron, lalu pindah ke pnci kukusan, dn kukus slma 30 mnit, setelah matang angkat dn sisih kn
1. Bihun goreng: rebus bihun dlm air mndidih slma 5 mnit lalu tiris kan, iris kol daun bawang dn cabe merah, ulek bahan bumbu halus, dlm minyak pnas tumis bumbu halus dn cabe merah iris sampe harum, kmudian tmbah kn kol dn daun bawang iris aduk2 sampe layu, kmudian masukan bihun tambh kn kecap, garam dn kaldu bubuk, aduk aduk sampe rata kmudian mati kn api, dn sisih kn
1. Telur dadar: kocok telur dlm mangkuk, kmudian pnas kn margarin dlm pnggorengn, kmudian dadar telur sampe matang, klau sdah dingin lalu potong2 dn sisih kan, Goreng jga krupuk nya dlm minyak panas sampe matang lalu tiris kan
1. Penyelesaian: ambil nasi dn taruh dpiring, dn tambah kn lauk pelengkap nya, sajikan hangat2
1. 😋😋😋


Masukkan bumbu halus, lalu tambahkan garam. Nasi uduk Betawi siap disajikan dan dinikmati dengan aneka lauk favorit Anda. Rasanya yang enak, Sambal Kacang nasi uduk khas betawi sangat disukai dan cocok menjadi santapan pilihan di waktu pagi. Diketahui nasi uduk adalah salah satu makanan dari nasi yang dimasak bersama santan kemudian diberi bumbu. Inilah resep nasi uduk khas Betawi yang enak dan lezat. 

Daripada   beli  Nasi uduk khas betawi  diluar terus, bunda  bisa membuatnya sendiri dirumah. Resep  Nasi uduk khas betawi  sederhana ini cukup praktis pembuatannya, serta cukup menggunakan bumbu sederhana  Nasi uduk khas betawi  yang enak, bunda nikmati di rumah.
