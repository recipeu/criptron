---
description: "Resep Nasi Uduk Betawi, Bisa Manjain Lidah"
title: "Resep Nasi Uduk Betawi, Bisa Manjain Lidah"
slug: 92-resep-nasi-uduk-betawi-bisa-manjain-lidah
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-03T05:30:32.700Z 
thumbnail: https://img-global.cpcdn.com/recipes/56b61e2f45644a87/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/56b61e2f45644a87/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/56b61e2f45644a87/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/56b61e2f45644a87/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
author: Roxie Harmon
ratingvalue: 4.4
reviewcount: 14
recipeingredient:
- "Beras 1/2 kg"
- "Santan secukupnya"
- "Serai 4 siung"
- "Daun Salam 4 helai"
- "Lengkuas secukupnya"
- "Garam secukupnya"
recipeinstructions:
- "Siapkan bahan : Beras, Santan, daun Salam, Serai, Lengkuas dan Garam. Serai dan lengkuas digeprek"
- "Cuci beras lalu rendam beras dengan santan, serai, daun salam, lengkuas dan beri garam secukupnya"
- "Rebus hingga mendidih dengan api kecil sambil diaduk-aduk supaya tidak lengket di panci"
- "Setelah air rebusan habis, pindahkan ke Dandang untuk dikukus hingga matang"
- "Nasi uduk sudah matang, siap dihidangkan dengan taburan bawang goreng"
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 144 calories
recipecuisine: Indonesian
preptime: "PT12M"
cooktime: "PT37M"
recipeyield: "2"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Betawi](https://img-global.cpcdn.com/recipes/56b61e2f45644a87/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp)

Resep rahasia Nasi Uduk Betawi    dengan 5 langkahcepat dan mudah yang wajib ibu coba dirumah

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Dalam Menyiapkan Nasi Uduk Betawi:

1. Beras 1/2 kg
1. Santan secukupnya
1. Serai 4 siung
1. Daun Salam 4 helai
1. Lengkuas secukupnya
1. Garam secukupnya



<!--inarticleads2-->

## Cara Membuat Nasi Uduk Betawi:

1. Siapkan bahan : Beras, Santan, daun Salam, Serai, Lengkuas dan Garam. Serai dan lengkuas digeprek
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/0e02e60f2f6754c5/160x128cq70/nasi-uduk-betawi-langkah-memasak-1-foto.webp" alt="Nasi Uduk Betawi" width="340" height="340">
><img class="lazyload" data-src="https://img-global.cpcdn.com/steps/0944a9dc8eda452b/160x128cq70/nasi-uduk-betawi-langkah-memasak-1-foto.webp" alt="Nasi Uduk Betawi" width="340" height="340">
>1. Cuci beras lalu rendam beras dengan santan, serai, daun salam, lengkuas dan beri garam secukupnya
1. Rebus hingga mendidih dengan api kecil sambil diaduk-aduk supaya tidak lengket di panci
1. Setelah air rebusan habis, pindahkan ke Dandang untuk dikukus hingga matang
1. Nasi uduk sudah matang, siap dihidangkan dengan taburan bawang goreng




Selamat memasak dan menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
