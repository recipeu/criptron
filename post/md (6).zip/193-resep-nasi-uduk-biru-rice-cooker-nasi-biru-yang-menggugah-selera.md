---
description: "Resep Nasi Uduk Biru Rice Cooker/ Nasi Biru yang Menggugah Selera"
title: "Resep Nasi Uduk Biru Rice Cooker/ Nasi Biru yang Menggugah Selera"
slug: 193-resep-nasi-uduk-biru-rice-cooker-nasi-biru-yang-menggugah-selera
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-24T12:02:14.243Z 
thumbnail: https://img-global.cpcdn.com/recipes/0cb18a5d11cd1500/682x484cq65/nasi-uduk-biru-rice-cooker-nasi-biru-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/0cb18a5d11cd1500/682x484cq65/nasi-uduk-biru-rice-cooker-nasi-biru-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/0cb18a5d11cd1500/682x484cq65/nasi-uduk-biru-rice-cooker-nasi-biru-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/0cb18a5d11cd1500/682x484cq65/nasi-uduk-biru-rice-cooker-nasi-biru-foto-resep-utama.webp
author: Tony Becker
ratingvalue: 3.2
reviewcount: 10
recipeingredient:
- "beras 200 gr"
- "kembang telang rendam air panas 15"
- "santan kara kecil 1/2 bungkus"
- "serai geprek 1 batang"
- "jahe geprek 1 ruas"
- "daun pandan 1 helai"
- "daun salam 2 helai"
- "daun jeruk 2 helai"
- "bawang putih geprek 1 siung"
- "Garam "
- "Gula "
- "Penyedap rasa "
recipeinstructions:
- "Rendam kembang telang di air panas kurleb 30 menit. Lalu saring."
- "Cuci beras, masukan santan, rempah2, garam, gula, penyedap rasa dan air rendaman kembang telang &amp; air biasa (saya 2 cup beras termasuk air rendaman kembang telang)"
- "Masak di rice cooker seperti memasak nasi biasa. Setelah matang nasi bisa dimakan bersama berbagai lauk. Tambahkan bawang goreng supaya lebih sedap."
categories:
- Resep
tags:
- nasi
- uduk
- biru

katakunci: nasi uduk biru 
nutrition: 297 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT56M"
recipeyield: "4"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Biru Rice Cooker/ Nasi Biru](https://img-global.cpcdn.com/recipes/0cb18a5d11cd1500/682x484cq65/nasi-uduk-biru-rice-cooker-nasi-biru-foto-resep-utama.webp)

Resep rahasia Nasi Uduk Biru Rice Cooker/ Nasi Biru  enak dengan 3 langkahcepat dan mudah cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Dibutuhkan Dalam Pembuatan Nasi Uduk Biru Rice Cooker/ Nasi Biru:

1. beras 200 gr
1. kembang telang rendam air panas 15
1. santan kara kecil 1/2 bungkus
1. serai geprek 1 batang
1. jahe geprek 1 ruas
1. daun pandan 1 helai
1. daun salam 2 helai
1. daun jeruk 2 helai
1. bawang putih geprek 1 siung
1. Garam 
1. Gula 
1. Penyedap rasa 



<!--inarticleads2-->

## Cara Mudah Membuat Nasi Uduk Biru Rice Cooker/ Nasi Biru:

1. Rendam kembang telang di air panas kurleb 30 menit. Lalu saring.
1. Cuci beras, masukan santan, rempah2, garam, gula, penyedap rasa dan air rendaman kembang telang &amp; air biasa (saya 2 cup beras termasuk air rendaman kembang telang)
1. Masak di rice cooker seperti memasak nasi biasa. Setelah matang nasi bisa dimakan bersama berbagai lauk. Tambahkan bawang goreng supaya lebih sedap.




Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
