---
description: "Bagaimana Membuat Nasi bakar ayam kemangi yang Menggugah Selera"
title: "Bagaimana Membuat Nasi bakar ayam kemangi yang Menggugah Selera"
slug: 399-bagaimana-membuat-nasi-bakar-ayam-kemangi-yang-menggugah-selera
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-15T17:00:38.617Z 
thumbnail: https://img-global.cpcdn.com/recipes/5dc4826228ce6caa/682x484cq65/nasi-bakar-ayam-kemangi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/5dc4826228ce6caa/682x484cq65/nasi-bakar-ayam-kemangi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/5dc4826228ce6caa/682x484cq65/nasi-bakar-ayam-kemangi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/5dc4826228ce6caa/682x484cq65/nasi-bakar-ayam-kemangi-foto-resep-utama.webp
author: Benjamin Marsh
ratingvalue: 4.5
reviewcount: 5
recipeingredient:
- "ayam 1/2 kg"
- "Daun pisang secukupnya"
- "nasi putih 1 piring"
- "margarin 1/2 sdm"
- " Bumbu halus  "
- "cabai merah besar 2"
- "cabai kecil 10"
- "bawang putih 6 siung"
- "daun jeruk 3 lembar"
- "kemangi 30 pucuk daun"
- "garam 1/2 sdm"
- "gula 1/2 sdm"
- "merica 1/2 sdm"
- "kaldu jamur 1/2 sdm"
recipeinstructions:
- "Potong ayam, saya pakai bagian dada tanpa tulang.  Cuci bersih ayam kemudian saya tumis menggunakan margarin hingga berubah warna."
- "Sambil menunggu ayam, rebus cabai besar, cabai kecil dan juga bawang putih sampai mendidih.  Kemudian haluskan bumbu tersebut."
- "Tiriskan ayam jika sudah berubah warna.  Kemudian tumis bumbu halus dengan sedikit minyak, masukkan daun jeruk tumis hingga harum.  🌼Masukkan garam, gula, merica, penyedap rasa, dan juga kaldu jamur, aduk hingga merata.  🌼Cuci daun kemangi kemudian masukkan, aduk rata hingga aromanya wangi, kemudian masukkan daging ayamnya aduk kembali."
- ""
- "Ingat untuk koreksi rasa, angkat ayam jika sudah matang."
- "Siapkan daun pisang dan juga tusuk gigi/ semat.  Bersihkan daun pisang kemudian letakkan nasi putih, taburkan daging ayam diatasnya dan tambahkan daun kemangi.  Kemudian digulung dan tutup menggunakan tusuk gigi atau semat."
- "Bakar nasi dengan api kecil saja, agar matangnya merata.  Ingat untuk dibalik-balik ya nasi bakarnya, bair tidak gosong 😁 Angkat nasi bakar jika sudah matang."
categories:
- Resep
tags:
- nasi
- bakar
- ayam

katakunci: nasi bakar ayam 
nutrition: 242 calories
recipecuisine: Indonesian
preptime: "PT13M"
cooktime: "PT38M"
recipeyield: "2"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi bakar ayam kemangi](https://img-global.cpcdn.com/recipes/5dc4826228ce6caa/682x484cq65/nasi-bakar-ayam-kemangi-foto-resep-utama.webp)

Resep rahasia Nasi bakar ayam kemangi  sederhana dengan 7 langkahmudah dan cepat cocok banget jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Dalam Pembuatan Nasi bakar ayam kemangi:

1. ayam 1/2 kg
1. Daun pisang secukupnya
1. nasi putih 1 piring
1. margarin 1/2 sdm
1.  Bumbu halus  
1. cabai merah besar 2
1. cabai kecil 10
1. bawang putih 6 siung
1. daun jeruk 3 lembar
1. kemangi 30 pucuk daun
1. garam 1/2 sdm
1. gula 1/2 sdm
1. merica 1/2 sdm
1. kaldu jamur 1/2 sdm

Resep dan cara memasak nasi bakar. Nasi Bakar Ayam Suwir Kemangi. beras•Santan•daun pandan•daun serai•garam•Isian nasi bakarnya di resep sebelumnya•daun kemangi. Kemudian tata daun pisang, nasi liwet serta tambahkan kemangi kemudian tambahkan suwiran ayam, tembahkan lagi kemangi di atas ayam dan dapat pula tambahkan irisan cabe rawit apabila anda menyukai pedas, setelah itu bakar di atas grill pan, bolak - balik hingga matang, angkat dan hidangkan. Biasa ditemukan di Pulau Jawa, nasi bakar berisi beragam protein. 

<!--inarticleads2-->

## Langkah-langkah Untuk Menyiapkan Nasi bakar ayam kemangi:

1. Potong ayam, saya pakai bagian dada tanpa tulang.  - Cuci bersih ayam kemudian saya tumis menggunakan margarin hingga berubah warna.
1. Sambil menunggu ayam, rebus cabai besar, cabai kecil dan juga bawang putih sampai mendidih.  - Kemudian haluskan bumbu tersebut.
1. Tiriskan ayam jika sudah berubah warna.  - Kemudian tumis bumbu halus dengan sedikit minyak, masukkan daun jeruk tumis hingga harum.  - 🌼Masukkan garam, gula, merica, penyedap rasa, dan juga kaldu jamur, aduk hingga merata.  - 🌼Cuci daun kemangi kemudian masukkan, aduk rata hingga aromanya wangi, kemudian masukkan daging ayamnya aduk kembali.
1. 
1. Ingat untuk koreksi rasa, angkat ayam jika sudah matang.
1. Siapkan daun pisang dan juga tusuk gigi/ semat.  - Bersihkan daun pisang kemudian letakkan nasi putih, taburkan daging ayam diatasnya dan tambahkan daun kemangi.  - Kemudian digulung dan tutup menggunakan tusuk gigi atau semat.
1. Bakar nasi dengan api kecil saja, agar matangnya merata.  - Ingat untuk dibalik-balik ya nasi bakarnya, bair tidak gosong 😁 - Angkat nasi bakar jika sudah matang.


Salah satu yang paling disukai adalah daging ayam dengan sentuhan daun kemangi. Bisa untuk ide menu makan siang bersama keluarga, berikut resep membuat nasi bakar ayam kemangi yang enak dan mudah. Nasi bakar ayam kemangi adalah salah satu inovasi masakan Nusantara yang sangat terkenal di seluruh Indonesia terutama di pulau Jawa. Aroma harum muncul dari daun kemangi yang ada dan dipadukan dengan daging ayam, sungguh menambah nikmatnya nasi goreng bakar kemangi ini. There are so many versions of nasi bakar out there and honestly, there aren&#39;t really any right or wrong recipes if you ask me. 

Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
