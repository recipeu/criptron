---
description: "Bagaimana Membuat Nasi Uduk khas Betawi Anti Gagal"
title: "Bagaimana Membuat Nasi Uduk khas Betawi Anti Gagal"
slug: 114-bagaimana-membuat-nasi-uduk-khas-betawi-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-04T11:09:40.463Z 
thumbnail: https://img-global.cpcdn.com/recipes/1d61f77f87e35f8d/682x484cq65/nasi-uduk-khas-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/1d61f77f87e35f8d/682x484cq65/nasi-uduk-khas-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/1d61f77f87e35f8d/682x484cq65/nasi-uduk-khas-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/1d61f77f87e35f8d/682x484cq65/nasi-uduk-khas-betawi-foto-resep-utama.webp
author: Harriett Stevenson
ratingvalue: 3.3
reviewcount: 13
recipeingredient:
- "beras pulen 1 ltr"
- "santan sedang Secukupnya"
- "serai 3 btg"
- "Lengkoas geprek 1 ruas"
- "bawang merah agak besar parut 5 bh"
- "daun salam 7 lbr"
- "jahe kupas kulitnya parut 1 ruas"
- "kayu manis bisa di skip 1 ruas"
- "garam Secukupnya"
recipeinstructions:
- "Cuci bersih beras, lalu sisihkan"
- "Rebus santan, beri garam aduk sampai mendidih setelah itu masukkan parutan jahe n bawang aduk kembali berturut2 masukan salam, sereh, lengkoas dan kayu manis."
- "Kemudian masukan berasnya, aduk smp menjadi aron koreksi rasa."
- "Kemudian kukus aron sampai matang."
- "Nasi uduk siap dihidangkan, ditambah krupuk, sambal, bawang goreng. Semur dll"
- "Sedikit tips, kalo membuat nasi uduk jgn takut menggunakan bumbu rempah (jahe bisa juga di geprek aja ya, salam dan sereh) agak banyak."
categories:
- Resep
tags:
- nasi
- uduk
- khas

katakunci: nasi uduk khas 
nutrition: 244 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT58M"
recipeyield: "2"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk khas Betawi](https://img-global.cpcdn.com/recipes/1d61f77f87e35f8d/682x484cq65/nasi-uduk-khas-betawi-foto-resep-utama.webp)

Ingin membuat Nasi Uduk khas Betawi ? Coba resep berikut ini. Cara memasaknya sangat praktis namun jangan kaget jika hasilnya gurih dan lezat yang wajib kamu coba dirumah

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Dalam Menyiapkan Nasi Uduk khas Betawi:

1. beras pulen 1 ltr
1. santan sedang Secukupnya
1. serai 3 btg
1. Lengkoas geprek 1 ruas
1. bawang merah agak besar parut 5 bh
1. daun salam 7 lbr
1. jahe kupas kulitnya parut 1 ruas
1. kayu manis bisa di skip 1 ruas
1. garam Secukupnya



<!--inarticleads2-->

## Langkah-langkah Untuk Membuat Nasi Uduk khas Betawi:

1. Cuci bersih beras, lalu sisihkan
1. Rebus santan, beri garam aduk sampai mendidih setelah itu masukkan parutan jahe n bawang aduk kembali berturut2 masukan salam, sereh, lengkoas dan kayu manis.
1. Kemudian masukan berasnya, aduk smp menjadi aron koreksi rasa.
1. Kemudian kukus aron sampai matang.
1. Nasi uduk siap dihidangkan, ditambah krupuk, sambal, bawang goreng. Semur dll
1. Sedikit tips, kalo membuat nasi uduk jgn takut menggunakan bumbu rempah (jahe bisa juga di geprek aja ya, salam dan sereh) agak banyak.




Salah satu kuliner yang cukup praktis pembuatannya adalah  Nasi Uduk khas Betawi. Selain itu  Nasi Uduk khas Betawi  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu lakukan 6 langkah, dan  Nasi Uduk khas Betawi  pun siap di hidangkan. selamat mencoba !
