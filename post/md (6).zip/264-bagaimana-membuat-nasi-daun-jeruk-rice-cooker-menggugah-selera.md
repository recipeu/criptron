---
description: "Bagaimana Membuat Nasi Daun Jeruk #Rice Cooker, Menggugah Selera"
title: "Bagaimana Membuat Nasi Daun Jeruk #Rice Cooker, Menggugah Selera"
slug: 264-bagaimana-membuat-nasi-daun-jeruk-rice-cooker-menggugah-selera
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-29T01:28:54.765Z 
thumbnail: https://img-global.cpcdn.com/recipes/f7e476bcefdecbdc/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/f7e476bcefdecbdc/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/f7e476bcefdecbdc/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/f7e476bcefdecbdc/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
author: Hannah Sherman
ratingvalue: 3.3
reviewcount: 9
recipeingredient:
- "Beras 2 cup"
- "Daun jeruk cincangiris halus 15 lbr"
- "Sereh geprek 1 btg"
- "Daun salam 3 lbr"
- "Butter Margarin 1 sdm"
- "Kaldu bubuk "
- "Garam "
- "Merica bubuk "
- "Air secukupnya"
recipeinstructions:
- "Cuci bersih beras dan berikan air seperti takaran air mau masak nasi biasa"
- "Siapkan daun jeruk yg telah di cincang/iris, daun salam, sereh yg telah digeprek, butter/ mentega, garam, kaldu bubuk dan merica secukupnya sesuai selera. Masukan semua bahan ke dalam wadah rice cooker dan aduk2 rata."
- "Masak beras di rice cooker sambil terus diaduk2 sekali2 sebelum beras masak."
- "NASI DAUN JERUK gurih dan harum bgt siap dinikmati dengan lauk ya... Selamat mencoba, Tuhan memberkati 🙏😇"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 260 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT30M"
recipeyield: "1"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk #Rice Cooker](https://img-global.cpcdn.com/recipes/f7e476bcefdecbdc/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp)

Ingin membuat Nasi Daun Jeruk #Rice Cooker ? Coba resep berikut ini. Cara memasaknya sangat praktis namun jangan kaget jika hasilnya gurih dan lezat yang bisa kamu coba segera

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Untuk Pembuatan Nasi Daun Jeruk #Rice Cooker:

1. Beras 2 cup
1. Daun jeruk cincangiris halus 15 lbr
1. Sereh geprek 1 btg
1. Daun salam 3 lbr
1. Butter Margarin 1 sdm
1. Kaldu bubuk 
1. Garam 
1. Merica bubuk 
1. Air secukupnya



<!--inarticleads2-->

## Langkah-langkah Untuk Membuat Nasi Daun Jeruk #Rice Cooker:

1. Cuci bersih beras dan berikan air seperti takaran air mau masak nasi biasa
1. Siapkan daun jeruk yg telah di cincang/iris, daun salam, sereh yg telah digeprek, butter/ mentega, garam, kaldu bubuk dan merica secukupnya sesuai selera. Masukan semua bahan ke dalam wadah rice cooker dan aduk2 rata.
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/7c8c967590c871ae/160x128cq70/nasi-daun-jeruk-rice-cooker-langkah-memasak-2-foto.webp" alt="Nasi Daun Jeruk #Rice Cooker" width="340" height="340">
><img class="lazyload" data-src="https://img-global.cpcdn.com/steps/b79f2f703f96e8a0/160x128cq70/nasi-daun-jeruk-rice-cooker-langkah-memasak-2-foto.webp" alt="Nasi Daun Jeruk #Rice Cooker" width="340" height="340">
>1. Masak beras di rice cooker sambil terus diaduk2 sekali2 sebelum beras masak.
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/907f3ceb0451ad18/160x128cq70/nasi-daun-jeruk-rice-cooker-langkah-memasak-3-foto.webp" alt="Nasi Daun Jeruk #Rice Cooker" width="340" height="340">
><img class="lazyload" data-src="https://img-global.cpcdn.com/steps/8695ecd51669def2/160x128cq70/nasi-daun-jeruk-rice-cooker-langkah-memasak-3-foto.webp" alt="Nasi Daun Jeruk #Rice Cooker" width="340" height="340">
><img class="lazyload" data-src="https://img-global.cpcdn.com/steps/c2ec5f66b2409036/160x128cq70/nasi-daun-jeruk-rice-cooker-langkah-memasak-3-foto.webp" alt="Nasi Daun Jeruk #Rice Cooker" width="340" height="340">
>1. NASI DAUN JERUK gurih dan harum bgt siap dinikmati dengan lauk ya... Selamat mencoba, Tuhan memberkati 🙏😇
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/40bda9da89f2770a/160x128cq70/nasi-daun-jeruk-rice-cooker-langkah-memasak-4-foto.webp" alt="Nasi Daun Jeruk #Rice Cooker" width="340" height="340">
><img class="lazyload" data-src="https://img-global.cpcdn.com/steps/e345b9120a0fd5c7/160x128cq70/nasi-daun-jeruk-rice-cooker-langkah-memasak-4-foto.webp" alt="Nasi Daun Jeruk #Rice Cooker" width="340" height="340">
>



Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
