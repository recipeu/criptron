---
description: "Resep Nasi Bakar Ikan Tuna yang Sempurna"
title: "Resep Nasi Bakar Ikan Tuna yang Sempurna"
slug: 357-resep-nasi-bakar-ikan-tuna-yang-sempurna
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-23T21:35:43.654Z 
thumbnail: https://img-global.cpcdn.com/recipes/27bb051406b5cf1d/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/27bb051406b5cf1d/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/27bb051406b5cf1d/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/27bb051406b5cf1d/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp
author: Charlie Harris
ratingvalue: 3
reviewcount: 10
recipeingredient:
- "nasi putih 600 gr"
- "fillet ikan tuna potong kotak 300 gr"
- "kemangi 1 ikat"
- "daun jeruk 3 lbr"
- "laos geprek 1/2 ruas"
- "daun salam 2 lbr"
- "sereh geprek 1 btg"
- "Bumbu halus  "
- "bawang merah 3 siung"
- "bawang putih 2 siung"
- "kemiri 1 btr"
- "cabe merah besar 2 buah"
- "cabe keriting 4 buah"
- "cabe rawit 4 buah"
- "tomat 1/2 buah"
- "kunyit 1/2 ruas"
- "jahe 1/4 ruas"
recipeinstructions:
- "Blender bumbu halus dengan sedikit air hingga tercampur rata"
- "Panaskan minyak, tumis bumbu halus. Masak hingga setengah tanak"
- "Masukkan sereh, laos, daun jeruk, daun salam dan ikan tuna"
- "Tambahkan garam, gula dan penyedap secukupnya. Tes rasa hingga pas dan sedap"
- "Masak kembali sampai bumbu dan ikan tuna matang. Masukkan kemangi, aduk rata dan sisihkan."
- "Ambil 2lembar daun pisang, dengan ukuran besar dan yang lebih kecil."
- "Letakkan 150 gr nasi, isian tuna 2 sdm dan sedikit kemangi"
- "Bungkus rapi dengan memadatkan dan digulung seperti lontong. Sematkan ujung daun pisang dengan lidi atau staples"
- "Bakar nasi diatas teflon anti lengket hingga daun layu dan wangi sambil dibalik balik."
- "Sajikan nasi bakar dengan kerupuk dan aneka lauk sesuai selera."
categories:
- Resep
tags:
- nasi
- bakar
- ikan

katakunci: nasi bakar ikan 
nutrition: 279 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT42M"
recipeyield: "1"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Bakar Ikan Tuna](https://img-global.cpcdn.com/recipes/27bb051406b5cf1d/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp)

Ingin membuat Nasi Bakar Ikan Tuna ? Coba resep berikut ini. Cara memasaknya sangat praktis namun hasilnya gurih dan lezat yang bisa kamu coba dirumah

<!--inarticleads1-->

## Bahan-bahan Yang Dibutuhkan Dalam Menyiapkan Nasi Bakar Ikan Tuna:

1. nasi putih 600 gr
1. fillet ikan tuna potong kotak 300 gr
1. kemangi 1 ikat
1. daun jeruk 3 lbr
1. laos geprek 1/2 ruas
1. daun salam 2 lbr
1. sereh geprek 1 btg
1. Bumbu halus  
1. bawang merah 3 siung
1. bawang putih 2 siung
1. kemiri 1 btr
1. cabe merah besar 2 buah
1. cabe keriting 4 buah
1. cabe rawit 4 buah
1. tomat 1/2 buah
1. kunyit 1/2 ruas
1. jahe 1/4 ruas



<!--inarticleads2-->

## Cara Membuat Nasi Bakar Ikan Tuna:

1. Blender bumbu halus dengan sedikit air hingga tercampur rata
1. Panaskan minyak, tumis bumbu halus. Masak hingga setengah tanak
1. Masukkan sereh, laos, daun jeruk, daun salam dan ikan tuna
1. Tambahkan garam, gula dan penyedap secukupnya. Tes rasa hingga pas dan sedap
1. Masak kembali sampai bumbu dan ikan tuna matang. Masukkan kemangi, aduk rata dan sisihkan.
1. Ambil 2lembar daun pisang, dengan ukuran besar dan yang lebih kecil.
1. Letakkan 150 gr nasi, isian tuna 2 sdm dan sedikit kemangi
1. Bungkus rapi dengan memadatkan dan digulung seperti lontong. Sematkan ujung daun pisang dengan lidi atau staples
1. Bakar nasi diatas teflon anti lengket hingga daun layu dan wangi sambil dibalik balik.
1. Sajikan nasi bakar dengan kerupuk dan aneka lauk sesuai selera.




Demikian informasi  resep Nasi Bakar Ikan Tuna   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
