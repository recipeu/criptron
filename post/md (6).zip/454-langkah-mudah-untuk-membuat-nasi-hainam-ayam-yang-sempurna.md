---
description: "Langkah Mudah untuk Membuat Nasi hainam ayam yang Sempurna"
title: "Langkah Mudah untuk Membuat Nasi hainam ayam yang Sempurna"
slug: 454-langkah-mudah-untuk-membuat-nasi-hainam-ayam-yang-sempurna
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-14T04:28:54.708Z 
thumbnail: https://img-global.cpcdn.com/recipes/3f0ed26886e9b170/682x484cq65/nasi-hainam-ayam-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/3f0ed26886e9b170/682x484cq65/nasi-hainam-ayam-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/3f0ed26886e9b170/682x484cq65/nasi-hainam-ayam-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/3f0ed26886e9b170/682x484cq65/nasi-hainam-ayam-foto-resep-utama.webp
author: Lester Miles
ratingvalue: 4.1
reviewcount: 6
recipeingredient:
- "ayam kampung ukuran sedang yg difillet dengan kulit 1 ekor"
- "Beras 3 cup"
- "Air 2 liter"
- "Bawang merah 3 siung"
- "Bawang putih 5 siung"
- "Jahe 3 cm"
- "Saus tiram 2 sdm"
- "Kecap asin 3 sdm"
- "Minyak wijen 2 sdm"
- "Minyak jahe 3 sdm jahe yg d oseng pk minyak dgn api kecil "
- "Garam lada dan totole secukupnya"
- "Kecap ikan 1 sdm"
- "Angciu 1 sdm bs skip jika ingin buat yg halal "
recipeinstructions:
- "Haluskan bawang merah,bawang putih dan jahe. Oseng dengan minyak sdikit"
- "Masukkan ayam fillrt beserta tulangnya"
- "Masukkan air 2 liter, aduk rata hingga mendidih"
- "Masukkan beras yang sudah dicuci"
- "Masukkan saus tiram, kecap asin, kecap ikan, lada, garam, totole,minyak wijen dan minyak jahe (bs d tambahkan bbrp iris jahe jg. Jadinya lbh wangi)"
- "Aron beras sekitar 20 mnt dgn api besar. Atau sampai air meresap habis."
- "Panaskan kukusan sebelumnya. Lalu pindahkan nasi hainam. Kukus selama 30 menit."
- "Ayam fillet bs d potong kecil2 untuk d taburkan d atas nasi hainam..tulang ayam bisa d keluarkan dari nasi. Biasanya masi banyak dagingnya yg menempel d tulangnya."
- "Taburkan bawang putih goreng &amp; wansui, add on sambal ataupun bs membuat kuah nya dr kaldu tulang ayam/ bubuk, tungcai, kecap asin dan daun bawang."
- "Nasi hainam siap dinikmati selagi hangat 😊"
categories:
- Resep
tags:
- nasi
- hainam
- ayam

katakunci: nasi hainam ayam 
nutrition: 149 calories
recipecuisine: Indonesian
preptime: "PT36M"
cooktime: "PT60M"
recipeyield: "3"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi hainam ayam](https://img-global.cpcdn.com/recipes/3f0ed26886e9b170/682x484cq65/nasi-hainam-ayam-foto-resep-utama.webp)

Ingin membuat Nasi hainam ayam ? Coba resep berikut ini. Cara memasaknya sangat praktis namun jangan kaget jika hasilnya gurih dan lezat cocok sekali jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Untuk Menyiapkan Nasi hainam ayam:

1. ayam kampung ukuran sedang yg difillet dengan kulit 1 ekor
1. Beras 3 cup
1. Air 2 liter
1. Bawang merah 3 siung
1. Bawang putih 5 siung
1. Jahe 3 cm
1. Saus tiram 2 sdm
1. Kecap asin 3 sdm
1. Minyak wijen 2 sdm
1. Minyak jahe 3 sdm jahe yg d oseng pk minyak dgn api kecil 
1. Garam lada dan totole secukupnya
1. Kecap ikan 1 sdm
1. Angciu 1 sdm bs skip jika ingin buat yg halal 

Apollo Nasi Ayam Hainam Jakarta, Gajah Mada; View reviews, menu, contact, location, and more for Ini salah satu nasi hainam yang jadi wishlistku karena pas SD aku lumayan sering ngelewatin. Kalori Nasi Hainam Babi / I was surprised to see that they only gave ayam rebus and babi panggang thats it. Nasi putih yang disajikan bersama babi panggang asin, babi panggang manis( char siu). Cara membuat nasi hainam ini tergolong unik. 

<!--inarticleads2-->

## Tata Cara Menyiapkan Nasi hainam ayam:

1. Haluskan bawang merah,bawang putih dan jahe. Oseng dengan minyak sdikit
1. Masukkan ayam fillrt beserta tulangnya
1. Masukkan air 2 liter, aduk rata hingga mendidih
1. Masukkan beras yang sudah dicuci
1. Masukkan saus tiram, kecap asin, kecap ikan, lada, garam, totole,minyak wijen dan minyak jahe (bs d tambahkan bbrp iris jahe jg. Jadinya lbh wangi)
1. Aron beras sekitar 20 mnt dgn api besar. Atau sampai air meresap habis.
1. Panaskan kukusan sebelumnya. Lalu pindahkan nasi hainam. Kukus selama 30 menit.
1. Ayam fillet bs d potong kecil2 untuk d taburkan d atas nasi hainam..tulang ayam bisa d keluarkan dari nasi. Biasanya masi banyak dagingnya yg menempel d tulangnya.
1. Taburkan bawang putih goreng &amp; wansui, add on sambal ataupun bs membuat kuah nya dr kaldu tulang ayam/ bubuk, tungcai, kecap asin dan daun bawang.
1. Nasi hainam siap dinikmati selagi hangat 😊


Terutama terletak pada bagian nasi yang dimasak dengan kaldu ayam disertai bumbu rempah di dalam rice cooker, sehingga membuatnya menjadi. Resep Nasi Ayam Hainan, Ikuti video masak cara membuat nasi ayam hainam Siapkan Bahan &amp; bumbunya Nasi Ayam Hainan adalah salah satu makanan populer di beberapa negara, salah. Resep nasi ayam hainan super simple masak pakai rice cooker. Jikalau membahas nasi hainam, umumnya akan seketika terbayang dengan nasi yang berwarna gelap kecoklatan. Nasi hainam merupakan kuliner nasi khas oriental. 

Terima kasih telah membaca resep yang tim kami tampilkan di halaman ini. Selamat mencoba!
