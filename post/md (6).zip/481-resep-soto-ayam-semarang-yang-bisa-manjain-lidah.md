---
description: "Resep Soto Ayam Semarang yang Bisa Manjain Lidah"
title: "Resep Soto Ayam Semarang yang Bisa Manjain Lidah"
slug: 481-resep-soto-ayam-semarang-yang-bisa-manjain-lidah
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-10T21:26:15.023Z 
thumbnail: https://img-global.cpcdn.com/recipes/c0ea52389fd7d1b5/682x484cq65/soto-ayam-semarang-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/c0ea52389fd7d1b5/682x484cq65/soto-ayam-semarang-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/c0ea52389fd7d1b5/682x484cq65/soto-ayam-semarang-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/c0ea52389fd7d1b5/682x484cq65/soto-ayam-semarang-foto-resep-utama.webp
author: Gordon Vargas
ratingvalue: 3
reviewcount: 4
recipeingredient:
- "Kaldu  "
- "daging ayam 250 grm"
- "Mill air 1000"
- "daun bawang 1 batang"
- "daun seledri 1"
- "Bahan pelengkap "
- "soun rebus 1 bungkus"
- "kecambah rebus 2 genggam"
- "daun kubis iris 2 helai"
- "daun seledri iris 1 helai"
- "Bawang merah goreng "
- "jeruk nipis potong jadi 8 1 buah"
- "Nasi secukupnya"
- "Bahan kuah "
- "Air rebusan kaldu "
- "daun salam 1 lembar"
- "sereh geprek 1 batang"
- "daun jeruk atau kulit jeruk purut 3"
- "Bumbu halus "
- "bawang merah 6"
- "bawang putih 4"
- "kemiri sangrai 2 butir"
- "Bumbu tambahan "
- "bubuk merica Secukupnya"
- "bubuk kunyit Secukupnya"
- "bubuk jinten ketumbar dan pala Secukupnya"
- "Garam gula pasir penyedap rasa Masako "
- "Pelengkap sajian "
- "Kecap manis "
- "Sambal "
- "Lauk tempe goreng dll "
recipeinstructions:
- "Cuci bersih daging ayam, Masak air hingga mendidih, Rebus 30 menit, ayam, daun bawang, dan seledri. Setelah 30 menit buang daun bawang dan seledrinya. Sisihkan daging ayamnya."
- "Kemudian, Goreng daging ayam hingga sedikit garing, Tiriskan."
- "Potong jeruk nipis, iris daun seledri, kol dan kemudian rebus kecambah serta bihun. Suir2 ayam dan siapkan pula bawang merah goreng. Sisihkan ya...lanjut bikin kuah.."
- "Haluskan bumbu, tumis bumbu hingga harum, tambahkan serai, masukkan bubuk merica, bubuk kunyit dan ketumbar, bubuk pala, serta sedikit jinten. Tumis kembali hingga harum."
- "Tambahkan air kaldu ayam yg tadi sudah direbus bersama daging ayam ya...masak hingga mendidih tambahkan daun salam dan daun jeruk atau kulit jeruk purut. Garam, penyedap rasa, gula pasir, Masak hingga kuah harum."
- "Racik soto, dengan nasi dan bahan lainnya, sajikan bersama kuah hidangkan selagi hangat."
categories:
- Resep
tags:
- soto
- ayam
- semarang

katakunci: soto ayam semarang 
nutrition: 147 calories
recipecuisine: Indonesian
preptime: "PT12M"
cooktime: "PT37M"
recipeyield: "4"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Soto Ayam Semarang](https://img-global.cpcdn.com/recipes/c0ea52389fd7d1b5/682x484cq65/soto-ayam-semarang-foto-resep-utama.webp)

Ingin membuat Soto Ayam Semarang ? Coba resep berikut ini. Cara memasaknya sangat praktis namun jangan kaget jika hasilnya gurih dan lezat cocok sekali jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Dalam Menyiapkan Soto Ayam Semarang:

1. Kaldu  
1. daging ayam 250 grm
1. Mill air 1000
1. daun bawang 1 batang
1. daun seledri 1
1. Bahan pelengkap 
1. soun rebus 1 bungkus
1. kecambah rebus 2 genggam
1. daun kubis iris 2 helai
1. daun seledri iris 1 helai
1. Bawang merah goreng 
1. jeruk nipis potong jadi 8 1 buah
1. Nasi secukupnya
1. Bahan kuah 
1. Air rebusan kaldu 
1. daun salam 1 lembar
1. sereh geprek 1 batang
1. daun jeruk atau kulit jeruk purut 3
1. Bumbu halus 
1. bawang merah 6
1. bawang putih 4
1. kemiri sangrai 2 butir
1. Bumbu tambahan 
1. bubuk merica Secukupnya
1. bubuk kunyit Secukupnya
1. bubuk jinten ketumbar dan pala Secukupnya
1. Garam gula pasir penyedap rasa Masako 
1. Pelengkap sajian 
1. Kecap manis 
1. Sambal 
1. Lauk tempe goreng dll 



<!--inarticleads2-->

## Tata Cara Menyiapkan Soto Ayam Semarang:

1. Cuci bersih daging ayam, Masak air hingga mendidih, Rebus 30 menit, ayam, daun bawang, dan seledri. Setelah 30 menit buang daun bawang dan seledrinya. Sisihkan daging ayamnya.
1. Kemudian, Goreng daging ayam hingga sedikit garing, Tiriskan.
1. Potong jeruk nipis, iris daun seledri, kol dan kemudian rebus kecambah serta bihun. Suir2 ayam dan siapkan pula bawang merah goreng. Sisihkan ya...lanjut bikin kuah..
1. Haluskan bumbu, tumis bumbu hingga harum, tambahkan serai, masukkan bubuk merica, bubuk kunyit dan ketumbar, bubuk pala, serta sedikit jinten. Tumis kembali hingga harum.
1. Tambahkan air kaldu ayam yg tadi sudah direbus bersama daging ayam ya...masak hingga mendidih tambahkan daun salam dan daun jeruk atau kulit jeruk purut. Garam, penyedap rasa, gula pasir, Masak hingga kuah harum.
1. Racik soto, dengan nasi dan bahan lainnya, sajikan bersama kuah hidangkan selagi hangat.




Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
