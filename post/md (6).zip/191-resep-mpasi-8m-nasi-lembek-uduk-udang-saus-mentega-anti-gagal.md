---
description: "Resep MPASI 8m+ : Nasi Lembek Uduk Udang Saus Mentega Anti Gagal"
title: "Resep MPASI 8m+ : Nasi Lembek Uduk Udang Saus Mentega Anti Gagal"
slug: 191-resep-mpasi-8m-nasi-lembek-uduk-udang-saus-mentega-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-22T23:35:01.903Z 
thumbnail: https://img-global.cpcdn.com/recipes/347bec065f58f361/682x484cq65/mpasi-8m-nasi-lembek-uduk-udang-saus-mentega-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/347bec065f58f361/682x484cq65/mpasi-8m-nasi-lembek-uduk-udang-saus-mentega-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/347bec065f58f361/682x484cq65/mpasi-8m-nasi-lembek-uduk-udang-saus-mentega-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/347bec065f58f361/682x484cq65/mpasi-8m-nasi-lembek-uduk-udang-saus-mentega-foto-resep-utama.webp
author: Clifford McDaniel
ratingvalue: 3.1
reviewcount: 12
recipeingredient:
- "Nasi Lembek Uduk "
- "nasi putih 60 gram"
- "air putih 200 ml"
- "santan kental me kara 30 ml"
- "serai geprek 1 batang"
- "daun salam 1 lembar"
- "Bumbu halus bawang merah bawang putih kemiri "
- "Udang Saus Mentega "
- "udang cincang halus marinasi dengan jeruk nipis 60 gram"
- "daun bayam cincang halus 4 lembar"
- "kecil labu siam potong dadu 2 slice"
- "margarin 1,5 sdm"
- "kecap manis 1 sdt"
- "minyak wijen 1/2 sdt"
- "Bumbu halus bawang merah bawang putih "
- "bawang bombay ukuran kecil iris kasar 1/5"
- "air 60 ml"
recipeinstructions:
- "Nasi lembek: Masukkan nasi, diikuti dengan seluruh bahan nasi lembek lainnya. Masak selama 15 menit, aduk sesekali agar nasi tidak lengket di teflon. Sesuaikan tekstur, sisihkan."
- "Marinasi udang yang sudah dicincang dengan jeruk nipis, sisihkan dan diamkan selama 30 menit."
- "Tumis bumbu halus dan bawang bombay dengan margarin sampai harum."
- "Masukkan udang yang sudah dimarinasi, masak hingga udang matang sempurna."
- "Tuang kecap manis dan labu siam, tumis sebentar."
- "Tambahkan air, aduk, dan diamkan hingga air agak mendidih."
- "Setelah air agak mendidih, masukkan bayam. Masak sebentar hingga bayam matang, matikan api."
- "Tuang minyak wijen, aduk rata. Sajikan dengan nasi lembek 😊"
categories:
- Resep
tags:
- mpasi
- 8m
- 

katakunci: mpasi 8m  
nutrition: 183 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT37M"
recipeyield: "1"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![MPASI 8m+ : Nasi Lembek Uduk Udang Saus Mentega](https://img-global.cpcdn.com/recipes/347bec065f58f361/682x484cq65/mpasi-8m-nasi-lembek-uduk-udang-saus-mentega-foto-resep-utama.webp)

8 langkah cepat dan mudah memasak  MPASI 8m+ : Nasi Lembek Uduk Udang Saus Mentega yang harus ibu coba dirumah

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Untuk Pembuatan MPASI 8m+ : Nasi Lembek Uduk Udang Saus Mentega:

1. Nasi Lembek Uduk 
1. nasi putih 60 gram
1. air putih 200 ml
1. santan kental me kara 30 ml
1. serai geprek 1 batang
1. daun salam 1 lembar
1. Bumbu halus bawang merah bawang putih kemiri 
1. Udang Saus Mentega 
1. udang cincang halus marinasi dengan jeruk nipis 60 gram
1. daun bayam cincang halus 4 lembar
1. kecil labu siam potong dadu 2 slice
1. margarin 1,5 sdm
1. kecap manis 1 sdt
1. minyak wijen 1/2 sdt
1. Bumbu halus bawang merah bawang putih 
1. bawang bombay ukuran kecil iris kasar 1/5
1. air 60 ml



<!--inarticleads2-->

## Langkah-langkah Untuk Menyiapkan MPASI 8m+ : Nasi Lembek Uduk Udang Saus Mentega:

1. Nasi lembek: Masukkan nasi, diikuti dengan seluruh bahan nasi lembek lainnya. Masak selama 15 menit, aduk sesekali agar nasi tidak lengket di teflon. Sesuaikan tekstur, sisihkan.
1. Marinasi udang yang sudah dicincang dengan jeruk nipis, sisihkan dan diamkan selama 30 menit.
1. Tumis bumbu halus dan bawang bombay dengan margarin sampai harum.
1. Masukkan udang yang sudah dimarinasi, masak hingga udang matang sempurna.
1. Tuang kecap manis dan labu siam, tumis sebentar.
1. Tambahkan air, aduk, dan diamkan hingga air agak mendidih.
1. Setelah air agak mendidih, masukkan bayam. Masak sebentar hingga bayam matang, matikan api.
1. Tuang minyak wijen, aduk rata. Sajikan dengan nasi lembek 😊




Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
