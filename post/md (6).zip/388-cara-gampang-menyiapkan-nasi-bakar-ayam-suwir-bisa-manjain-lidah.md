---
description: "Cara Gampang Menyiapkan Nasi Bakar Ayam Suwir, Bisa Manjain Lidah"
title: "Cara Gampang Menyiapkan Nasi Bakar Ayam Suwir, Bisa Manjain Lidah"
slug: 388-cara-gampang-menyiapkan-nasi-bakar-ayam-suwir-bisa-manjain-lidah
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-28T11:08:18.380Z 
thumbnail: https://img-global.cpcdn.com/recipes/d487b5866a9af4cb/682x484cq65/nasi-bakar-ayam-suwir-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/d487b5866a9af4cb/682x484cq65/nasi-bakar-ayam-suwir-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/d487b5866a9af4cb/682x484cq65/nasi-bakar-ayam-suwir-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/d487b5866a9af4cb/682x484cq65/nasi-bakar-ayam-suwir-foto-resep-utama.webp
author: Dennis Luna
ratingvalue: 3
reviewcount: 5
recipeingredient:
- "beras putih 500 gr"
- "santan kara 1 bh"
- "daun salam 2 lbr"
- "daun pandan boleh skip 1 lbr"
- "serai 2 btg"
- "garam 1 sdt"
- "kaldu bubuk 1/2 sdt"
- "Sec air "
- "Resep ayam suwir  "
- "ayam suwir 250"
- "daun kemangi 1 iket"
- "air 60 ml"
- "daun dalamnya 3 lbr"
- "serai 2 btg"
- "daun jeruk 4 lbr"
- "Bumbu halus "
- "sg bawang putih 3"
- "sg bawang merah 8"
- "cabe merah keriting 5 bh"
- "cabe rawit merah 3 bh"
- "terasi 1/2 sdt"
- "kemiri 3 bh"
- "garamlada bubukkaldu bubuk dan gula Secukupnya"
- "Daun pisang secukupnya  lidi utk menyemat "
- "minyak utk menumis 2 sdm"
recipeinstructions:
- "Cuci bersih beras masukan ke dlm magic com tambahkan daun pandan,daun salam,garam,air dan santan.lalu tambahkan kaldu bubuk aduk rata.masak smp mateng sisihkan."
- "Rebus ayam smp matang lalu suwir&#34;"
- "Haluskan bumbu lalu panaskan minyak tumis bumbu halus smp harum tambahkan daun jeruk,daun salam garam gula dan kaldu bubuk.masukan ayam suwir aduk rata beri air masak sampai air menyusut koreksi rasa,masukan kemangi sesaat sblm diangkat."
- "Ambil selembar daun pisang beri nasi secukupnya lalu tbahkan ayam suwir diatasnya lalu gulung.semat ujungnya dg lidi lakukan smp nasi habis."
- "Bakar diatas panggangan/teflon smp daun pisang layu dan agak gosong.angkat sajikan."
categories:
- Resep
tags:
- nasi
- bakar
- ayam

katakunci: nasi bakar ayam 
nutrition: 137 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT47M"
recipeyield: "2"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Bakar Ayam Suwir](https://img-global.cpcdn.com/recipes/d487b5866a9af4cb/682x484cq65/nasi-bakar-ayam-suwir-foto-resep-utama.webp)

Resep Nasi Bakar Ayam Suwir  sederhana dengan 5 langkahcepat dan mudah cocok banget jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Untuk Menyiapkan Nasi Bakar Ayam Suwir:

1. beras putih 500 gr
1. santan kara 1 bh
1. daun salam 2 lbr
1. daun pandan boleh skip 1 lbr
1. serai 2 btg
1. garam 1 sdt
1. kaldu bubuk 1/2 sdt
1. Sec air 
1. Resep ayam suwir  
1. ayam suwir 250
1. daun kemangi 1 iket
1. air 60 ml
1. daun dalamnya 3 lbr
1. serai 2 btg
1. daun jeruk 4 lbr
1. Bumbu halus 
1. sg bawang putih 3
1. sg bawang merah 8
1. cabe merah keriting 5 bh
1. cabe rawit merah 3 bh
1. terasi 1/2 sdt
1. kemiri 3 bh
1. garamlada bubukkaldu bubuk dan gula Secukupnya
1. Daun pisang secukupnya  lidi utk menyemat 
1. minyak utk menumis 2 sdm



<!--inarticleads2-->

## Cara Mudah Menyiapkan Nasi Bakar Ayam Suwir:

1. Cuci bersih beras masukan ke dlm magic com tambahkan daun pandan,daun salam,garam,air dan santan.lalu tambahkan kaldu bubuk aduk rata.masak smp mateng sisihkan.
1. Rebus ayam smp matang lalu suwir&#34;
1. Haluskan bumbu lalu panaskan minyak tumis bumbu halus smp harum tambahkan daun jeruk,daun salam garam gula dan kaldu bubuk.masukan ayam suwir aduk rata beri air masak sampai air menyusut koreksi rasa,masukan kemangi sesaat sblm diangkat.
1. Ambil selembar daun pisang beri nasi secukupnya lalu tbahkan ayam suwir diatasnya lalu gulung.semat ujungnya dg lidi lakukan smp nasi habis.
1. Bakar diatas panggangan/teflon smp daun pisang layu dan agak gosong.angkat sajikan.




Terima kasih telah membaca resep yang kami tampilkan di halaman ini. Selamat mencoba!
