---
description: "Cara Gampang Membuat Semur kentang tahu coklat ala nasi uduk yang Lezat"
title: "Cara Gampang Membuat Semur kentang tahu coklat ala nasi uduk yang Lezat"
slug: 216-cara-gampang-membuat-semur-kentang-tahu-coklat-ala-nasi-uduk-yang-lezat
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-28T09:16:55.039Z 
thumbnail: https://img-global.cpcdn.com/recipes/123ce9276e8e4820/682x484cq65/semur-kentang-tahu-coklat-ala-nasi-uduk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/123ce9276e8e4820/682x484cq65/semur-kentang-tahu-coklat-ala-nasi-uduk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/123ce9276e8e4820/682x484cq65/semur-kentang-tahu-coklat-ala-nasi-uduk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/123ce9276e8e4820/682x484cq65/semur-kentang-tahu-coklat-ala-nasi-uduk-foto-resep-utama.webp
author: Adelaide Bush
ratingvalue: 3.8
reviewcount: 13
recipeingredient:
- "tahu coklat 10"
- "kentang 2"
- "bawang merah 4"
- "bawang putih 2"
- "daun salam 2"
- "kayu manis 5 cm"
- "kemiri 3 buah"
- "minyak goreng 7 sdm"
- "gula putih 1,5 sdm"
- "kecap 10 sdm"
- "lada bubuk 1 sdm"
- "royco ayam 2 sdm"
- "garam 1/4 sdt"
- "air matang 450 ml"
- "bawang bombay 1/4"
recipeinstructions:
- "Cuci bersih tahu coklat, peras. lalu kukus 15 menit. cuci bersih bawang merah, bawang putih, daun salam, kayu manis, bawang bombay dan kentang"
- "Haluskan bawang merah bawang putih kemiri. panaskan minyak. tumis dengan daun salam hingga harum. tambahkan kecap dan kayu manis aduk sampai rata. tunggu 5 menit"
- "Masukkan air, dan kentang yang telah potong pipih. tunggu sampai setengah empuk, masukkan gula royco lada garam, aduk tes rasa, tambahkan tahu. aduk rata"
categories:
- Resep
tags:
- semur
- kentang
- tahu

katakunci: semur kentang tahu 
nutrition: 152 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT56M"
recipeyield: "4"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Semur kentang tahu coklat ala nasi uduk](https://img-global.cpcdn.com/recipes/123ce9276e8e4820/682x484cq65/semur-kentang-tahu-coklat-ala-nasi-uduk-foto-resep-utama.webp)

Resep rahasia dan cara memasak  Semur kentang tahu coklat ala nasi uduk cocok sekali jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Untuk Pembuatan Semur kentang tahu coklat ala nasi uduk:

1. tahu coklat 10
1. kentang 2
1. bawang merah 4
1. bawang putih 2
1. daun salam 2
1. kayu manis 5 cm
1. kemiri 3 buah
1. minyak goreng 7 sdm
1. gula putih 1,5 sdm
1. kecap 10 sdm
1. lada bubuk 1 sdm
1. royco ayam 2 sdm
1. garam 1/4 sdt
1. air matang 450 ml
1. bawang bombay 1/4

Nasi uduk memang salah satu menu andalan warga Jakarta. Mulai dari nasi uduk ala Betawi yang dimakan pakai Semur (kentang/tahu/jengkol), nasi uduk pinggir jalan yang disajikan pake orek tempe dan soun goreng dan biasa ditemui buat menu sarapan, sampai nasi uduk ala kebon kacang. Resep Semur Tahu, telur dan kentang Resep semur tahu telur ala mommy anna. 

<!--inarticleads2-->

## Langkah-langkah Untuk Menyiapkan Semur kentang tahu coklat ala nasi uduk:

1. Cuci bersih tahu coklat, peras. lalu kukus 15 menit. cuci bersih bawang merah, bawang putih, daun salam, kayu manis, bawang bombay dan kentang
1. Haluskan bawang merah bawang putih kemiri. panaskan minyak. tumis dengan daun salam hingga harum. tambahkan kecap dan kayu manis aduk sampai rata. tunggu 5 menit
1. Masukkan air, dan kentang yang telah potong pipih. tunggu sampai setengah empuk, masukkan gula royco lada garam, aduk tes rasa, tambahkan tahu. aduk rata


Semur merupakan makanan yang identik dengan bahan masakan daging, namun tidak melulu harus menggunakan daging untuk Tahu juga bisa digunakan sebagai bahan utama semur, dipadukan dengan kentang rasanya juga tidak kalah dengan semur daging. Semur daging kentang bertektur empuk dengan kuah kental sangat cocok dijadikan menu makan siang, rasanya yang Rahasia membuat semur daging yang sempurna selain bumbunya, kuncinya yaitu cara memasak yang benar dan Semur daging kentang siap disajikan bersama nasi hangat. Semur kentang tahu, lauk pendamping nasi putih, nasi uduk, maupun nasi kuning. Resep nasi uduknya udah pernah saya buat ya sebelumnya. tipsnya dibumbui garam dan. Hallo sobat dapur jehana Di video #berbagi resep ala dapur jehana kali ini adalah resep semur tahu dan kentang 

Salah satu masakan yang cukup praktis pembuatannya adalah  Semur kentang tahu coklat ala nasi uduk. Selain itu  Semur kentang tahu coklat ala nasi uduk  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu ikuti 3 langkah, dan  Semur kentang tahu coklat ala nasi uduk  pun siap di hidangkan. selamat mencoba !
