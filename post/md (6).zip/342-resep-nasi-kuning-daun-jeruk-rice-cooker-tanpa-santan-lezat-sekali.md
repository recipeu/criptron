---
description: "Resep Nasi kuning daun jeruk rice cooker tanpa santan, Lezat Sekali"
title: "Resep Nasi kuning daun jeruk rice cooker tanpa santan, Lezat Sekali"
slug: 342-resep-nasi-kuning-daun-jeruk-rice-cooker-tanpa-santan-lezat-sekali
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-05T19:54:39.663Z 
thumbnail: https://img-global.cpcdn.com/recipes/ef1be2acb097d737/682x484cq65/nasi-kuning-daun-jeruk-rice-cooker-tanpa-santan-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/ef1be2acb097d737/682x484cq65/nasi-kuning-daun-jeruk-rice-cooker-tanpa-santan-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/ef1be2acb097d737/682x484cq65/nasi-kuning-daun-jeruk-rice-cooker-tanpa-santan-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/ef1be2acb097d737/682x484cq65/nasi-kuning-daun-jeruk-rice-cooker-tanpa-santan-foto-resep-utama.webp
author: Douglas Fox
ratingvalue: 4.5
reviewcount: 14
recipeingredient:
- "beras 1,5 cup"
- "air sesuai takaran memasak seperti biasa ya 2.5 cup"
- "kunyit bubuk 1/2 sdt"
- "margarine 1 sdm"
- "daun jeruk 10 lembar"
- "sereh geprek 1 batang"
- "daun salam 2 lembar"
- "garam dan kaldu jamur secukupnya"
recipeinstructions:
- "Buang batang pada daun jeruk, iris tipis. sisihkan"
- "Cuci beras hingga bersih lalu tiriskan. masukan 2.5 cup air, larutkan dengan 1 sdm margarine, tambahkan daun jeruk, batang sereh geprek, kaldu jamur, garam, daun salam. aduk hingga rata. lalu pencet tombol cook."
categories:
- Resep
tags:
- nasi
- kuning
- daun

katakunci: nasi kuning daun 
nutrition: 164 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT55M"
recipeyield: "4"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi kuning daun jeruk rice cooker tanpa santan](https://img-global.cpcdn.com/recipes/ef1be2acb097d737/682x484cq65/nasi-kuning-daun-jeruk-rice-cooker-tanpa-santan-foto-resep-utama.webp)

Ingin membuat Nasi kuning daun jeruk rice cooker tanpa santan ? Coba resep berikut ini. Cara memasaknya sangat praktis namun jangan kaget jika hasilnya gurih dan lezat cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Dalam Pembuatan Nasi kuning daun jeruk rice cooker tanpa santan:

1. beras 1,5 cup
1. air sesuai takaran memasak seperti biasa ya 2.5 cup
1. kunyit bubuk 1/2 sdt
1. margarine 1 sdm
1. daun jeruk 10 lembar
1. sereh geprek 1 batang
1. daun salam 2 lembar
1. garam dan kaldu jamur secukupnya

Ceritanya temen-temen di kosan mau ngadain syukuran. Naah, nasi kuning ini bisa jadi alternatif makanan utama untuk makan bersama. So yummy, apalagi ditambah lauknya ikan asin, lalapan, dan sambel. Cara praktis memasak nasi kuning dengan modal rice cooker ini dapat menjadi alternatif bagi anak kos, atau Anda yang ingin membuat nasi kuning tanpa ribet. 

<!--inarticleads2-->

## Cara Membuat Nasi kuning daun jeruk rice cooker tanpa santan:

1. Buang batang pada daun jeruk, iris tipis. sisihkan
1. Cuci beras hingga bersih lalu tiriskan. masukan 2.5 cup air, larutkan dengan 1 sdm margarine, tambahkan daun jeruk, batang sereh geprek, kaldu jamur, garam, daun salam. aduk hingga rata. lalu pencet tombol cook.


Bagi Anda yang tidak menyukai nasi kuning lemak bersantan, maka bisa menjadikan nasi kuning tanpa santan sebagai alternatif solusi. cara membuat nasi kuning santan kara. Related posts. cara membuat lamaran kerja tanpa mencantumkan nama perusahaan. Nasi kuning merupakan salah satu makanan khas Indonesia. Makanan ini terbuat dari beras dan bercampur dengan kunyit, santan Tumis bahan-bahan bumbu halus bersama daun jeruk dan daun salam. Nasi kuning rice cooker. foto: Instagram/@lely_pongoh. 

Terima kasih telah membaca resep yang tim kami tampilkan di sini. Selamat mencoba!
