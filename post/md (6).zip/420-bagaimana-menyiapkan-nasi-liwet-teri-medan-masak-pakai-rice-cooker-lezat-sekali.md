---
description: "Bagaimana Menyiapkan Nasi Liwet Teri Medan (masak pakai rice cooker), Lezat Sekali"
title: "Bagaimana Menyiapkan Nasi Liwet Teri Medan (masak pakai rice cooker), Lezat Sekali"
slug: 420-bagaimana-menyiapkan-nasi-liwet-teri-medan-masak-pakai-rice-cooker-lezat-sekali
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-05T22:27:51.126Z 
thumbnail: https://img-global.cpcdn.com/recipes/4d31b8bf82af76e8/682x484cq65/nasi-liwet-teri-medan-masak-pakai-rice-cooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/4d31b8bf82af76e8/682x484cq65/nasi-liwet-teri-medan-masak-pakai-rice-cooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/4d31b8bf82af76e8/682x484cq65/nasi-liwet-teri-medan-masak-pakai-rice-cooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/4d31b8bf82af76e8/682x484cq65/nasi-liwet-teri-medan-masak-pakai-rice-cooker-foto-resep-utama.webp
author: Harvey Greene
ratingvalue: 3.8
reviewcount: 10
recipeingredient:
- "Beras putih 2 cup"
- "Beras air bersih 3 Cup"
- "santan Kara 3 sendok makan"
- "teri Medan 50 gr"
- "bawang putih 3 siung"
- "cabe rawit domba 7 buah"
- "daun salam 2 lembar"
- "daun jeruk 2 lembar"
- "Sereh 1 batang"
- "garam 1 sendok teh"
- "kaldu jamur Secukupnya"
- "Minyak goreng "
recipeinstructions:
- "Cuci bersih beras dan tiriskan"
- "Goreng teri Medan hingga kering dan sisihkan"
- "Haluskan bawang putih, lalu Tumis bawang, daun salam, daun jeruk serta Sereh hingga wangi."
- "Tambahkan air, santan, garam dan kaldu jamur. Masukkan beras, teri dan cabe rawit (boleh utuh atau di iris, sesuaikan dengan selera). Tunggu sampai matang dan nasi liwet rice Cooker super gampil siap di sajikan."
- "Notes: Aku Tumis bumbunya pakai minyak bekas goreng teri biar makin gurih, dan Tumis bumbu nya juga langsung di rice cooker ini sih optional ya. Mau di Tumis dulu di wajan juga gak papa."
categories:
- Resep
tags:
- nasi
- liwet
- teri

katakunci: nasi liwet teri 
nutrition: 212 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT42M"
recipeyield: "3"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Liwet Teri Medan (masak pakai rice cooker)](https://img-global.cpcdn.com/recipes/4d31b8bf82af76e8/682x484cq65/nasi-liwet-teri-medan-masak-pakai-rice-cooker-foto-resep-utama.webp)

Resep rahasia dan cara mengolah  Nasi Liwet Teri Medan (masak pakai rice cooker) cocok banget jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Bahan-bahan Yang Dibutuhkan Dalam Pembuatan Nasi Liwet Teri Medan (masak pakai rice cooker):

1. Beras putih 2 cup
1. Beras air bersih 3 Cup
1. santan Kara 3 sendok makan
1. teri Medan 50 gr
1. bawang putih 3 siung
1. cabe rawit domba 7 buah
1. daun salam 2 lembar
1. daun jeruk 2 lembar
1. Sereh 1 batang
1. garam 1 sendok teh
1. kaldu jamur Secukupnya
1. Minyak goreng 



<!--inarticleads2-->

## Langkah-langkah Untuk Menyiapkan Nasi Liwet Teri Medan (masak pakai rice cooker):

1. Cuci bersih beras dan tiriskan
1. Goreng teri Medan hingga kering dan sisihkan
1. Haluskan bawang putih, lalu Tumis bawang, daun salam, daun jeruk serta Sereh hingga wangi.
1. Tambahkan air, santan, garam dan kaldu jamur. Masukkan beras, teri dan cabe rawit (boleh utuh atau di iris, sesuaikan dengan selera). Tunggu sampai matang dan nasi liwet rice Cooker super gampil siap di sajikan.
1. Notes: Aku Tumis bumbunya pakai minyak bekas goreng teri biar makin gurih, dan Tumis bumbu nya juga langsung di rice cooker ini sih optional ya. Mau di Tumis dulu di wajan juga gak papa.




Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
