---
description: "Bagaimana Membuat Nasi bakar ayam kemangi Anti Gagal"
title: "Bagaimana Membuat Nasi bakar ayam kemangi Anti Gagal"
slug: 426-bagaimana-membuat-nasi-bakar-ayam-kemangi-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-30T03:22:52.544Z 
thumbnail: https://img-global.cpcdn.com/recipes/e2763a38c609e810/682x484cq65/nasi-bakar-ayam-kemangi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/e2763a38c609e810/682x484cq65/nasi-bakar-ayam-kemangi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/e2763a38c609e810/682x484cq65/nasi-bakar-ayam-kemangi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/e2763a38c609e810/682x484cq65/nasi-bakar-ayam-kemangi-foto-resep-utama.webp
author: Estelle Pope
ratingvalue: 4.4
reviewcount: 11
recipeingredient:
- "ekor ayam 1/2 kg"
- "Beras 3 gelas belimbing dibkin nasi gurih dgn magicom "
- "kemangi segar 5 ikat"
- "Daun pisang "
- "Bumbu2 "
- "bawang merah 10 siung"
- "bawang putih 3 siung"
- "cabe keriting 10"
- "jahe lengkuas dan kunyit 1 ruas"
- "daun salam 1"
- "kemiri 3"
- "garam kaldu jamur gula pasir 1/4 sdt"
recipeinstructions:
- "Potong ayam mnjadi 2 bagian cuci bersih dan rebus sampai matang. Tiriskan, tunggu dingin dan suwir2"
- "Siapkan bumbu yg akan dihaluskan (kecuali daun salam dan lengkuas) Blender/uleg semua bumbu halus."
- "Oseng/gongso bumbu halus di wajan tmbahkan daun salam dan lengkuas geprek. Jika air sudah menyusut, masukkan ayam suwir, aduk rata, tambahkan air sedikit tunggu sampai mendidih. Setelah itu beri garam, gula pasir dan kaldu jamur. Cek rasa"
- "Setelah di rasa sudah cukup, masukkan daun kemangi dan masak sampai daun kemangi setengah layu."
- "Jika sudah di bungkus dengan daun pisang, kukus terlebih dahulu dan siap untuk di bakar (dibakar sbntar saja)."
- "Setelah dibakar"
categories:
- Resep
tags:
- nasi
- bakar
- ayam

katakunci: nasi bakar ayam 
nutrition: 187 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT48M"
recipeyield: "2"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi bakar ayam kemangi](https://img-global.cpcdn.com/recipes/e2763a38c609e810/682x484cq65/nasi-bakar-ayam-kemangi-foto-resep-utama.webp)

Resep Nasi bakar ayam kemangi  enak dengan 6 langkahcepat cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Untuk Pembuatan Nasi bakar ayam kemangi:

1. ekor ayam 1/2 kg
1. Beras 3 gelas belimbing dibkin nasi gurih dgn magicom 
1. kemangi segar 5 ikat
1. Daun pisang 
1. Bumbu2 
1. bawang merah 10 siung
1. bawang putih 3 siung
1. cabe keriting 10
1. jahe lengkuas dan kunyit 1 ruas
1. daun salam 1
1. kemiri 3
1. garam kaldu jamur gula pasir 1/4 sdt

Resep dan cara memasak nasi bakar. Salah satunya adanya nasi bakar isi ati ampela, nasi bakar cumi pedas, nasi bakar ayam petai, nasi bakar orek tempe Berawal dari kegemaran menyantap nasi bakar yang tidak cukup satu, akhirnya pada waktu luang saya mencoba membuat nasi bakar ayam suwir kemangi favorit sendiri di rumah. Kemudian tata daun pisang, nasi liwet serta tambahkan kemangi kemudian tambahkan suwiran ayam, tembahkan lagi kemangi di atas ayam dan dapat pula tambahkan irisan cabe rawit apabila anda menyukai pedas, setelah itu bakar di atas grill pan, bolak - balik hingga matang, angkat dan hidangkan. Nasi bakar ayam kemangi adalah salah satu inovasi masakan Nusantara yang sangat terkenal di seluruh Indonesia terutama di pulau Jawa. 

<!--inarticleads2-->

## Tata Cara Membuat Nasi bakar ayam kemangi:

1. Potong ayam mnjadi 2 bagian cuci bersih dan rebus sampai matang. Tiriskan, tunggu dingin dan suwir2
1. Siapkan bumbu yg akan dihaluskan (kecuali daun salam dan lengkuas) - Blender/uleg semua bumbu halus.
1. Oseng/gongso bumbu halus di wajan tmbahkan daun salam dan lengkuas geprek. Jika air sudah menyusut, masukkan ayam suwir, aduk rata, tambahkan air sedikit tunggu sampai mendidih. Setelah itu beri garam, gula pasir dan kaldu jamur. Cek rasa
1. Setelah di rasa sudah cukup, masukkan daun kemangi dan masak sampai daun kemangi setengah layu.
1. Jika sudah di bungkus dengan daun pisang, kukus terlebih dahulu dan siap untuk di bakar (dibakar sbntar saja).
1. Setelah dibakar


Aroma harum muncul dari daun kemangi yang ada dan dipadukan dengan daging ayam, sungguh menambah nikmatnya nasi goreng bakar kemangi ini. Umumnya nasi bakar yang gurih dan lezat terdapat daging ayam, sumsum, jamur, ikan teri di dalamnya, Untuk kali ini kami akan mencobanya Selain ikan asin peda yang khas dari nasi bakar kali ini, aroma dari daun kemangi dapat menambah cita rasa penyajiannya. Biasa ditemukan di Pulau Jawa, nasi bakar berisi beragam protein. Salah satu yang paling disukai adalah daging ayam dengan sentuhan daun kemangi. Bisa untuk ide menu makan siang bersama keluarga, berikut resep membuat nasi bakar ayam kemangi yang enak dan mudah. 

Terima kasih telah membaca resep yang tim kami tampilkan di halaman ini. Semoga bermanfaat dan selamat mencoba!
