---
description: "Resep 7. Nasi Daun Jeruk yang Lezat"
title: "Resep 7. Nasi Daun Jeruk yang Lezat"
slug: 308-resep-7-nasi-daun-jeruk-yang-lezat
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-04T10:55:04.566Z 
thumbnail: https://img-global.cpcdn.com/recipes/b2ba1fbf3017c7c5/682x484cq65/7-nasi-daun-jeruk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/b2ba1fbf3017c7c5/682x484cq65/7-nasi-daun-jeruk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/b2ba1fbf3017c7c5/682x484cq65/7-nasi-daun-jeruk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/b2ba1fbf3017c7c5/682x484cq65/7-nasi-daun-jeruk-foto-resep-utama.webp
author: Jeremy Scott
ratingvalue: 4.4
reviewcount: 9
recipeingredient:
- "Beras pake cup bawaan magic com 3,5 cup"
- "Daun Jeruk Purut haluskan 20 lembar"
- "Sereh geprek 1 batang"
- "Daun Salam 4 lembar"
- "ButterMargarin 1 sdm"
- "Kaldu bubuk Secukupnya"
- "Garam Secukupnya"
recipeinstructions:
- "Cuci beras, masukkan semua bahan ke dalam beras. Beri Air sesuai takaran magic com (kalo aku ngukur pake jari. Seruas jari)"
- "Masukkan ke magic com sambil diaduk. Tunggu hingga setengah matang, aduk dan tunggu hingga matang dan tanak."
- "Oya jangan lupa magic com dicolokin dan diceklek ke tombol &#34;cook&#34;, aku sering lupa nyeklek 🙈. Dan maaf lupa banget moto bahan dan stepnya 🙈"
categories:
- Resep
tags:
- 7
- nasi
- daun

katakunci: 7 nasi daun 
nutrition: 175 calories
recipecuisine: Indonesian
preptime: "PT20M"
cooktime: "PT34M"
recipeyield: "4"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![7. Nasi Daun Jeruk](https://img-global.cpcdn.com/recipes/b2ba1fbf3017c7c5/682x484cq65/7-nasi-daun-jeruk-foto-resep-utama.webp)

Ingin membuat 7. Nasi Daun Jeruk ? Coba resep berikut ini. Cara memasaknya sangat praktis namun jangan kaget jika hasilnya gurih dan lezat cocok banget jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Dalam Pembuatan 7. Nasi Daun Jeruk:

1. Beras pake cup bawaan magic com 3,5 cup
1. Daun Jeruk Purut haluskan 20 lembar
1. Sereh geprek 1 batang
1. Daun Salam 4 lembar
1. ButterMargarin 1 sdm
1. Kaldu bubuk Secukupnya
1. Garam Secukupnya



<!--inarticleads2-->

## Cara Mudah Membuat 7. Nasi Daun Jeruk:

1. Cuci beras, masukkan semua bahan ke dalam beras. Beri Air sesuai takaran magic com (kalo aku ngukur pake jari. Seruas jari)
1. Masukkan ke magic com sambil diaduk. Tunggu hingga setengah matang, aduk dan tunggu hingga matang dan tanak.
1. Oya jangan lupa magic com dicolokin dan diceklek ke tombol &#34;cook&#34;, aku sering lupa nyeklek 🙈. Dan maaf lupa banget moto bahan dan stepnya 🙈




Salah satu kuliner yang cukup praktis pembuatannya adalah  7. Nasi Daun Jeruk. Selain itu  7. Nasi Daun Jeruk  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu lakukan 3 langkah, dan  7. Nasi Daun Jeruk  pun siap di hidangkan. selamat mencoba !
