---
description: "Resep Nasi Uduk Betawi RiceCooker Enak Gampil yang Enak Banget"
title: "Resep Nasi Uduk Betawi RiceCooker Enak Gampil yang Enak Banget"
slug: 73-resep-nasi-uduk-betawi-ricecooker-enak-gampil-yang-enak-banget
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-26T06:38:26.748Z 
thumbnail: https://img-global.cpcdn.com/recipes/3f826fbc4a5ee42b/682x484cq65/nasi-uduk-betawi-ricecooker-enak-gampil-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/3f826fbc4a5ee42b/682x484cq65/nasi-uduk-betawi-ricecooker-enak-gampil-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/3f826fbc4a5ee42b/682x484cq65/nasi-uduk-betawi-ricecooker-enak-gampil-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/3f826fbc4a5ee42b/682x484cq65/nasi-uduk-betawi-ricecooker-enak-gampil-foto-resep-utama.webp
author: Evelyn Gardner
ratingvalue: 3.1
reviewcount: 7
recipeingredient:
- "Bahan  "
- "Beras cuci bersih 2 gelas belimbing"
- "Air secukupnya"
- "Bumbu dicuci dulu yah  "
- "Daun salam 4 lembar"
- "Serai memarkan 3 batang"
- "Daun jeruk buang tulangnya 2 lembar"
- "Lengkuas memarkan 2 ruas"
- "Jahe memarkan 1 ruas"
- "Bawang merah cincang halus 5 siung"
- "Bawang putih cincang halus 2 siung"
- "kencur cincang halus 1 ruas jempol"
- "Santan kara 65 ml"
- "Garam sesuai selera secukupnya"
- "kaldu jamur Secukupnya"
recipeinstructions:
- "Siapkan beras dalam wadah magic com, isi air secukupnya seperti masak nasi biasa."
- "Masukan semua bumbu, aduk rata. Tekan tombol cook, biarkan sampai matang spt masak nasi biasa"
- "Setelah matang aduk rata, tutup kembali, tekan tombol cook biarkan sampai tombol pindah ke warm."
- "Siap disajikan bersama lauk andalan bunda, tante, kakak 😘"
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 119 calories
recipecuisine: Indonesian
preptime: "PT16M"
cooktime: "PT34M"
recipeyield: "3"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Betawi RiceCooker Enak Gampil](https://img-global.cpcdn.com/recipes/3f826fbc4a5ee42b/682x484cq65/nasi-uduk-betawi-ricecooker-enak-gampil-foto-resep-utama.webp)

Resep rahasia Nasi Uduk Betawi RiceCooker Enak Gampil  sederhana dengan 4 langkahmudah yang wajib bunda coba segera

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Untuk Menyiapkan Nasi Uduk Betawi RiceCooker Enak Gampil:

1. Bahan  
1. Beras cuci bersih 2 gelas belimbing
1. Air secukupnya
1. Bumbu dicuci dulu yah  
1. Daun salam 4 lembar
1. Serai memarkan 3 batang
1. Daun jeruk buang tulangnya 2 lembar
1. Lengkuas memarkan 2 ruas
1. Jahe memarkan 1 ruas
1. Bawang merah cincang halus 5 siung
1. Bawang putih cincang halus 2 siung
1. kencur cincang halus 1 ruas jempol
1. Santan kara 65 ml
1. Garam sesuai selera secukupnya
1. kaldu jamur Secukupnya



<!--inarticleads2-->

## Cara Membuat Nasi Uduk Betawi RiceCooker Enak Gampil:

1. Siapkan beras dalam wadah magic com, isi air secukupnya seperti masak nasi biasa.
1. Masukan semua bumbu, aduk rata. Tekan tombol cook, biarkan sampai matang spt masak nasi biasa
1. Setelah matang aduk rata, tutup kembali, tekan tombol cook biarkan sampai tombol pindah ke warm.
1. Siap disajikan bersama lauk andalan bunda, tante, kakak 😘




Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
