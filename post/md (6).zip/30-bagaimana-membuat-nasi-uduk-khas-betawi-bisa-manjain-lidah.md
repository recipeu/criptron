---
description: "Bagaimana Membuat Nasi Uduk Khas Betawi, Bisa Manjain Lidah"
title: "Bagaimana Membuat Nasi Uduk Khas Betawi, Bisa Manjain Lidah"
slug: 30-bagaimana-membuat-nasi-uduk-khas-betawi-bisa-manjain-lidah
future: true
lang: id
language: id
languageCode: id
publishDate: 2022-01-04T01:33:45.225Z 
thumbnail: https://img-global.cpcdn.com/recipes/3a0aa253f4ecc5cf/682x484cq65/nasi-uduk-khas-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/3a0aa253f4ecc5cf/682x484cq65/nasi-uduk-khas-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/3a0aa253f4ecc5cf/682x484cq65/nasi-uduk-khas-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/3a0aa253f4ecc5cf/682x484cq65/nasi-uduk-khas-betawi-foto-resep-utama.webp
author: Pauline Hayes
ratingvalue: 4.5
reviewcount: 11
recipeingredient:
- "beras rendam selama 2 jam 1 1/2 liter"
- "santan dari 12 kelapa 500 ml"
- "sereh geprek 5"
- "lengkuas 3 ruas"
- "jahe 1 ruas"
- "daun salam 5 lembar"
- "daun jeruk 2 lembar"
- "cengkeh 4 buah"
- "bawang merah 1 siung"
- "bawang putih 1 siung"
- "garam 2 sdm"
- "gula pasir Sejumput"
recipeinstructions:
- "Pertama cuci bersih beras yang sudah direndam. Masukkan semua bahan lalu masak sampai santan menyusut. Aduk terus y agar bawahnya gosong. Setelah menyusut lalu kukus beras sampai matang."
- "Nasi uduk siap disajikan. Selamat mencoba, semoga berhasil."
categories:
- Resep
tags:
- nasi
- uduk
- khas

katakunci: nasi uduk khas 
nutrition: 147 calories
recipecuisine: Indonesian
preptime: "PT12M"
cooktime: "PT54M"
recipeyield: "3"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Khas Betawi](https://img-global.cpcdn.com/recipes/3a0aa253f4ecc5cf/682x484cq65/nasi-uduk-khas-betawi-foto-resep-utama.webp)

Resep dan cara memasak  Nasi Uduk Khas Betawi cocok banget jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Dalam Pembuatan Nasi Uduk Khas Betawi:

1. beras rendam selama 2 jam 1 1/2 liter
1. santan dari 12 kelapa 500 ml
1. sereh geprek 5
1. lengkuas 3 ruas
1. jahe 1 ruas
1. daun salam 5 lembar
1. daun jeruk 2 lembar
1. cengkeh 4 buah
1. bawang merah 1 siung
1. bawang putih 1 siung
1. garam 2 sdm
1. gula pasir Sejumput

Nasi uduk terbuat dari beras yang dimasak dengan santan, garam juga bumbu rempah lainnya hingga menghasilkan nasi yang gurih dan memiliki aroma khas yang menggugah selera. Восточная Джакарта, Джакарта /. Masih tentang nasi favorit saya, Nasi Uduk Gondangdia juga merupakan salah satu dari sekian jenis nasi yang saya suka. Jika beberapa waktu lalu saya sudah memposting Nasi Ayam Hainan, Nasi Krawu, Nasi Bakar Isi Ayam dan Teri. Rasanya yang enak, Sambal Kacang nasi uduk khas betawi sangat disukai dan cocok menjadi santapan pilihan di waktu pagi. 

<!--inarticleads2-->

## Cara Mudah Menyiapkan Nasi Uduk Khas Betawi:

1. Pertama cuci bersih beras yang sudah direndam. Masukkan semua bahan lalu masak sampai santan menyusut. Aduk terus y agar bawahnya gosong. Setelah menyusut lalu kukus beras sampai matang.
1. Nasi uduk siap disajikan. Selamat mencoba, semoga berhasil.


Diketahui nasi uduk adalah salah satu makanan dari nasi yang dimasak bersama santan kemudian diberi bumbu. Cara Membuat Nasi Uduk Betawi: Tuang santan dalam wajan. Masukkan bumbu halus, lalu tambahkan garam. Nasi uduk Betawi siap disajikan dan dinikmati dengan aneka lauk favorit Anda. Resep Nasi Uduk - Sajian lezat di hadirkan dari nusantara lagi yaitu Nasi Uduk yang gurih dan nikmat. 

Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
