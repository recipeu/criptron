---
description: "Resep Nasi Uduk Betawi &amp;#34;Rice Cooker&amp;#34; yang Lezat"
title: "Resep Nasi Uduk Betawi &amp;#34;Rice Cooker&amp;#34; yang Lezat"
slug: 155-resep-nasi-uduk-betawi-and-34-rice-cooker-and-34-yang-lezat
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-01T18:07:11.795Z 
thumbnail: https://img-global.cpcdn.com/recipes/1d1bd3e320520e3f/682x484cq65/nasi-uduk-betawi-rice-cooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/1d1bd3e320520e3f/682x484cq65/nasi-uduk-betawi-rice-cooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/1d1bd3e320520e3f/682x484cq65/nasi-uduk-betawi-rice-cooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/1d1bd3e320520e3f/682x484cq65/nasi-uduk-betawi-rice-cooker-foto-resep-utama.webp
author: Clara Glover
ratingvalue: 4.8
reviewcount: 10
recipeingredient:
- "beras pulen 1 liter"
- "santan kelapa tua 1 liter"
- "daun sereh 1 Ikat"
- "daun salam 3 Lembar"
- "daun jeruk 3 Lembar"
- "gula pasir 1 Sendok teh"
- "garam 1 Sendok teh"
recipeinstructions:
- "Pertama-tama, cuci beras sampai bersih. Kemudian masukkan ke dalam pan rice cooker."
- "Masukkan daun sereh yang sudah digeprek sebelumnya, 3 lembar daun salam, dan 3 lembar daun jeruk"
- "Masukan santan kira-kira tinggi santan satu ruas jari tengah dari atas beras"
- "Tambahkan 1 sendok teh garam dan 1 sendok teh gula (atau sesuai selera) kemudian aduk rata"
- "Masak nasi uduk sama dengan proses memasak nasi di rice cooker. Apabila masih keras berasnya, dibuka kembali rice cooker dan aduk merata."
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 174 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT39M"
recipeyield: "4"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Betawi &#34;Rice Cooker&#34;](https://img-global.cpcdn.com/recipes/1d1bd3e320520e3f/682x484cq65/nasi-uduk-betawi-rice-cooker-foto-resep-utama.webp)

Ingin membuat Nasi Uduk Betawi &#34;Rice Cooker&#34; ? Coba resep berikut ini. Cara memasaknya sangat praktis namun jangan kaget jika hasilnya gurih dan lezat yang harus ibu coba dirumah

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Dalam Menyiapkan Nasi Uduk Betawi &#34;Rice Cooker&#34;:

1. beras pulen 1 liter
1. santan kelapa tua 1 liter
1. daun sereh 1 Ikat
1. daun salam 3 Lembar
1. daun jeruk 3 Lembar
1. gula pasir 1 Sendok teh
1. garam 1 Sendok teh



<!--inarticleads2-->

## Tata Cara Membuat Nasi Uduk Betawi &#34;Rice Cooker&#34;:

1. Pertama-tama, cuci beras sampai bersih. Kemudian masukkan ke dalam pan rice cooker.
1. Masukkan daun sereh yang sudah digeprek sebelumnya, 3 lembar daun salam, dan 3 lembar daun jeruk
1. Masukan santan kira-kira tinggi santan satu ruas jari tengah dari atas beras
1. Tambahkan 1 sendok teh garam dan 1 sendok teh gula (atau sesuai selera) kemudian aduk rata
1. Masak nasi uduk sama dengan proses memasak nasi di rice cooker. Apabila masih keras berasnya, dibuka kembali rice cooker dan aduk merata.




Daripada   beli  Nasi Uduk Betawi &#34;Rice Cooker&#34;  diluar terus, kamu  bisa membuatnya sendiri dirumah. Resep  Nasi Uduk Betawi &#34;Rice Cooker&#34;  sederhana ini cukup praktis dalam proses pembuatannya, serta cukup menggunakan bumbu sederhana  Nasi Uduk Betawi &#34;Rice Cooker&#34;  yang enak, kamu nikmati di rumah.
