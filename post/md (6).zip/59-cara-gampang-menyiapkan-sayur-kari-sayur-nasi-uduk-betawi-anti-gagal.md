---
description: "Cara Gampang Menyiapkan Sayur kari (sayur nasi uduk betawi) Anti Gagal"
title: "Cara Gampang Menyiapkan Sayur kari (sayur nasi uduk betawi) Anti Gagal"
slug: 59-cara-gampang-menyiapkan-sayur-kari-sayur-nasi-uduk-betawi-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-05T06:48:49.779Z 
thumbnail: https://img-global.cpcdn.com/recipes/81e20583ff15584e/682x484cq65/sayur-kari-sayur-nasi-uduk-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/81e20583ff15584e/682x484cq65/sayur-kari-sayur-nasi-uduk-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/81e20583ff15584e/682x484cq65/sayur-kari-sayur-nasi-uduk-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/81e20583ff15584e/682x484cq65/sayur-kari-sayur-nasi-uduk-betawi-foto-resep-utama.webp
author: Augusta Willis
ratingvalue: 4.7
reviewcount: 5
recipeingredient:
- "Bahan bahan "
- "Tempe 1 papan"
- "Tahu putih besar di ganti tahu goreng model segitiga juga boleh 1"
- "Cabe merah keriting secukup ny "
- "Kentang 4 buah"
- "Santan kara 1 bungkus"
- "Daun bawang "
- "Bumbu halus "
- "bawang putih 2 siung"
- "bawang merah 5 siung"
- "Lada secukup ny "
- "Ketumbar secukup nya "
- "Kemiri bisa di tambah kalo suka lebih medok kuah nya 4 butir"
- "kunyit 1 ruas"
- "Garam dan penyedap rasa "
- "daun salam 2 lembar"
- "Bumbu di geprek "
- "sereh 1 batang"
- "lengkuas 1 ruas"
recipeinstructions:
- "Bumbu halus di ulek atau di blender (kl saya lebih praktis di blender)"
- "Tumis bumbu halus sampai harum,kemudian masukan salam sereh dan lengkuas yg sdh di geprek,kemudian masukan air secukup nya"
- "Potong2 tahu,tempe dan kentang,setelah kuah mendidih masukan kentang kemudian tempe dan tahu"
- "Setelah kentang cukup matang masukan santan garam dan penyedap rasa biarkan sampai mendidih tapi di aduk2 agar jangan sampai santan ny pecah ya........masukan daun bawang yg sudah di iris2 selanjutnya koreksi rasa,dan siap di hidangkan"
categories:
- Resep
tags:
- sayur
- kari
- sayur

katakunci: sayur kari sayur 
nutrition: 185 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT38M"
recipeyield: "4"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Sayur kari (sayur nasi uduk betawi)](https://img-global.cpcdn.com/recipes/81e20583ff15584e/682x484cq65/sayur-kari-sayur-nasi-uduk-betawi-foto-resep-utama.webp)

Resep rahasia Sayur kari (sayur nasi uduk betawi)  enak dengan 4 langkahmudah yang wajib kamu coba dirumah

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Dalam Pembuatan Sayur kari (sayur nasi uduk betawi):

1. Bahan bahan 
1. Tempe 1 papan
1. Tahu putih besar di ganti tahu goreng model segitiga juga boleh 1
1. Cabe merah keriting secukup ny 
1. Kentang 4 buah
1. Santan kara 1 bungkus
1. Daun bawang 
1. Bumbu halus 
1. bawang putih 2 siung
1. bawang merah 5 siung
1. Lada secukup ny 
1. Ketumbar secukup nya 
1. Kemiri bisa di tambah kalo suka lebih medok kuah nya 4 butir
1. kunyit 1 ruas
1. Garam dan penyedap rasa 
1. daun salam 2 lembar
1. Bumbu di geprek 
1. sereh 1 batang
1. lengkuas 1 ruas

Add stock and coconut milk, salt and daun salam and bring slowly to a boil, stirring occasionally. At no stage must the sayur be covered. Kredit foto: Rosita Ismail (Gambar bukan menggunakan resepi dibawah). Ayam Tandoori ialah hidangan ayam yang disediakan dengan memanggang ayam awet dalam yogurt dan rempah-rempah di dalam tandoor, ketuhar silinder tanah liat. 

<!--inarticleads2-->

## Tata Cara Membuat Sayur kari (sayur nasi uduk betawi):

1. Bumbu halus di ulek atau di blender (kl saya lebih praktis di blender)
1. Tumis bumbu halus sampai harum,kemudian masukan salam sereh dan lengkuas yg sdh di geprek,kemudian masukan air secukup nya
1. Potong2 tahu,tempe dan kentang,setelah kuah mendidih masukan kentang kemudian tempe dan tahu
1. Setelah kentang cukup matang masukan santan garam dan penyedap rasa biarkan sampai mendidih tapi di aduk2 agar jangan sampai santan ny pecah ya........masukan daun bawang yg sudah di iris2 selanjutnya koreksi rasa,dan siap di hidangkan


Merdeka.com - sayur asem termasuk salah satu jenis sup yang populer sebagai hidangan rumahan Makanan berkuah ini baik untuk kesehatan dan cocok disantap bersama nasi saat cuaca panas. Berikut ini kami tampilkan beberapa resep dan cara masak sayur asem dari berbagai daerah, antara. Resep rendang ayam Resep sayur nangka KARI AYAM SPEICAL MENU YANG ENAK UNTUK KELUARGA TERCINTA!!! ALA MASAKAN RUMAHAN RUDY &amp; SAHABAT - SOP AYAM SAYURAN INDONESIA Resep Sayur Asem Betawi Pedas ala Masakan Rumahan Resep Telur Dadar Crispy. Resep membuat Sayur Kari, maknyusss banget deh bun. 

Salah satu kuliner yang cukup praktis dalam pembuatannya adalah  Sayur kari (sayur nasi uduk betawi). Selain itu  Sayur kari (sayur nasi uduk betawi)  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu ikuti 4 langkah, dan  Sayur kari (sayur nasi uduk betawi)  pun siap di hidangkan. selamat mencoba !
