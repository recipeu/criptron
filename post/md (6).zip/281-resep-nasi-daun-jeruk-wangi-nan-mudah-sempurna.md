---
description: "Resep Nasi Daun Jeruk Wangi nan Mudah, Sempurna"
title: "Resep Nasi Daun Jeruk Wangi nan Mudah, Sempurna"
slug: 281-resep-nasi-daun-jeruk-wangi-nan-mudah-sempurna
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-18T05:57:31.105Z 
thumbnail: https://img-global.cpcdn.com/recipes/abfd561e924cebe6/682x484cq65/nasi-daun-jeruk-wangi-nan-mudah-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/abfd561e924cebe6/682x484cq65/nasi-daun-jeruk-wangi-nan-mudah-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/abfd561e924cebe6/682x484cq65/nasi-daun-jeruk-wangi-nan-mudah-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/abfd561e924cebe6/682x484cq65/nasi-daun-jeruk-wangi-nan-mudah-foto-resep-utama.webp
author: Duane Harrison
ratingvalue: 3.4
reviewcount: 13
recipeingredient:
- "beras 3 cup"
- "bawang putih 3-4 siung"
- "daun jeruk 10-15 helai"
- "daun salam Secukupnya"
- "garam dan kaldu bubuk Secukupnya"
- "serai saya skip 1 batang"
recipeinstructions:
- "Cuci beras, masukkan ke baskom rice cooker dan isi dengan air secukupnya."
- "Pisahkan daun jeruk dari tangkai tengahnya, iris atau cincang halus. Sisihkan."
- "Cincang bawang putih dan tumis hingga wangi dan berwarna cokelat muda.  Masukkan tumisan bawang, irisan daun jeruk, daun salam, garam, dan kaldu bubuk ke dalam baskom rice cooker."
- "Masak nasinya seperti biasa. Tunggu hingga matang (sambil menikmati bau wanginya 😁)"
- "Siap disajikan!"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 193 calories
recipecuisine: Indonesian
preptime: "PT38M"
cooktime: "PT51M"
recipeyield: "1"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk Wangi nan Mudah](https://img-global.cpcdn.com/recipes/abfd561e924cebe6/682x484cq65/nasi-daun-jeruk-wangi-nan-mudah-foto-resep-utama.webp)

Resep rahasia dan cara memasak  Nasi Daun Jeruk Wangi nan Mudah yang harus bunda coba segera

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Untuk Menyiapkan Nasi Daun Jeruk Wangi nan Mudah:

1. beras 3 cup
1. bawang putih 3-4 siung
1. daun jeruk 10-15 helai
1. daun salam Secukupnya
1. garam dan kaldu bubuk Secukupnya
1. serai saya skip 1 batang



<!--inarticleads2-->

## Tata Cara Menyiapkan Nasi Daun Jeruk Wangi nan Mudah:

1. Cuci beras, masukkan ke baskom rice cooker dan isi dengan air secukupnya.
1. Pisahkan daun jeruk dari tangkai tengahnya, iris atau cincang halus. Sisihkan.
1. Cincang bawang putih dan tumis hingga wangi dan berwarna cokelat muda. -  - Masukkan tumisan bawang, irisan daun jeruk, daun salam, garam, dan kaldu bubuk ke dalam baskom rice cooker.
1. Masak nasinya seperti biasa. Tunggu hingga matang (sambil menikmati bau wanginya 😁)
1. Siap disajikan!




Selamat memasak dan menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
