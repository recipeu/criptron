---
description: "Langkah Mudah untuk Menyiapkan Nasi Daun Jeruk Rice Cooker yang Bisa Manjain Lidah"
title: "Langkah Mudah untuk Menyiapkan Nasi Daun Jeruk Rice Cooker yang Bisa Manjain Lidah"
slug: 244-langkah-mudah-untuk-menyiapkan-nasi-daun-jeruk-rice-cooker-yang-bisa-manjain-lidah
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-16T01:31:07.147Z 
thumbnail: https://img-global.cpcdn.com/recipes/5b55041d1b51d720/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/5b55041d1b51d720/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/5b55041d1b51d720/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/5b55041d1b51d720/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
author: Hulda Carr
ratingvalue: 4.8
reviewcount: 15
recipeingredient:
- "beras 3 cup"
- "bawang putih cincang halus 5 siung"
- "daun jeruk buang tulangnya iris tipis daunnya 10 lembar"
- "daun salam 3 lembar"
- "serai 1 batang"
- "mentega 2 sdm"
- "minyak 1 sdm"
recipeinstructions:
- "Cuci beras sampai bersih, beri air seperti biasa memasak nasi"
- "Panaskan minyak kedalam wajan, tumis bawang putih, disusul daun jeruk, daun salam, dan serai"
- "Setelah bumbu harum, tambahkan mentega"
- "Masukkan bumbu kedalam panci rice cooker, tambahkan garam&amp;penyedap secukupnya, aduk, dan masak nasi hingga matang"
- "Nasi daun jeruk siap disajikan dengan lauk pendamping           (lihat resep)"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 250 calories
recipecuisine: Indonesian
preptime: "PT20M"
cooktime: "PT35M"
recipeyield: "4"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk Rice Cooker](https://img-global.cpcdn.com/recipes/5b55041d1b51d720/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp)

Resep Nasi Daun Jeruk Rice Cooker  enak dengan 5 langkahmudah dan cepat yang musti ibu coba segera

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Dalam Pembuatan Nasi Daun Jeruk Rice Cooker:

1. beras 3 cup
1. bawang putih cincang halus 5 siung
1. daun jeruk buang tulangnya iris tipis daunnya 10 lembar
1. daun salam 3 lembar
1. serai 1 batang
1. mentega 2 sdm
1. minyak 1 sdm



<!--inarticleads2-->

## Cara Mudah Membuat Nasi Daun Jeruk Rice Cooker:

1. Cuci beras sampai bersih, beri air seperti biasa memasak nasi
1. Panaskan minyak kedalam wajan, tumis bawang putih, disusul daun jeruk, daun salam, dan serai
1. Setelah bumbu harum, tambahkan mentega
1. Masukkan bumbu kedalam panci rice cooker, tambahkan garam&amp;penyedap secukupnya, aduk, dan masak nasi hingga matang
1. Nasi daun jeruk siap disajikan dengan lauk pendamping -           (lihat resep)




Salah satu kuliner yang cukup praktis dalam pembuatannya adalah  Nasi Daun Jeruk Rice Cooker. Selain itu  Nasi Daun Jeruk Rice Cooker  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu lakukan 5 langkah, dan  Nasi Daun Jeruk Rice Cooker  pun siap di hidangkan. selamat mencoba !
