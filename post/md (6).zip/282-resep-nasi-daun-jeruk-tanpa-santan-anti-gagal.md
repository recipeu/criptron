---
description: "Resep Nasi Daun Jeruk (Tanpa Santan) Anti Gagal"
title: "Resep Nasi Daun Jeruk (Tanpa Santan) Anti Gagal"
slug: 282-resep-nasi-daun-jeruk-tanpa-santan-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2022-01-06T11:07:27.104Z 
thumbnail: https://img-global.cpcdn.com/recipes/1aa0166d1a61e658/682x484cq65/nasi-daun-jeruk-tanpa-santan-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/1aa0166d1a61e658/682x484cq65/nasi-daun-jeruk-tanpa-santan-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/1aa0166d1a61e658/682x484cq65/nasi-daun-jeruk-tanpa-santan-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/1aa0166d1a61e658/682x484cq65/nasi-daun-jeruk-tanpa-santan-foto-resep-utama.webp
author: Frank Williamson
ratingvalue: 4.5
reviewcount: 7
recipeingredient:
- "beras 1,5 cup"
- "Bumbu Tumis "
- "bawang putih 2 siung"
- "sereh 1 pcs"
- "daun salam 2 lembar"
- "daun jeruk 10 lembar"
- "Garam secukupnya tabur saat sudah di magicom "
- "Minyak secukupnya utk menumis "
recipeinstructions:
- "Cuci beras hingga bersih. Tambahkan air 1 ruas jari."
- "Potong² bawang putih, daun jeruk, dan geprek serehnya."
- "Panaskan sedikit minyak. Tumis bumbu hingga harum (step no 2)"
- "Masukkan ke magicom. Aduk2 dan tambahkan garam sedikit. Masak hingga matang. Siap dihidangkan."
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 245 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT45M"
recipeyield: "3"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk (Tanpa Santan)](https://img-global.cpcdn.com/recipes/1aa0166d1a61e658/682x484cq65/nasi-daun-jeruk-tanpa-santan-foto-resep-utama.webp)

Resep rahasia dan cara memasak  Nasi Daun Jeruk (Tanpa Santan) yang musti kamu coba segera

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Dalam Pembuatan Nasi Daun Jeruk (Tanpa Santan):

1. beras 1,5 cup
1. Bumbu Tumis 
1. bawang putih 2 siung
1. sereh 1 pcs
1. daun salam 2 lembar
1. daun jeruk 10 lembar
1. Garam secukupnya tabur saat sudah di magicom 
1. Minyak secukupnya utk menumis 



<!--inarticleads2-->

## Cara Membuat Nasi Daun Jeruk (Tanpa Santan):

1. Cuci beras hingga bersih. Tambahkan air 1 ruas jari.
1. Potong² bawang putih, daun jeruk, dan geprek serehnya.
1. Panaskan sedikit minyak. Tumis bumbu hingga harum (step no 2)
1. Masukkan ke magicom. Aduk2 dan tambahkan garam sedikit. Masak hingga matang. Siap dihidangkan.




Salah satu kuliner yang cukup praktis pembuatannya adalah  Nasi Daun Jeruk (Tanpa Santan). Selain itu  Nasi Daun Jeruk (Tanpa Santan)  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu lakukan 4 langkah, dan  Nasi Daun Jeruk (Tanpa Santan)  pun siap di hidangkan. selamat mencoba !
