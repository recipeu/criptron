---
description: "Bagaimana Menyiapkan Nasi Uduk Betawi Rice Cooker yang Enak"
title: "Bagaimana Menyiapkan Nasi Uduk Betawi Rice Cooker yang Enak"
slug: 22-bagaimana-menyiapkan-nasi-uduk-betawi-rice-cooker-yang-enak
future: true
lang: id
language: id
languageCode: id
publishDate: 2022-01-02T11:16:38.820Z 
thumbnail: https://img-global.cpcdn.com/recipes/e9b466108f130f05/682x484cq65/nasi-uduk-betawi-rice-cooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/e9b466108f130f05/682x484cq65/nasi-uduk-betawi-rice-cooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/e9b466108f130f05/682x484cq65/nasi-uduk-betawi-rice-cooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/e9b466108f130f05/682x484cq65/nasi-uduk-betawi-rice-cooker-foto-resep-utama.webp
author: Nicholas Adkins
ratingvalue: 3.6
reviewcount: 8
recipeingredient:
- "beras pulen 2 cup"
- "santan instan 65ml 1 saset"
- "munjung garam 2 sdt"
- "lada bubuk 1 sdt"
- "bawang merah cincang alus 2 siung"
- "jahe geprek me  pakai jahe bubuk 1sdt 1 ruas"
- "serai 1 batang"
- "daun salam 2 lembar"
- "lengkuas geprek 1 cm"
- "kayu manis 1/2 batang"
- "Minyak untuk menumis bawang "
- "Air sekitar 2-2,5 cup"
recipeinstructions:
- "Cuci beras sampai bersih. Masukkan beras, serai, daun salam, kayu manis, jahe, lengkuas, santan instan, garam, lada, dan air ke dalam panci rice cooker. Sisihkan."
- "Tumis bawang merah dengan minyak sampai harum. Masukkan kedalam panci rice cooker yg berisi beras."
- "Masak nasi dengan ricecooker sampai matang. Ketika sdh matang aduk spy rata. Dan dicek apakah nasi matang sempurna. Jika blm dan msh keras bisa ditambahkan sedikit air. Kemudian cook kembali.  Selamat mencoba."
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 287 calories
recipecuisine: Indonesian
preptime: "PT19M"
cooktime: "PT59M"
recipeyield: "3"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Betawi Rice Cooker](https://img-global.cpcdn.com/recipes/e9b466108f130f05/682x484cq65/nasi-uduk-betawi-rice-cooker-foto-resep-utama.webp)

Ingin membuat Nasi Uduk Betawi Rice Cooker ? Coba resep berikut ini. Cara memasaknya sangat praktis namun hasilnya gurih dan lezat yang wajib bunda coba dirumah

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Dalam Pembuatan Nasi Uduk Betawi Rice Cooker:

1. beras pulen 2 cup
1. santan instan 65ml 1 saset
1. munjung garam 2 sdt
1. lada bubuk 1 sdt
1. bawang merah cincang alus 2 siung
1. jahe geprek me  pakai jahe bubuk 1sdt 1 ruas
1. serai 1 batang
1. daun salam 2 lembar
1. lengkuas geprek 1 cm
1. kayu manis 1/2 batang
1. Minyak untuk menumis bawang 
1. Air sekitar 2-2,5 cup



<!--inarticleads2-->

## Cara Mudah Menyiapkan Nasi Uduk Betawi Rice Cooker:

1. Cuci beras sampai bersih. Masukkan beras, serai, daun salam, kayu manis, jahe, lengkuas, santan instan, garam, lada, dan air ke dalam panci rice cooker. Sisihkan.
1. Tumis bawang merah dengan minyak sampai harum. Masukkan kedalam panci rice cooker yg berisi beras.
1. Masak nasi dengan ricecooker sampai matang. Ketika sdh matang aduk spy rata. Dan dicek apakah nasi matang sempurna. Jika blm dan msh keras bisa ditambahkan sedikit air. Kemudian cook kembali.  - Selamat mencoba.




Daripada kamu beli  Nasi Uduk Betawi Rice Cooker  diluar terus, ibu  bisa membuatnya sendiri dirumah. Resep  Nasi Uduk Betawi Rice Cooker  sederhana ini cukup praktis dalam proses pembuatannya, cukup menggunakan bumbu sederhana  Nasi Uduk Betawi Rice Cooker  yang enak, ibu nikmati di rumah.
