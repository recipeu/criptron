---
description: "Bagaimana Membuat Nasi Ayam Hainan Magic Com Anti Gagal"
title: "Bagaimana Membuat Nasi Ayam Hainan Magic Com Anti Gagal"
slug: 446-bagaimana-membuat-nasi-ayam-hainan-magic-com-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-01T16:05:41.285Z 
thumbnail: https://img-global.cpcdn.com/recipes/037534fa3c2f4dec/682x484cq65/nasi-ayam-hainan-magic-com-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/037534fa3c2f4dec/682x484cq65/nasi-ayam-hainan-magic-com-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/037534fa3c2f4dec/682x484cq65/nasi-ayam-hainan-magic-com-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/037534fa3c2f4dec/682x484cq65/nasi-ayam-hainan-magic-com-foto-resep-utama.webp
author: Cody Thomas
ratingvalue: 3.6
reviewcount: 4
recipeingredient:
- "beras 500 g"
- "Daging Ayam potong sesuai selera 500 g"
- "bawang putih cincang 4 siung"
- "jahe iris tipis 2 ruas"
- "saus tiram 2 sdm"
- "kecap asin 1 sdm"
- "garam 1 sdt"
- "kaldu bubuk 1/2 sdt"
- "lada bubuk 1/2 sdt"
- "Air untuk secukupnya tuk masak nasi "
- "daun bawang rajang kasar 1 batang"
recipeinstructions:
- "Campurkan Ayam, irisan jahe, saus tiram, kecap asin, garam, kaldu bubuk dan lada bubuk. Aduk rada. Marinasi selama 30 menit"
- "Tumis bawang putih cincang dg sedikit minyak sampai matang, angkat sisihkan."
- "Masukkan dlm magic com beras yg sdh dicuci. Tambahkan air secukupnya spt memasak nasi. Lalu masukkan ayam yg sdh dimarinasi dan bawang putih yg sdh ditumis beserta minyaknya. Masak sampai nasi matang"
- "Ketikan matang masukkan irisan daun bawang. Tutup kembali magic com diamkan 15 menit. Nasi ayam hainan siap dinikmat. Aduk rata nasi sebelum dihidangkan."
categories:
- Resep
tags:
- nasi
- ayam
- hainan

katakunci: nasi ayam hainan 
nutrition: 115 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT50M"
recipeyield: "4"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Ayam Hainan Magic Com](https://img-global.cpcdn.com/recipes/037534fa3c2f4dec/682x484cq65/nasi-ayam-hainan-magic-com-foto-resep-utama.webp)

Resep dan cara mengolah  Nasi Ayam Hainan Magic Com cocok banget jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Untuk Pembuatan Nasi Ayam Hainan Magic Com:

1. beras 500 g
1. Daging Ayam potong sesuai selera 500 g
1. bawang putih cincang 4 siung
1. jahe iris tipis 2 ruas
1. saus tiram 2 sdm
1. kecap asin 1 sdm
1. garam 1 sdt
1. kaldu bubuk 1/2 sdt
1. lada bubuk 1/2 sdt
1. Air untuk secukupnya tuk masak nasi 
1. daun bawang rajang kasar 1 batang



<!--inarticleads2-->

## Cara Membuat Nasi Ayam Hainan Magic Com:

1. Campurkan Ayam, irisan jahe, saus tiram, kecap asin, garam, kaldu bubuk dan lada bubuk. Aduk rada. Marinasi selama 30 menit
1. Tumis bawang putih cincang dg sedikit minyak sampai matang, angkat sisihkan.
1. Masukkan dlm magic com beras yg sdh dicuci. Tambahkan air secukupnya spt memasak nasi. Lalu masukkan ayam yg sdh dimarinasi dan bawang putih yg sdh ditumis beserta minyaknya. - Masak sampai nasi matang
1. Ketikan matang masukkan irisan daun bawang. Tutup kembali magic com diamkan 15 menit. Nasi ayam hainan siap dinikmat. Aduk rata nasi sebelum dihidangkan.




Selamat memasak dan menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
