---
description: "Resep Soto Semarang Ala Bangkong, Sempurna"
title: "Resep Soto Semarang Ala Bangkong, Sempurna"
slug: 498-resep-soto-semarang-ala-bangkong-sempurna
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-24T08:10:29.487Z 
thumbnail: https://img-global.cpcdn.com/recipes/452b0c44731d6faa/682x484cq65/soto-semarang-ala-bangkong-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/452b0c44731d6faa/682x484cq65/soto-semarang-ala-bangkong-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/452b0c44731d6faa/682x484cq65/soto-semarang-ala-bangkong-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/452b0c44731d6faa/682x484cq65/soto-semarang-ala-bangkong-foto-resep-utama.webp
author: Elmer Matthews
ratingvalue: 3.9
reviewcount: 3
recipeingredient:
- "Dada Ayam 600 gr"
- "Air Panci ukuran 20cm 3/4"
- "Garam dan Gula Pasir Secukupnya"
- "Kaldu Ayam Bubuk me  Royco Secukupnya"
- "Minyak Goreng dan Margarin Secukupnya"
- "Bumbu Halus "
- "Bawang Merah 8 Siung"
- "Bawang Putih 4 Siung"
- "Kemiri Sangrai 3 Butir"
- "Jahe 3 cm"
- "Kunyit 3 cm"
- "Ketumbar Bubuk 2 sdt"
- "Lada Bubuk 2 sdt"
- "Pala Bubuk 1/4 sdt"
- "Bumbu Rempah Tambahan "
- "Daun Jeruk 3 Lembar"
- "Daun Salam 3 Lembar"
- "Lengkuas Geprek 4 cm"
- "Sereh Geprek 2 Batang"
- "Pelengkap Soto "
- "Sohun Rendam dlm air panas kurleb 3menit lalu tiriskan "
- "Nasi "
- "Kol potong kecil tipis celup dalam air mendidih Tiriskan "
- "Tauge celup dlm air mendidih Tiriskan "
- "Bawang Putih Goreng Potong bentuk kotakkotak Secukupnya"
- "Daun Bawang  Daun Seledri Iris tipissesuai selera 1 Batang"
- "Tomat sy skip 1 Buah"
- "Jeruk NipisJeruk Kasturi Secukupnya"
- "Kecap Manis "
recipeinstructions:
- "Siapkan panci lalu masukkan air, rebus dada ayam hingga matang dan keluar kaldunya. Sambil merebus ayam, siapkan bumbu-bumbu halusnya."
- "Siapkan wajan, panaskan minyak goreng dan sedikit margarin lalu tumis bumbu-bumbu halusnya kemudian masukkan daun jeruk dan daun salam (daun jeruk dan daun salam diremas dulu, agar aromanya keluar dan memberi rasa bumbu lebih mantap), lalu masukkan lengkuas dan sereh. Tumis hingga wangi."
- "Masukkan tumisan bumbu tadi ke dalam panci yang berisi air rebusan ayam. Tambahkan garam, gula pasir dan kaldu ayam bubuk. Aduk rata. Koreksi rasa, hingga pas. Lanjutkan memasak kuahnya hingga bumbu meresap pada ayam."
- "Angkat ayam dari kuah, tiriskan. Lalu goreng dan suwir-suwir ayam. Kuahnya tetap dipanaskan. Sebelum disajikan, masukkan ke dalam kuah soto irisan daun bawang, bawang putih goreng, dan potongan tomat."
- "Untuk penyajiannya, siapkan mangkok. Lalu tata nasi, sohun, kol, tauge, potongan tomat, dan suwiran ayam, lalu beri kuah. Kemudian taburi irisan daun seledri, daun bawang, dan bawang goreng lalu tambahkan kecap hingga pas sesuai selera. Sesuai saran dari empunya resep, untuk rasa yang lebih mantap, berani dalam memberi garam dan gula pada kuah soto."
- "Makin mantap kalau ditambahkan sambal dan air perasan jeruk nipis. 😁 (Saya gak sempat bikin sambal, jadi hanya menambah 1 biji cabe rawit yg digeprek dalam mangkok saya) 😅"
- "Selamat mencoba 🥰"
categories:
- Resep
tags:
- soto
- semarang
- ala

katakunci: soto semarang ala 
nutrition: 199 calories
recipecuisine: Indonesian
preptime: "PT29M"
cooktime: "PT51M"
recipeyield: "2"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Soto Semarang Ala Bangkong](https://img-global.cpcdn.com/recipes/452b0c44731d6faa/682x484cq65/soto-semarang-ala-bangkong-foto-resep-utama.webp)

Ingin membuat Soto Semarang Ala Bangkong ? Coba resep berikut ini. Cara memasaknya sangat praktis namun hasilnya gurih dan lezat cocok sekali jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Bahan-bahan Yang Dibutuhkan Dalam Menyiapkan Soto Semarang Ala Bangkong:

1. Dada Ayam 600 gr
1. Air Panci ukuran 20cm 3/4
1. Garam dan Gula Pasir Secukupnya
1. Kaldu Ayam Bubuk me  Royco Secukupnya
1. Minyak Goreng dan Margarin Secukupnya
1. Bumbu Halus 
1. Bawang Merah 8 Siung
1. Bawang Putih 4 Siung
1. Kemiri Sangrai 3 Butir
1. Jahe 3 cm
1. Kunyit 3 cm
1. Ketumbar Bubuk 2 sdt
1. Lada Bubuk 2 sdt
1. Pala Bubuk 1/4 sdt
1. Bumbu Rempah Tambahan 
1. Daun Jeruk 3 Lembar
1. Daun Salam 3 Lembar
1. Lengkuas Geprek 4 cm
1. Sereh Geprek 2 Batang
1. Pelengkap Soto 
1. Sohun Rendam dlm air panas kurleb 3menit lalu tiriskan 
1. Nasi 
1. Kol potong kecil tipis celup dalam air mendidih Tiriskan 
1. Tauge celup dlm air mendidih Tiriskan 
1. Bawang Putih Goreng Potong bentuk kotakkotak Secukupnya
1. Daun Bawang  Daun Seledri Iris tipissesuai selera 1 Batang
1. Tomat sy skip 1 Buah
1. Jeruk NipisJeruk Kasturi Secukupnya
1. Kecap Manis 



<!--inarticleads2-->

## Cara Mudah Membuat Soto Semarang Ala Bangkong:

1. Siapkan panci lalu masukkan air, rebus dada ayam hingga matang dan keluar kaldunya. Sambil merebus ayam, siapkan bumbu-bumbu halusnya.
1. Siapkan wajan, panaskan minyak goreng dan sedikit margarin lalu tumis bumbu-bumbu halusnya kemudian masukkan daun jeruk dan daun salam (daun jeruk dan daun salam diremas dulu, agar aromanya keluar dan memberi rasa bumbu lebih mantap), lalu masukkan lengkuas dan sereh. Tumis hingga wangi.
1. Masukkan tumisan bumbu tadi ke dalam panci yang berisi air rebusan ayam. Tambahkan garam, gula pasir dan kaldu ayam bubuk. Aduk rata. Koreksi rasa, hingga pas. Lanjutkan memasak kuahnya hingga bumbu meresap pada ayam.
1. Angkat ayam dari kuah, tiriskan. Lalu goreng dan suwir-suwir ayam. Kuahnya tetap dipanaskan. Sebelum disajikan, masukkan ke dalam kuah soto irisan daun bawang, bawang putih goreng, dan potongan tomat.
1. Untuk penyajiannya, siapkan mangkok. Lalu tata nasi, sohun, kol, tauge, potongan tomat, dan suwiran ayam, lalu beri kuah. Kemudian taburi irisan daun seledri, daun bawang, dan bawang goreng lalu tambahkan kecap hingga pas sesuai selera. Sesuai saran dari empunya resep, untuk rasa yang lebih mantap, berani dalam memberi garam dan gula pada kuah soto.
1. Makin mantap kalau ditambahkan sambal dan air perasan jeruk nipis. 😁 (Saya gak sempat bikin sambal, jadi hanya menambah 1 biji cabe rawit yg digeprek dalam mangkok saya) 😅
1. Selamat mencoba 🥰




Salah satu kuliner yang cukup praktis pembuatannya adalah  Soto Semarang Ala Bangkong. Selain itu  Soto Semarang Ala Bangkong  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu lakukan 7 langkah, dan  Soto Semarang Ala Bangkong  pun siap di hidangkan. selamat mencoba !
