---
description: "Resep Nasi uduk betawi Anti Gagal"
title: "Resep Nasi uduk betawi Anti Gagal"
slug: 37-resep-nasi-uduk-betawi-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-02T14:40:57.445Z 
thumbnail: https://img-global.cpcdn.com/recipes/f4c621c03aa9736e/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/f4c621c03aa9736e/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/f4c621c03aa9736e/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/f4c621c03aa9736e/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
author: Della Goodwin
ratingvalue: 3.6
reviewcount: 6
recipeingredient:
- "beras sedang jgn terlalu pulen 1 liter"
- "serai memarkan 2 batang"
- "kencur geprek 2 ruas"
- "jahe geprek 1 ruas"
- "daun salam 5 lembar"
- "bawang merah 5 siung"
- "santan atau 2 bungkus kara yg ukuran kecil 1 liter"
- "garam 1 1/2 sdm"
- "minyak goreng 2 sdm"
recipeinstructions:
- "Cuci bersih berasnya"
- "Cuci bersih semua bumbu kemudian geprek kencur, jahe, sereh dan haluskan bawang merahnya."
- "Didihkan santan bersama semua bumbu jahe, kencur, salam, serai bawang merah.. agar aroma bumbunya lebih meresap."
- "Siapkan panci untuk aron kemudian beras yg sdh di cuci pindahkan ke panci dan tuang santan yg sdh di masak tadi ke dalam beras, berikan garam dan tambahkan 2 sdm minyak goreng."
- "Lakukan proses aron dengan api sedang, saat sedang aronin beras jangan ditinggal.. tunggu sambil di balik2 agar tdk gosong bagian bawahnya"
- "Siapkan dandang untuk mengukus dan panaskan dandang terlebih dahulu.. jika sdh jd nasi aronnya pin dahkan nasi ke dalam kukusan dan kukus dengan api sedang selama 25-30 menit"
- "Jika sudah matang tes rasa.. dan sbg pelengkap siapkan sambal kacang, bawang goreng, kerupuk serta pelengkap lainnya sesuai selera.. dan nasi uduk siap disajikan"
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 224 calories
recipecuisine: Indonesian
preptime: "PT26M"
cooktime: "PT48M"
recipeyield: "4"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi uduk betawi](https://img-global.cpcdn.com/recipes/f4c621c03aa9736e/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp)

7 langkah cepat memasak  Nasi uduk betawi yang wajib kamu coba dirumah

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Untuk Pembuatan Nasi uduk betawi:

1. beras sedang jgn terlalu pulen 1 liter
1. serai memarkan 2 batang
1. kencur geprek 2 ruas
1. jahe geprek 1 ruas
1. daun salam 5 lembar
1. bawang merah 5 siung
1. santan atau 2 bungkus kara yg ukuran kecil 1 liter
1. garam 1 1/2 sdm
1. minyak goreng 2 sdm

Menu siap saji, tinggal goreng dan siap disantap dengan. There are no reviews for Nasi Uduk Betawi Bang Acim, Indonesia yet. Be the first to write a review! Cara membuat nasi uduk betawi bisa dibikin mudah, cukup gunakan magic com. 

<!--inarticleads2-->

## Cara Mudah Membuat Nasi uduk betawi:

1. Cuci bersih berasnya
1. Cuci bersih semua bumbu kemudian geprek kencur, jahe, sereh dan haluskan bawang merahnya.
1. Didihkan santan bersama semua bumbu jahe, kencur, salam, serai bawang merah.. agar aroma bumbunya lebih meresap.
1. Siapkan panci untuk aron kemudian beras yg sdh di cuci pindahkan ke panci dan tuang santan yg sdh di masak tadi ke dalam beras, berikan garam dan tambahkan 2 sdm minyak goreng.
1. Lakukan proses aron dengan api sedang, saat sedang aronin beras jangan ditinggal.. tunggu sambil di balik2 agar tdk gosong bagian bawahnya
1. Siapkan dandang untuk mengukus dan panaskan dandang terlebih dahulu.. jika sdh jd nasi aronnya pin dahkan nasi ke dalam kukusan dan kukus dengan api sedang selama 25-30 menit
1. Jika sudah matang tes rasa.. dan sbg pelengkap siapkan sambal kacang, bawang goreng, kerupuk serta pelengkap lainnya sesuai selera.. dan nasi uduk siap disajikan


Berikut resep nasi uduk betawi sederhana yang bisa untuk dijual. Resep Nasi Uduk Betawi - Makanan khas Betawi ini cocok sekali dijadikan menu sarapan. Uhh, sajian nasi uduk betawi ini akan semakin lezat dan komplit. Baca Juga : Resep Mie Aceh Tumis. Nasi uduk Betawi memiliki kekhasannya sendiri dan sudah memiliki citra tersendiri. 

Terima kasih telah menggunakan resep yang tim kami tampilkan di halaman ini. Semoga bermanfaat dan selamat mencoba!
