---
description: "Resep Nasi Daun Jeruk Anti Gagal"
title: "Resep Nasi Daun Jeruk Anti Gagal"
slug: 292-resep-nasi-daun-jeruk-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-03T00:18:31.048Z 
thumbnail: https://img-global.cpcdn.com/recipes/1e61c285f3cc2516/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/1e61c285f3cc2516/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/1e61c285f3cc2516/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/1e61c285f3cc2516/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
author: Jackson Robbins
ratingvalue: 3.4
reviewcount: 3
recipeingredient:
- "beras 4 cup"
- "daun jeruk 20 lembar"
- "sereh 2 batang"
- "daun salam 2 lembar"
- "bawang putih 3 siung"
- "bawang merah 2 siung"
- "margarin 2 sdm"
- "santan instan opt bisa diganti 3 sdm fiber creme 1 bungkus"
- "bubuk kaldu rasa ayam 1 sachet"
- "Sekitar 12  1 sdt garam "
recipeinstructions:
- "Masukkan beras yang sudah dicuci ke dalam magic com."
- "Iris bawang, tumis dengan margarin sampai harum. Masukkan ke magic com."
- "Buang batang tengah daun jeruk lalu iris tipis, masukkan ke magic com."
- "Masukkan daun salam dan sereh yang digeprek dahulu ke magic com."
- "Masukkan santan/fiber creme, kaldu bubuk, dan garam ke magic com. Masukkan air(dilebihkan sedikit dibanding masak nasi biasa), aduk rata. Masak. Tunggu nasi matang. Selesai."
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 228 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT51M"
recipeyield: "4"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk](https://img-global.cpcdn.com/recipes/1e61c285f3cc2516/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp)

5 langkah mudah mengolah  Nasi Daun Jeruk cocok sekali jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Dalam Pembuatan Nasi Daun Jeruk:

1. beras 4 cup
1. daun jeruk 20 lembar
1. sereh 2 batang
1. daun salam 2 lembar
1. bawang putih 3 siung
1. bawang merah 2 siung
1. margarin 2 sdm
1. santan instan opt bisa diganti 3 sdm fiber creme 1 bungkus
1. bubuk kaldu rasa ayam 1 sachet
1. Sekitar 12  1 sdt garam 



<!--inarticleads2-->

## Cara Menyiapkan Nasi Daun Jeruk:

1. Masukkan beras yang sudah dicuci ke dalam magic com.
1. Iris bawang, tumis dengan margarin sampai harum. Masukkan ke magic com.
1. Buang batang tengah daun jeruk lalu iris tipis, masukkan ke magic com.
1. Masukkan daun salam dan sereh yang digeprek dahulu ke magic com.
1. Masukkan santan/fiber creme, kaldu bubuk, dan garam ke magic com. Masukkan air(dilebihkan sedikit dibanding masak nasi biasa), aduk rata. Masak. Tunggu nasi matang. Selesai.




Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
