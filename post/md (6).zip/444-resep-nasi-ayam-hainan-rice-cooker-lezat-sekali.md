---
description: "Resep Nasi Ayam Hainan Rice Cooker, Lezat Sekali"
title: "Resep Nasi Ayam Hainan Rice Cooker, Lezat Sekali"
slug: 444-resep-nasi-ayam-hainan-rice-cooker-lezat-sekali
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-12T20:06:27.533Z 
thumbnail: https://img-global.cpcdn.com/recipes/ae60bbab088866e9/682x484cq65/nasi-ayam-hainan-rice-cooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/ae60bbab088866e9/682x484cq65/nasi-ayam-hainan-rice-cooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/ae60bbab088866e9/682x484cq65/nasi-ayam-hainan-rice-cooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/ae60bbab088866e9/682x484cq65/nasi-ayam-hainan-rice-cooker-foto-resep-utama.webp
author: Earl Hogan
ratingvalue: 3.4
reviewcount: 6
recipeingredient:
- "beras 2 cup"
- "air atau menyesuaikan ukuran beras masingmasing 2 cup"
- "Bumbu "
- "paha ayam 250 gr"
- "jahe bubuk 1/2 sdt"
- "garam 1/2 sdt"
- "kaldu jamur bubuk 1/4 sdt"
- "saos tiram 2 sdm"
- "kecap asin 1/2 sdt"
- "minyak goreng 2 sdm"
- "bawang putih goreng           lihat resep 2 sdm"
recipeinstructions:
- "Cuci bersih ayam, tiriskan. Bumbui ayam dengan bumbu-bumbu kecuali bawang putih goreng dan marinasi selama kurang lebih 20 menit."
- "Cuci beras seperti biasanya, tuangkan ayam marinasi, tuang air aduk dan taburi bawang putih goreng."
- "Aduk aduk lagi kemudian pencet tombol cooking,ketika sudah setengah matang angkat ayam dan keluarkan dari rice cooker. Dan biarkan nasi sampai matang atau pindah ketombol warm. Sajikan."
- "Nikmati bersama ayam hainan.Liat resep berikutnya."
categories:
- Resep
tags:
- nasi
- ayam
- hainan

katakunci: nasi ayam hainan 
nutrition: 241 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT36M"
recipeyield: "3"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Ayam Hainan Rice Cooker](https://img-global.cpcdn.com/recipes/ae60bbab088866e9/682x484cq65/nasi-ayam-hainan-rice-cooker-foto-resep-utama.webp)

Ingin membuat Nasi Ayam Hainan Rice Cooker ? Coba resep berikut ini. Cara memasaknya sangat praktis namun jangan kaget jika hasilnya gurih dan lezat yang harus ibu coba dirumah

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Dalam Menyiapkan Nasi Ayam Hainan Rice Cooker:

1. beras 2 cup
1. air atau menyesuaikan ukuran beras masingmasing 2 cup
1. Bumbu 
1. paha ayam 250 gr
1. jahe bubuk 1/2 sdt
1. garam 1/2 sdt
1. kaldu jamur bubuk 1/4 sdt
1. saos tiram 2 sdm
1. kecap asin 1/2 sdt
1. minyak goreng 2 sdm
1. bawang putih goreng           lihat resep 2 sdm



<!--inarticleads2-->

## Cara Menyiapkan Nasi Ayam Hainan Rice Cooker:

1. Cuci bersih ayam, tiriskan. Bumbui ayam dengan bumbu-bumbu kecuali bawang putih goreng dan marinasi selama kurang lebih 20 menit.
1. Cuci beras seperti biasanya, tuangkan ayam marinasi, tuang air aduk dan taburi bawang putih goreng.
1. Aduk aduk lagi kemudian pencet tombol cooking,ketika sudah setengah matang angkat ayam dan keluarkan dari rice cooker. Dan biarkan nasi sampai matang atau pindah ketombol warm. Sajikan.
1. Nikmati bersama ayam hainan.Liat resep berikutnya.




Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
