---
description: "Cara Gampang Menyiapkan Nasi Uduk Betawi Ricecooker yang Lezat"
title: "Cara Gampang Menyiapkan Nasi Uduk Betawi Ricecooker yang Lezat"
slug: 4-cara-gampang-menyiapkan-nasi-uduk-betawi-ricecooker-yang-lezat
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-07T19:44:01.254Z 
thumbnail: https://img-global.cpcdn.com/recipes/4d15c36086ac6686/682x484cq65/nasi-uduk-betawi-ricecooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/4d15c36086ac6686/682x484cq65/nasi-uduk-betawi-ricecooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/4d15c36086ac6686/682x484cq65/nasi-uduk-betawi-ricecooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/4d15c36086ac6686/682x484cq65/nasi-uduk-betawi-ricecooker-foto-resep-utama.webp
author: Jean Dean
ratingvalue: 4.6
reviewcount: 10
recipeingredient:
- "beras 2 cup"
- "santan instan  65ml 1 sachet"
- "munjung garam 2 sdt"
- "sdr lada bubuk 1"
- "bawang merah cincang halus 2 siung"
- "jahe geprek 1 ruas"
- "serai 1 batang"
- "daun salam 2 lembar"
- "lengkuas geprek 1 cm"
- "kayu manis 1/2 batang"
- "Minyak untuk menumis bawang "
- " 5 cup air sekitar 2-2"
- "Masakan tambahan sesuai selera  "
- "Telur dadar "
- "Tempe gula asem           lihat resep "
- "Ayam ngohiang           lihat resep "
- "Sambel bawang           lihat resep "
- "Bawang goreng           lihat resep "
- "Lalapan  kol mentah "
recipeinstructions:
- "Cuci beras hingga bersih"
- "Masukan beras, serai, salam, kayu manis, lengkuas, jahe, santan, lada bubuk, garam dan air ke dalam Ricecooker."
- "Iris bawang merah, lalu tumis hingga wangi"
- "Masukan tumisan bawang merah kedalam panci Ricecooker, masukan beserta minyaknya.  Supaya lebih wangi dan gurih"
- "Masak nasi dengan ricecooker sampai matang. Ketika sdh matang aduk spy rata. Dan dicek apakah nasi matang sempurna. Jika blm dan msh keras bisa ditambahkan sedikit air. Kemudian cook kembali. Selamat mencoba"
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 196 calories
recipecuisine: Indonesian
preptime: "PT12M"
cooktime: "PT47M"
recipeyield: "2"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Betawi Ricecooker](https://img-global.cpcdn.com/recipes/4d15c36086ac6686/682x484cq65/nasi-uduk-betawi-ricecooker-foto-resep-utama.webp)

5 langkah mudah membuat  Nasi Uduk Betawi Ricecooker cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Untuk Menyiapkan Nasi Uduk Betawi Ricecooker:

1. beras 2 cup
1. santan instan  65ml 1 sachet
1. munjung garam 2 sdt
1. sdr lada bubuk 1
1. bawang merah cincang halus 2 siung
1. jahe geprek 1 ruas
1. serai 1 batang
1. daun salam 2 lembar
1. lengkuas geprek 1 cm
1. kayu manis 1/2 batang
1. Minyak untuk menumis bawang 
1.  5 cup air sekitar 2-2
1. Masakan tambahan sesuai selera  
1. Telur dadar 
1. Tempe gula asem           lihat resep 
1. Ayam ngohiang           lihat resep 
1. Sambel bawang           lihat resep 
1. Bawang goreng           lihat resep 
1. Lalapan  kol mentah 



<!--inarticleads2-->

## Tata Cara Menyiapkan Nasi Uduk Betawi Ricecooker:

1. Cuci beras hingga bersih
1. Masukan beras, serai, salam, kayu manis, lengkuas, jahe, santan, lada bubuk, garam dan air ke dalam Ricecooker.
1. Iris bawang merah, lalu tumis hingga wangi
1. Masukan tumisan bawang merah kedalam panci Ricecooker, masukan beserta minyaknya.  - Supaya lebih wangi dan gurih
1. Masak nasi dengan ricecooker sampai matang. Ketika sdh matang aduk spy rata. Dan dicek apakah nasi matang sempurna. Jika blm dan msh keras bisa ditambahkan sedikit air. Kemudian cook kembali. Selamat mencoba




Demikian informasi  resep Nasi Uduk Betawi Ricecooker   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
