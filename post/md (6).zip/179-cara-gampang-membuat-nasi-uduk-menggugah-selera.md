---
description: "Cara Gampang Membuat Nasi Uduk 🇮🇩, Menggugah Selera"
title: "Cara Gampang Membuat Nasi Uduk 🇮🇩, Menggugah Selera"
slug: 179-cara-gampang-membuat-nasi-uduk-menggugah-selera
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-16T17:26:08.307Z 
thumbnail: https://img-global.cpcdn.com/recipes/ecd6b2cd12d05696/682x484cq65/nasi-uduk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/ecd6b2cd12d05696/682x484cq65/nasi-uduk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/ecd6b2cd12d05696/682x484cq65/nasi-uduk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/ecd6b2cd12d05696/682x484cq65/nasi-uduk-foto-resep-utama.webp
author: Harvey Black
ratingvalue: 4.9
reviewcount: 14
recipeingredient:
- "beras putih 1,8 Kg"
- "serai geprek 2 batang"
- "lengkuas iris lalu geprek 1 ruas"
- "santan 200 ml"
- "daun salam 4-5"
- "royco sapi 1 bungkus"
- "Minyak goreng "
- "Bumbu ulekan "
- "bawang putih 3 siung"
- "bawang merah 10 siung"
- "kencur 2 ruas"
- "kemiri 2 sdm"
- "garam 1 sdm"
recipeinstructions:
- "Ulek semua bahan di bawah ini hingga halus"
- "Panaskan minyak lalu tumis hingga wangi.  Masukan santan masak hingga mendidih.   Sisihkan terlebih dahulu"
- "Cuci beras hingga bersih.   Masukan lengkuas, serai, daun salam beri air"
- "Masukan bahan no 2 dan royco ke dalam beras. Masak dengan api sedang hingga air menyusut.  Untuk airnya bisa diukur 1 setengah jari atau hingga tingginya menyentuh sendi kedua jari telunjuk  Kurang lebih seperti gigih beras setelah di masak."
- "Kukus kurang lebih 15-20 menit gigih beras hingga matang menjadi nasi uduk."
- "Nasi uduk siap dihidangkan. Selamat mencoba 🥰   Selamat hari kemerdekaan RI 🇮🇩"
categories:
- Resep
tags:
- nasi
- uduk

katakunci: nasi uduk 
nutrition: 245 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT43M"
recipeyield: "1"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk 🇮🇩](https://img-global.cpcdn.com/recipes/ecd6b2cd12d05696/682x484cq65/nasi-uduk-foto-resep-utama.webp)

Resep Nasi Uduk 🇮🇩    dengan 6 langkahmudah cocok banget jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Untuk Pembuatan Nasi Uduk 🇮🇩:

1. beras putih 1,8 Kg
1. serai geprek 2 batang
1. lengkuas iris lalu geprek 1 ruas
1. santan 200 ml
1. daun salam 4-5
1. royco sapi 1 bungkus
1. Minyak goreng 
1. Bumbu ulekan 
1. bawang putih 3 siung
1. bawang merah 10 siung
1. kencur 2 ruas
1. kemiri 2 sdm
1. garam 1 sdm



<!--inarticleads2-->

## Langkah-langkah Untuk Membuat Nasi Uduk 🇮🇩:

1. Ulek semua bahan di bawah ini hingga halus
1. Panaskan minyak lalu tumis hingga wangi. -  - Masukan santan masak hingga mendidih.  -  - Sisihkan terlebih dahulu
<img class="lazyload" data-src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Nasi Uduk 🇮🇩" width="340" height="340">
>1. Cuci beras hingga bersih.  -  - Masukan lengkuas, serai, daun salam beri air
1. Masukan bahan no 2 dan royco ke dalam beras. Masak dengan api sedang hingga air menyusut. -  - Untuk airnya bisa diukur 1 setengah jari atau hingga tingginya menyentuh sendi kedua jari telunjuk -  - Kurang lebih seperti gigih beras setelah di masak.
<img class="lazyload" data-src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Nasi Uduk 🇮🇩" width="340" height="340">
>1. Kukus kurang lebih 15-20 menit gigih beras hingga matang menjadi nasi uduk.
1. Nasi uduk siap dihidangkan. Selamat mencoba 🥰  -  - Selamat hari kemerdekaan RI 🇮🇩




Daripada   beli  Nasi Uduk 🇮🇩  diluar terus, ibu  bisa membuatnya sendiri dirumah. Resep  Nasi Uduk 🇮🇩  sederhana ini cukup praktis dalam proses pembuatannya, cukup menggunakan bumbu sederhana  Nasi Uduk 🇮🇩  yang enak, ibu nikmati di rumah.
