---
description: "Resep Nasi Liwet Daun Jeruk Rice cooker Anti Gagal"
title: "Resep Nasi Liwet Daun Jeruk Rice cooker Anti Gagal"
slug: 341-resep-nasi-liwet-daun-jeruk-rice-cooker-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-11T07:57:23.113Z 
thumbnail: https://img-global.cpcdn.com/recipes/a24bf72a84eaffc0/682x484cq65/nasi-liwet-daun-jeruk-rice-cooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/a24bf72a84eaffc0/682x484cq65/nasi-liwet-daun-jeruk-rice-cooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/a24bf72a84eaffc0/682x484cq65/nasi-liwet-daun-jeruk-rice-cooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/a24bf72a84eaffc0/682x484cq65/nasi-liwet-daun-jeruk-rice-cooker-foto-resep-utama.webp
author: Aaron Jones
ratingvalue: 4.9
reviewcount: 6
recipeingredient:
- "beras cuci dan rendam 30 menit 4 mug"
- "bawang merah ukuran besar 3 siung"
- "bawang putih ukuran besar 3 siung"
- "sereh 2 batang"
- "daun jeruk besar bersihkan dari batang tengah 5 lembar"
- "garam 1 sdt"
- "makan mentega 1 sdm"
- "minyak goreng 1 sdm"
- "Daun pisang alas rice cooker "
- "Air untuk memasak nasi "
recipeinstructions:
- "Bawang merah &amp; Bawang Putih di iris."
- "Panaskan mentega dan minyak, tumis kedua jenis bawang hingga layu dan agak kuning. Lalu masukkan sereh yang telah di geprak dan daun jeruk. Kalau selera, daun jeruk bisa diiris halus"
- "Masukkan beras yang sudah di rendam sebelumnya. Aduk aduk sebentar di atas api, hingga bumbu terserap"
- "Masukkan ke dalam rice cooker yang sebelumnya sdh di lapisi dengan daun pisang. Tambahkan air secukupnya, lalu masak seperti biasa"
- "Setelah nasi matang, daun pisang di singkirkan dan nasi di aduk hingga rata, agar tidak mengendap / kerak. Dan nasi siap di hidangkan"
categories:
- Resep
tags:
- nasi
- liwet
- daun

katakunci: nasi liwet daun 
nutrition: 235 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT37M"
recipeyield: "2"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Liwet Daun Jeruk Rice cooker](https://img-global.cpcdn.com/recipes/a24bf72a84eaffc0/682x484cq65/nasi-liwet-daun-jeruk-rice-cooker-foto-resep-utama.webp)

Resep rahasia Nasi Liwet Daun Jeruk Rice cooker  anti gagal dengan 5 langkahcepat cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Dalam Menyiapkan Nasi Liwet Daun Jeruk Rice cooker:

1. beras cuci dan rendam 30 menit 4 mug
1. bawang merah ukuran besar 3 siung
1. bawang putih ukuran besar 3 siung
1. sereh 2 batang
1. daun jeruk besar bersihkan dari batang tengah 5 lembar
1. garam 1 sdt
1. makan mentega 1 sdm
1. minyak goreng 1 sdm
1. Daun pisang alas rice cooker 
1. Air untuk memasak nasi 

Cara membuat nasi liwet rice cooker. Panaskan minyak dalam rice cooker, masukkan. Nasi daun jeruk siap dihidangkan dengan. Resep Nasi Liwet Sunda - Nasi liwet merupakan salah satu hidangan berupa nasi gurih yang khas dari Jawa Barat. 

<!--inarticleads2-->

## Langkah-langkah Untuk Membuat Nasi Liwet Daun Jeruk Rice cooker:

1. Bawang merah &amp; Bawang Putih di iris.
1. Panaskan mentega dan minyak, tumis kedua jenis bawang hingga layu dan agak kuning. Lalu masukkan sereh yang telah di geprak dan daun jeruk. Kalau selera, daun jeruk bisa diiris halus
1. Masukkan beras yang sudah di rendam sebelumnya. Aduk aduk sebentar di atas api, hingga bumbu terserap
1. Masukkan ke dalam rice cooker yang sebelumnya sdh di lapisi dengan daun pisang. Tambahkan air secukupnya, lalu masak seperti biasa
1. Setelah nasi matang, daun pisang di singkirkan dan nasi di aduk hingga rata, agar tidak mengendap / kerak. Dan nasi siap di hidangkan


Simak Juga: Resep Nasi Ayam Hainan Rice Cooker : Nasi Ayam Pek Cam Kee Rebus Halal ala Resto. There are many rice dishes in Indonesia that use coconut milk and The addition of daun kemangi / holy basil leaves made the nasi liwet even more aromatic. My favorite ways are rice cooker and instant pot because they are easy and convenient. Nasi daun jeruk ini perpaduan antara nasi liwet dan nasi gurih dengan wangi daun jeruk yang dominan. Untuk mempermudah pembuatannya, kali ini saya membuat nasi daun jeruk menggunakan rice cooker. 

Demikian informasi  resep Nasi Liwet Daun Jeruk Rice cooker   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
