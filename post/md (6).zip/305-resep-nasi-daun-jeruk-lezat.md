---
description: "Resep Nasi daun jeruk, Lezat"
title: "Resep Nasi daun jeruk, Lezat"
slug: 305-resep-nasi-daun-jeruk-lezat
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-06T22:00:52.879Z 
thumbnail: https://img-global.cpcdn.com/recipes/da2044a0ac3ca932/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/da2044a0ac3ca932/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/da2044a0ac3ca932/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/da2044a0ac3ca932/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
author: Jean Chandler
ratingvalue: 3.2
reviewcount: 11
recipeingredient:
- "beras 4 cup"
- "Air menyesuaikan banyaknya beras "
- "daun jeruk 20 lembar"
- "daun salam 3 lembar"
- "serai 1 batang"
- "margarin 2 sdm"
- "garam 1 sdt"
- "daun pandan 1 lembar"
recipeinstructions:
- "Siapkan bahan. Cuci bersih beras, taruh dalam panci magic com."
- "Tambahkan air. Sobek-sobek daun jeruk. Masukkan daun jeruk, daun salam, serai, daun pandan, margarin, garam. Aduk rata."
- "Masak hingga nasi matang, siap disajikan"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 274 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT51M"
recipeyield: "3"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi daun jeruk](https://img-global.cpcdn.com/recipes/da2044a0ac3ca932/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp)

3 langkah cepat memasak  Nasi daun jeruk cocok sekali jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Untuk Pembuatan Nasi daun jeruk:

1. beras 4 cup
1. Air menyesuaikan banyaknya beras 
1. daun jeruk 20 lembar
1. daun salam 3 lembar
1. serai 1 batang
1. margarin 2 sdm
1. garam 1 sdt
1. daun pandan 1 lembar

Nasi daun jeruk siap dihidangkan dengan. Nasi daun jeruk ini memang sedang tren di kalangan masyarakat Indonesia, banyak sekali kaum muda mudi yang berlomba-lomba membuat makanan nasi putih spesial ini. Nasi daun jeruk ala geprek bensu rekomended buat di coba. Geprek bensu nasi daun jeruk anti mainst. 

<!--inarticleads2-->

## Tata Cara Membuat Nasi daun jeruk:

1. Siapkan bahan. Cuci bersih beras, taruh dalam panci magic com.
1. Tambahkan air. Sobek-sobek daun jeruk. Masukkan daun jeruk, daun salam, serai, daun pandan, margarin, garam. Aduk rata.
1. Masak hingga nasi matang, siap disajikan


Gurih dan wangi dari daun jeruk menambah kelezatan nasi daun jeruk. Nasi dengan campuran daun jeruk yang wangi sedang tren. Hai selamat pagi sahabat CWS, pagi ini saya share resep Nasi Daun Jeruk. Praktis banget karena saya gunakan rice cooker. Rasanya mirip nasi uduk tapi wangiiii. 

Demikian informasi  resep Nasi daun jeruk   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
