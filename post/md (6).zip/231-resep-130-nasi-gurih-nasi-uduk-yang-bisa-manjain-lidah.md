---
description: "Resep 130. Nasi gurih / nasi uduk yang Bisa Manjain Lidah"
title: "Resep 130. Nasi gurih / nasi uduk yang Bisa Manjain Lidah"
slug: 231-resep-130-nasi-gurih-nasi-uduk-yang-bisa-manjain-lidah
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-12T09:35:47.576Z 
thumbnail: https://img-global.cpcdn.com/recipes/2a2c566fed93a1b8/682x484cq65/130-nasi-gurih-nasi-uduk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/2a2c566fed93a1b8/682x484cq65/130-nasi-gurih-nasi-uduk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/2a2c566fed93a1b8/682x484cq65/130-nasi-gurih-nasi-uduk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/2a2c566fed93a1b8/682x484cq65/130-nasi-gurih-nasi-uduk-foto-resep-utama.webp
author: Harold Stevens
ratingvalue: 4.2
reviewcount: 10
recipeingredient:
- "beras 1 kg"
- "kelapa jadikan santan kental 1 butir"
- "daun salam 4 lbr"
- "lb daun jeruk 3"
- "sereh 1 btg"
- "Garam secukupnya "
recipeinstructions:
- "Bersihkan beras, taruh dalam wadah, masukkan daun salam, daun jeruk dan sereh. Tuang santan, masukkan garam lalu nyalakan api"
- "Sesekali aduk, agar tidak gosong dibawahnya.....Kalau santan sudah menyusut, matikan kompor lalu tutup panci"
- "Panaskan air dalam dandang, masukkan beras aron tadi...lalu kukus sampai matang 😉😉 mudah bukan"
categories:
- Resep
tags:
- 130
- nasi
- gurih

katakunci: 130 nasi gurih 
nutrition: 223 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT36M"
recipeyield: "1"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![130. Nasi gurih / nasi uduk](https://img-global.cpcdn.com/recipes/2a2c566fed93a1b8/682x484cq65/130-nasi-gurih-nasi-uduk-foto-resep-utama.webp)

3 langkah mudah mengolah  130. Nasi gurih / nasi uduk yang musti bunda coba segera

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Untuk Menyiapkan 130. Nasi gurih / nasi uduk:

1. beras 1 kg
1. kelapa jadikan santan kental 1 butir
1. daun salam 4 lbr
1. lb daun jeruk 3
1. sereh 1 btg
1. Garam secukupnya 

Resep Nasi Uduk - Salah satu dari variasi nasi biasa yang memiliki banyak penggemar adalah nasi uduk. Selain rasa yang gurih nasi ini dijual dengan harga yang cukup terjangkau. Bahkan di beberapa warung nasi biasanya dijual dengan harga tidak lebih dari Rp. Selesai nasi gurihnya siap disantap bersama orang tercinta bun selamat mencoba. 

<!--inarticleads2-->

## Cara Membuat 130. Nasi gurih / nasi uduk:

1. Bersihkan beras, taruh dalam wadah, masukkan daun salam, daun jeruk dan sereh. Tuang santan, masukkan garam lalu nyalakan api
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/eac8d6167a74c83d/160x128cq70/130-nasi-gurih-nasi-uduk-langkah-memasak-1-foto.webp" alt="130. Nasi gurih / nasi uduk" width="340" height="340">
>1. Sesekali aduk, agar tidak gosong dibawahnya.....Kalau santan sudah menyusut, matikan kompor lalu tutup panci
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/cbf2ea4207e163a0/160x128cq70/130-nasi-gurih-nasi-uduk-langkah-memasak-2-foto.webp" alt="130. Nasi gurih / nasi uduk" width="340" height="340">
><img class="lazyload" data-src="https://img-global.cpcdn.com/steps/57ada9bc1318cc24/160x128cq70/130-nasi-gurih-nasi-uduk-langkah-memasak-2-foto.webp" alt="130. Nasi gurih / nasi uduk" width="340" height="340">
><img class="lazyload" data-src="https://img-global.cpcdn.com/steps/1c937b761d074b34/160x128cq70/130-nasi-gurih-nasi-uduk-langkah-memasak-2-foto.webp" alt="130. Nasi gurih / nasi uduk" width="340" height="340">
>1. Panaskan air dalam dandang, masukkan beras aron tadi...lalu kukus sampai matang 😉😉 mudah bukan
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/8ce757748874122f/160x128cq70/130-nasi-gurih-nasi-uduk-langkah-memasak-3-foto.webp" alt="130. Nasi gurih / nasi uduk" width="340" height="340">
><img class="lazyload" data-src="https://img-global.cpcdn.com/steps/1c97ed0bd275e977/160x128cq70/130-nasi-gurih-nasi-uduk-langkah-memasak-3-foto.webp" alt="130. Nasi gurih / nasi uduk" width="340" height="340">
>

Nasi uduk juga seringkali disajikan jika ada acara-acara tertentu, seperti acara ulang tahun atau acara selamatan lho Moms. Tentunya dengan sayur dan lauk pendamping yang tidak kalah lezatnya. Tapi jika Moms ingin mencoba membuat nasi uduk sebagai hidangan untuk kelurga di rumah, bisa dengan. Nasi Uduk &amp; Nasi Gurih. by Pecinta Kuliner Kediri Raya. Nasi kuning salah satu varian dari sekian banyak menu nasi. 

Salah satu kuliner yang cukup praktis pembuatannya adalah  130. Nasi gurih / nasi uduk. Selain itu  130. Nasi gurih / nasi uduk  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu ikuti 3 langkah, dan  130. Nasi gurih / nasi uduk  pun siap di hidangkan. selamat mencoba !
