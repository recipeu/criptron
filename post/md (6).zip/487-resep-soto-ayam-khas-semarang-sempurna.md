---
description: "Resep Soto Ayam Khas Semarang, Sempurna"
title: "Resep Soto Ayam Khas Semarang, Sempurna"
slug: 487-resep-soto-ayam-khas-semarang-sempurna
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-12T11:12:39.028Z 
thumbnail: https://img-global.cpcdn.com/recipes/d008cffee09c5e9c/682x484cq65/soto-ayam-khas-semarang-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/d008cffee09c5e9c/682x484cq65/soto-ayam-khas-semarang-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/d008cffee09c5e9c/682x484cq65/soto-ayam-khas-semarang-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/d008cffee09c5e9c/682x484cq65/soto-ayam-khas-semarang-foto-resep-utama.webp
author: Alex Mann
ratingvalue: 3
reviewcount: 7
recipeingredient:
- "ayam kampung lebih enak 500 gr"
- "kerang dara  cangkang 500 gr"
- "Air secukupnya"
- "daun salam 2 lembar"
- "daun jeruk 3 lembar"
- "serai geprek 1 batang"
- "jahe geprek 1 ruas"
- "Bumbu halus  "
- "bawang merah 5 siung"
- "bawang putih 3 siung"
- "kemiri 3 butir"
- "ketumbar 1 sdt"
- "lada butiran 1/4 sdt"
- "jinten 1/4 sdt"
- "kunyit 1 cm"
- "Garam gula jawa dan kaldu bubuk sesuai selera"
- "Bahan pelengkap  "
- "Nasi "
- "Bawang putih goreng "
- "Daun bawang iris"
- "Taoge siram air panas "
- "Soun rendam air panas "
- "Sambal cabe "
- "Kecap manis "
- "Jeruk nipis "
recipeinstructions:
- "Rebus kerang dara, kerangnya wajib yg masih ada kulitnya ya, ambil kaldunya. Sisihkan. Rebus ayam sampai berminyak. Sambil menunggu kita siapkan bumbu2. Ulek/ blender bumbu sampai halus"
- "Tumis bumbu halus bersama daun salam, daun jeruk, jahe dan lengkuas sampai harum. Lalu masukkan kedalam rebusan ayam. Tambahkan kaldu kerang, garam, gula jawa dan kaldu bubuk. Aduk hingga mendidih. Koreksi rasa. Angkat ayamnya (bisa digoreng dulu atau tidak) lalu suwir2."
- "Tata dimangkok, nasi, taoge, soun, ayam suwir, irisan daun bawang dan bawang putih goreng, lalu siramkan dengan kuahnya. Sajikan bersama sambal cabe dan perasan air jeruk nipis serta kecap manis. Nikmati bersama kerupuk dan es teh manis hhmmm syegeer,,, 😋👍"
categories:
- Resep
tags:
- soto
- ayam
- khas

katakunci: soto ayam khas 
nutrition: 293 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT53M"
recipeyield: "3"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Soto Ayam Khas Semarang](https://img-global.cpcdn.com/recipes/d008cffee09c5e9c/682x484cq65/soto-ayam-khas-semarang-foto-resep-utama.webp)

3 langkah mudah memasak  Soto Ayam Khas Semarang cocok sekali jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Dalam Pembuatan Soto Ayam Khas Semarang:

1. ayam kampung lebih enak 500 gr
1. kerang dara  cangkang 500 gr
1. Air secukupnya
1. daun salam 2 lembar
1. daun jeruk 3 lembar
1. serai geprek 1 batang
1. jahe geprek 1 ruas
1. Bumbu halus  
1. bawang merah 5 siung
1. bawang putih 3 siung
1. kemiri 3 butir
1. ketumbar 1 sdt
1. lada butiran 1/4 sdt
1. jinten 1/4 sdt
1. kunyit 1 cm
1. Garam gula jawa dan kaldu bubuk sesuai selera
1. Bahan pelengkap  
1. Nasi 
1. Bawang putih goreng 
1. Daun bawang iris
1. Taoge siram air panas 
1. Soun rendam air panas 
1. Sambal cabe 
1. Kecap manis 
1. Jeruk nipis 



<!--inarticleads2-->

## Tata Cara Membuat Soto Ayam Khas Semarang:

1. Rebus kerang dara, kerangnya wajib yg masih ada kulitnya ya, ambil kaldunya. Sisihkan. Rebus ayam sampai berminyak. Sambil menunggu kita siapkan bumbu2. Ulek/ blender bumbu sampai halus
1. Tumis bumbu halus bersama daun salam, daun jeruk, jahe dan lengkuas sampai harum. Lalu masukkan kedalam rebusan ayam. Tambahkan kaldu kerang, garam, gula jawa dan kaldu bubuk. Aduk hingga mendidih. Koreksi rasa. Angkat ayamnya (bisa digoreng dulu atau tidak) lalu suwir2.
1. Tata dimangkok, nasi, taoge, soun, ayam suwir, irisan daun bawang dan bawang putih goreng, lalu siramkan dengan kuahnya. Sajikan bersama sambal cabe dan perasan air jeruk nipis serta kecap manis. Nikmati bersama kerupuk dan es teh manis hhmmm syegeer,,, 😋👍




Selamat memasak dan menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
