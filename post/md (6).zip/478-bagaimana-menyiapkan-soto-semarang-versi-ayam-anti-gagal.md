---
description: "Bagaimana Menyiapkan Soto Semarang versi Ayam Anti Gagal"
title: "Bagaimana Menyiapkan Soto Semarang versi Ayam Anti Gagal"
slug: 478-bagaimana-menyiapkan-soto-semarang-versi-ayam-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2022-01-05T00:08:03.912Z 
thumbnail: https://img-global.cpcdn.com/recipes/ec19556adfeb2f29/682x484cq65/soto-semarang-versi-ayam-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/ec19556adfeb2f29/682x484cq65/soto-semarang-versi-ayam-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/ec19556adfeb2f29/682x484cq65/soto-semarang-versi-ayam-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/ec19556adfeb2f29/682x484cq65/soto-semarang-versi-ayam-foto-resep-utama.webp
author: Eva Wilkins
ratingvalue: 3.1
reviewcount: 11
recipeingredient:
- "Ayam potong2 1 kg"
- "ceker ayam 20"
- "Air 1.2 liter"
- "Salam 3"
- "Sereh geprek 2"
- "Daun jeruk 4"
- "Garam gula pasir lada bubuk kaldu ayam bubuk Secukupnya"
- "kunyit bubuk Secukupnya"
- "Daun bawang disimpulkan 1 batang"
- "Bahan yg dihaluskan  "
- "Bawang putih di goreng 5"
- "Bawang merah di goreng 7"
- "Kemiri di goreng 4"
- "Pelengkap  "
- "Nasi putih "
- "Soun "
- "Toge "
- "Kol "
- "Bawang putih goreng "
- "Jeruk nipis "
- "Daun bawang iris2 "
- "Seledri iris"
- "Kecap manis "
- "Sambal soto           lihat resep "
- "Tempe goreng "
- "Tahu goreng "
recipeinstructions:
- "Ayam dipotong2 lalu rebus brsama ceker ayam, air rebusan pertama dibuang. Lalu rebus dgn air yg baru masukan salam, sereh,daun jeruk"
- "Tumis bahan yg telah digoreng dan dihaluskan sampai harum lalu masukan bahan tumisan kedalam air rebusan ayam tambahkan daun bawang, garam, lada bubuk, gula pasir dan kaldu bubuk,kunyit bubuk aduk2"
- "Persiapkan bahan pelengkapnya. Soun,toge dan kol rebus sebentar atau rendam air panas lalu tiriskan."
- "Penyajiannya : dalam mangkok saji masukan nasi, soun, kol, toge, lalu siram air kuah ayam lalu beri daun bawang, seledri, taburan bawang putih goreng. Ayam ada yg disuwir2 ada jg yg utuh yg disajikan di mangkok beri kecap manis"
- "Sajikan.. dgn kucuran jeruk nipis dan sambal rawit.. juga tempe dan tahu goreng"
categories:
- Resep
tags:
- soto
- semarang
- versi

katakunci: soto semarang versi 
nutrition: 228 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT58M"
recipeyield: "3"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Soto Semarang versi Ayam](https://img-global.cpcdn.com/recipes/ec19556adfeb2f29/682x484cq65/soto-semarang-versi-ayam-foto-resep-utama.webp)

5 langkah cepat dan mudah mengolah  Soto Semarang versi Ayam cocok banget jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Untuk Pembuatan Soto Semarang versi Ayam:

1. Ayam potong2 1 kg
1. ceker ayam 20
1. Air 1.2 liter
1. Salam 3
1. Sereh geprek 2
1. Daun jeruk 4
1. Garam gula pasir lada bubuk kaldu ayam bubuk Secukupnya
1. kunyit bubuk Secukupnya
1. Daun bawang disimpulkan 1 batang
1. Bahan yg dihaluskan  
1. Bawang putih di goreng 5
1. Bawang merah di goreng 7
1. Kemiri di goreng 4
1. Pelengkap  
1. Nasi putih 
1. Soun 
1. Toge 
1. Kol 
1. Bawang putih goreng 
1. Jeruk nipis 
1. Daun bawang iris2 
1. Seledri iris
1. Kecap manis 
1. Sambal soto           lihat resep 
1. Tempe goreng 
1. Tahu goreng 



<!--inarticleads2-->

## Cara Mudah Membuat Soto Semarang versi Ayam:

1. Ayam dipotong2 lalu rebus brsama ceker ayam, air rebusan pertama dibuang. Lalu rebus dgn air yg baru masukan salam, sereh,daun jeruk
1. Tumis bahan yg telah digoreng dan dihaluskan sampai harum lalu masukan bahan tumisan kedalam air rebusan ayam tambahkan daun bawang, garam, lada bubuk, gula pasir dan kaldu bubuk,kunyit bubuk aduk2
1. Persiapkan bahan pelengkapnya. Soun,toge dan kol rebus sebentar atau rendam air panas lalu tiriskan.
1. Penyajiannya : dalam mangkok saji masukan nasi, soun, kol, toge, lalu siram air kuah ayam lalu beri daun bawang, seledri, taburan bawang putih goreng. Ayam ada yg disuwir2 ada jg yg utuh yg disajikan di mangkok beri kecap manis
1. Sajikan.. dgn kucuran jeruk nipis dan sambal rawit.. juga tempe dan tahu goreng




Salah satu masakan yang cukup praktis dalam pembuatannya adalah  Soto Semarang versi Ayam. Selain itu  Soto Semarang versi Ayam  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu lakukan 5 langkah, dan  Soto Semarang versi Ayam  pun siap di hidangkan. selamat mencoba !
