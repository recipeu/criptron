---
description: "Resep Nasi Uduk Betawi Anti Gagal"
title: "Resep Nasi Uduk Betawi Anti Gagal"
slug: 36-resep-nasi-uduk-betawi-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-08T19:53:58.730Z 
thumbnail: https://img-global.cpcdn.com/recipes/099178e5eb94b4b3/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/099178e5eb94b4b3/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/099178e5eb94b4b3/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/099178e5eb94b4b3/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
author: Alberta McLaughlin
ratingvalue: 5
reviewcount: 4
recipeingredient:
- "beras 4 cup"
- "santan sedang saya ganti 2 sachet kara 800 ml"
- "Air "
- "Bumbu "
- "serai memarkan 6 batang"
- "daun salam 4 lembar"
- "lengkuas memarkan 1 ruas"
- "kayu manis 1 batang"
- "daun pandan 2 lbr"
- "bawang merah parut 5 siung"
- "jahe parut 1 ruas"
- "garam Secukupnya"
recipeinstructions:
- "Cuci bersih beras"
- "Masukkan santan dan semua bumbu ke dalam panci, masukkan beras, beri air seperti masak nasi seperti biasa. Masak hingga menjadi aron. Lalu kukus selama 30 menit"
- "Setelah matang, angkat dan aduk-aduk sambil dikipasi biar tidak menggumpal. Hmm... aromanya wangiii...."
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 142 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT52M"
recipeyield: "4"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Betawi](https://img-global.cpcdn.com/recipes/099178e5eb94b4b3/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp)

3 langkah mudah memasak  Nasi Uduk Betawi yang wajib ibu coba dirumah

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Dalam Pembuatan Nasi Uduk Betawi:

1. beras 4 cup
1. santan sedang saya ganti 2 sachet kara 800 ml
1. Air 
1. Bumbu 
1. serai memarkan 6 batang
1. daun salam 4 lembar
1. lengkuas memarkan 1 ruas
1. kayu manis 1 batang
1. daun pandan 2 lbr
1. bawang merah parut 5 siung
1. jahe parut 1 ruas
1. garam Secukupnya



<!--inarticleads2-->

## Cara Menyiapkan Nasi Uduk Betawi:

1. Cuci bersih beras
1. Masukkan santan dan semua bumbu ke dalam panci, masukkan beras, beri air seperti masak nasi seperti biasa. Masak hingga menjadi aron. Lalu kukus selama 30 menit
1. Setelah matang, angkat dan aduk-aduk sambil dikipasi biar tidak menggumpal. Hmm... aromanya wangiii....




Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
