---
description: "Resep Nasi ayam hainan, Enak"
title: "Resep Nasi ayam hainan, Enak"
slug: 455-resep-nasi-ayam-hainan-enak
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-04T06:18:32.789Z 
thumbnail: https://img-global.cpcdn.com/recipes/3577a6b7c4bf46ea/682x484cq65/nasi-ayam-hainan-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/3577a6b7c4bf46ea/682x484cq65/nasi-ayam-hainan-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/3577a6b7c4bf46ea/682x484cq65/nasi-ayam-hainan-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/3577a6b7c4bf46ea/682x484cq65/nasi-ayam-hainan-foto-resep-utama.webp
author: Seth Kelly
ratingvalue: 4.9
reviewcount: 5
recipeingredient:
- "Kuah kaldu ayam "
- "ayam kampung potong sesuai selera me 4 bagian 1 ekor"
- "bawang putih geprek 4 siung"
- "bawang merah geprek 3 siung"
- "Jahe bersihkan geprek 1 bh"
- "Secukupnya gula garam merica kaldu penyedap "
- "Secukupnya air "
- "Nasi hainan "
- "beras cuci bersih rendam air 15 min 3 cup"
- "bawang putih haluskan 3 siung"
- "bawang merah haluskan 2 siung"
- "jahe parut 1 buah"
- "kaldu ayam merk yummy house 2 sdm"
- "kecap asin 1 sdm"
- "minyak wijen 1 sdm"
- "Secukupnya minyak goreng dan lada "
recipeinstructions:
- "Rendam ayam di dalam air gula dan garam kira2 15 sampai 30 mins. Tujuannya biar ayamnya gurih."
- "Tumis bawang2 serta jahe menggunakan potongan lemak kuning ayam dan sedikit minyak hingga harum (optional y. Bisa skip lemaknya), masukan ayam, aduk hingga merata. Tambahkan air. Beri bumbu sesuai selera. Didigkan diatas api kecil minimal 1 jam. Bisa lebih lama ayam semakin empuk."
- "Sambil menunggu ayam, beras yg telah direndam tiriskan. Sisihkan dahulu."
- "Panaskan minyak (aku pakai minyak yg cukup banyak. Agar nasi enak dan tidak lengket2) masukkan bawang merah dan putih serta jahe. Goreng hingga kecokelatan  Sisihkan."
- "Pindahkan beras ke rice cooker, masukan minyak bawang serta smua bumbu. Aduk merata. Tambahkan kuah kaldu sesuai takaran memasak nasi. Aduk merata. Koreksi rasa. Masak di ricecooker seperti biasa"
- "Optional: Angkat dan tiriskan ayam didalam kuah. Kuasin kaldu ayam yummy house dan kecap asin serta minyak wijen. Air fry sekitar 15 mins. Sajikan dengan nasi hainam"
categories:
- Resep
tags:
- nasi
- ayam
- hainan

katakunci: nasi ayam hainan 
nutrition: 157 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT30M"
recipeyield: "2"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi ayam hainan](https://img-global.cpcdn.com/recipes/3577a6b7c4bf46ea/682x484cq65/nasi-ayam-hainan-foto-resep-utama.webp)

Ingin membuat Nasi ayam hainan ? Coba resep berikut ini. Cara memasaknya sangat praktis namun hasilnya gurih dan lezat cocok banget jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Untuk Menyiapkan Nasi ayam hainan:

1. Kuah kaldu ayam 
1. ayam kampung potong sesuai selera me 4 bagian 1 ekor
1. bawang putih geprek 4 siung
1. bawang merah geprek 3 siung
1. Jahe bersihkan geprek 1 bh
1. Secukupnya gula garam merica kaldu penyedap 
1. Secukupnya air 
1. Nasi hainan 
1. beras cuci bersih rendam air 15 min 3 cup
1. bawang putih haluskan 3 siung
1. bawang merah haluskan 2 siung
1. jahe parut 1 buah
1. kaldu ayam merk yummy house 2 sdm
1. kecap asin 1 sdm
1. minyak wijen 1 sdm
1. Secukupnya minyak goreng dan lada 

Jom kita layan gambar gambar dan. Hari ni msk nasi ayam lagi. Dah selalu sangat buat nasi ayam yg ayamnya digoreng je. Kali ni tukarlah selera pulak.cuba buat resepi nasi ayam hainan. 

<!--inarticleads2-->

## Cara Membuat Nasi ayam hainan:

1. Rendam ayam di dalam air gula dan garam kira2 15 sampai 30 mins. Tujuannya biar ayamnya gurih.
1. Tumis bawang2 serta jahe menggunakan potongan lemak kuning ayam dan sedikit minyak hingga harum (optional y. Bisa skip lemaknya), masukan ayam, aduk hingga merata. Tambahkan air. Beri bumbu sesuai selera. Didigkan diatas api kecil minimal 1 jam. Bisa lebih lama ayam semakin empuk.
1. Sambil menunggu ayam, beras yg telah direndam tiriskan. Sisihkan dahulu.
1. Panaskan minyak (aku pakai minyak yg cukup banyak. Agar nasi enak dan tidak lengket2) masukkan bawang merah dan putih serta jahe. Goreng hingga kecokelatan -  Sisihkan.
1. Pindahkan beras ke rice cooker, masukan minyak bawang serta smua bumbu. Aduk merata. Tambahkan kuah kaldu sesuai takaran memasak nasi. Aduk merata. Koreksi rasa. Masak di ricecooker seperti biasa
1. Optional: Angkat dan tiriskan ayam didalam kuah. Kuasin kaldu ayam yummy house dan kecap asin serta minyak wijen. Air fry sekitar 15 mins. Sajikan dengan nasi hainam


Bahan-bahan Nasi hainan terbilang populer di Singapura. Rasa nasi hainan umami tetapi ringan karena beras dimasak bersama kaldu ayam. Sebaiknya jenis beras yang digunakan tidak pulen tetapi juga tidak pera. Selamat petang, cuaca tersangat panas hari ini, alhamdulillah. Senang dan sedap serta digemari seisi keluarga. 

Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
