---
description: "Bagaimana Membuat Nasi ayam Semarang, Enak Banget"
title: "Bagaimana Membuat Nasi ayam Semarang, Enak Banget"
slug: 470-bagaimana-membuat-nasi-ayam-semarang-enak-banget
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-11T13:22:57.207Z 
thumbnail: https://img-global.cpcdn.com/recipes/e9c36fe3424dd79f/682x484cq65/nasi-ayam-semarang-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/e9c36fe3424dd79f/682x484cq65/nasi-ayam-semarang-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/e9c36fe3424dd79f/682x484cq65/nasi-ayam-semarang-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/e9c36fe3424dd79f/682x484cq65/nasi-ayam-semarang-foto-resep-utama.webp
author: Mattie Townsend
ratingvalue: 4
reviewcount: 14
recipeingredient:
- "ayam kampung sy 900 gr ayam broilerpotong2 1 ekor"
- "telur rebussy tdk pake sy pake semur telur 5 butir"
- "santan dr 2 butir kelapa secukupnya 3 liter"
- "lengkuas 2 ptg"
- "daun salam 2 lbr"
- "sereh 1 btg"
- "garam secukupnya minyak goreng utk menymis 1 sdt"
- "Bumbu halus "
- "bawang merah 10 butir"
- "siumg bawang putih 6"
- "ketumbar 1 sdt"
- "kemiri 5 butir"
- "kunyit 2 ruas"
recipeinstructions:
- "Tumis bumbu halus, lengkuas, daun salam &amp; sereh. Tuangkan santan, masukkan ayam &amp; telur rebus (jika pake)"
- "Masak hingga ayam matang &amp; bumbu meresap"
- "Angkat dan pindahkan ke panci ato wadah"
- "Bahan sayur labu siam 2 buah labu siam potong bentuk korek api taburi sedikit garam remas2 cuci bersih, 750 ml santan sedang, 1 sdt garam, 2 lbr daun salam, 2 potong lengkuas, 1 sdt gula jawa"
- "Bumbu halus: 5 bawang merah, 3 bawang putih, 8 buah cabe merah besar buang bijinya (sy pake cabe keriting), minyak utk menumis"
- "Tumis bumbu halus, lengkuas &amp; daun salam hingga harum"
- "Tuangkan santan, masukkan labu sian, garam&amp; gula jawa"
- "Masak hingga sayur matang. Angkat"
- "Cara penyajian: taruh nasi diatas piring tambahkan sayur labu siam, suwiran opor ayam, telur &amp; tahu"
- "2"
categories:
- Resep
tags:
- nasi
- ayam
- semarang

katakunci: nasi ayam semarang 
nutrition: 139 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT49M"
recipeyield: "4"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi ayam Semarang](https://img-global.cpcdn.com/recipes/e9c36fe3424dd79f/682x484cq65/nasi-ayam-semarang-foto-resep-utama.webp)

Resep Nasi ayam Semarang  enak dengan 10 langkahmudah dan cepat yang wajib bunda coba dirumah

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Dalam Menyiapkan Nasi ayam Semarang:

1. ayam kampung sy 900 gr ayam broilerpotong2 1 ekor
1. telur rebussy tdk pake sy pake semur telur 5 butir
1. santan dr 2 butir kelapa secukupnya 3 liter
1. lengkuas 2 ptg
1. daun salam 2 lbr
1. sereh 1 btg
1. garam secukupnya minyak goreng utk menymis 1 sdt
1. Bumbu halus 
1. bawang merah 10 butir
1. siumg bawang putih 6
1. ketumbar 1 sdt
1. kemiri 5 butir
1. kunyit 2 ruas

Semarang jangan lupa Baca juga Kumpulan Pin BB Artis Indonesia Terbaru. Jawa Tengah, Kota Magelang, Kota Pekalongan, Kota Salatiga, Kota Semarang, Kota Surakarta, Kota Tegal. Nasi ayam menyajikan citarasa gurih yang cukup pekat karena disiram kuah opor. Pasti rugi, deh kalau ke Semarang kalian gak icip kuliner nasi ayam ini. 

<!--inarticleads2-->

## Cara Mudah Menyiapkan Nasi ayam Semarang:

1. Tumis bumbu halus, lengkuas, daun salam &amp; sereh. Tuangkan santan, masukkan ayam &amp; telur rebus (jika pake)
1. Masak hingga ayam matang &amp; bumbu meresap
1. Angkat dan pindahkan ke panci ato wadah
1. Bahan sayur labu siam 2 buah labu siam potong bentuk korek api taburi sedikit garam remas2 cuci bersih, 750 ml santan sedang, 1 sdt garam, 2 lbr daun salam, 2 potong lengkuas, 1 sdt gula jawa
1. Bumbu halus: 5 bawang merah, 3 bawang putih, 8 buah cabe merah besar buang bijinya (sy pake cabe keriting), minyak utk menumis
1. Tumis bumbu halus, lengkuas &amp; daun salam hingga harum
1. Tuangkan santan, masukkan labu sian, garam&amp; gula jawa
1. Masak hingga sayur matang. Angkat
1. Cara penyajian: taruh nasi diatas piring tambahkan sayur labu siam, suwiran opor ayam, telur &amp; tahu
1. 2


You can choose to buy it spicy or not. The skewers were also good This is a very good Nasi Ayam, the best in Semarang. The portion of vegetables and other ingredients are. Pagi semua, Ini aku posting lagi menu Nasi Ayam Semarang ya teman-teman, walau dulu udah pernah posting, tapi ini ada beberapa pelengkap yang baru. Tapi jangan di sama-samakan, karena baik orang semarang dan orang solo, suka tidak terima jika antara nasi liwet di samakan dengan nasi ayam. 

Demikian informasi  resep Nasi ayam Semarang   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
