---
description: "Resep Nasi daun jeruk yang Bisa Manjain Lidah"
title: "Resep Nasi daun jeruk yang Bisa Manjain Lidah"
slug: 330-resep-nasi-daun-jeruk-yang-bisa-manjain-lidah
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-11T16:59:26.453Z 
thumbnail: https://img-global.cpcdn.com/recipes/6f20d9976ec6213e/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/6f20d9976ec6213e/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/6f20d9976ec6213e/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/6f20d9976ec6213e/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
author: Mable Strickland
ratingvalue: 4.6
reviewcount: 14
recipeingredient:
- "beras pulen 3 cup"
- "daun salam 3 lembar"
- "daun jeruk buang tulang iris2 tipis 7 lembar"
- "sereh geprek ikat simpul 1 buah"
- "daun pandan ikat simpul 1 lembar"
- "santan fe skip 1 gelas"
- "garam 1 sdt"
- "bawang putih cincang halus lalu digoreng kering 1 siung"
- "bawang merah iris2 goreng kering 1 sdm"
recipeinstructions:
- "Cuci beras seperti biasa, masak dengan rice cooker seperti biasa. Lalu masukkan bawang putih, garam, daun salam, daun pandan &amp; sereh yg sudah diikat simpul. Jika pakai santan sesuaikan takaran air &amp; aduk rata dulu supaya terserap sempurna. Masak nasi hingga matang."
- "Iris2 tipis daun jeruk yang sudah dibuang tulangnya. Masukkan sebagian saat masak nasi &amp; kedalam rice cooker sesaat sebelum nasi matang."
- "Wangi banget nasinya 🥰aroma rempah2 &amp; wangi daun jeruknya semerbak. Sajikan dengan taburan bawang goreng &amp; irisan daun pandan."
- "Bisa dibekal atau dimakan langsung saat hangat2 nikmat banget."
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 147 calories
recipecuisine: Indonesian
preptime: "PT20M"
cooktime: "PT49M"
recipeyield: "2"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi daun jeruk](https://img-global.cpcdn.com/recipes/6f20d9976ec6213e/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp)

Ingin membuat Nasi daun jeruk ? Coba resep berikut ini. Cara memasaknya sangat praktis namun jangan kaget jika hasilnya gurih dan lezat yang musti kamu coba segera

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Dalam Menyiapkan Nasi daun jeruk:

1. beras pulen 3 cup
1. daun salam 3 lembar
1. daun jeruk buang tulang iris2 tipis 7 lembar
1. sereh geprek ikat simpul 1 buah
1. daun pandan ikat simpul 1 lembar
1. santan fe skip 1 gelas
1. garam 1 sdt
1. bawang putih cincang halus lalu digoreng kering 1 siung
1. bawang merah iris2 goreng kering 1 sdm

Nasi daun jeruk siap dihidangkan dengan. Nasi daun jeruk ini memang sedang tren di kalangan masyarakat Indonesia, banyak sekali kaum muda mudi yang berlomba-lomba membuat makanan nasi putih spesial ini. Nasi daun jeruk ala geprek bensu rekomended buat di coba. Geprek bensu nasi daun jeruk anti mainst. 

<!--inarticleads2-->

## Tata Cara Membuat Nasi daun jeruk:

1. Cuci beras seperti biasa, masak dengan rice cooker seperti biasa. Lalu masukkan bawang putih, garam, daun salam, daun pandan &amp; sereh yg sudah diikat simpul. Jika pakai santan sesuaikan takaran air &amp; aduk rata dulu supaya terserap sempurna. Masak nasi hingga matang.
1. Iris2 tipis daun jeruk yang sudah dibuang tulangnya. Masukkan sebagian saat masak nasi &amp; kedalam rice cooker sesaat sebelum nasi matang.
1. Wangi banget nasinya 🥰aroma rempah2 &amp; wangi daun jeruknya semerbak. Sajikan dengan taburan bawang goreng &amp; irisan daun pandan.
1. Bisa dibekal atau dimakan langsung saat hangat2 nikmat banget.


Gurih dan wangi dari daun jeruk menambah kelezatan nasi daun jeruk. Nasi dengan campuran daun jeruk yang wangi sedang tren. Hai selamat pagi sahabat CWS, pagi ini saya share resep Nasi Daun Jeruk. Praktis banget karena saya gunakan rice cooker. Rasanya mirip nasi uduk tapi wangiiii. 

Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
