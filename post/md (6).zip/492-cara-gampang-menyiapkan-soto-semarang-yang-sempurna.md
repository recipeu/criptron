---
description: "Cara Gampang Menyiapkan Soto Semarang yang Sempurna"
title: "Cara Gampang Menyiapkan Soto Semarang yang Sempurna"
slug: 492-cara-gampang-menyiapkan-soto-semarang-yang-sempurna
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-06T23:13:12.491Z 
thumbnail: https://img-global.cpcdn.com/recipes/f9727407d09cce77/682x484cq65/soto-semarang-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/f9727407d09cce77/682x484cq65/soto-semarang-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/f9727407d09cce77/682x484cq65/soto-semarang-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/f9727407d09cce77/682x484cq65/soto-semarang-foto-resep-utama.webp
author: Danny Malone
ratingvalue: 3.6
reviewcount: 6
recipeingredient:
- "Bahan Kaldu "
- "Ayam 250 gram"
- "Air 1,5 liter"
- "Daun Jeruk 4 lembar"
- "Daun Salam 2 lembar"
- "Sereh geprek 1 batang"
- "Bumbu Halus "
- "Bawang Putih 4 siung"
- "Kunyit 1 ruas"
- "Jahe 1 ruas"
- "Bumbu Lain "
- "Kecap Manis 1 sdm"
- "Daun Bawang potongpotong 1 batang"
- "Bawang Putih Goreng 2 sdm"
- "Seasoning "
- "Garam 1 sdm"
- "Gula Jawa 1 sdm"
- "Ketumbar Bubuk 3/4 sdt"
- "Lada 1/2 sdt"
- "Pala Bubuk 1/4 sdt"
- "Kaldu Jamur 1/4 sdt"
- "Sambal "
- "Cabe Rawit rebus 5 buah"
- "Bawang Putih rebus 1 siung"
- "Pelengkap "
- "Nasi Putih "
- "Soun seduh air panas "
- "Taoge Pendek seduh air panas "
- "Kubis iris tipis "
- "Jeruk Nipis "
- "Tempe Goreng Garit           lihat resep "
recipeinstructions:
- "Rebus ayam bersama bumbu aromatik, hingga mendidih, ayam matang dan empuk."
- "Tumis bumbu halus hingga harum.  Tambahkan kecap manis, tumis kembali hingga bumbu matang. Angkat."
- "Tuang bumbu halus ke dalam air rebusan ayam, aduk rata.  Beri seasoning, aduk rata. Masak hingga mendidih, tes rasa. Jika sudah pas, angkat ayam untuk disuwir.  Terakhir, masukkan potongan daun bawang dan bawang putih goreng. Masak sebentar saja, angkat."
- "Siapkan bahan pelengkap.  Uleg bahan sambal."
- "Siapkan mangkuk saji, tata nasi putih, bihun, kubis, taoge, dan suwiran ayam. Tuang kuah soto."
- "Soto Semarang siap disajikan dengan sambal, jeruk nipis, dan tempe goreng garit ♥️♥️."
categories:
- Resep
tags:
- soto
- semarang

katakunci: soto semarang 
nutrition: 251 calories
recipecuisine: Indonesian
preptime: "PT16M"
cooktime: "PT54M"
recipeyield: "4"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Soto Semarang](https://img-global.cpcdn.com/recipes/f9727407d09cce77/682x484cq65/soto-semarang-foto-resep-utama.webp)

6 langkah mudah membuat  Soto Semarang cocok banget jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Dalam Pembuatan Soto Semarang:

1. Bahan Kaldu 
1. Ayam 250 gram
1. Air 1,5 liter
1. Daun Jeruk 4 lembar
1. Daun Salam 2 lembar
1. Sereh geprek 1 batang
1. Bumbu Halus 
1. Bawang Putih 4 siung
1. Kunyit 1 ruas
1. Jahe 1 ruas
1. Bumbu Lain 
1. Kecap Manis 1 sdm
1. Daun Bawang potongpotong 1 batang
1. Bawang Putih Goreng 2 sdm
1. Seasoning 
1. Garam 1 sdm
1. Gula Jawa 1 sdm
1. Ketumbar Bubuk 3/4 sdt
1. Lada 1/2 sdt
1. Pala Bubuk 1/4 sdt
1. Kaldu Jamur 1/4 sdt
1. Sambal 
1. Cabe Rawit rebus 5 buah
1. Bawang Putih rebus 1 siung
1. Pelengkap 
1. Nasi Putih 
1. Soun seduh air panas 
1. Taoge Pendek seduh air panas 
1. Kubis iris tipis 
1. Jeruk Nipis 
1. Tempe Goreng Garit           lihat resep 



<!--inarticleads2-->

## Tata Cara Membuat Soto Semarang:

1. Rebus ayam bersama bumbu aromatik, hingga mendidih, ayam matang dan empuk.
1. Tumis bumbu halus hingga harum. -  - Tambahkan kecap manis, tumis kembali hingga bumbu matang. Angkat.
1. Tuang bumbu halus ke dalam air rebusan ayam, aduk rata. -  - Beri seasoning, aduk rata. Masak hingga mendidih, tes rasa. Jika sudah pas, angkat ayam untuk disuwir. -  - Terakhir, masukkan potongan daun bawang dan bawang putih goreng. Masak sebentar saja, angkat.
1. Siapkan bahan pelengkap. -  - Uleg bahan sambal.
1. Siapkan mangkuk saji, tata nasi putih, bihun, kubis, taoge, dan suwiran ayam. Tuang kuah soto.
1. Soto Semarang siap disajikan dengan sambal, jeruk nipis, dan tempe goreng garit ♥️♥️.




Demikian informasi  resep Soto Semarang   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
