---
description: "Langkah Mudah untuk Menyiapkan Nasi Bakar Ikan Tuna Mudah, Enak Banget"
title: "Langkah Mudah untuk Menyiapkan Nasi Bakar Ikan Tuna Mudah, Enak Banget"
slug: 356-langkah-mudah-untuk-menyiapkan-nasi-bakar-ikan-tuna-mudah-enak-banget
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-31T01:32:11.750Z 
thumbnail: https://img-global.cpcdn.com/recipes/c023560dc1691b8a/682x484cq65/nasi-bakar-ikan-tuna-mudah-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/c023560dc1691b8a/682x484cq65/nasi-bakar-ikan-tuna-mudah-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/c023560dc1691b8a/682x484cq65/nasi-bakar-ikan-tuna-mudah-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/c023560dc1691b8a/682x484cq65/nasi-bakar-ikan-tuna-mudah-foto-resep-utama.webp
author: Harriett Warren
ratingvalue: 3.8
reviewcount: 4
recipeingredient:
- "Nasi saat masak beri daun salam dan sere agar harum "
- "Daging ikan tuna "
- "Daun salam "
- "Daun kemangi "
- "Sere "
- "Lengkuas digeprek "
- "Gula Garam merica bubuk "
- "Daun pisang untuk membungkus "
- "Bumbu halus "
- "Bawang merah bawang putih "
- "Cabe merah cabe rawit "
- "Gula merah kemiri "
recipeinstructions:
- "Tumis bumbu halus, daun salam, lengkuas dan sere."
- "Jika sudah harum masukan ikan, garam, gula dan merica bubuk. Tambhakan penyedap rasa jika suka. Masak hingga ikan matang jgn terlalu lama."
- "Bersihkan daun pisang panaskan di atas kompor agar daun tidak kaku atau dijemur sebentar."
- "Jika daun sudah tidak kaku taruh sedikit nasi diatasnya kemudian beri ikan yg sudah dimasak td beserta kemangi dan tutup daun pisan dengan lidi. Seperti membuat lontong."
- "Bakar diatas kompor, arang atau tempat bakar dr batu lamanya pembakaran tergantung selera sebentar pun tidak masalah karena bahan2 sudah matang semua. Oke selamat mencoba."
categories:
- Resep
tags:
- nasi
- bakar
- ikan

katakunci: nasi bakar ikan 
nutrition: 228 calories
recipecuisine: Indonesian
preptime: "PT29M"
cooktime: "PT37M"
recipeyield: "1"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Bakar Ikan Tuna Mudah](https://img-global.cpcdn.com/recipes/c023560dc1691b8a/682x484cq65/nasi-bakar-ikan-tuna-mudah-foto-resep-utama.webp)

5 langkah cepat memasak  Nasi Bakar Ikan Tuna Mudah cocok banget jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Dalam Menyiapkan Nasi Bakar Ikan Tuna Mudah:

1. Nasi saat masak beri daun salam dan sere agar harum 
1. Daging ikan tuna 
1. Daun salam 
1. Daun kemangi 
1. Sere 
1. Lengkuas digeprek 
1. Gula Garam merica bubuk 
1. Daun pisang untuk membungkus 
1. Bumbu halus 
1. Bawang merah bawang putih 
1. Cabe merah cabe rawit 
1. Gula merah kemiri 



<!--inarticleads2-->

## Langkah-langkah Untuk Membuat Nasi Bakar Ikan Tuna Mudah:

1. Tumis bumbu halus, daun salam, lengkuas dan sere.
1. Jika sudah harum masukan ikan, garam, gula dan merica bubuk. Tambhakan penyedap rasa jika suka. Masak hingga ikan matang jgn terlalu lama.
1. Bersihkan daun pisang panaskan di atas kompor agar daun tidak kaku atau dijemur sebentar.
1. Jika daun sudah tidak kaku taruh sedikit nasi diatasnya kemudian beri ikan yg sudah dimasak td beserta kemangi dan tutup daun pisan dengan lidi. Seperti membuat lontong.
1. Bakar diatas kompor, arang atau tempat bakar dr batu lamanya pembakaran tergantung selera sebentar pun tidak masalah karena bahan2 sudah matang semua. Oke selamat mencoba.




Terima kasih telah membaca resep yang kami tampilkan di sini. Semoga bermanfaat dan selamat mencoba!
