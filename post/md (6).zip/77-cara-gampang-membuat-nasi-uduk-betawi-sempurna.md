---
description: "Cara Gampang Membuat Nasi uduk betawi, Sempurna"
title: "Cara Gampang Membuat Nasi uduk betawi, Sempurna"
slug: 77-cara-gampang-membuat-nasi-uduk-betawi-sempurna
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-13T18:09:24.575Z 
thumbnail: https://img-global.cpcdn.com/recipes/8e2c44d57ec57007/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/8e2c44d57ec57007/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/8e2c44d57ec57007/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/8e2c44d57ec57007/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
author: Mable Sparks
ratingvalue: 3.9
reviewcount: 11
recipeingredient:
- "beras 4 cup"
- "sereh digeprek 3 batang"
- "daun salam 5 lembar"
- "lengkuas digeprek 10 ruas"
- "jahe digeprek 10 ruas"
- "garam 3 sdt"
- "sasa santan siap pakai 2 bks"
- "Minyak bawang  "
- "bawang merah 4 siung"
- "Minyak untuk menggoreng "
- "Pelengkap  "
- "Semur telor dan kentang "
- "Kering tempe "
- "Emping goreng "
- "Bawang goreng "
recipeinstructions:
- "Cuci bersih beras. Masukkan dalam panci magic com. Beri air sesuai memasak nasi."
- "Masukkan daun salam, sereh, lengkuas, jahe, dan sasa santan siap pakai. (Aku pakai yang bubuk 1 dan yang cair 1, ngabisin stok)."
- "Tambahkan garam lalu aduk rata. Test rasa. Masukkan dalam magic com. Lalu tekan tombol cook. Masak hingga tombol berubah jadi warm. (Ini untuk mengaron nasi uduk. Pakai magic com aja jadi gak perlu aduk aduk atau takut aron gosong.)"
- "Panaskan kukusan, lalu kukus aron nasi uduk tadi selama 40 menit hingga matang dan tanak."
- "Panaskan minyak, lalu goreng irisan bawang merah hingga matang. Angkat bawangnya dan ambil minyaknya. Taruh nasi ke dalam panci magic com lagi lalu masukkan minyak sedikit demi sedikit sambil diaduk rata. Masukkan lagi ke magic com agar hangat."
- "Siap disajikan dengan semur telor dan kentang, kering tempe, emping dan bawang goreng."
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 237 calories
recipecuisine: Indonesian
preptime: "PT26M"
cooktime: "PT40M"
recipeyield: "2"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi uduk betawi](https://img-global.cpcdn.com/recipes/8e2c44d57ec57007/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp)

6 langkah cepat dan mudah mengolah  Nasi uduk betawi yang bisa bunda coba segera

<!--inarticleads1-->

## Bahan-bahan Yang Dibutuhkan Untuk Menyiapkan Nasi uduk betawi:

1. beras 4 cup
1. sereh digeprek 3 batang
1. daun salam 5 lembar
1. lengkuas digeprek 10 ruas
1. jahe digeprek 10 ruas
1. garam 3 sdt
1. sasa santan siap pakai 2 bks
1. Minyak bawang  
1. bawang merah 4 siung
1. Minyak untuk menggoreng 
1. Pelengkap  
1. Semur telor dan kentang 
1. Kering tempe 
1. Emping goreng 
1. Bawang goreng 

Menu siap saji, tinggal goreng dan siap disantap dengan. There are no reviews for Nasi Uduk Betawi Bang Acim, Indonesia yet. Be the first to write a review! Cara membuat nasi uduk betawi bisa dibikin mudah, cukup gunakan magic com. 

<!--inarticleads2-->

## Cara Mudah Membuat Nasi uduk betawi:

1. Cuci bersih beras. Masukkan dalam panci magic com. Beri air sesuai memasak nasi.
1. Masukkan daun salam, sereh, lengkuas, jahe, dan sasa santan siap pakai. (Aku pakai yang bubuk 1 dan yang cair 1, ngabisin stok).
1. Tambahkan garam lalu aduk rata. Test rasa. Masukkan dalam magic com. Lalu tekan tombol cook. Masak hingga tombol berubah jadi warm. (Ini untuk mengaron nasi uduk. Pakai magic com aja jadi gak perlu aduk aduk atau takut aron gosong.)
1. Panaskan kukusan, lalu kukus aron nasi uduk tadi selama 40 menit hingga matang dan tanak.
1. Panaskan minyak, lalu goreng irisan bawang merah hingga matang. Angkat bawangnya dan ambil minyaknya. Taruh nasi ke dalam panci magic com lagi lalu masukkan minyak sedikit demi sedikit sambil diaduk rata. Masukkan lagi ke magic com agar hangat.
1. Siap disajikan dengan semur telor dan kentang, kering tempe, emping dan bawang goreng.


Berikut resep nasi uduk betawi sederhana yang bisa untuk dijual. Resep Nasi Uduk Betawi - Makanan khas Betawi ini cocok sekali dijadikan menu sarapan. Uhh, sajian nasi uduk betawi ini akan semakin lezat dan komplit. Baca Juga : Resep Mie Aceh Tumis. Nasi uduk Betawi memiliki kekhasannya sendiri dan sudah memiliki citra tersendiri. 

Selamat memasak dan menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
