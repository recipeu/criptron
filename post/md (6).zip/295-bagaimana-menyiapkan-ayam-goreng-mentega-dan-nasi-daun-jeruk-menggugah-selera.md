---
description: "Bagaimana Menyiapkan Ayam Goreng Mentega dan Nasi Daun Jeruk, Menggugah Selera"
title: "Bagaimana Menyiapkan Ayam Goreng Mentega dan Nasi Daun Jeruk, Menggugah Selera"
slug: 295-bagaimana-menyiapkan-ayam-goreng-mentega-dan-nasi-daun-jeruk-menggugah-selera
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-16T22:10:06.958Z 
thumbnail: https://img-global.cpcdn.com/recipes/e82a943c34534bd0/682x484cq65/ayam-goreng-mentega-dan-nasi-daun-jeruk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/e82a943c34534bd0/682x484cq65/ayam-goreng-mentega-dan-nasi-daun-jeruk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/e82a943c34534bd0/682x484cq65/ayam-goreng-mentega-dan-nasi-daun-jeruk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/e82a943c34534bd0/682x484cq65/ayam-goreng-mentega-dan-nasi-daun-jeruk-foto-resep-utama.webp
author: Addie Todd
ratingvalue: 4.1
reviewcount: 9
recipeingredient:
- "paha ayam bagi 2 1 potong"
- "Lada hitam "
- "Merica bubuk "
- "Garam secukupnya"
- "Gula pasir secukupnya"
- "Saus tiram secukupnya"
- "Kecap Inggris secukupnya"
- "bawang putih cincang halus 1 siung"
- "jahe cincang halus 1/2 ruas"
- "bawang Bombay potong memanjang 1/2 buah"
- "Daun bawang iris serong "
- "mentega 1 sdm"
- "kecap manis 1 sdm"
- "kecap Inggris 1 sdm"
- "Perasan jeruk limau "
- "Minyak untuk menggoreng ayam secukupnya"
- "Garam gula secukupnya"
- "Nasi Daun Jeruk "
- "Beras secukupnya"
- "Garam secukupnya"
- "Daun jeruk "
- "Daun pandan salam lengkuas "
- "bawang merah dan 2 siung bawang putih 2 siung"
- "Santan dari 12 butir kelapa parut 300 ml"
- "Minyak goreng secukupnya untuk menumis "
- "Hias dengan daun selada tomat dan timun segar "
recipeinstructions:
- "Marinasi ayam dengan garam, gula pasir, saus tiram, kecap manis, kecap Inggris, lada hitam dan lada putih. Diamkan selama 10 menit."
- "Panaskan minyak, goreng dalam minyak hingga berkulit golden brown."
- "Ambil sedikit minyak bekas goreng ayam. Tumis bawang putih, bawang Bombay dan jahe. Tambahkan kecap Inggris, kecap manis, garam, lada bubuk dan lada hitam, gula pasir. Tambahkan ayam goreng. Masak sampai meresap dan matang."
- "Ketika sudah sampai di akhir. Tambahkan mentega dan perasan jeruk limau. Aduk rata."
- "Tambahkan irisan daun bawang. Sajikan."
- "Nasi daun jeruk: Cuci beras, sisihkan. Tumis bawang putih, bawang merah hingga harum, tambahkan daun jeruk, daun pandan, sereh dan lengkuas. Matikan api."
- "Tuang santan ke dalam beras (magic com) dan tumisan bumbu. Tambahkan garam secukupnya. Masak seperti masak nasi biasa."
- "Tata nasi daun jeruk, ayam goreng mentega. Hias dengan selada, timun dan tomat.Tambahkan sambal bawang secukupnya. Jika suka pedas."
categories:
- Resep
tags:
- ayam
- goreng
- mentega

katakunci: ayam goreng mentega 
nutrition: 243 calories
recipecuisine: Indonesian
preptime: "PT13M"
cooktime: "PT36M"
recipeyield: "4"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Ayam Goreng Mentega dan Nasi Daun Jeruk](https://img-global.cpcdn.com/recipes/e82a943c34534bd0/682x484cq65/ayam-goreng-mentega-dan-nasi-daun-jeruk-foto-resep-utama.webp)

Resep rahasia Ayam Goreng Mentega dan Nasi Daun Jeruk  anti gagal dengan 8 langkahcepat dan mudah cocok sekali jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Dibutuhkan Dalam Pembuatan Ayam Goreng Mentega dan Nasi Daun Jeruk:

1. paha ayam bagi 2 1 potong
1. Lada hitam 
1. Merica bubuk 
1. Garam secukupnya
1. Gula pasir secukupnya
1. Saus tiram secukupnya
1. Kecap Inggris secukupnya
1. bawang putih cincang halus 1 siung
1. jahe cincang halus 1/2 ruas
1. bawang Bombay potong memanjang 1/2 buah
1. Daun bawang iris serong 
1. mentega 1 sdm
1. kecap manis 1 sdm
1. kecap Inggris 1 sdm
1. Perasan jeruk limau 
1. Minyak untuk menggoreng ayam secukupnya
1. Garam gula secukupnya
1. Nasi Daun Jeruk 
1. Beras secukupnya
1. Garam secukupnya
1. Daun jeruk 
1. Daun pandan salam lengkuas 
1. bawang merah dan 2 siung bawang putih 2 siung
1. Santan dari 12 butir kelapa parut 300 ml
1. Minyak goreng secukupnya untuk menumis 
1. Hias dengan daun selada tomat dan timun segar 



<!--inarticleads2-->

## Cara Mudah Membuat Ayam Goreng Mentega dan Nasi Daun Jeruk:

1. Marinasi ayam dengan garam, gula pasir, saus tiram, kecap manis, kecap Inggris, lada hitam dan lada putih. Diamkan selama 10 menit.
1. Panaskan minyak, goreng dalam minyak hingga berkulit golden brown.
1. Ambil sedikit minyak bekas goreng ayam. Tumis bawang putih, bawang Bombay dan jahe. Tambahkan kecap Inggris, kecap manis, garam, lada bubuk dan lada hitam, gula pasir. Tambahkan ayam goreng. Masak sampai meresap dan matang.
1. Ketika sudah sampai di akhir. Tambahkan mentega dan perasan jeruk limau. Aduk rata.
1. Tambahkan irisan daun bawang. Sajikan.
1. Nasi daun jeruk: Cuci beras, sisihkan. Tumis bawang putih, bawang merah hingga harum, tambahkan daun jeruk, daun pandan, sereh dan lengkuas. Matikan api.
1. Tuang santan ke dalam beras (magic com) dan tumisan bumbu. Tambahkan garam secukupnya. Masak seperti masak nasi biasa.
1. Tata nasi daun jeruk, ayam goreng mentega. Hias dengan selada, timun dan tomat.Tambahkan sambal bawang secukupnya. Jika suka pedas.




Terima kasih telah menggunakan resep yang tim kami tampilkan di sini. Semoga bermanfaat dan selamat mencoba!
