---
description: "Resep Nasi Uduk Betawi &amp;amp; Sambel Kacang Anti Gagal"
title: "Resep Nasi Uduk Betawi &amp;amp; Sambel Kacang Anti Gagal"
slug: 123-resep-nasi-uduk-betawi-and-amp-sambel-kacang-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-29T23:08:43.095Z 
thumbnail: https://img-global.cpcdn.com/recipes/64e2470972ebc4fc/682x484cq65/nasi-uduk-betawi-sambel-kacang-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/64e2470972ebc4fc/682x484cq65/nasi-uduk-betawi-sambel-kacang-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/64e2470972ebc4fc/682x484cq65/nasi-uduk-betawi-sambel-kacang-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/64e2470972ebc4fc/682x484cq65/nasi-uduk-betawi-sambel-kacang-foto-resep-utama.webp
author: Bernice Kim
ratingvalue: 4
reviewcount: 7
recipeingredient:
- "beras 4 cup"
- "santan 1/2 liter"
- "kayu manis 2 btg"
- "cengkeh 6 bh"
- "lengkuas memarkan 2 ruas"
- "daun salam 4 lmb"
- "serai bag putihny aja memarkan 2 btg"
- "daun pandan 2 lmbar"
- "garam secukupnya"
- "Bahan sambel kacang  "
- "kacang 1/2 ons"
- "bawang putih 3 siung"
- "cabe rawit 10 bh"
- "air jerik nipis 1 sdt"
- "garam dan gula secukupnya"
recipeinstructions:
- "Cuci beras sampai bersih lalu rendam dgn air kurleb 10 menit"
- "Masak santan dengan semua bahan2 sampai mendidih. Diamkan sampai jd hangat."
- "Buang air rendaman beras lalu masukkan kedalam magic com bersama santan yg sudah hangat beserta rempah2nya. Lalu masak sperti masak nasi biasa, tp harus sering2 diaduk biar masakny rata."
- "Sambal kacang : goreng kacang bersama bawang putih smpai kacang matang, sisihkan. Goreng cabe rawit sebentar, sishkan. Uleg cabe, bawang putih, dan cabe rawit smpai halus. Tambahkan garam, gula secukupny. Waktu menyajikan tambahkan air hangat secukupny (sekentalnya saja) dan air jeruk nipis."
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 100 calories
recipecuisine: Indonesian
preptime: "PT11M"
cooktime: "PT47M"
recipeyield: "2"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Betawi &amp; Sambel Kacang](https://img-global.cpcdn.com/recipes/64e2470972ebc4fc/682x484cq65/nasi-uduk-betawi-sambel-kacang-foto-resep-utama.webp)

Resep rahasia dan cara mengolah  Nasi Uduk Betawi &amp; Sambel Kacang cocok sekali jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Untuk Menyiapkan Nasi Uduk Betawi &amp; Sambel Kacang:

1. beras 4 cup
1. santan 1/2 liter
1. kayu manis 2 btg
1. cengkeh 6 bh
1. lengkuas memarkan 2 ruas
1. daun salam 4 lmb
1. serai bag putihny aja memarkan 2 btg
1. daun pandan 2 lmbar
1. garam secukupnya
1. Bahan sambel kacang  
1. kacang 1/2 ons
1. bawang putih 3 siung
1. cabe rawit 10 bh
1. air jerik nipis 1 sdt
1. garam dan gula secukupnya



<!--inarticleads2-->

## Tata Cara Membuat Nasi Uduk Betawi &amp; Sambel Kacang:

1. Cuci beras sampai bersih lalu rendam dgn air kurleb 10 menit
1. Masak santan dengan semua bahan2 sampai mendidih. Diamkan sampai jd hangat.
1. Buang air rendaman beras lalu masukkan kedalam magic com bersama santan yg sudah hangat beserta rempah2nya. Lalu masak sperti masak nasi biasa, tp harus sering2 diaduk biar masakny rata.
1. Sambal kacang : goreng kacang bersama bawang putih smpai kacang matang, sisihkan. Goreng cabe rawit sebentar, sishkan. Uleg cabe, bawang putih, dan cabe rawit smpai halus. Tambahkan garam, gula secukupny. Waktu menyajikan tambahkan air hangat secukupny (sekentalnya saja) dan air jeruk nipis.




Terima kasih telah membaca resep yang tim kami tampilkan di halaman ini. Semoga bermanfaat dan selamat mencoba!
