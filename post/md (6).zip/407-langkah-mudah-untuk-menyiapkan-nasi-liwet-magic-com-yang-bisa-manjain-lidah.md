---
description: "Langkah Mudah untuk Menyiapkan Nasi Liwet Magic Com yang Bisa Manjain Lidah"
title: "Langkah Mudah untuk Menyiapkan Nasi Liwet Magic Com yang Bisa Manjain Lidah"
slug: 407-langkah-mudah-untuk-menyiapkan-nasi-liwet-magic-com-yang-bisa-manjain-lidah
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-31T09:25:45.838Z 
thumbnail: https://img-global.cpcdn.com/recipes/1d51b803b2419661/682x484cq65/nasi-liwet-magic-com-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/1d51b803b2419661/682x484cq65/nasi-liwet-magic-com-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/1d51b803b2419661/682x484cq65/nasi-liwet-magic-com-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/1d51b803b2419661/682x484cq65/nasi-liwet-magic-com-foto-resep-utama.webp
author: Eula Miller
ratingvalue: 4.2
reviewcount: 5
recipeingredient:
- "beras 4 cup 600 gr"
- "air sesuaikan dengan takaran air memasak nasi masing 950 ml"
- "teri 50 gr"
- "bawang merah iris 8 butir"
- "bawang putih iris 3 siung"
- "cabe merah keriting iris 4 buah"
- "daun salam 4 lembar"
- "sereh geprek 2 batang"
- "lengkuas geprek 1 cm"
- "garam 2 sdt"
- "gula pasir 1/2 sdt"
- "lada bubuk 1/6 sdt"
- "minyak goreng "
recipeinstructions:
- "Goreng ikan teri sampai kering dengan api sedang cenderung kecil, tiriskan minyak. Simpan minyak sisa goreng ikan teri."
- "Tumis bawang putih dan bawang merah menggunakan minyak sisa menggoreng ikan teri agar semakin gurih. Masukkan cabe merah iris, daun salam, sereh, dan lengkuas. Ketika sudah cukup empuk dan layu, masukkan ikan teri. Aduk sampai rata, matikan api."
- "Masukkan beras dan semua bahan tumisan beserta minyaknya kedalam rice cooker. Tambahkan air, garam, gula pasir dan lada bubuk, aduk dan tes rasa. Tekan tombol cook di magic com. Masak nasi sampai matang."
- "Sajikan dengan pelengkapnya."
categories:
- Resep
tags:
- nasi
- liwet
- magic

katakunci: nasi liwet magic 
nutrition: 282 calories
recipecuisine: Indonesian
preptime: "PT20M"
cooktime: "PT34M"
recipeyield: "1"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Liwet Magic Com](https://img-global.cpcdn.com/recipes/1d51b803b2419661/682x484cq65/nasi-liwet-magic-com-foto-resep-utama.webp)

4 langkah cepat dan mudah membuat  Nasi Liwet Magic Com yang bisa ibu coba dirumah

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Dalam Pembuatan Nasi Liwet Magic Com:

1. beras 4 cup 600 gr
1. air sesuaikan dengan takaran air memasak nasi masing 950 ml
1. teri 50 gr
1. bawang merah iris 8 butir
1. bawang putih iris 3 siung
1. cabe merah keriting iris 4 buah
1. daun salam 4 lembar
1. sereh geprek 2 batang
1. lengkuas geprek 1 cm
1. garam 2 sdt
1. gula pasir 1/2 sdt
1. lada bubuk 1/6 sdt
1. minyak goreng 



<!--inarticleads2-->

## Cara Membuat Nasi Liwet Magic Com:

1. Goreng ikan teri sampai kering dengan api sedang cenderung kecil, tiriskan minyak. Simpan minyak sisa goreng ikan teri.
1. Tumis bawang putih dan bawang merah menggunakan minyak sisa menggoreng ikan teri agar semakin gurih. Masukkan cabe merah iris, daun salam, sereh, dan lengkuas. Ketika sudah cukup empuk dan layu, masukkan ikan teri. Aduk sampai rata, matikan api.
1. Masukkan beras dan semua bahan tumisan beserta minyaknya kedalam rice cooker. Tambahkan air, garam, gula pasir dan lada bubuk, aduk dan tes rasa. Tekan tombol cook di magic com. Masak nasi sampai matang.
1. Sajikan dengan pelengkapnya.




Salah satu kuliner yang cukup praktis pembuatannya adalah  Nasi Liwet Magic Com. Selain itu  Nasi Liwet Magic Com  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu ikuti 4 langkah, dan  Nasi Liwet Magic Com  pun siap di hidangkan. selamat mencoba !
