---
description: "Resep Nasi Uduk, Bikin Ngiler"
title: "Resep Nasi Uduk, Bikin Ngiler"
slug: 124-resep-nasi-uduk-bikin-ngiler
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-12T08:00:13.613Z 
thumbnail: https://img-global.cpcdn.com/recipes/c5f18b84336516da/682x484cq65/nasi-uduk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/c5f18b84336516da/682x484cq65/nasi-uduk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/c5f18b84336516da/682x484cq65/nasi-uduk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/c5f18b84336516da/682x484cq65/nasi-uduk-foto-resep-utama.webp
author: Cynthia Holloway
ratingvalue: 4.2
reviewcount: 6
recipeingredient:
- "beras 2 cup"
- "santan kental 100 ml"
- "daun salam 3 lbr"
- "sereh geprek 1 btg"
- "daun jeruk 2 lbr"
- "lengkuas geprek sy skip 2 ruas"
- "garam Secukupnya"
- "air Secukupnya"
recipeinstructions:
- "Cuci bersih beras, tiriskan. Masukan ke dalam rice cooker, masukan juga semua rempahnya."
- "Tuang santan dan bubuhi garam. Tambahkan air dan takar air yang sudah bercampur santan tadi seperti masak nasi biasanya. Tekan tombol cook pada rice cooker,. biarkan masak sampai matang."
- "Nasi uduk siap disajikan dengan pelengkapnya."
categories:
- Resep
tags:
- nasi
- uduk

katakunci: nasi uduk 
nutrition: 274 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT57M"
recipeyield: "2"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk](https://img-global.cpcdn.com/recipes/c5f18b84336516da/682x484cq65/nasi-uduk-foto-resep-utama.webp)

Resep rahasia dan cara mengolah  Nasi Uduk cocok sekali jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Dalam Pembuatan Nasi Uduk:

1. beras 2 cup
1. santan kental 100 ml
1. daun salam 3 lbr
1. sereh geprek 1 btg
1. daun jeruk 2 lbr
1. lengkuas geprek sy skip 2 ruas
1. garam Secukupnya
1. air Secukupnya



<!--inarticleads2-->

## Tata Cara Menyiapkan Nasi Uduk:

1. Cuci bersih beras, tiriskan. Masukan ke dalam rice cooker, masukan juga semua rempahnya.
1. Tuang santan dan bubuhi garam. Tambahkan air dan takar air yang sudah bercampur santan tadi seperti masak nasi biasanya. Tekan tombol cook pada rice cooker,. biarkan masak sampai matang.
1. Nasi uduk siap disajikan dengan pelengkapnya.




Salah satu kuliner yang cukup praktis dalam pembuatannya adalah  Nasi Uduk. Selain itu  Nasi Uduk  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu ikuti 3 langkah, dan  Nasi Uduk  pun siap di hidangkan. selamat mencoba !
