---
description: "Resep Semur Tahu Telur (Pelengkap Nasi Uduk Khas Jakarta), Bikin Ngiler"
title: "Resep Semur Tahu Telur (Pelengkap Nasi Uduk Khas Jakarta), Bikin Ngiler"
slug: 41-resep-semur-tahu-telur-pelengkap-nasi-uduk-khas-jakarta-bikin-ngiler
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-28T19:58:36.612Z 
thumbnail: https://img-global.cpcdn.com/recipes/3aa505ee3095dd6c/682x484cq65/semur-tahu-telur-pelengkap-nasi-uduk-khas-jakarta-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/3aa505ee3095dd6c/682x484cq65/semur-tahu-telur-pelengkap-nasi-uduk-khas-jakarta-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/3aa505ee3095dd6c/682x484cq65/semur-tahu-telur-pelengkap-nasi-uduk-khas-jakarta-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/3aa505ee3095dd6c/682x484cq65/semur-tahu-telur-pelengkap-nasi-uduk-khas-jakarta-foto-resep-utama.webp
author: Ora Jones
ratingvalue: 3
reviewcount: 12
recipeingredient:
- "tahu yang sudah di goreng 4 potong"
- "telur rebus 4 butir"
- "Kecap manis "
- "Bumbu rempah cempung  "
- "serai 2 batang"
- "daun salam 2 lembar"
- "daun jeruk 3 lembar"
- "lengkuas 1 ruas jari"
- "kayu manis 2 batang"
- "pala geprek 1/4 butir"
- "Bumbu halus  "
- "bawang merah 6 siung"
- "bawang putih 3 siung"
- "kemiri 2 butir"
- "merica 1/2 sdt"
- "ketumbar bubuk 1 sdm"
- "kunyit bubuk 1/2 sdt"
- "jahe 1 ruas jari"
- "Pelengkap "
- "Bawang goreng "
recipeinstructions:
- "Tumis bumbu halus sampai harum. Masukkan semua bumbu rempah. Tumis lagi sebentar."
- "Masukkan tahu dan telur. Beri 1 gelas air. Masukkan kecap manis dan beri garam, gula, dan penyedap rasa. Masak sampai air sedikit menyusut. Kalau suka encer bisa dibuat encer atau buat sesuai selera (encer atau dibuat sat)"
- "Beri taburan bawang goreng. Hidangkan dengan nasi uduk dan sambal kacang."
categories:
- Resep
tags:
- semur
- tahu
- telur

katakunci: semur tahu telur 
nutrition: 244 calories
recipecuisine: Indonesian
preptime: "PT26M"
cooktime: "PT56M"
recipeyield: "2"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Semur Tahu Telur (Pelengkap Nasi Uduk Khas Jakarta)](https://img-global.cpcdn.com/recipes/3aa505ee3095dd6c/682x484cq65/semur-tahu-telur-pelengkap-nasi-uduk-khas-jakarta-foto-resep-utama.webp)

Resep dan cara mengolah  Semur Tahu Telur (Pelengkap Nasi Uduk Khas Jakarta) yang bisa bunda coba segera

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Dalam Menyiapkan Semur Tahu Telur (Pelengkap Nasi Uduk Khas Jakarta):

1. tahu yang sudah di goreng 4 potong
1. telur rebus 4 butir
1. Kecap manis 
1. Bumbu rempah cempung  
1. serai 2 batang
1. daun salam 2 lembar
1. daun jeruk 3 lembar
1. lengkuas 1 ruas jari
1. kayu manis 2 batang
1. pala geprek 1/4 butir
1. Bumbu halus  
1. bawang merah 6 siung
1. bawang putih 3 siung
1. kemiri 2 butir
1. merica 1/2 sdt
1. ketumbar bubuk 1 sdm
1. kunyit bubuk 1/2 sdt
1. jahe 1 ruas jari
1. Pelengkap 
1. Bawang goreng 



<!--inarticleads2-->

## Tata Cara Membuat Semur Tahu Telur (Pelengkap Nasi Uduk Khas Jakarta):

1. Tumis bumbu halus sampai harum. Masukkan semua bumbu rempah. Tumis lagi sebentar.
1. Masukkan tahu dan telur. Beri 1 gelas air. Masukkan kecap manis dan beri garam, gula, dan penyedap rasa. Masak sampai air sedikit menyusut. Kalau suka encer bisa dibuat encer atau buat sesuai selera (encer atau dibuat sat)
1. Beri taburan bawang goreng. Hidangkan dengan nasi uduk dan sambal kacang.




Terima kasih telah membaca resep yang tim kami tampilkan di halaman ini. Selamat mencoba!
