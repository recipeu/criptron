---
description: "Cara Gampang Menyiapkan 27. Nasi uduk betawi yang Sempurna"
title: "Cara Gampang Menyiapkan 27. Nasi uduk betawi yang Sempurna"
slug: 94-cara-gampang-menyiapkan-27-nasi-uduk-betawi-yang-sempurna
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-27T17:04:10.909Z 
thumbnail: https://img-global.cpcdn.com/recipes/7b406fb75ccae77f/682x484cq65/27-nasi-uduk-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/7b406fb75ccae77f/682x484cq65/27-nasi-uduk-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/7b406fb75ccae77f/682x484cq65/27-nasi-uduk-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/7b406fb75ccae77f/682x484cq65/27-nasi-uduk-betawi-foto-resep-utama.webp
author: Vera Cummings
ratingvalue: 3.3
reviewcount: 15
recipeingredient:
- "beras 2 liter"
- "santan 1 kg"
- "daun salam 10"
- "daun jeruk 8 lembar"
- "Jahe "
- "Laos "
- "Swcukupnya Garampenyedap "
recipeinstructions:
- "Cuci bersih beras, lalu geprek jahe n laos. Masukkan santan dalam panci, masukkan smua bahan n tambah garam. Masak santan di api yg kecil n aduk2 smp mendidih. Koreksi rasa"
- "Setelah santan matang, masukkan air santan tersebut ke dlm beras n masak dgn api kecil, saya tambah dgn air kira2 200 ml. Aduk sesekali biar ga jadi kerak. Setelah santan menyusut, saya biarkan nasi slm 10 menit baru saya kukus di dandang slm 25 smp 30 menit. Sajikan dgn bawang goreng dan lauk lainya. Selamat mencoba."
categories:
- Resep
tags:
- 27
- nasi
- uduk

katakunci: 27 nasi uduk 
nutrition: 136 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT53M"
recipeyield: "2"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![27. Nasi uduk betawi](https://img-global.cpcdn.com/recipes/7b406fb75ccae77f/682x484cq65/27-nasi-uduk-betawi-foto-resep-utama.webp)

2 langkah mudah mengolah  27. Nasi uduk betawi cocok sekali jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Dibutuhkan Untuk Menyiapkan 27. Nasi uduk betawi:

1. beras 2 liter
1. santan 1 kg
1. daun salam 10
1. daun jeruk 8 lembar
1. Jahe 
1. Laos 
1. Swcukupnya Garampenyedap 

Bebek dg ukuran besar diungkep dg bumbu lezat. Nasi Uduk Khas Betawi in Surabaya. Menyediakan nasi uduk asli jakarta lengkap dengan lauk andalan. There are no reviews for Nasi Uduk Betawi Bang Acim, Indonesia yet. 

<!--inarticleads2-->

## Tata Cara Membuat 27. Nasi uduk betawi:

1. Cuci bersih beras, lalu geprek jahe n laos. Masukkan santan dalam panci, masukkan smua bahan n tambah garam. Masak santan di api yg kecil n aduk2 smp mendidih. Koreksi rasa
1. Setelah santan matang, masukkan air santan tersebut ke dlm beras n masak dgn api kecil, saya tambah dgn air kira2 200 ml. Aduk sesekali biar ga jadi kerak. Setelah santan menyusut, saya biarkan nasi slm 10 menit baru saya kukus di dandang slm 25 smp 30 menit. Sajikan dgn bawang goreng dan lauk lainya. Selamat mencoba.


Be the first to write a review! Nasi Uduk is one of the Betawi culinary culture which in Malay society is known as &#34;fat rice&#34;. Betawi people enjoy rice uduk as breakfast menu. Resep nasi uduk betawi ini makanan pokok sangatlah turun temurun. Makanan ini kemudian dihidangkan dengan suatu emping goreng, tahu Resep nasi uduk betawi ini sudah sangat populer dikalangan masyarakat indonesia. 

Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
