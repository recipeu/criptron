---
description: "Resep Nasi bakar ikan Tuna Asap yang Bisa Manjain Lidah"
title: "Resep Nasi bakar ikan Tuna Asap yang Bisa Manjain Lidah"
slug: 359-resep-nasi-bakar-ikan-tuna-asap-yang-bisa-manjain-lidah
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-11T05:23:03.673Z 
thumbnail: https://img-global.cpcdn.com/recipes/000865d6cc10de82/682x484cq65/nasi-bakar-ikan-tuna-asap-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/000865d6cc10de82/682x484cq65/nasi-bakar-ikan-tuna-asap-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/000865d6cc10de82/682x484cq65/nasi-bakar-ikan-tuna-asap-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/000865d6cc10de82/682x484cq65/nasi-bakar-ikan-tuna-asap-foto-resep-utama.webp
author: Mae Delgado
ratingvalue: 4.7
reviewcount: 9
recipeingredient:
- "ikan tuna asap ukuran sedang 1/3 ekor"
- "Nasi putih matang kira2 1/2 liter"
- "Bawang merah 7 siung"
- "Bawang putih 5 siung"
- "Cabe merah kriting 7 buah"
- "Jahe seruas jari di bakar "
- "Kunyit seruas jari di bakar "
- "Daun salam daun jeruk sereh di memarkan lengkuas di memarkan "
- "Santan dr 12 butir kelapa "
- "Tomat merah 1 buah"
- "daun bawang 3 batang"
- "Garam gula dan royco ayam secukupnya"
- "Jeruk nipis utk merendam tongkol asap 1 buah"
recipeinstructions:
- "Siapkan bahan 2 yg di perlukan."
- "Ikan tuna asap di lumuri dgn air perasan jeruk nipis, diamkan selama 10 menit, setelah itu ikan tongkol di suir suir sedang ukurannya."
- "Peras santan dr 1/2 butir kelapa, kemudian di buat areh, yaitu di rebus sampai matang, tambahkan garam sedikit, tambahkan daun salam n sereh."
- "Ulek halus, bawang merah, bawang putih, cabe merah kriting, jahe,kemiri"
- "Tumis bumbu halus sampai harum, lalu masukkan daun salam,daun jeruk, sereh dan daun jeruk"
- "Masukkan ikan suir ke tumisan bumbu"
- "Tumis ikan sampai bumbu tercampur rata, tambahkan tomat iris dan daun bawang iris, aduk sampai merata."
- "Siapkan daun pisang utk membungkus nasi."
- "Ambil nasi sebanyak 2 sdk nasi, taruh tumisan ikan"
- "Siram dengan areh santan di atas tumisan ikan, kemudian di gulung rapi"
- "Gulung sampai nasi habis"
- "Siapkan dan panaskan happy call utk membakar nasi, dan bakar selama 25 menit, kira 2 10 menit happy call di balik ke sisi yg atas spy gulungan nasi didalamnya kedua sisi terbakar rata"
- "Alhamdulillah sudah matang dan aromanya tercium harum"
- "Selamat mencoba yaa"
categories:
- Resep
tags:
- nasi
- bakar
- ikan

katakunci: nasi bakar ikan 
nutrition: 291 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT53M"
recipeyield: "4"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi bakar ikan Tuna Asap](https://img-global.cpcdn.com/recipes/000865d6cc10de82/682x484cq65/nasi-bakar-ikan-tuna-asap-foto-resep-utama.webp)

Resep rahasia dan cara mengolah  Nasi bakar ikan Tuna Asap cocok sekali jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Untuk Pembuatan Nasi bakar ikan Tuna Asap:

1. ikan tuna asap ukuran sedang 1/3 ekor
1. Nasi putih matang kira2 1/2 liter
1. Bawang merah 7 siung
1. Bawang putih 5 siung
1. Cabe merah kriting 7 buah
1. Jahe seruas jari di bakar 
1. Kunyit seruas jari di bakar 
1. Daun salam daun jeruk sereh di memarkan lengkuas di memarkan 
1. Santan dr 12 butir kelapa 
1. Tomat merah 1 buah
1. daun bawang 3 batang
1. Garam gula dan royco ayam secukupnya
1. Jeruk nipis utk merendam tongkol asap 1 buah

Salah satunya adalah tumis tuna pedas. Aroma harum daun pisang berpadu rasa tuna yang pedas-gurih bikin ingin nambah. Kumpulan resep masakan berisi tentang resep. Sambal seafood varian ikan laut tuna bakar/asap. 

<!--inarticleads2-->

## Cara Mudah Menyiapkan Nasi bakar ikan Tuna Asap:

1. Siapkan bahan 2 yg di perlukan.
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/aa651ef20af5d33b/160x128cq70/nasi-bakar-ikan-tuna-asap-langkah-memasak-1-foto.webp" alt="Nasi bakar ikan Tuna Asap" width="340" height="340">
>1. Ikan tuna asap di lumuri dgn air perasan jeruk nipis, diamkan selama 10 menit, setelah itu ikan tongkol di suir suir sedang ukurannya.
1. Peras santan dr 1/2 butir kelapa, kemudian di buat areh, yaitu di rebus sampai matang, tambahkan garam sedikit, tambahkan daun salam n sereh.
1. Ulek halus, bawang merah, bawang putih, cabe merah kriting, jahe,kemiri
1. Tumis bumbu halus sampai harum, lalu masukkan daun salam,daun jeruk, sereh dan daun jeruk
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/5470c1b2eb693f4e/160x128cq70/nasi-bakar-ikan-tuna-asap-langkah-memasak-5-foto.webp" alt="Nasi bakar ikan Tuna Asap" width="340" height="340">
>1. Masukkan ikan suir ke tumisan bumbu
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/32a789090f279f54/160x128cq70/nasi-bakar-ikan-tuna-asap-langkah-memasak-6-foto.webp" alt="Nasi bakar ikan Tuna Asap" width="340" height="340">
>1. Tumis ikan sampai bumbu tercampur rata, tambahkan tomat iris dan daun bawang iris, aduk sampai merata.
1. Siapkan daun pisang utk membungkus nasi.
1. Ambil nasi sebanyak 2 sdk nasi, taruh tumisan ikan
1. Siram dengan areh santan di atas tumisan ikan, kemudian di gulung rapi
1. Gulung sampai nasi habis
1. Siapkan dan panaskan happy call utk membakar nasi, dan bakar selama 25 menit, kira 2 10 menit happy call di balik ke sisi yg atas spy gulungan nasi didalamnya kedua sisi terbakar rata
1. Alhamdulillah sudah matang dan aromanya tercium harum
1. Selamat mencoba yaa


Harga IKAN TUNA BAKAR BUMBU KECAP VEGAN / VEGETARIAN. Masukkan tuna, aduk hingga rata dan agak kering. Membuat nasi bakar isi ikan tuna tidaklah sulit, bahkan Anda dapat membuatnya dengan dua cara. Cara pertama adalah nasi aron yang diberikan bumbu santan dan rempah kemudian dicampur dengan isiannya, lalu dibungkus menggunakan daun pisang kemudian dibakar di atas bara api. Varian Ikan Tuna Asap Nasi dengan campuran daun kemangi, bawang goreng, teri medan goreng, dan Ikan Tuna Asap. 

Terima kasih telah menggunakan resep yang tim kami tampilkan di halaman ini. Selamat mencoba!
