---
description: "Bagaimana Membuat Nasi bakar Tuna pedas yang Bikin Ngiler"
title: "Bagaimana Membuat Nasi bakar Tuna pedas yang Bikin Ngiler"
slug: 376-bagaimana-membuat-nasi-bakar-tuna-pedas-yang-bikin-ngiler
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-10T13:14:17.398Z 
thumbnail: https://img-global.cpcdn.com/recipes/ea7e90846cad2ca1/682x484cq65/nasi-bakar-tuna-pedas-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/ea7e90846cad2ca1/682x484cq65/nasi-bakar-tuna-pedas-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/ea7e90846cad2ca1/682x484cq65/nasi-bakar-tuna-pedas-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/ea7e90846cad2ca1/682x484cq65/nasi-bakar-tuna-pedas-foto-resep-utama.webp
author: Dylan Hammond
ratingvalue: 4.8
reviewcount: 4
recipeingredient:
- "Bahan nasi "
- "beras cuci bersih 500 gram"
- "santan sedang 750 ml"
- "serai ambil bagian putihnya 2 batang"
- "daun salam 2 lembar"
- "daun pandan 2 lembar"
- "garam Secukupnya"
- "Pelengkap "
- "Daun pisang  lidi untuk menyemat "
- "Bahan isi "
- "Ikan tuna rebussuwir2 "
- "daun salam 2 lembar"
- "serai memarkan 1 batang"
- "daun jeruk memarkan 2 lembar"
- "lengkuas memarkan 2 cm"
- "santan kental 250 ml"
- "daun kemangi petiki daunnya 2 ikat"
- "garamgula  minyak untuk menumis Secukupnya"
- "Bumbu halus "
- "bawang merah 5 siung"
- "bawang putih 3 siung"
- "kemiri sangrai 4 butir"
- "kunyit bakar 1 cm"
- "cabe merah keriting 5"
- "rawit merah 5"
- "cabe merah besar 1"
recipeinstructions:
- "Siapkan semua bahan. Saya membuat 2 macam isian yaitu tuna &amp; ayam,tp yg ayam tdk pedas untuk anak2)"
- "Buat nasi: masak santan,tambahkan serai,salam,pandan &amp; garam,masak hingga mendidih,masukkan beras,masak hingga menjadi aron (santan abis terserap),matikan api."
- "Kukus  nasi aron sampai matang kurang lebih 30 menit,sisihkan."
- "Buat isi: panaskan minyak goreng,tumis bumbu halus,aduk rata, masukkan serai,salam,daun jeruk &amp; lengkuas,aduk sampai wangi,lalu masukkan ikan/ayam suwir,tambahkan santan kental,bumbui garam &amp; gula,masak sampai santan menyusut &amp; bumbu meresap,terakhir masukkan daun kemangi,angkat."
- "Ambil daun pisang,taruh nasi,tambahkan bahan isian diatasnya,rapatkan &amp; rapikan lalu semat dg lidi,bakar hingga aromanya wangi &amp; daun berubah warna,siap disajikan hangat dg pelengkap sambal,lalapan &amp; lauk pendamping. (Tanpa pelengkap pun nasi bakar ini sdh enak😘)"
categories:
- Resep
tags:
- nasi
- bakar
- tuna

katakunci: nasi bakar tuna 
nutrition: 168 calories
recipecuisine: Indonesian
preptime: "PT26M"
cooktime: "PT57M"
recipeyield: "3"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi bakar Tuna pedas](https://img-global.cpcdn.com/recipes/ea7e90846cad2ca1/682x484cq65/nasi-bakar-tuna-pedas-foto-resep-utama.webp)

Ingin membuat Nasi bakar Tuna pedas ? Coba resep berikut ini. Cara memasaknya sangat praktis namun jangan kaget jika hasilnya gurih dan lezat cocok sekali jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Untuk Pembuatan Nasi bakar Tuna pedas:

1. Bahan nasi 
1. beras cuci bersih 500 gram
1. santan sedang 750 ml
1. serai ambil bagian putihnya 2 batang
1. daun salam 2 lembar
1. daun pandan 2 lembar
1. garam Secukupnya
1. Pelengkap 
1. Daun pisang  lidi untuk menyemat 
1. Bahan isi 
1. Ikan tuna rebussuwir2 
1. daun salam 2 lembar
1. serai memarkan 1 batang
1. daun jeruk memarkan 2 lembar
1. lengkuas memarkan 2 cm
1. santan kental 250 ml
1. daun kemangi petiki daunnya 2 ikat
1. garamgula  minyak untuk menumis Secukupnya
1. Bumbu halus 
1. bawang merah 5 siung
1. bawang putih 3 siung
1. kemiri sangrai 4 butir
1. kunyit bakar 1 cm
1. cabe merah keriting 5
1. rawit merah 5
1. cabe merah besar 1

Anda sedang mencari info tentang resep Nasi Bakar Tuna Pedas?. Jika itu yang Anda cari maka sekarang Anda berada di halaman website yang tepat, karena kami Aneka Resep terpercaya siap memberikan. Tapi, tuna itu harus dibuat jadi apa, ya? Tuna bukanlah ikan sehari-hari kebanyakan orang Indonesia. 

<!--inarticleads2-->

## Cara Menyiapkan Nasi bakar Tuna pedas:

1. Siapkan semua bahan. Saya membuat 2 macam isian yaitu tuna &amp; ayam,tp yg ayam tdk pedas untuk anak2)
1. Buat nasi: masak santan,tambahkan serai,salam,pandan &amp; garam,masak hingga mendidih,masukkan beras,masak hingga menjadi aron (santan abis terserap),matikan api.
1. Kukus  nasi aron sampai matang kurang lebih 30 menit,sisihkan.
1. Buat isi: panaskan minyak goreng,tumis bumbu halus,aduk rata, masukkan serai,salam,daun jeruk &amp; lengkuas,aduk sampai wangi,lalu masukkan ikan/ayam suwir,tambahkan santan kental,bumbui garam &amp; gula,masak sampai santan menyusut &amp; bumbu meresap,terakhir masukkan daun kemangi,angkat.
1. Ambil daun pisang,taruh nasi,tambahkan bahan isian diatasnya,rapatkan &amp; rapikan lalu semat dg lidi,bakar hingga aromanya wangi &amp; daun berubah warna,siap disajikan hangat dg pelengkap sambal,lalapan &amp; lauk pendamping. (Tanpa pelengkap pun nasi bakar ini sdh enak😘)


Berbeda dengan ikan lele, nila, mas, mujair, kakap Ikannya ditumis. Ikan tuna merupakan ikan yang hidup di air laut dan memiliki ukuran tubuh yang besar, namun memiliki dagingnya yang gurih kala dimasak. Aneka Varian masakan merupakan salah satu Makanan yang banyak diminati dan banyak sekali jenisnya, baik berupa masakan berbahan daging, seafood, ikan. Nasi bakar (Indonesian for &#34;burned or grilled rice&#34;) refer to steamed rice seasoned with spices and ingredients and wrapped in banana leaf secured with lidi semat (small needle made of central rib of coconut leaf) and later grilled upon charcoal fire. Nasi Bakar Tuna &amp; Jamur Tiram 

Daripada   beli  Nasi bakar Tuna pedas  diluar terus, ibu  bisa membuatnya sendiri dirumah. Resep  Nasi bakar Tuna pedas  sederhana ini cukup praktis dalam proses pembuatannya, serta cukup menggunakan bumbu-bumbu sederhana yang ada di dapur  Nasi bakar Tuna pedas  yang enak, bunda nikmati di rumah.
