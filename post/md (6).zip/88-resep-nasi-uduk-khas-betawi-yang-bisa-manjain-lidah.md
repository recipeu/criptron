---
description: "Resep Nasi Uduk khas Betawi yang Bisa Manjain Lidah"
title: "Resep Nasi Uduk khas Betawi yang Bisa Manjain Lidah"
slug: 88-resep-nasi-uduk-khas-betawi-yang-bisa-manjain-lidah
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-20T03:53:39.791Z 
thumbnail: https://img-global.cpcdn.com/recipes/6fd7a602e5ed86fa/682x484cq65/nasi-uduk-khas-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/6fd7a602e5ed86fa/682x484cq65/nasi-uduk-khas-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/6fd7a602e5ed86fa/682x484cq65/nasi-uduk-khas-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/6fd7a602e5ed86fa/682x484cq65/nasi-uduk-khas-betawi-foto-resep-utama.webp
author: Nathan Goodwin
ratingvalue: 4.3
reviewcount: 11
recipeingredient:
- "beras pulen 1 liter"
- "santan kental resep asli santan sedang Secukupnya"
- "serai memarkan 3 batang"
- "bawang merah agak besar resep asli 5 siung 8 siung"
- "daun salam resep asli 7 lembar 3 lembar"
- "daun pandan resep asli ngga pake 3 lembar"
- "jahe kupas kulitnya 1 ruas"
- "garam Secukupnya"
- "Lengkoas geprek 1 ruas"
- "air resep asli nggak pake secukupnya"
recipeinstructions:
- "Cuci bersih beras, lalu sisihkan. Blender bawang merah dan jahe. Moon maap aku terlalu males ngulek hehehe"
- "Masukkan beras ke wadah rice cooker.. tambahkan daun salam, batang serai yabg sudah dimemarkan, daun pandan bawang merah dan jahe yang sudah diblender, santan (tambahkan air secukupnya) dan beri garam secukupnya."
- "Masak nasi sampai matang yaaa. Kalo nasinya udah matang, siap deh disantap pake bawang goreng, bihun goreng, orek tempe, bakwan sayuran, telor balado.. adududuhhhhhhhh manteeeppppp"
categories:
- Resep
tags:
- nasi
- uduk
- khas

katakunci: nasi uduk khas 
nutrition: 288 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT33M"
recipeyield: "4"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk khas Betawi](https://img-global.cpcdn.com/recipes/6fd7a602e5ed86fa/682x484cq65/nasi-uduk-khas-betawi-foto-resep-utama.webp)

Resep dan cara mengolah  Nasi Uduk khas Betawi yang bisa kamu coba dirumah

<!--inarticleads1-->

## Bahan-bahan Yang Dibutuhkan Dalam Menyiapkan Nasi Uduk khas Betawi:

1. beras pulen 1 liter
1. santan kental resep asli santan sedang Secukupnya
1. serai memarkan 3 batang
1. bawang merah agak besar resep asli 5 siung 8 siung
1. daun salam resep asli 7 lembar 3 lembar
1. daun pandan resep asli ngga pake 3 lembar
1. jahe kupas kulitnya 1 ruas
1. garam Secukupnya
1. Lengkoas geprek 1 ruas
1. air resep asli nggak pake secukupnya



<!--inarticleads2-->

## Langkah-langkah Untuk Menyiapkan Nasi Uduk khas Betawi:

1. Cuci bersih beras, lalu sisihkan. Blender bawang merah dan jahe. Moon maap aku terlalu males ngulek hehehe
1. Masukkan beras ke wadah rice cooker.. tambahkan daun salam, batang serai yabg sudah dimemarkan, daun pandan bawang merah dan jahe yang sudah diblender, santan (tambahkan air secukupnya) dan beri garam secukupnya.
1. Masak nasi sampai matang yaaa. Kalo nasinya udah matang, siap deh disantap pake bawang goreng, bihun goreng, orek tempe, bakwan sayuran, telor balado.. adududuhhhhhhhh manteeeppppp




Terima kasih telah menggunakan resep yang tim kami tampilkan di sini. Semoga bermanfaat dan selamat mencoba!
