---
description: "Resep Nasi uduk khas betawi megicom, Enak"
title: "Resep Nasi uduk khas betawi megicom, Enak"
slug: 57-resep-nasi-uduk-khas-betawi-megicom-enak
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-20T00:33:58.276Z 
thumbnail: https://img-global.cpcdn.com/recipes/528f1bfb6665c46e/682x484cq65/nasi-uduk-khas-betawi-megicom-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/528f1bfb6665c46e/682x484cq65/nasi-uduk-khas-betawi-megicom-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/528f1bfb6665c46e/682x484cq65/nasi-uduk-khas-betawi-megicom-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/528f1bfb6665c46e/682x484cq65/nasi-uduk-khas-betawi-megicom-foto-resep-utama.webp
author: Sara Quinn
ratingvalue: 5
reviewcount: 11
recipeingredient:
- "beras rendam 1 jam 2 cup"
- "Santan sesuai keinginan nasi ingin pera lembek "
- "Serai "
- "Lengkuas "
- "Jahe "
- "Daun salam "
- "Garam "
recipeinstructions:
- "Rendam beras selama 1 jam"
- "Geprek jahe, lengkuas, serai, siapkan santan jagan terlalu kental dan jangan terlau encer sedang saja"
- "Masukkan serai, lengkuas, jahe daun salam lalu tuang santan untuk ukuran santan samakan dengan air biasa kita memasak banyak jika mau nasi lembek dan sedikit jika mau pera saya sedang saja tambahkan sedikit garam masak megicom sampai matang setelah matang buang semua dedaunan aduk2 agar tidak lengket"
- "Nasi uduk siap di sajikan bersama lauk pauk pelengkap lainnya untuk resep lauk pauk sudah saya share terpisah selamat mencoba. Enduls pisan pokoknya gak kalah sama nasi uduk yg di jual di warung2 khas betawi"
categories:
- Resep
tags:
- nasi
- uduk
- khas

katakunci: nasi uduk khas 
nutrition: 142 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT58M"
recipeyield: "3"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi uduk khas betawi megicom](https://img-global.cpcdn.com/recipes/528f1bfb6665c46e/682x484cq65/nasi-uduk-khas-betawi-megicom-foto-resep-utama.webp)

Ingin membuat Nasi uduk khas betawi megicom ? Coba resep berikut ini. Cara memasaknya sangat praktis namun hasilnya gurih dan lezat cocok sekali jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Dalam Menyiapkan Nasi uduk khas betawi megicom:

1. beras rendam 1 jam 2 cup
1. Santan sesuai keinginan nasi ingin pera lembek 
1. Serai 
1. Lengkuas 
1. Jahe 
1. Daun salam 
1. Garam 

I&#39;m sharing how you can make it easily with a rice cooker but it can be cooked on the stove and Instant Pot too. My kids get very excited whenever I make coconut rice. Berbeda dengan nasi putih biasa, tekstur nasi uduk tidak lengket dan rasanya pun tidak benyek. Aromanya pun punya ciri khas tersendiri dan sangat harum. 

<!--inarticleads2-->

## Cara Mudah Membuat Nasi uduk khas betawi megicom:

1. Rendam beras selama 1 jam
1. Geprek jahe, lengkuas, serai, siapkan santan jagan terlalu kental dan jangan terlau encer sedang saja
1. Masukkan serai, lengkuas, jahe daun salam lalu tuang santan untuk ukuran santan samakan dengan air biasa kita memasak banyak jika mau nasi lembek dan sedikit jika mau pera saya sedang saja tambahkan sedikit garam masak megicom sampai matang setelah matang buang semua dedaunan aduk2 agar tidak lengket
1. Nasi uduk siap di sajikan bersama lauk pauk pelengkap lainnya untuk resep lauk pauk sudah saya share terpisah selamat mencoba. Enduls pisan pokoknya gak kalah sama nasi uduk yg di jual di warung2 khas betawi


Ini karena nasi uduk dimasak setengah matang (diaron) dulu dengan santan dan berbagai bumbu lain seperti daun jeruk, lengkuas, serai, dan. Khusus nasi uduk khas Betawi, biasanya memang dibuat oleh orang Betawi. Baca juga: Resep Nasi Uduk Rice Cooker yang Mudah Dibuat, Anak Kost Juga Bisa. Ciri khasnya ada pada lauk pauk pelengkap, terdiri dari semur entah itu dari bahan daging, kentang, tahu, telur, atau jengkol. Nasi Uduk Betawi hadir dengan inovasi terbaru paket menu Ungkepan. 

Selamat memasak dan menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
