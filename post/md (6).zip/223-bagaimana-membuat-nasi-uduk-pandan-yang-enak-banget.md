---
description: "Bagaimana Membuat Nasi Uduk Pandan yang Enak Banget"
title: "Bagaimana Membuat Nasi Uduk Pandan yang Enak Banget"
slug: 223-bagaimana-membuat-nasi-uduk-pandan-yang-enak-banget
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-26T06:04:13.931Z 
thumbnail: https://img-global.cpcdn.com/recipes/ce06441680c29930/682x484cq65/nasi-uduk-pandan-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/ce06441680c29930/682x484cq65/nasi-uduk-pandan-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/ce06441680c29930/682x484cq65/nasi-uduk-pandan-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/ce06441680c29930/682x484cq65/nasi-uduk-pandan-foto-resep-utama.webp
author: Belle Morris
ratingvalue: 3.5
reviewcount: 4
recipeingredient:
- "bawang putih 5 siung"
- "bawang merah 3 siung"
- "beras 1200 gr"
- "serai 2-3 batang"
- "daun jeruk 5 lbr"
- "daun salam 5 lbr"
- "daun pandan 2 lbr"
- "santan instan kara 400 ml"
- "air putih  10 daun suji  20 daun pandan diblender peras dgn kain 300 ml"
- "air putih 700 ml"
- "garam 1,5 sdt"
- "kaldu jamur 1 sdm"
- "Minyak secukupnya untuk menumis "
recipeinstructions:
- "Panaskan wajan, tuang minyak dan masukkan bawang putih, bawang putih, serai, daun jeruk, daun salam, garam."
- "Setelah wangi masukkan beras yg sudah dicuci, tumis sebentar."
- "Tuang santan, air pandan, dan air putih. Masak sampai air menyusut, pindahkan ke kukusan."
- "Kukus sampai matang."
categories:
- Resep
tags:
- nasi
- uduk
- pandan

katakunci: nasi uduk pandan 
nutrition: 219 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT41M"
recipeyield: "4"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Pandan](https://img-global.cpcdn.com/recipes/ce06441680c29930/682x484cq65/nasi-uduk-pandan-foto-resep-utama.webp)

Ingin membuat Nasi Uduk Pandan ? Coba resep berikut ini. Cara memasaknya sangat praktis namun hasilnya gurih dan lezat yang bisa ibu coba dirumah

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Dalam Menyiapkan Nasi Uduk Pandan:

1. bawang putih 5 siung
1. bawang merah 3 siung
1. beras 1200 gr
1. serai 2-3 batang
1. daun jeruk 5 lbr
1. daun salam 5 lbr
1. daun pandan 2 lbr
1. santan instan kara 400 ml
1. air putih  10 daun suji  20 daun pandan diblender peras dgn kain 300 ml
1. air putih 700 ml
1. garam 1,5 sdt
1. kaldu jamur 1 sdm
1. Minyak secukupnya untuk menumis 



<!--inarticleads2-->

## Tata Cara Menyiapkan Nasi Uduk Pandan:

1. Panaskan wajan, tuang minyak dan masukkan bawang putih, bawang putih, serai, daun jeruk, daun salam, garam.
1. Setelah wangi masukkan beras yg sudah dicuci, tumis sebentar.
1. Tuang santan, air pandan, dan air putih. Masak sampai air menyusut, pindahkan ke kukusan.
1. Kukus sampai matang.




Selamat memasak dan menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
