---
description: "Resep Nasi Uduk Betawi ala Violet Azalea, Lezat Sekali"
title: "Resep Nasi Uduk Betawi ala Violet Azalea, Lezat Sekali"
slug: 32-resep-nasi-uduk-betawi-ala-violet-azalea-lezat-sekali
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-12T22:29:36.035Z 
thumbnail: https://img-global.cpcdn.com/recipes/0223ede819991215/682x484cq65/nasi-uduk-betawi-ala-violet-azalea-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/0223ede819991215/682x484cq65/nasi-uduk-betawi-ala-violet-azalea-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/0223ede819991215/682x484cq65/nasi-uduk-betawi-ala-violet-azalea-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/0223ede819991215/682x484cq65/nasi-uduk-betawi-ala-violet-azalea-foto-resep-utama.webp
author: Susan Lane
ratingvalue: 3.4
reviewcount: 11
recipeingredient:
- "Bahan Nasi Uduk  "
- "beras lebih bagus yang pulen cuci bersih dan tiriskan 1 liter"
- "santan kekentalan sedang "
- "serai geprek 3 batang"
- "laos geprek 1 ruas"
- "kayumanis 5 cm 1 batang"
- "bawang merah yang besar parut 5 buah"
- "jahe parut 1 ruas"
- "garam dan vetsin sesuai selera"
- "daun pandan sobek dan simpulkan optional 1 buah"
- "daun salam 7 lembar"
- "Bahan Ayam Goreng Kunyit  "
- "daging ayam cuci bersih tiriskan 1 kg"
- "perasan jeruk nipis 1 sdt"
- "Garam dan vetsin secukupnya"
- "kunyit parut 1 buah"
- "bawang putih parut 3 siung"
- "Bahan Tempe Orek  "
- "tempe 1 papan"
- "bawang merah 3 siung"
- "bawang putih 2 siung"
- "minyak untuk menumis "
- "daun salam 2 lembar"
- "garam dan vetsin secukupnya"
- "kecap secukupnya"
- "Pelengkap  "
- "Taburan bawang goreng "
- "Sambal "
recipeinstructions:
- "Kita buat nasi uduknya. Parut bawang merah dan jahe.           (lihat resep)"
- "Beras dicuci bersih dan tiriskan. Beri santan yang ukurannya disesuaikan dengan berasnya seperti ketika biasa memasak nasi. Beri serai, daun pandan, daun salam, bawang merah parut, jahe parut, lengkuas, garam dan penyedap rasa."
- "Rebus nasi santan berbumbu dengan api sedang hingga semua cairan terserap ke nasi. Ketika mendidih sesekali diaduk ya agar nasi tidak gosong ataupun melekat di permukaan bawah panci. Jika sudah meresap cairannya, angkat panci dari kompor."
- "Siapkan kukusan dan didihkan. Ketika kukusan sudah mendidih masukkan beras yang sudah dimasak bersama rempah tadi dan kukus hingga matang."
- "Jika sudah matang aduk nasi supaya tidak menggumpal. Angkat. Sisihkan."
- "Sekarang siapkan bahan untuk ayam goreng kunyit : parut halus kunyit dan bawang putih. Sisihkan.           (lihat resep)"
- "Siapkan daging ayam yang sudah dicuci bersih dan ditiriskan. Beri perasan jeruk nipis dan dibalur untuk menghilangkan amisnya."
- "Campur ayam dengan bumbu halus serta garam dan vetsin. Diamkan sampai bumbu meresap minimal 5 menit."
- "Goreng ayam dengan api kecil cenderung sedang. Jangan terlalu kering tapi dalamnya harus matang supaya daging ayam tetap empuk. Sisihkan"
- "Sekarang menyiapkan bahan tempe oreknya : bawang diiris, lengkuas digeprek dan tempe dipotong-potong.           (lihat resep)"
- "Goreng tempe tapi jangan terlalu kering dan sisihkan."
- "Panaskan minyak. Tumis bawang beserta daun salam dan lengkuas dengan api sedang hingga harum. Masukkan tempe. Aduk rata."
- "Beri garam, vetsin dan kecap. Aduk hingga rata. Tes rasa dan masak sebentar. Angkat."
- "Sajikan nasi uduk dengan taburan bawang merah dan pelengkapnya.           (lihat resep)"
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 272 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT44M"
recipeyield: "4"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Betawi ala Violet Azalea](https://img-global.cpcdn.com/recipes/0223ede819991215/682x484cq65/nasi-uduk-betawi-ala-violet-azalea-foto-resep-utama.webp)

14 langkah cepat dan mudah mengolah  Nasi Uduk Betawi ala Violet Azalea cocok sekali jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Untuk Menyiapkan Nasi Uduk Betawi ala Violet Azalea:

1. Bahan Nasi Uduk  
1. beras lebih bagus yang pulen cuci bersih dan tiriskan 1 liter
1. santan kekentalan sedang 
1. serai geprek 3 batang
1. laos geprek 1 ruas
1. kayumanis 5 cm 1 batang
1. bawang merah yang besar parut 5 buah
1. jahe parut 1 ruas
1. garam dan vetsin sesuai selera
1. daun pandan sobek dan simpulkan optional 1 buah
1. daun salam 7 lembar
1. Bahan Ayam Goreng Kunyit  
1. daging ayam cuci bersih tiriskan 1 kg
1. perasan jeruk nipis 1 sdt
1. Garam dan vetsin secukupnya
1. kunyit parut 1 buah
1. bawang putih parut 3 siung
1. Bahan Tempe Orek  
1. tempe 1 papan
1. bawang merah 3 siung
1. bawang putih 2 siung
1. minyak untuk menumis 
1. daun salam 2 lembar
1. garam dan vetsin secukupnya
1. kecap secukupnya
1. Pelengkap  
1. Taburan bawang goreng 
1. Sambal 



<!--inarticleads2-->

## Cara Membuat Nasi Uduk Betawi ala Violet Azalea:

1. Kita buat nasi uduknya. Parut bawang merah dan jahe. -           (lihat resep)
1. Beras dicuci bersih dan tiriskan. Beri santan yang ukurannya disesuaikan dengan berasnya seperti ketika biasa memasak nasi. Beri serai, daun pandan, daun salam, bawang merah parut, jahe parut, lengkuas, garam dan penyedap rasa.
1. Rebus nasi santan berbumbu dengan api sedang hingga semua cairan terserap ke nasi. Ketika mendidih sesekali diaduk ya agar nasi tidak gosong ataupun melekat di permukaan bawah panci. Jika sudah meresap cairannya, angkat panci dari kompor.
1. Siapkan kukusan dan didihkan. Ketika kukusan sudah mendidih masukkan beras yang sudah dimasak bersama rempah tadi dan kukus hingga matang.
1. Jika sudah matang aduk nasi supaya tidak menggumpal. Angkat. Sisihkan.
1. Sekarang siapkan bahan untuk ayam goreng kunyit : parut halus kunyit dan bawang putih. Sisihkan. -           (lihat resep)
1. Siapkan daging ayam yang sudah dicuci bersih dan ditiriskan. Beri perasan jeruk nipis dan dibalur untuk menghilangkan amisnya.
1. Campur ayam dengan bumbu halus serta garam dan vetsin. Diamkan sampai bumbu meresap minimal 5 menit.
1. Goreng ayam dengan api kecil cenderung sedang. Jangan terlalu kering tapi dalamnya harus matang supaya daging ayam tetap empuk. Sisihkan
1. Sekarang menyiapkan bahan tempe oreknya : bawang diiris, lengkuas digeprek dan tempe dipotong-potong. -           (lihat resep)
1. Goreng tempe tapi jangan terlalu kering dan sisihkan.
1. Panaskan minyak. Tumis bawang beserta daun salam dan lengkuas dengan api sedang hingga harum. Masukkan tempe. Aduk rata.
1. Beri garam, vetsin dan kecap. Aduk hingga rata. Tes rasa dan masak sebentar. Angkat.
1. Sajikan nasi uduk dengan taburan bawang merah dan pelengkapnya. -           (lihat resep)




Salah satu masakan yang cukup praktis pembuatannya adalah  Nasi Uduk Betawi ala Violet Azalea. Selain itu  Nasi Uduk Betawi ala Violet Azalea  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu lakukan 14 langkah, dan  Nasi Uduk Betawi ala Violet Azalea  pun siap di hidangkan. selamat mencoba !
