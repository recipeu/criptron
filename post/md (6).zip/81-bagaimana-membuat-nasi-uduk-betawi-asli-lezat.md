---
description: "Bagaimana Membuat Nasi uduk betawi asli, Lezat"
title: "Bagaimana Membuat Nasi uduk betawi asli, Lezat"
slug: 81-bagaimana-membuat-nasi-uduk-betawi-asli-lezat
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-15T21:20:50.144Z 
thumbnail: https://img-global.cpcdn.com/recipes/5590f8cc76ebc0bf/682x484cq65/nasi-uduk-betawi-asli-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/5590f8cc76ebc0bf/682x484cq65/nasi-uduk-betawi-asli-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/5590f8cc76ebc0bf/682x484cq65/nasi-uduk-betawi-asli-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/5590f8cc76ebc0bf/682x484cq65/nasi-uduk-betawi-asli-foto-resep-utama.webp
author: Jared Keller
ratingvalue: 4.3
reviewcount: 3
recipeingredient:
- "beras 4 cup"
- "santan sedang 800 ml"
- "sereh geprek 6 batang"
- "daun salam 8 lembar"
- "lengkuas geprek 2 cm"
- "kayu manis 2 cm"
- "Garam secukupnya"
- "Bumbu halus "
- "bawang merah diparut halus 5 btr"
- "jahe diparut halus 1 cm"
- "Pelengkap sesuai selera "
- "Kerupuk bihun mie goreng bawang goreng perkedel semur tahu "
- "Semur jengkol ayam goreng telur dadar timun kemangi "
- "Sambal kacang sambal tomat "
recipeinstructions:
- "Siapkan semua bahan"
- "Tuang santan dalam wajan masukkan bumbu, beri garam, masukkan beras masak sambil diaduk sesekali sampai santan menjadi susut"
- "Panaskan kukusan, kemudian kukus nasi aron hingga matang selama 30 mnt. Tutup dialasi kain bersih"
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 243 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT45M"
recipeyield: "2"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi uduk betawi asli](https://img-global.cpcdn.com/recipes/5590f8cc76ebc0bf/682x484cq65/nasi-uduk-betawi-asli-foto-resep-utama.webp)

Ingin membuat Nasi uduk betawi asli ? Coba resep berikut ini. Cara memasaknya sangat praktis namun jangan kaget jika hasilnya gurih dan lezat cocok sekali jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Dalam Pembuatan Nasi uduk betawi asli:

1. beras 4 cup
1. santan sedang 800 ml
1. sereh geprek 6 batang
1. daun salam 8 lembar
1. lengkuas geprek 2 cm
1. kayu manis 2 cm
1. Garam secukupnya
1. Bumbu halus 
1. bawang merah diparut halus 5 btr
1. jahe diparut halus 1 cm
1. Pelengkap sesuai selera 
1. Kerupuk bihun mie goreng bawang goreng perkedel semur tahu 
1. Semur jengkol ayam goreng telur dadar timun kemangi 
1. Sambal kacang sambal tomat 

Resep nasi uduk betawi sebenarnya cukup sederhana, cara membuatnya juga tidak terlalu sulit, bahan dan bumbunya mudah didapat, serta tidak butuh waktu lama untuk memasaknya. Kabarnya Nasi Uduk Betawi Asli ini mulai buka sesudah maghrib hingga tengah malam, tetapi tak jarang sebelum tengah malam sudah tutup karena habis. Uduk (Javanese: segá uduk; Indonesian: &#34;nasi uduk&#34;) is an Indonesian style steamed rice cooked in coconut milk dish, which originated from Java. Rahasia resep nasi uduk betawi termasuk dalam resep masakan tradisional indonesia. 

<!--inarticleads2-->

## Cara Mudah Menyiapkan Nasi uduk betawi asli:

1. Siapkan semua bahan
1. Tuang santan dalam wajan masukkan bumbu, beri garam, masukkan beras masak sambil diaduk sesekali sampai santan menjadi susut
1. Panaskan kukusan, kemudian kukus nasi aron hingga matang selama 30 mnt. Tutup dialasi kain bersih


Untuk dapat menghasilkan nasi uduk yang berkualitas dengan cita rasa gurih sempurna tentunya bunda juga mesti menggunakan santan kelapa asli dan baru ( masih fres ). Resep Nasi Uduk - Salah satu dari variasi nasi biasa yang memiliki banyak penggemar adalah nasi uduk. Selain rasa yang gurih nasi ini dijual dengan harga yang cukup terjangkau. RESEP NASI UDUK KHAS BETAWI ASLI. Rasakan nikmatnya nasi uduk khas betawi asli dengan khas aromanya. 

Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
