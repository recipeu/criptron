---
description: "Resep Nasi Daun Jeruk, Sempurna"
title: "Resep Nasi Daun Jeruk, Sempurna"
slug: 301-resep-nasi-daun-jeruk-sempurna
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-27T18:32:47.151Z 
thumbnail: https://img-global.cpcdn.com/recipes/f10efa99e88e0416/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/f10efa99e88e0416/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/f10efa99e88e0416/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/f10efa99e88e0416/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
author: Marc Guzman
ratingvalue: 3.4
reviewcount: 6
recipeingredient:
- "Beras 2 gelas"
- "Daun jeruk 15 lembar"
- "Bawang putih 4 siung"
- "Serai 1 batang"
- "Penyedap rasa ayam 1/2 sdm"
- "Garam 1/2 sdm"
- "Margarin untuk menumis 1 sendok"
recipeinstructions:
- "Masukkan beras ke dalam wadah magic com. Cuci beras sampai bersih lalu isi dengan 1 gelas air."
- "Potong tipis daun jeruk dan bawang putih. Geprek serai menjadi 2 bagian."
- "Siapkan wajan, masukkan margarin dan nyalakan kompor. Tunggu hingga margarin meleleh."
- "Masukkan bawang putih dan serai, tumis hingga harum. Jangan sampai bawang putih gosong agar tidak pahit."
- "Masukkan tumisan bawang putih dan serai, serta daun jeruk ke dalam magic com. Tambahkan, garam dan penyedap rasa. Pencet tombol &#34;cook&#34; dari magic com."
- "Tunggu hingga matang. Nasi daun jeruk siap disajikan."
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 103 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT34M"
recipeyield: "4"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk](https://img-global.cpcdn.com/recipes/f10efa99e88e0416/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp)

6 langkah mudah dan cepat mengolah  Nasi Daun Jeruk cocok banget jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Untuk Menyiapkan Nasi Daun Jeruk:

1. Beras 2 gelas
1. Daun jeruk 15 lembar
1. Bawang putih 4 siung
1. Serai 1 batang
1. Penyedap rasa ayam 1/2 sdm
1. Garam 1/2 sdm
1. Margarin untuk menumis 1 sendok



<!--inarticleads2-->

## Cara Menyiapkan Nasi Daun Jeruk:

1. Masukkan beras ke dalam wadah magic com. Cuci beras sampai bersih lalu isi dengan 1 gelas air.
1. Potong tipis daun jeruk dan bawang putih. Geprek serai menjadi 2 bagian.
1. Siapkan wajan, masukkan margarin dan nyalakan kompor. Tunggu hingga margarin meleleh.
1. Masukkan bawang putih dan serai, tumis hingga harum. Jangan sampai bawang putih gosong agar tidak pahit.
1. Masukkan tumisan bawang putih dan serai, serta daun jeruk ke dalam magic com. Tambahkan, garam dan penyedap rasa. Pencet tombol &#34;cook&#34; dari magic com.
1. Tunggu hingga matang. Nasi daun jeruk siap disajikan.




Selamat memasak dan menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
