---
description: "Cara Gampang Membuat Nasi Daun Jeruk ayam sambal matah Anti Gagal"
title: "Cara Gampang Membuat Nasi Daun Jeruk ayam sambal matah Anti Gagal"
slug: 280-cara-gampang-membuat-nasi-daun-jeruk-ayam-sambal-matah-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-31T17:50:34.242Z 
thumbnail: https://img-global.cpcdn.com/recipes/fb3101302c737ec5/682x484cq65/nasi-daun-jeruk-ayam-sambal-matah-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/fb3101302c737ec5/682x484cq65/nasi-daun-jeruk-ayam-sambal-matah-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/fb3101302c737ec5/682x484cq65/nasi-daun-jeruk-ayam-sambal-matah-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/fb3101302c737ec5/682x484cq65/nasi-daun-jeruk-ayam-sambal-matah-foto-resep-utama.webp
author: Jose Hudson
ratingvalue: 3.9
reviewcount: 12
recipeingredient:
- "chicken karage fiesta bisa juga ayam buat sendiri 150 gram"
- "Nasi daun jeruk "
- "beras 300 gram"
- "santan 500 ml"
- "garam 1 sdt"
- "daun salam 2 lembar"
- "seraimemarkan 1 batang"
- "daun jerukbuang tulangnya 4 lbr"
- "daun jerukbuang tulangnya dan iris halus 15 lbr"
- "Sambal matah  "
- "bawang merahiris 5 siung"
- "cabai rawitiris 8 buah"
- "seraiiris 1 batang"
- "minyak kelapa 1 sdm"
- "daun jerukiris 1 lembar"
- "jeruk nipisair perasannya 1/2 sdt"
- "Garam secukupnya"
recipeinstructions:
- "Nasi daun jeruk : siapkan rice cooker,masukkan beras,santan,garam,daun salam,serai dan daun jeruk utuh"
- "Masak nasi hingga matang,lalu aduk sebentar untuk mengaroni,tambahkan irisan daun jeruk, dan aduk rata lagi."
- "Goreng ayam karage hingga kuning keemasan dan matang sisihkan."
- "Sambal matah : campur irisan bawang merah,cabai,serai, dan daun jeruk lalu beri perasan jeruk nipis,garam dan minyak kelapa,aduk hingga rata."
- "Siapkan nasi daun jeruk didalam mangkuk,tata rapi ayam karage yg sudah digoreng diatasnya. Siram sambal matah,taburi irisan daun jeruk,sajikan."
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 191 calories
recipecuisine: Indonesian
preptime: "PT20M"
cooktime: "PT53M"
recipeyield: "1"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk ayam sambal matah](https://img-global.cpcdn.com/recipes/fb3101302c737ec5/682x484cq65/nasi-daun-jeruk-ayam-sambal-matah-foto-resep-utama.webp)

Ingin membuat Nasi Daun Jeruk ayam sambal matah ? Coba resep berikut ini. Cara memasaknya sangat praktis namun jangan kaget jika hasilnya gurih dan lezat cocok banget jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Dalam Pembuatan Nasi Daun Jeruk ayam sambal matah:

1. chicken karage fiesta bisa juga ayam buat sendiri 150 gram
1. Nasi daun jeruk 
1. beras 300 gram
1. santan 500 ml
1. garam 1 sdt
1. daun salam 2 lembar
1. seraimemarkan 1 batang
1. daun jerukbuang tulangnya 4 lbr
1. daun jerukbuang tulangnya dan iris halus 15 lbr
1. Sambal matah  
1. bawang merahiris 5 siung
1. cabai rawitiris 8 buah
1. seraiiris 1 batang
1. minyak kelapa 1 sdm
1. daun jerukiris 1 lembar
1. jeruk nipisair perasannya 1/2 sdt
1. Garam secukupnya



<!--inarticleads2-->

## Cara Mudah Membuat Nasi Daun Jeruk ayam sambal matah:

1. Nasi daun jeruk : siapkan rice cooker,masukkan beras,santan,garam,daun salam,serai dan daun jeruk utuh
1. Masak nasi hingga matang,lalu aduk sebentar untuk mengaroni,tambahkan irisan daun jeruk, dan aduk rata lagi.
1. Goreng ayam karage hingga kuning keemasan dan matang sisihkan.
1. Sambal matah : campur irisan bawang merah,cabai,serai, dan daun jeruk lalu beri perasan jeruk nipis,garam dan minyak kelapa,aduk hingga rata.
1. Siapkan nasi daun jeruk didalam mangkuk,tata rapi ayam karage yg sudah digoreng diatasnya. Siram sambal matah,taburi irisan daun jeruk,sajikan.




Salah satu masakan yang cukup praktis dalam pembuatannya adalah  Nasi Daun Jeruk ayam sambal matah. Selain itu  Nasi Daun Jeruk ayam sambal matah  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu lakukan 5 langkah, dan  Nasi Daun Jeruk ayam sambal matah  pun siap di hidangkan. selamat mencoba !
