---
description: "Cara Gampang Menyiapkan Nasi Daun Jeruk Limau, Enak Banget"
title: "Cara Gampang Menyiapkan Nasi Daun Jeruk Limau, Enak Banget"
slug: 286-cara-gampang-menyiapkan-nasi-daun-jeruk-limau-enak-banget
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-02T19:36:58.992Z 
thumbnail: https://img-global.cpcdn.com/recipes/a3557c524b3daca2/682x484cq65/nasi-daun-jeruk-limau-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/a3557c524b3daca2/682x484cq65/nasi-daun-jeruk-limau-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/a3557c524b3daca2/682x484cq65/nasi-daun-jeruk-limau-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/a3557c524b3daca2/682x484cq65/nasi-daun-jeruk-limau-foto-resep-utama.webp
author: Kyle Byrd
ratingvalue: 3
reviewcount: 3
recipeingredient:
- "Beras Putih 3 cup"
- "Air "
- "Santan 500 mL"
- "Bumbu Tumis "
- "Minyak Goreng 1 sdt"
- "Margarin 1 sdm"
- "Daun Jeruk 10 lembar"
- "Serai dijembarkan 4 batang"
- "Daun Salam 2 lembar"
- "Bawang Merah 5 siung"
- "Bawang Putih 3 siung"
- "Garam 1 sdt"
- "Gula Pasir 1/2 sdt"
- "Royco saya pakai Rasa Ayam sedikit"
recipeinstructions:
- "Cuci bersih beras dan tiriskan di Panci Rice Cooker"
- "Iris halus daun jeruk, bawang merah, bawang putih"
- "Tumis semua bumbu dengan minyak dan margarin sampai harum"
- "Masukkan santan dan air secukupnya ke dalam Panci isi beras tadi"
- "Masukkan bumbu tumis yang sudah matang tadi"
- "Masak di penanak nasi seperti biasa selama kurang lebih 45 menit"
- "Setelah matang, sajikan nasi hangat dengan lauk yang ada"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 268 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT58M"
recipeyield: "3"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk Limau](https://img-global.cpcdn.com/recipes/a3557c524b3daca2/682x484cq65/nasi-daun-jeruk-limau-foto-resep-utama.webp)

7 langkah cepat dan mudah membuat  Nasi Daun Jeruk Limau yang musti ibu coba dirumah

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Dalam Menyiapkan Nasi Daun Jeruk Limau:

1. Beras Putih 3 cup
1. Air 
1. Santan 500 mL
1. Bumbu Tumis 
1. Minyak Goreng 1 sdt
1. Margarin 1 sdm
1. Daun Jeruk 10 lembar
1. Serai dijembarkan 4 batang
1. Daun Salam 2 lembar
1. Bawang Merah 5 siung
1. Bawang Putih 3 siung
1. Garam 1 sdt
1. Gula Pasir 1/2 sdt
1. Royco saya pakai Rasa Ayam sedikit



<!--inarticleads2-->

## Cara Menyiapkan Nasi Daun Jeruk Limau:

1. Cuci bersih beras dan tiriskan di Panci Rice Cooker
1. Iris halus daun jeruk, bawang merah, bawang putih
1. Tumis semua bumbu dengan minyak dan margarin sampai harum
1. Masukkan santan dan air secukupnya ke dalam Panci isi beras tadi
1. Masukkan bumbu tumis yang sudah matang tadi
1. Masak di penanak nasi seperti biasa selama kurang lebih 45 menit
1. Setelah matang, sajikan nasi hangat dengan lauk yang ada




Demikian informasi  resep Nasi Daun Jeruk Limau   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
