---
description: "Resep Nasi uduk betawi ala magicom Anti Gagal"
title: "Resep Nasi uduk betawi ala magicom Anti Gagal"
slug: 110-resep-nasi-uduk-betawi-ala-magicom-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-09T15:17:10.088Z 
thumbnail: https://img-global.cpcdn.com/recipes/120180c5302828a5/682x484cq65/nasi-uduk-betawi-ala-magicom-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/120180c5302828a5/682x484cq65/nasi-uduk-betawi-ala-magicom-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/120180c5302828a5/682x484cq65/nasi-uduk-betawi-ala-magicom-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/120180c5302828a5/682x484cq65/nasi-uduk-betawi-ala-magicom-foto-resep-utama.webp
author: Inez Nichols
ratingvalue: 3.7
reviewcount: 15
recipeingredient:
- "beras cuci bersih 750 gr"
- "Santan 2 sun kara kecil "
- "bawang merah 20 butir"
- "daun salam 2 lembar"
- "sereh geprek 2 batang"
- "jahe geprek 5 cm"
- "kerupuk 1/4 kg"
- "Minyak goreng "
recipeinstructions:
- "Masukkan beras,daun salam,sereh,jahe,santan ke dlm magicom beri air seperti biasa mau masak nasi.masak hingga matang.jangan lupa beri garam secukupnya"
- "Sementara itu iris bawang merah,kemudian cuci dan tiriskan"
- "Panaskan minyak goreng...setelah panas goreng irisan bawang merah hingga kuning kecoklatan.angkat tiriskan (ketika bawang setengah matang beri sejumput garam)"
- "Sisihkan minyak goreng yg dipakai utk menggoreng bawang tadi."
- "Setelah nasi matang,tggu sekitar 3 mnt kemudian aduk beri minyak bawang td,sedikit demi sedikit(kurleb 1 sendok sayur) sambil diaduk.lakukan sampai dirasa cukup (aq pakai sekitar 2 sendok sayur).tutup kembali dan diamkan"
- "Sajikan nasi uduk betawi + sambel kacang + taburan bawang goreng+kerupuk.....selamat menikmati"
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 102 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT45M"
recipeyield: "2"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi uduk betawi ala magicom](https://img-global.cpcdn.com/recipes/120180c5302828a5/682x484cq65/nasi-uduk-betawi-ala-magicom-foto-resep-utama.webp)

Resep rahasia dan cara memasak  Nasi uduk betawi ala magicom yang wajib ibu coba segera

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Dalam Pembuatan Nasi uduk betawi ala magicom:

1. beras cuci bersih 750 gr
1. Santan 2 sun kara kecil 
1. bawang merah 20 butir
1. daun salam 2 lembar
1. sereh geprek 2 batang
1. jahe geprek 5 cm
1. kerupuk 1/4 kg
1. Minyak goreng 

Ditambah ayam goreng atau lele goreng dengan sayuran lalapan membuat rasa nasi uduk menjadi bintang lima dengan Dengan uang kurang dari sepuluh ribu, anda bisa menikmati sensasi nasi uduk Betawi. Bikin nasi uduk sendiri untuk makan siang atau malam bisa pakai rice cooker. Memakai bumbu autentik Betawi kamu bisa menanak nasi sendiri dengan rice cooker. Ikuti petunjuk resep dan tips berikut ini. 

<!--inarticleads2-->

## Tata Cara Membuat Nasi uduk betawi ala magicom:

1. Masukkan beras,daun salam,sereh,jahe,santan ke dlm magicom beri air seperti biasa mau masak nasi.masak hingga matang.jangan lupa beri garam secukupnya
1. Sementara itu iris bawang merah,kemudian cuci dan tiriskan
1. Panaskan minyak goreng...setelah panas goreng irisan bawang merah hingga kuning kecoklatan.angkat tiriskan (ketika bawang setengah matang beri sejumput garam)
1. Sisihkan minyak goreng yg dipakai utk menggoreng bawang tadi.
1. Setelah nasi matang,tggu sekitar 3 mnt kemudian aduk beri minyak bawang td,sedikit demi sedikit(kurleb 1 sendok sayur) sambil diaduk.lakukan sampai dirasa cukup (aq pakai sekitar 2 sendok sayur).tutup kembali dan diamkan
1. Sajikan nasi uduk betawi + sambel kacang + taburan bawang goreng+kerupuk.....selamat menikmati


Nasi uduk can be served as breakfast, with a simple side dish of telur dadar gulung (rolled fried egg). It can also be served as lunch/dinner, typically Back in the days, cooking nasi uduk is just downright complicated. The rice needs to be half cooked in a pot on a stove, and then transfer to a steamer to. Make this easy and aromatic Betawi-style nasi uduk that goes with many main and side dishes. I&#39;m sharing how you can make it easily with a rice cooker but it can be cooked on the stove and Instant Pot too. 

Demikian informasi  resep Nasi uduk betawi ala magicom   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
