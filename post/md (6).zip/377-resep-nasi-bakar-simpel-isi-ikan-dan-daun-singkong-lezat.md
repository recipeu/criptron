---
description: "Resep Nasi Bakar Simpel Isi Ikan dan Daun Singkong, Lezat"
title: "Resep Nasi Bakar Simpel Isi Ikan dan Daun Singkong, Lezat"
slug: 377-resep-nasi-bakar-simpel-isi-ikan-dan-daun-singkong-lezat
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-03T08:40:19.048Z 
thumbnail: https://img-global.cpcdn.com/recipes/Recipe_2015_05_09_12_57_13_135_3c25e9fe28124bf6f81c/682x484cq65/nasi-bakar-simpel-isi-ikan-dan-daun-singkong-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/Recipe_2015_05_09_12_57_13_135_3c25e9fe28124bf6f81c/682x484cq65/nasi-bakar-simpel-isi-ikan-dan-daun-singkong-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/Recipe_2015_05_09_12_57_13_135_3c25e9fe28124bf6f81c/682x484cq65/nasi-bakar-simpel-isi-ikan-dan-daun-singkong-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/Recipe_2015_05_09_12_57_13_135_3c25e9fe28124bf6f81c/682x484cq65/nasi-bakar-simpel-isi-ikan-dan-daun-singkong-foto-resep-utama.webp
author: Earl Matthews
ratingvalue: 3.5
reviewcount: 6
recipeingredient:
- "Nasi putih secukupnya"
- "Daun pisang secukupnya"
- "ikan tuna ditiriskan dan disuwir2 1 kaleng"
- "daun singkong 2 ikat"
- "bawang bombay dicincang 1/2 siung"
- "bawang putih dicincang halus 2 siung"
- "cabe merah besar diiris 6 buah"
- "gula pasir 1 sdt"
- "garam 1 sdt"
- "kaldu 1 sdt"
- "daun kemangi 1 ikat"
- "cabe rawit secukupnya"
recipeinstructions:
- "Rebus daun singkong dalam air mendidih dan sedikit garam hingga lunak. Setelah matang dan dingin, daun singkong dibentuk bola2 dan diiris kecil2. Sisihkan."
- "Tumis bawang hingga harum, lalu masukkan cabe, ikan, daun singkong rebus. Tambahkan gula, garam, dan kaldu bubuk. Aduk rata dan cicipi. Sisihkan."
- "Siapkan lembaran daun pisang, dan letakkan nasi putih dgn takaran sesuai selera. Di atas nasi diberi daun kemangi, cabe rawit, dan tumisan ikan. Tutup lagi dengan nasi putih."
- "Bungkus nasi dengan daun pisang dan semat ujungnya dengan lidi."
- "Oles tipis bagian luar daun pisang dengan minyak goreng agar permukaan daun tidak pecah saat pembakaran."
- "Bakar dengan api sedang sambil dibolak-balik. Angkat bila permukaan daun pisang sudah berubah warna menjadi coklat kehitaman (agak hangus)."
- "Sajikan hangat-hangat."
categories:
- Resep
tags:
- nasi
- bakar
- simpel

katakunci: nasi bakar simpel 
nutrition: 210 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT47M"
recipeyield: "3"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Bakar Simpel Isi Ikan dan Daun Singkong](https://img-global.cpcdn.com/recipes/Recipe_2015_05_09_12_57_13_135_3c25e9fe28124bf6f81c/682x484cq65/nasi-bakar-simpel-isi-ikan-dan-daun-singkong-foto-resep-utama.webp)

Resep rahasia Nasi Bakar Simpel Isi Ikan dan Daun Singkong  sederhana dengan 7 langkahmudah dan cepat yang musti kamu coba dirumah

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Dalam Menyiapkan Nasi Bakar Simpel Isi Ikan dan Daun Singkong:

1. Nasi putih secukupnya
1. Daun pisang secukupnya
1. ikan tuna ditiriskan dan disuwir2 1 kaleng
1. daun singkong 2 ikat
1. bawang bombay dicincang 1/2 siung
1. bawang putih dicincang halus 2 siung
1. cabe merah besar diiris 6 buah
1. gula pasir 1 sdt
1. garam 1 sdt
1. kaldu 1 sdt
1. daun kemangi 1 ikat
1. cabe rawit secukupnya



<!--inarticleads2-->

## Cara Menyiapkan Nasi Bakar Simpel Isi Ikan dan Daun Singkong:

1. Rebus daun singkong dalam air mendidih dan sedikit garam hingga lunak. Setelah matang dan dingin, daun singkong dibentuk bola2 dan diiris kecil2. Sisihkan.
1. Tumis bawang hingga harum, lalu masukkan cabe, ikan, daun singkong rebus. Tambahkan gula, garam, dan kaldu bubuk. Aduk rata dan cicipi. Sisihkan.
1. Siapkan lembaran daun pisang, dan letakkan nasi putih dgn takaran sesuai selera. Di atas nasi diberi daun kemangi, cabe rawit, dan tumisan ikan. Tutup lagi dengan nasi putih.
1. Bungkus nasi dengan daun pisang dan semat ujungnya dengan lidi.
1. Oles tipis bagian luar daun pisang dengan minyak goreng agar permukaan daun tidak pecah saat pembakaran.
1. Bakar dengan api sedang sambil dibolak-balik. Angkat bila permukaan daun pisang sudah berubah warna menjadi coklat kehitaman (agak hangus).
1. Sajikan hangat-hangat.




Demikian informasi  resep Nasi Bakar Simpel Isi Ikan dan Daun Singkong   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
