---
description: "Cara Gampang Membuat Soto Ayam Semarang yang Sempurna"
title: "Cara Gampang Membuat Soto Ayam Semarang yang Sempurna"
slug: 482-cara-gampang-membuat-soto-ayam-semarang-yang-sempurna
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-17T03:47:36.889Z 
thumbnail: https://img-global.cpcdn.com/recipes/7bcd2402dbdc7d83/682x484cq65/soto-ayam-semarang-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/7bcd2402dbdc7d83/682x484cq65/soto-ayam-semarang-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/7bcd2402dbdc7d83/682x484cq65/soto-ayam-semarang-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/7bcd2402dbdc7d83/682x484cq65/soto-ayam-semarang-foto-resep-utama.webp
author: Rachel Johnston
ratingvalue: 4.9
reviewcount: 12
recipeingredient:
- "Kuah kaldu  "
- "sayap ayam 250 gr"
- "air 1,5 liter"
- "sereh 1 batang"
- "daun jeruk 2 lembar"
- "daun salam 2 lembar"
- "Bumbu halus  "
- "bawang merah 5 siung"
- "bawang putih 3 siung"
- "jahe 2 ruas"
- "garam 1,5 sdt"
- "kaldu 1 sdt"
- "lada 1 sdt"
- "gula pasir 1,5 sdt"
- "Bumbu cemplung  "
- "kayu manis 4 cm"
- "jinten 1/2 sdt"
- "cengkeh 6 butir"
- "Pelengkap  "
- "Nasi putih "
- "Bawang putih goreng "
- "Tauge rebus "
- "Daun bawangseledri iris halus "
- "Sate telur puyuh           lihat resep "
- "Perkedel kentang           lihat resep "
- "Sambal "
- "Kecap manis "
- "Jeruk nipis "
recipeinstructions:
- "Siapkan semua bahan dan bumbu,"
- "Didihkan air rebus ayam bersama sereh, daun salam dan daun jeruk"
- "Haluskan bumbu, tumis hingga harum dan matang. Masukkan dalam kuah kaldu"
- "Tambahkan bumbu cemplung, koreksi rasa. Siapkan semua bahan pelengkap"
- "Penyajian : tata semua bahan pelengkap dalam mangkuk saji, siram kuah kaldu. Tabur dengan bawang putih goreng, seledri+daun bawang. Sajikan segera           (lihat resep)"
categories:
- Resep
tags:
- soto
- ayam
- semarang

katakunci: soto ayam semarang 
nutrition: 219 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT53M"
recipeyield: "3"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Soto Ayam Semarang](https://img-global.cpcdn.com/recipes/7bcd2402dbdc7d83/682x484cq65/soto-ayam-semarang-foto-resep-utama.webp)

5 langkah mudah dan cepat membuat  Soto Ayam Semarang yang wajib kamu coba dirumah

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Dalam Pembuatan Soto Ayam Semarang:

1. Kuah kaldu  
1. sayap ayam 250 gr
1. air 1,5 liter
1. sereh 1 batang
1. daun jeruk 2 lembar
1. daun salam 2 lembar
1. Bumbu halus  
1. bawang merah 5 siung
1. bawang putih 3 siung
1. jahe 2 ruas
1. garam 1,5 sdt
1. kaldu 1 sdt
1. lada 1 sdt
1. gula pasir 1,5 sdt
1. Bumbu cemplung  
1. kayu manis 4 cm
1. jinten 1/2 sdt
1. cengkeh 6 butir
1. Pelengkap  
1. Nasi putih 
1. Bawang putih goreng 
1. Tauge rebus 
1. Daun bawangseledri iris halus 
1. Sate telur puyuh           lihat resep 
1. Perkedel kentang           lihat resep 
1. Sambal 
1. Kecap manis 
1. Jeruk nipis 



<!--inarticleads2-->

## Langkah-langkah Untuk Menyiapkan Soto Ayam Semarang:

1. Siapkan semua bahan dan bumbu,
1. Didihkan air rebus ayam bersama sereh, daun salam dan daun jeruk
1. Haluskan bumbu, tumis hingga harum dan matang. Masukkan dalam kuah kaldu
1. Tambahkan bumbu cemplung, koreksi rasa. Siapkan semua bahan pelengkap
1. Penyajian : tata semua bahan pelengkap dalam mangkuk saji, siram kuah kaldu. Tabur dengan bawang putih goreng, seledri+daun bawang. Sajikan segera -           (lihat resep)




Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
