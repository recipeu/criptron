---
description: "Cara Gampang Menyiapkan Nasi Daun Jeruk, Lezat"
title: "Cara Gampang Menyiapkan Nasi Daun Jeruk, Lezat"
slug: 316-cara-gampang-menyiapkan-nasi-daun-jeruk-lezat
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-16T04:30:15.613Z 
thumbnail: https://img-global.cpcdn.com/recipes/bc5265d9a35f285d/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/bc5265d9a35f285d/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/bc5265d9a35f285d/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/bc5265d9a35f285d/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
author: Austin Obrien
ratingvalue: 3.5
reviewcount: 10
recipeingredient:
- "beras 250 gram"
- "daun jeruk buang tulangnya lalu iris tipis tipis 10 lembar"
- "serai digeprek dulu 2 batang"
- "penyedap rasa saya pakai royco ayam 1 sdm"
- "garam 1/2 sdt"
- "santan 200 ml"
- "air secukupnya"
recipeinstructions:
- "Cuci bersih beras, masukkan irisan daun jeruk, serai yang sudah digeprek, penyedap rasa, garam, santan dan air secukupnya"
- "Masukkan ke dalam magic com lalu masak hingga matang"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 107 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT38M"
recipeyield: "1"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk](https://img-global.cpcdn.com/recipes/bc5265d9a35f285d/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp)

2 langkah cepat dan mudah memasak  Nasi Daun Jeruk cocok banget jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Dalam Pembuatan Nasi Daun Jeruk:

1. beras 250 gram
1. daun jeruk buang tulangnya lalu iris tipis tipis 10 lembar
1. serai digeprek dulu 2 batang
1. penyedap rasa saya pakai royco ayam 1 sdm
1. garam 1/2 sdt
1. santan 200 ml
1. air secukupnya

Nasi daun jeruk siap dihidangkan dengan. Nasi daun jeruk ini memang sedang tren di kalangan masyarakat Indonesia, banyak sekali kaum muda mudi yang berlomba-lomba membuat makanan nasi putih spesial ini. Nasi daun jeruk ala geprek bensu rekomended buat di coba. Geprek bensu nasi daun jeruk anti mainst. 

<!--inarticleads2-->

## Langkah-langkah Untuk Membuat Nasi Daun Jeruk:

1. Cuci bersih beras, masukkan irisan daun jeruk, serai yang sudah digeprek, penyedap rasa, garam, santan dan air secukupnya
1. Masukkan ke dalam magic com lalu masak hingga matang


Gurih dan wangi dari daun jeruk menambah kelezatan nasi daun jeruk. Nasi dengan campuran daun jeruk yang wangi sedang tren. Hai selamat pagi sahabat CWS, pagi ini saya share resep Nasi Daun Jeruk. Praktis banget karena saya gunakan rice cooker. Rasanya mirip nasi uduk tapi wangiiii. 

Terima kasih telah menggunakan resep yang tim kami tampilkan di sini. Selamat mencoba!
