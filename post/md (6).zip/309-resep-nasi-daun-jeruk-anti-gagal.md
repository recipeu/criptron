---
description: "Resep Nasi Daun Jeruk Anti Gagal"
title: "Resep Nasi Daun Jeruk Anti Gagal"
slug: 309-resep-nasi-daun-jeruk-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-28T08:08:23.436Z 
thumbnail: https://img-global.cpcdn.com/recipes/9948596f08c1db64/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/9948596f08c1db64/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/9948596f08c1db64/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/9948596f08c1db64/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
author: Peter Roberson
ratingvalue: 3.1
reviewcount: 5
recipeingredient:
- "beras jumlahnya tergantung dengan kebutuhan masingmasing yaa 2 1/2 cup"
- "daun salam 2 lembar"
- "daun pandan potong menjadi lebih kecilikat simpul 1 helai"
- "daun jeruk buang tulangnya dan iris tipis 10-15"
- "serai ukuran besar ambil bagian putihnya dan memarkan 1 buah"
- "lengkuas memarkan 2 ruas"
- "santan instan 65 ml"
- "garam atau sesuai selera 1 sdt"
- "Air secukupnya untuk memasak nasi seperti biasa hasil nasi jangan lembek pulen tapi tetap terpisah bulirnya "
recipeinstructions:
- "Cuci bersih beras"
- "Masukkan semua bahan nasi uduk jadi satu di dalam rice cooker"
- "Tuang air secukupnya seperti memasak nasi biasanya, aduk rata. (hasil nasi daun jeruk yang pas adalah nasinya pulen tapi tidak lembek, bulir nasinya masih terpisah satu sama lain). Masak nasi seperti biasa (bisa menggunakan rice cooker atau panci, kali ini saya menggunakan rice cooker)"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 260 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT32M"
recipeyield: "1"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk](https://img-global.cpcdn.com/recipes/9948596f08c1db64/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp)

Resep Nasi Daun Jeruk  anti gagal dengan 3 langkahmudah dan cepat yang wajib ibu coba dirumah

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Dalam Menyiapkan Nasi Daun Jeruk:

1. beras jumlahnya tergantung dengan kebutuhan masingmasing yaa 2 1/2 cup
1. daun salam 2 lembar
1. daun pandan potong menjadi lebih kecilikat simpul 1 helai
1. daun jeruk buang tulangnya dan iris tipis 10-15
1. serai ukuran besar ambil bagian putihnya dan memarkan 1 buah
1. lengkuas memarkan 2 ruas
1. santan instan 65 ml
1. garam atau sesuai selera 1 sdt
1. Air secukupnya untuk memasak nasi seperti biasa hasil nasi jangan lembek pulen tapi tetap terpisah bulirnya 

Nasi daun jeruk siap dihidangkan dengan. Nasi daun jeruk ini memang sedang tren di kalangan masyarakat Indonesia, banyak sekali kaum muda mudi yang berlomba-lomba membuat makanan nasi putih spesial ini. Nasi daun jeruk ala geprek bensu rekomended buat di coba. Geprek bensu nasi daun jeruk anti mainst. 

<!--inarticleads2-->

## Cara Mudah Membuat Nasi Daun Jeruk:

1. Cuci bersih beras
1. Masukkan semua bahan nasi uduk jadi satu di dalam rice cooker
1. Tuang air secukupnya seperti memasak nasi biasanya, aduk rata. (hasil nasi daun jeruk yang pas adalah nasinya pulen tapi tidak lembek, bulir nasinya masih terpisah satu sama lain). Masak nasi seperti biasa (bisa menggunakan rice cooker atau panci, kali ini saya menggunakan rice cooker)


Gurih dan wangi dari daun jeruk menambah kelezatan nasi daun jeruk. Nasi dengan campuran daun jeruk yang wangi sedang tren. Hai selamat pagi sahabat CWS, pagi ini saya share resep Nasi Daun Jeruk. Praktis banget karena saya gunakan rice cooker. Rasanya mirip nasi uduk tapi wangiiii. 

Daripada kamu beli  Nasi Daun Jeruk  diluar terus, ibu  bisa membuatnya sendiri dirumah. Resep  Nasi Daun Jeruk  sederhana ini cukup praktis pembuatannya, cukup menggunakan bumbu-bumbu sederhana yang ada di dapur  Nasi Daun Jeruk  yang enak, ibu nikmati di rumah.
