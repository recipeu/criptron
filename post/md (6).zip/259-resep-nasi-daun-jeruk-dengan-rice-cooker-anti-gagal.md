---
description: "Resep Nasi daun jeruk (dengan rice cooker) Anti Gagal"
title: "Resep Nasi daun jeruk (dengan rice cooker) Anti Gagal"
slug: 259-resep-nasi-daun-jeruk-dengan-rice-cooker-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2022-01-05T16:27:52.856Z 
thumbnail: https://img-global.cpcdn.com/recipes/574ab218a04931b6/682x484cq65/nasi-daun-jeruk-dengan-rice-cooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/574ab218a04931b6/682x484cq65/nasi-daun-jeruk-dengan-rice-cooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/574ab218a04931b6/682x484cq65/nasi-daun-jeruk-dengan-rice-cooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/574ab218a04931b6/682x484cq65/nasi-daun-jeruk-dengan-rice-cooker-foto-resep-utama.webp
author: Wayne Taylor
ratingvalue: 3.9
reviewcount: 12
recipeingredient:
- "beras cuci bersih dan tiriskan 2 cup"
- "bawput iris cincang 4 btr"
- "cabe keriting buang biji dan iris halus 3 bh"
- "daun jeruk purut buang batang dan iris halus 16 lembar"
- "mentega untuk tumis 2 sdm"
- "air untuk memasak nasi 2 cup"
- "gula  garam untuk rasa Secukupnya"
recipeinstructions:
- "Siapkan bahan2 untuk tumis."
- "Tumis bahan2 langsung di rice cooker, masukkan beras dan air sesuai jenis beras ya, tp kurangin sedikit airnya. Masak seperti masak nasi biasa di rice cooker, setelah matang, aduk2 sebentar dan biarkan masak hingga 10 menit lagi baru matikan. Siap disajikan."
- "Nasi daun jeruk siap dihidangkan. Selamat mencoba!"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 152 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT32M"
recipeyield: "3"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi daun jeruk (dengan rice cooker)](https://img-global.cpcdn.com/recipes/574ab218a04931b6/682x484cq65/nasi-daun-jeruk-dengan-rice-cooker-foto-resep-utama.webp)

Resep dan cara mengolah  Nasi daun jeruk (dengan rice cooker) yang bisa bunda coba segera

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Dalam Pembuatan Nasi daun jeruk (dengan rice cooker):

1. beras cuci bersih dan tiriskan 2 cup
1. bawput iris cincang 4 btr
1. cabe keriting buang biji dan iris halus 3 bh
1. daun jeruk purut buang batang dan iris halus 16 lembar
1. mentega untuk tumis 2 sdm
1. air untuk memasak nasi 2 cup
1. gula  garam untuk rasa Secukupnya

Nasi daun jeruk ini perpaduan antara nasi liwet dan nasi gurih dengan wangi daun jeruk yang dominan. Untuk mempermudah pembuatannya, kali ini saya membuat nasi daun jeruk menggunakan rice cooker. Campurkan beras dengan daun jeruk, teri nasi, ebi, dan minyak sayur. Tambahkan air, masukan batang serai dan daun salam. 

<!--inarticleads2-->

## Cara Mudah Menyiapkan Nasi daun jeruk (dengan rice cooker):

1. Siapkan bahan2 untuk tumis.
1. Tumis bahan2 langsung di rice cooker, masukkan beras dan air sesuai jenis beras ya, tp kurangin sedikit airnya. Masak seperti masak nasi biasa di rice cooker, setelah matang, aduk2 sebentar dan biarkan masak hingga 10 menit lagi baru matikan. Siap disajikan.
1. Nasi daun jeruk siap dihidangkan. Selamat mencoba!


Masak dengan rice cooker hingga matak sempurna. Nasi gurih daun jeruk siap dihidangkan. Nasi daun jeruk harum dengan cita rasa santan dan teri lezat nggak perlu repot dibuat. Pakai rice cooker yang ada di rumah. Inilah cara membuat nasi liwet yang nikmat dengan menggunakan rice cooker atau penanak nasi. 

Terima kasih telah membaca resep yang kami tampilkan di halaman ini. Semoga bermanfaat dan selamat mencoba!
