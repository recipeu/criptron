---
description: "Resep Nasi uduk jakarta, Lezat"
title: "Resep Nasi uduk jakarta, Lezat"
slug: 8-resep-nasi-uduk-jakarta-lezat
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-25T18:17:49.484Z 
thumbnail: https://img-global.cpcdn.com/recipes/fe4689b834d654fa/682x484cq65/nasi-uduk-jakarta-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/fe4689b834d654fa/682x484cq65/nasi-uduk-jakarta-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/fe4689b834d654fa/682x484cq65/nasi-uduk-jakarta-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/fe4689b834d654fa/682x484cq65/nasi-uduk-jakarta-foto-resep-utama.webp
author: Evelyn Washington
ratingvalue: 4.3
reviewcount: 12
recipeingredient:
- "beras 1/2 liter"
- "santan  liter santan kental   santan cair 750 liter"
- "cengkeh 5 butir"
- "serai 2 batang"
- "besar daun salam 3 lembar"
- "garam 1 sdt"
- "penyedapkaldu bubuk 1/2 sdt"
- "Pelengkap "
- "Perkedel kentang "
- "Tumis bihun kecap "
- "Sambal goreng kentang hati "
- "Tahu dan telur bacem "
- "Empal goreng "
- "Kerupuk udang "
- "Bawang goreng "
recipeinstructions:
- "Cuci beras. Panaskan kukusan, masukan beras setelah air mendidih."
- "Kukus beras selama 15-20 menit tergantung api yang di gunakan, saya menggunakan api besar."
- "Setelah beras di kukus selama 20 menit, panaskan santan dan semua bahan lainnya dengan api kecil hingga mendidih. Jangan lupa di aduk terus menerus."
- "Setelah santan mendidih, matikan api lalu pindahkan semua beras kedalam air santan, dan rendam selama 15 menit sampai santan meresap semua kedalam beras."
- "Panaskan kukusan, setelah mendidih kukus beras yang telah di rendam santan. Jangan lupa di aduk sesekali jangan terlalu sering. Masak hingga beras menjadi nasi."
- "Selesai. Hidangkan dengan lauk sesukaan kalian. Jangan lupa recook dan tag saya yaaa Ig di bio"
categories:
- Resep
tags:
- nasi
- uduk
- jakarta

katakunci: nasi uduk jakarta 
nutrition: 155 calories
recipecuisine: Indonesian
preptime: "PT36M"
cooktime: "PT52M"
recipeyield: "1"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi uduk jakarta](https://img-global.cpcdn.com/recipes/fe4689b834d654fa/682x484cq65/nasi-uduk-jakarta-foto-resep-utama.webp)

Resep rahasia Nasi uduk jakarta  enak dengan 6 langkahmudah cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Dibutuhkan Dalam Menyiapkan Nasi uduk jakarta:

1. beras 1/2 liter
1. santan  liter santan kental   santan cair 750 liter
1. cengkeh 5 butir
1. serai 2 batang
1. besar daun salam 3 lembar
1. garam 1 sdt
1. penyedapkaldu bubuk 1/2 sdt
1. Pelengkap 
1. Perkedel kentang 
1. Tumis bihun kecap 
1. Sambal goreng kentang hati 
1. Tahu dan telur bacem 
1. Empal goreng 
1. Kerupuk udang 
1. Bawang goreng 

Di sini banyak warung nasi uduk Jakarta yang terkenal lezat. Dari sekian banyak menu khas Betawi, nasi uduk termasuk salah satu yang jadi favoritnya warga ibu kota. Di seluruh pelosok Jakarta kamu bisa mencari nasi uduk paling top di spot-spot berikut. See Nasi Uduk, Jakarta Utara on the map. 

<!--inarticleads2-->

## Langkah-langkah Untuk Menyiapkan Nasi uduk jakarta:

1. Cuci beras. Panaskan kukusan, masukan beras setelah air mendidih.
1. Kukus beras selama 15-20 menit tergantung api yang di gunakan, saya menggunakan api besar.
1. Setelah beras di kukus selama 20 menit, panaskan santan dan semua bahan lainnya dengan api kecil hingga mendidih. Jangan lupa di aduk terus menerus.
1. Setelah santan mendidih, matikan api lalu pindahkan semua beras kedalam air santan, dan rendam selama 15 menit sampai santan meresap semua kedalam beras.
1. Panaskan kukusan, setelah mendidih kukus beras yang telah di rendam santan. Jangan lupa di aduk sesekali jangan terlalu sering. Masak hingga beras menjadi nasi.
1. Selesai. Hidangkan dengan lauk sesukaan kalian. - Jangan lupa recook dan tag saya yaaa - Ig di bio


Nasi uduk yang satu ini rasanya pulen dengan aroma wangi balutan daun. Get food delivery from Nasi Uduk Gondangdia in Jakarta - ⏰ hours, phone number, address and map. On Trip.com, you can find out the best food and drinks of Nasi Uduk Gondangdia in JakartaJakarta. NASI UDUK Ayam Goreng Jakarta ini enak banget. Nasi Uduk Betawi is an Indonesian Betawi style of coconut rice. 

Salah satu kuliner yang cukup praktis pembuatannya adalah  Nasi uduk jakarta. Selain itu  Nasi uduk jakarta  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu ikuti 6 langkah, dan  Nasi uduk jakarta  pun siap di hidangkan. selamat mencoba !
