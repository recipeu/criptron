---
description: "Bagaimana Menyiapkan Nasi ayam Semarang, Menggugah Selera"
title: "Bagaimana Menyiapkan Nasi ayam Semarang, Menggugah Selera"
slug: 465-bagaimana-menyiapkan-nasi-ayam-semarang-menggugah-selera
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-28T09:11:23.760Z 
thumbnail: https://img-global.cpcdn.com/recipes/99d3fbc17c8e47e6/682x484cq65/nasi-ayam-semarang-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/99d3fbc17c8e47e6/682x484cq65/nasi-ayam-semarang-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/99d3fbc17c8e47e6/682x484cq65/nasi-ayam-semarang-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/99d3fbc17c8e47e6/682x484cq65/nasi-ayam-semarang-foto-resep-utama.webp
author: Lilly Hawkins
ratingvalue: 4.2
reviewcount: 9
recipeingredient:
- "1 Nasi uduk  "
- "httpscookpadcomidresep12228113nasilemaknasiudukrice "
- "2 A Bahan kuah labu jipanglabu Siam  "
- "labu Jipang potong korek api 1 bh"
- "garam 1 sdm"
- "kaldu jamur bubuk 2 sdm"
- "gula 2 sdm"
- "air sesuai selera kekentalan Secukupnya"
- "santan kental 250 ml"
- "santan cair 120 ml"
- "B Bumbu halus  "
- "bawang merah 4 siung"
- "bawang putih 2 siung"
- "kemiri 1 butir"
- "cabe merah 5 bh"
- "cabe rawit setan 2 bh"
- "C Bumbu tambahan  "
- "cabe rawit dan 2 cabe setan untuk di cemplungin 5 bh"
- "lengkuas geprek Seruas"
- "daun jeruk 2 lbr"
- "daun salam 2 lbr"
- "serei 1 btg"
- "3 A Bahan kuah krecekrambak  "
- "kerupuk rambak patahkan jadi potongan2 kecil 75 gr"
- "santan me  200santan instantair 800 ml"
- "garam 1 sdm"
- "kaldu jamur 2 sdm"
- "gula 2 sdm"
- "gula merahbrown sugar 50 gr"
- "B Bumbu halus  "
- "bawang merah 8 siung"
- "bawang putih 4 siung"
- "terasi sachet 1 bh"
- "cabe merah 10 bh"
- "cabe rawit setan 3 bh"
- "C Bumbu tambahan  "
- "daun salam 2 lbr"
- "lengkuas 2 ruas"
- "cabe rawit hijau dan merah 15 bh"
- "4 bahan opor ayam  "
- "opor ayam isntant indofd 1 sachet"
- "ayam potong sesuai selera 1/2 kg"
- "kunyit 1/4 sdt"
- "santan kental 4 sdm"
- "air klo tdk suka kental boleh di tambah 500 ml"
- "garam 1 sdt"
- "kaldu jamur 2 sdt"
- "gula 2 sdt"
- "5 Menu Pendamping  "
- "Telur kecappindang "
- "Tahu kecap "
recipeinstructions:
- "Ini nasi uduknya yang udah jadi. Resep nasi uduk : https://cookpad.com/id/resep/12228113-nasi-lemak-nasi-uduk-rice-cooker-ala-upin-ipin%F0%9F%98%81%F0%9F%98%81%F0%9F%98%81?invite_token=ZrXMqQYjeEsv18jTB6UhgRhk&amp;shared_at=1596504303"
- "Buat kuah labu jipangnya. Blender smua bumbu halus, tumis2 hingga harum, masukkan lengkuas,daun salam,daun jeruk,serei,cabe rawit, aduk sbntr lanjut masukkan labu jipang, aduk merata, tambahkan air sedikit, tumis hingga agak layu baru masukkan santan cair. tunggu mendidih baru masukkan santan kental. Aduk terus jangan sampai santan pecah. Kemudian masukkan garam,gula,kaldu jamur bubuk, test rasa. Tunggu hingga mendidih kembali baru tutup api. Angkat dan sisihkan."
- "Buat kuah krecek. Blender smua bumbu halus, tumis bersamaan dengan lengkuas dan daun salam. Kemudian masukkan santan, aduk sbntr hingga merata, kemudian masukkan rambak, masak hingga rambak mulai lunak, kemudian tambahkan garam,gula merah,gula pasir,kaldu jamur bubuk dan cabe rawit. Test rasa. Kalo udah pas rasanya dan rambak&#39;nya udah lunak, Angkat dan sisihkan."
- "Buat opor ayamnya. Tumis bumbu sachet opor ayamnya, kemudian masukkan ayamnya, aduk2 merata hingga ayam berubah warna baru masukin air dan bubuk kunyit, Tunggu hingga mendidih baru masukin Santan kental, aduk2 terus supaya santannya bagus, kemudian masukin garam,gula dan kaldu jamur bubuk. Test rasa. Tunggu hingga kuah mendidih kembali baru tutup api dan angkat. Pisahkan kuah opor dan ayamnya, daging ayam&#39;nya di suir2."
- "Sajikan nasi ayam Semarang dengan suiran ayam,labu jipang,rambak,telur dan tahu kecap, siram dengan kuah opor dan sedikit kuah rambak dan kuah labu jipang. Nikmat dinikmati selagi panas dengan kerupuk terung 😁😁😁. Selamat mencoba 🙏🙏🤗🤗🥰🥰💪💪"
- "Akan jauh lebih sedap kalo dimakan dengan alas daun pisang..hihihiii...😁😁😁"
categories:
- Resep
tags:
- nasi
- ayam
- semarang

katakunci: nasi ayam semarang 
nutrition: 297 calories
recipecuisine: Indonesian
preptime: "PT11M"
cooktime: "PT50M"
recipeyield: "2"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi ayam Semarang](https://img-global.cpcdn.com/recipes/99d3fbc17c8e47e6/682x484cq65/nasi-ayam-semarang-foto-resep-utama.webp)

6 langkah mudah dan cepat mengolah  Nasi ayam Semarang yang harus bunda coba dirumah

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Untuk Pembuatan Nasi ayam Semarang:

1. 1 Nasi uduk  
1. httpscookpadcomidresep12228113nasilemaknasiudukrice 
1. 2 A Bahan kuah labu jipanglabu Siam  
1. labu Jipang potong korek api 1 bh
1. garam 1 sdm
1. kaldu jamur bubuk 2 sdm
1. gula 2 sdm
1. air sesuai selera kekentalan Secukupnya
1. santan kental 250 ml
1. santan cair 120 ml
1. B Bumbu halus  
1. bawang merah 4 siung
1. bawang putih 2 siung
1. kemiri 1 butir
1. cabe merah 5 bh
1. cabe rawit setan 2 bh
1. C Bumbu tambahan  
1. cabe rawit dan 2 cabe setan untuk di cemplungin 5 bh
1. lengkuas geprek Seruas
1. daun jeruk 2 lbr
1. daun salam 2 lbr
1. serei 1 btg
1. 3 A Bahan kuah krecekrambak  
1. kerupuk rambak patahkan jadi potongan2 kecil 75 gr
1. santan me  200santan instantair 800 ml
1. garam 1 sdm
1. kaldu jamur 2 sdm
1. gula 2 sdm
1. gula merahbrown sugar 50 gr
1. B Bumbu halus  
1. bawang merah 8 siung
1. bawang putih 4 siung
1. terasi sachet 1 bh
1. cabe merah 10 bh
1. cabe rawit setan 3 bh
1. C Bumbu tambahan  
1. daun salam 2 lbr
1. lengkuas 2 ruas
1. cabe rawit hijau dan merah 15 bh
1. 4 bahan opor ayam  
1. opor ayam isntant indofd 1 sachet
1. ayam potong sesuai selera 1/2 kg
1. kunyit 1/4 sdt
1. santan kental 4 sdm
1. air klo tdk suka kental boleh di tambah 500 ml
1. garam 1 sdt
1. kaldu jamur 2 sdt
1. gula 2 sdt
1. 5 Menu Pendamping  
1. Telur kecappindang 
1. Tahu kecap 

Semarang jangan lupa Baca juga Kumpulan Pin BB Artis Indonesia Terbaru. Jawa Tengah, Kota Magelang, Kota Pekalongan, Kota Salatiga, Kota Semarang, Kota Surakarta, Kota Tegal. Nasi ayam menyajikan citarasa gurih yang cukup pekat karena disiram kuah opor. Pasti rugi, deh kalau ke Semarang kalian gak icip kuliner nasi ayam ini. 

<!--inarticleads2-->

## Tata Cara Membuat Nasi ayam Semarang:

1. Ini nasi uduknya yang udah jadi. Resep nasi uduk : https://cookpad.com/id/resep/12228113-nasi-lemak-nasi-uduk-rice-cooker-ala-upin-ipin%F0%9F%98%81%F0%9F%98%81%F0%9F%98%81?invite_token=ZrXMqQYjeEsv18jTB6UhgRhk&amp;shared_at=1596504303
1. Buat kuah labu jipangnya. Blender smua bumbu halus, tumis2 hingga harum, masukkan lengkuas,daun salam,daun jeruk,serei,cabe rawit, aduk sbntr lanjut masukkan labu jipang, aduk merata, tambahkan air sedikit, tumis hingga agak layu baru masukkan santan cair. tunggu mendidih baru masukkan santan kental. Aduk terus jangan sampai santan pecah. Kemudian masukkan garam,gula,kaldu jamur bubuk, test rasa. Tunggu hingga mendidih kembali baru tutup api. Angkat dan sisihkan.
1. Buat kuah krecek. Blender smua bumbu halus, tumis bersamaan dengan lengkuas dan daun salam. Kemudian masukkan santan, aduk sbntr hingga merata, kemudian masukkan rambak, masak hingga rambak mulai lunak, kemudian tambahkan garam,gula merah,gula pasir,kaldu jamur bubuk dan cabe rawit. Test rasa. Kalo udah pas rasanya dan rambak&#39;nya udah lunak, Angkat dan sisihkan.
1. Buat opor ayamnya. Tumis bumbu sachet opor ayamnya, kemudian masukkan ayamnya, aduk2 merata hingga ayam berubah warna baru masukin air dan bubuk kunyit, Tunggu hingga mendidih baru masukin Santan kental, aduk2 terus supaya santannya bagus, kemudian masukin garam,gula dan kaldu jamur bubuk. Test rasa. Tunggu hingga kuah mendidih kembali baru tutup api dan angkat. Pisahkan kuah opor dan ayamnya, daging ayam&#39;nya di suir2.
1. Sajikan nasi ayam Semarang dengan suiran ayam,labu jipang,rambak,telur dan tahu kecap, siram dengan kuah opor dan sedikit kuah rambak dan kuah labu jipang. Nikmat dinikmati selagi panas dengan kerupuk terung 😁😁😁. Selamat mencoba 🙏🙏🤗🤗🥰🥰💪💪
1. Akan jauh lebih sedap kalo dimakan dengan alas daun pisang..hihihiii...😁😁😁


You can choose to buy it spicy or not. The skewers were also good This is a very good Nasi Ayam, the best in Semarang. The portion of vegetables and other ingredients are. Pagi semua, Ini aku posting lagi menu Nasi Ayam Semarang ya teman-teman, walau dulu udah pernah posting, tapi ini ada beberapa pelengkap yang baru. Tapi jangan di sama-samakan, karena baik orang semarang dan orang solo, suka tidak terima jika antara nasi liwet di samakan dengan nasi ayam. 

Demikian informasi  resep Nasi ayam Semarang   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
