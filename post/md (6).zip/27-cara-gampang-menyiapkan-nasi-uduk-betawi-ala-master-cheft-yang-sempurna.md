---
description: "Cara Gampang Menyiapkan Nasi uduk betawi ala Master Cheft 😀 yang Sempurna"
title: "Cara Gampang Menyiapkan Nasi uduk betawi ala Master Cheft 😀 yang Sempurna"
slug: 27-cara-gampang-menyiapkan-nasi-uduk-betawi-ala-master-cheft-yang-sempurna
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-15T10:38:39.059Z 
thumbnail: https://img-global.cpcdn.com/recipes/94cef1e874d37721/682x484cq65/nasi-uduk-betawi-ala-master-cheft-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/94cef1e874d37721/682x484cq65/nasi-uduk-betawi-ala-master-cheft-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/94cef1e874d37721/682x484cq65/nasi-uduk-betawi-ala-master-cheft-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/94cef1e874d37721/682x484cq65/nasi-uduk-betawi-ala-master-cheft-foto-resep-utama.webp
author: Roger Morris
ratingvalue: 4.4
reviewcount: 13
recipeingredient:
- "beras me campur 2 gelas beras pera 2 Liter"
- "santan kental 2 liter"
- "bawang putih 5 siung"
- "Cemplung  "
- "Daun salam "
- "Daun sereh "
- "Kayu manis "
- "Cengkeh "
- "Garam secukupnya"
- "Minyak untuk menumis "
- "Lauk pelengkap  "
- "Ayam goreng ada resep ayam goreng sunda "
- "Telor balado "
- "Timun "
- "Bawang goreng "
- "Kerupuk "
- "Sambel kacang "
recipeinstructions:
- "Cuci beras, kemudian kukus beras kurang lebih 20 menit (sampai beras terlihar keras), jika sudah matang angkat dan tuang dalam baskom."
- "Masak santan kental, masukkan bumbu cemplung, kemudian tumis bawang putih sampai harum, jika sudah harum masukkan ke dalam santan yg sedang dimasak,tambahkan 1 sdm garam, masak kental sampai mendidih"
- "Jika santan sudah mendidih angkat, kemudian tuang santan sedikit2 kedalam beras yg sdh dikukus sambil diaduk2, jika sudah tercampur rata semua, diamkan selama 10 menit sampai beras mekar."
- "Jika beras sudah mekar, kukus beras sampai matang (30 menit), sajikan nasi uduk dengan lauk pelengkap"
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 266 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT35M"
recipeyield: "1"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi uduk betawi ala Master Cheft 😀](https://img-global.cpcdn.com/recipes/94cef1e874d37721/682x484cq65/nasi-uduk-betawi-ala-master-cheft-foto-resep-utama.webp)

4 langkah cepat dan mudah membuat  Nasi uduk betawi ala Master Cheft 😀 cocok sekali jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Untuk Pembuatan Nasi uduk betawi ala Master Cheft 😀:

1. beras me campur 2 gelas beras pera 2 Liter
1. santan kental 2 liter
1. bawang putih 5 siung
1. Cemplung  
1. Daun salam 
1. Daun sereh 
1. Kayu manis 
1. Cengkeh 
1. Garam secukupnya
1. Minyak untuk menumis 
1. Lauk pelengkap  
1. Ayam goreng ada resep ayam goreng sunda 
1. Telor balado 
1. Timun 
1. Bawang goreng 
1. Kerupuk 
1. Sambel kacang 



<!--inarticleads2-->

## Cara Membuat Nasi uduk betawi ala Master Cheft 😀:

1. Cuci beras, kemudian kukus beras kurang lebih 20 menit (sampai beras terlihar keras), jika sudah matang angkat dan tuang dalam baskom.
1. Masak santan kental, masukkan bumbu cemplung, kemudian tumis bawang putih sampai harum, jika sudah harum masukkan ke dalam santan yg sedang dimasak,tambahkan 1 sdm garam, masak kental sampai mendidih
1. Jika santan sudah mendidih angkat, kemudian tuang santan sedikit2 kedalam beras yg sdh dikukus sambil diaduk2, jika sudah tercampur rata semua, diamkan selama 10 menit sampai beras mekar.
1. Jika beras sudah mekar, kukus beras sampai matang (30 menit), sajikan nasi uduk dengan lauk pelengkap




Daripada   beli  Nasi uduk betawi ala Master Cheft 😀  diluar terus, kamu  bisa membuatnya sendiri dirumah. Resep  Nasi uduk betawi ala Master Cheft 😀  sederhana ini cukup praktis dalam proses pembuatannya, cukup menggunakan bumbu sederhana  Nasi uduk betawi ala Master Cheft 😀  yang enak, ibu nikmati di rumah.
