---
description: "Langkah Mudah untuk Membuat 99. Nasi Daun Jeruk Ricecooker yang Sempurna"
title: "Langkah Mudah untuk Membuat 99. Nasi Daun Jeruk Ricecooker yang Sempurna"
slug: 247-langkah-mudah-untuk-membuat-99-nasi-daun-jeruk-ricecooker-yang-sempurna
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-23T15:29:31.044Z 
thumbnail: https://img-global.cpcdn.com/recipes/e9b01ddb8b811e51/682x484cq65/99-nasi-daun-jeruk-ricecooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/e9b01ddb8b811e51/682x484cq65/99-nasi-daun-jeruk-ricecooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/e9b01ddb8b811e51/682x484cq65/99-nasi-daun-jeruk-ricecooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/e9b01ddb8b811e51/682x484cq65/99-nasi-daun-jeruk-ricecooker-foto-resep-utama.webp
author: Todd Flores
ratingvalue: 4.9
reviewcount: 14
recipeingredient:
- "beras 2 cup"
- "bawang putih 3 siung"
- "Daun jeruk sesuai selera iris tipis "
- "daun salam 2 lembar"
- "kaldu jamur 1 sdt"
- "sereh geprek 1 batang"
- "Garam optional "
recipeinstructions:
- "Cuci beras hingga bersih, beri air ukuran seperti masak beras biasa"
- "Tumis bawang putih dg sedikit minyak sampai harum."
- "Masukan bawang putih yang sudah digoreng, daun jeruk, daun salam, sereh, kaldu jamur, garam ke dalam beras yang akan dimasak. Masak seperti biasa."
- "Setelah matang hidangkan dg lauk pilihan. Aroma daun jeruk nya membuat selera makan meningkat loh bund"
categories:
- Resep
tags:
- 99
- nasi
- daun

katakunci: 99 nasi daun 
nutrition: 155 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT57M"
recipeyield: "4"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![99. Nasi Daun Jeruk Ricecooker](https://img-global.cpcdn.com/recipes/e9b01ddb8b811e51/682x484cq65/99-nasi-daun-jeruk-ricecooker-foto-resep-utama.webp)

Ingin membuat 99. Nasi Daun Jeruk Ricecooker ? Coba resep berikut ini. Cara memasaknya sangat praktis namun jangan kaget jika hasilnya gurih dan lezat cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Untuk Pembuatan 99. Nasi Daun Jeruk Ricecooker:

1. beras 2 cup
1. bawang putih 3 siung
1. Daun jeruk sesuai selera iris tipis 
1. daun salam 2 lembar
1. kaldu jamur 1 sdt
1. sereh geprek 1 batang
1. Garam optional 



<!--inarticleads2-->

## Cara Menyiapkan 99. Nasi Daun Jeruk Ricecooker:

1. Cuci beras hingga bersih, beri air ukuran seperti masak beras biasa
1. Tumis bawang putih dg sedikit minyak sampai harum.
1. Masukan bawang putih yang sudah digoreng, daun jeruk, daun salam, sereh, kaldu jamur, garam ke dalam beras yang akan dimasak. Masak seperti biasa.
1. Setelah matang hidangkan dg lauk pilihan. Aroma daun jeruk nya membuat selera makan meningkat loh bund




Daripada bunda beli  99. Nasi Daun Jeruk Ricecooker  diluar terus, ibu  bisa membuatnya sendiri dirumah. Resep  99. Nasi Daun Jeruk Ricecooker  sederhana ini cukup praktis dalam proses pembuatannya, serta cukup menggunakan bumbu sederhana  99. Nasi Daun Jeruk Ricecooker  yang enak, ibu nikmati di rumah.
