---
description: "Langkah Mudah untuk Menyiapkan Nasi Bakar Ikan Tuna Asap, Enak"
title: "Langkah Mudah untuk Menyiapkan Nasi Bakar Ikan Tuna Asap, Enak"
slug: 355-langkah-mudah-untuk-menyiapkan-nasi-bakar-ikan-tuna-asap-enak
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-09T01:23:07.976Z 
thumbnail: https://img-global.cpcdn.com/recipes/7e6179dd980455ea/682x484cq65/nasi-bakar-ikan-tuna-asap-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/7e6179dd980455ea/682x484cq65/nasi-bakar-ikan-tuna-asap-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/7e6179dd980455ea/682x484cq65/nasi-bakar-ikan-tuna-asap-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/7e6179dd980455ea/682x484cq65/nasi-bakar-ikan-tuna-asap-foto-resep-utama.webp
author: Eliza Frazier
ratingvalue: 3
reviewcount: 9
recipeingredient:
- "beras cuci bersih 3 gelas"
- "serai diiris tipis 1 batang"
- "daun jeruk iris tipis 3"
- "kaldu jamur 3 sendok makan"
- "Bumbu Halus Untuk Isian "
- "cabe keriting 5"
- "bawang merah 5 siung"
- "bawang putih 3 siung"
- "kencur 1 cm"
- "Bumbu Isian "
- "daun salam 2"
- "serai diiris tipis 1 batang"
- "daun jeruk purut disobek 3"
- "tuna asap saya pakai merek otaji 250 gram"
- "kaldu jamur 2 sdt"
- "garam 2 sdt"
- "Bungkus Nasi Bakar "
- "Daun pisang dijemur atau dipanaskan di kompor "
- "gigilidi Tusuk"
recipeinstructions:
- "Masak nasi dengan dimasukkan kaldu jamur, daun jeruk, dan serai yang dirajang."
- "Haluskan bumbu halus untuk isian dan siapkan bumbu yang dirajang serta kemangi."
- "Tumis bumbu halus, lalu bumbu isian, garam, kaldu jamur dan ikan. Saat kompor dimatikan baru masukkan kemangi dan aduk rata. Koreksi rasa."
- "Sisihkan 2/3 isian dalam wadah, dan sisakan 1/3 isian dalam wajan untuk diaduk bersama nasi yang sudah matang. Campur nasi dengan ikan sampai merata, lalu diamkan sampai uapnya hilang."
- "Bungkus nasi dan isiannya."
- "Setelah semua sudah dibungkus, bisa dibakar menggunakan teflon."
- "Untuk tuna asap yang digunakan, Saya pakai merek otaji, ini sudah ada rasanya."
- "Siap disajikan hangat-hangat."
categories:
- Resep
tags:
- nasi
- bakar
- ikan

katakunci: nasi bakar ikan 
nutrition: 197 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT33M"
recipeyield: "1"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Bakar Ikan Tuna Asap](https://img-global.cpcdn.com/recipes/7e6179dd980455ea/682x484cq65/nasi-bakar-ikan-tuna-asap-foto-resep-utama.webp)

8 langkah mudah dan cepat memasak  Nasi Bakar Ikan Tuna Asap cocok banget jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Untuk Pembuatan Nasi Bakar Ikan Tuna Asap:

1. beras cuci bersih 3 gelas
1. serai diiris tipis 1 batang
1. daun jeruk iris tipis 3
1. kaldu jamur 3 sendok makan
1. Bumbu Halus Untuk Isian 
1. cabe keriting 5
1. bawang merah 5 siung
1. bawang putih 3 siung
1. kencur 1 cm
1. Bumbu Isian 
1. daun salam 2
1. serai diiris tipis 1 batang
1. daun jeruk purut disobek 3
1. tuna asap saya pakai merek otaji 250 gram
1. kaldu jamur 2 sdt
1. garam 2 sdt
1. Bungkus Nasi Bakar 
1. Daun pisang dijemur atau dipanaskan di kompor 
1. gigilidi Tusuk



<!--inarticleads2-->

## Tata Cara Membuat Nasi Bakar Ikan Tuna Asap:

1. Masak nasi dengan dimasukkan kaldu jamur, daun jeruk, dan serai yang dirajang.
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/e264265defbe2741/160x128cq70/nasi-bakar-ikan-tuna-asap-langkah-memasak-1-foto.webp" alt="Nasi Bakar Ikan Tuna Asap" width="340" height="340">
>1. Haluskan bumbu halus untuk isian dan siapkan bumbu yang dirajang serta kemangi.
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/041bca6d1eec344f/160x128cq70/nasi-bakar-ikan-tuna-asap-langkah-memasak-2-foto.webp" alt="Nasi Bakar Ikan Tuna Asap" width="340" height="340">
><img class="lazyload" data-src="https://img-global.cpcdn.com/steps/d089285e9e11f6bf/160x128cq70/nasi-bakar-ikan-tuna-asap-langkah-memasak-2-foto.webp" alt="Nasi Bakar Ikan Tuna Asap" width="340" height="340">
><img class="lazyload" data-src="https://img-global.cpcdn.com/steps/121e1b70336fdfa1/160x128cq70/nasi-bakar-ikan-tuna-asap-langkah-memasak-2-foto.webp" alt="Nasi Bakar Ikan Tuna Asap" width="340" height="340">
>1. Tumis bumbu halus, lalu bumbu isian, garam, kaldu jamur dan ikan. Saat kompor dimatikan baru masukkan kemangi dan aduk rata. Koreksi rasa.
1. Sisihkan 2/3 isian dalam wadah, dan sisakan 1/3 isian dalam wajan untuk diaduk bersama nasi yang sudah matang. Campur nasi dengan ikan sampai merata, lalu diamkan sampai uapnya hilang.
1. Bungkus nasi dan isiannya.
1. Setelah semua sudah dibungkus, bisa dibakar menggunakan teflon.
1. Untuk tuna asap yang digunakan, Saya pakai merek otaji, ini sudah ada rasanya.
1. Siap disajikan hangat-hangat.




Demikian informasi  resep Nasi Bakar Ikan Tuna Asap   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
