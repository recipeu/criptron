---
description: "Bagaimana Membuat Nasi Daun Jeruk yang Enak Banget"
title: "Bagaimana Membuat Nasi Daun Jeruk yang Enak Banget"
slug: 315-bagaimana-membuat-nasi-daun-jeruk-yang-enak-banget
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-07T13:54:55.283Z 
thumbnail: https://img-global.cpcdn.com/recipes/52112db0e4cccf19/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/52112db0e4cccf19/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/52112db0e4cccf19/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/52112db0e4cccf19/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
author: Raymond Jacobs
ratingvalue: 4.4
reviewcount: 9
recipeingredient:
- "Beras 1,5 cup"
- "serai geprek 1"
- "margarin 1 sdm"
- "daun jeruk iris kecil2 11"
- "daun salam 3"
- "royko 1/2 sdt"
- "garam secukupnya"
- "lada secukupnya"
- "Air "
recipeinstructions:
- "Siapkan bahan2"
- "Cuci beras dan beri air sesuai selera ya..."
- "Masukan semua bahan ke rice cooker dan aduk2 rata... jgn lupa suka di aduk ya biar tercampur rata..."
- "Jika sudh selesai sajikannnn yummyyy 😋😋😋"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 274 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT37M"
recipeyield: "4"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk](https://img-global.cpcdn.com/recipes/52112db0e4cccf19/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp)

Ingin membuat Nasi Daun Jeruk ? Coba resep berikut ini. Cara memasaknya sangat praktis namun hasilnya gurih dan lezat yang wajib kamu coba segera

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Dalam Menyiapkan Nasi Daun Jeruk:

1. Beras 1,5 cup
1. serai geprek 1
1. margarin 1 sdm
1. daun jeruk iris kecil2 11
1. daun salam 3
1. royko 1/2 sdt
1. garam secukupnya
1. lada secukupnya
1. Air 

Nasi daun jeruk siap dihidangkan dengan. Nasi daun jeruk ini memang sedang tren di kalangan masyarakat Indonesia, banyak sekali kaum muda mudi yang berlomba-lomba membuat makanan nasi putih spesial ini. Nasi daun jeruk ala geprek bensu rekomended buat di coba. Geprek bensu nasi daun jeruk anti mainst. 

<!--inarticleads2-->

## Langkah-langkah Untuk Menyiapkan Nasi Daun Jeruk:

1. Siapkan bahan2
1. Cuci beras dan beri air sesuai selera ya...
1. Masukan semua bahan ke rice cooker dan aduk2 rata... jgn lupa suka di aduk ya biar tercampur rata...
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/acc02986e582225d/160x128cq70/nasi-daun-jeruk-langkah-memasak-3-foto.webp" alt="Nasi Daun Jeruk" width="340" height="340">
>1. Jika sudh selesai sajikannnn yummyyy 😋😋😋


Gurih dan wangi dari daun jeruk menambah kelezatan nasi daun jeruk. Nasi dengan campuran daun jeruk yang wangi sedang tren. Hai selamat pagi sahabat CWS, pagi ini saya share resep Nasi Daun Jeruk. Praktis banget karena saya gunakan rice cooker. Rasanya mirip nasi uduk tapi wangiiii. 

Terima kasih telah membaca resep yang tim kami tampilkan di sini. Semoga bermanfaat dan selamat mencoba!
