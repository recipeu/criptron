---
description: "Resep Nasi uduk kampung (jkt) rice cooker Anti Gagal"
title: "Resep Nasi uduk kampung (jkt) rice cooker Anti Gagal"
slug: 93-resep-nasi-uduk-kampung-jkt-rice-cooker-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-13T19:21:12.507Z 
thumbnail: https://img-global.cpcdn.com/recipes/a968568270e00c53/682x484cq65/nasi-uduk-kampung-jkt-rice-cooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/a968568270e00c53/682x484cq65/nasi-uduk-kampung-jkt-rice-cooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/a968568270e00c53/682x484cq65/nasi-uduk-kampung-jkt-rice-cooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/a968568270e00c53/682x484cq65/nasi-uduk-kampung-jkt-rice-cooker-foto-resep-utama.webp
author: Dustin Morton
ratingvalue: 3.5
reviewcount: 5
recipeingredient:
- "beras cuci bersih 4 liter"
- "telor ayam kocok lepas 3"
- "tempe 1 papan"
- "mie kuning 2 keping"
- "sereh 3 batang"
- "daun salam 4"
- "lengkuas ruas jempol 2"
- "bawang putih 9"
- "bawang merah 4"
- "cabe merah 3"
- "cabe rawit 1 ons"
- "penyedap rasa sapi 2 sachet"
- "santan kental 300 ml"
- "tomat sedang 1 buah"
- "terasi udang 2 sachet"
recipeinstructions:
- "Cuci bersih beras masukkan 3 sereh geprek 2 ruas lengkuas 4 daun salam,masukkan 4 gelas air putih dan 425 ml santan aduk supaya merata dan 2 sachet penyedap rasa sapi,masukkan ke rice cooker masak sampe mateng aduk sesekali"
- "Untuk sambel nya: ulek halus cabe rawit 2 bawang putih 1 bawang merah 1 sdt gula pasir 1/2 sdt garem,goreng sambel sampe kering icip rasa"
- "Untuk tempe orek nya: potong korek api tempe goreng setengah mateng,cincang halus 2 bawang merah 2 bawang putih,iris tipis 3 cabe merah besar,tumis semua bumbu sampe harum masukkan 2 sdt gula pasir 1/2 sdt garem 2 sdm penyedap rasa sapi 1 sdt olive oil 2 sdm kecap manis masak sampw mateng dan harum"
- "Untuk mie goreng nya: rebus mie tiriskan, ulek halus 2 bawang putih 1 bawang merah 2 buah kemiri,tumis masukkan semua bumbu dan 1/2 sdt garem 1 sdt gula pasir 2 sdm penyedap rasa sapi icip rasa sajikan"
- "Selamat mencoba👌"
categories:
- Resep
tags:
- nasi
- uduk
- kampung

katakunci: nasi uduk kampung 
nutrition: 250 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT33M"
recipeyield: "3"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi uduk kampung (jkt) rice cooker](https://img-global.cpcdn.com/recipes/a968568270e00c53/682x484cq65/nasi-uduk-kampung-jkt-rice-cooker-foto-resep-utama.webp)

Resep Nasi uduk kampung (jkt) rice cooker  anti gagal dengan 5 langkahmudah dan cepat cocok banget jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Dalam Pembuatan Nasi uduk kampung (jkt) rice cooker:

1. beras cuci bersih 4 liter
1. telor ayam kocok lepas 3
1. tempe 1 papan
1. mie kuning 2 keping
1. sereh 3 batang
1. daun salam 4
1. lengkuas ruas jempol 2
1. bawang putih 9
1. bawang merah 4
1. cabe merah 3
1. cabe rawit 1 ons
1. penyedap rasa sapi 2 sachet
1. santan kental 300 ml
1. tomat sedang 1 buah
1. terasi udang 2 sachet

Membuat nasi uduk dengan rice cooker merupakan cara memasak yang paling mudah dan praktis. Kamu juga bisa mencobanya sendiri di rumah! Selain dengan rice cooker, nasi uduk juga bisa dibuat menggunakan magic com. Cara membuatnya pun tidak berbeda jauh dengan menggunakan. 

<!--inarticleads2-->

## Langkah-langkah Untuk Menyiapkan Nasi uduk kampung (jkt) rice cooker:

1. Cuci bersih beras masukkan 3 sereh geprek 2 ruas lengkuas 4 daun salam,masukkan 4 gelas air putih dan 425 ml santan aduk supaya merata dan 2 sachet penyedap rasa sapi,masukkan ke rice cooker masak sampe mateng aduk sesekali
1. Untuk sambel nya: ulek halus cabe rawit 2 bawang putih 1 bawang merah 1 sdt gula pasir 1/2 sdt garem,goreng sambel sampe kering icip rasa
1. Untuk tempe orek nya: potong korek api tempe goreng setengah mateng,cincang halus 2 bawang merah 2 bawang putih,iris tipis 3 cabe merah besar,tumis semua bumbu sampe harum masukkan 2 sdt gula pasir 1/2 sdt garem 2 sdm penyedap rasa sapi 1 sdt olive oil 2 sdm kecap manis masak sampw mateng dan harum
1. Untuk mie goreng nya: rebus mie tiriskan, ulek halus 2 bawang putih 1 bawang merah 2 buah kemiri,tumis masukkan semua bumbu dan 1/2 sdt garem 1 sdt gula pasir 2 sdm penyedap rasa sapi icip rasa sajikan
1. Selamat mencoba👌


Nasi uduk merupakan hidanga utama khas di Indonesia. Nasi uduk memiliki cita rasa yang enak, dilengkapi dengan lauk-pauk yang komplit dan juga membuatnya cukup mudah dengan menggunakan rice cooker. Nasi uduk yang berasal dari Betawi sangat terkenal, meskipun berwarna putih akan. Nasi uduk rice cooker, foto by : @byviszaj. Nasi uduk merupakan salah satu hidangan yang seringkali dijadikan menu sarapan di pagi hari yang Nah, untuk membuatnya sendiri di rumah, simak saja resep nasi uduk rice cooker berikut ini. 

Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
