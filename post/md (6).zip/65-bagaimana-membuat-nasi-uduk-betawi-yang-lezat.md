---
description: "Bagaimana Membuat Nasi Uduk Betawi yang Lezat"
title: "Bagaimana Membuat Nasi Uduk Betawi yang Lezat"
slug: 65-bagaimana-membuat-nasi-uduk-betawi-yang-lezat
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-12T14:08:13.670Z 
thumbnail: https://img-global.cpcdn.com/recipes/82a5481b8129fc05/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/82a5481b8129fc05/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/82a5481b8129fc05/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/82a5481b8129fc05/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
author: Helena Gonzales
ratingvalue: 3.6
reviewcount: 11
recipeingredient:
- "beras 1 liter"
- "Santan segar kental 600ml jika santan instan 2sacet  air "
- "Minyak kelapa aku barco untuk menumis "
- "sereh besar digeprek 4 batang"
- "daun salam yang agak tua besar 6 lembar"
- "Garam 1 1/2 sdt"
- "bumbu halus "
- "bawang merah besar 8 siung"
- "bawang putih besar 6 siung"
recipeinstructions:
- "Cuci bersih beras lalu diamkan sambil menunggu persiapan bumbu lainnya"
- "Haluskan bawang merah dan bawang putih.."
- "Tumis bumbu halus sampai berubah warna dan matang plus harum. Lanjut masukkan santan kental dan sereh dan daun salam. Masak sampai mendidih (ingat harus terus diaduk selama memasak santan jangan sampai pecah)"
- "Setelah santan matang langsung masukan ke dalam beras yang sudah siap diwadah magic com. (Posisi air menutupi beras atau sesuai takaran beras masing-masing)"
- "Maka on magic com sampai matang"
- "Setelah nasi uduk dimagic com matang lalu pindahkan nasi uduk ke panci kukusan dan kukus sampai nasi uduk asat atau matang sempurna. (Kenapa harus dikukus lagi? Karena untuk menghasilkan nasi yang terasa enak, legit, lembut dan bagus) menurut saya. Selamat mencoba 😊🌹"
- "Nikmati nasi uduk dengan pelengkap sesuai keinginan masing-masing.. ada ayang goreng, jengkol balado, tempe orek kecap, timun dan bawang goreng 😋"
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 298 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT47M"
recipeyield: "2"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Betawi](https://img-global.cpcdn.com/recipes/82a5481b8129fc05/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp)

Resep dan cara memasak  Nasi Uduk Betawi yang harus ibu coba segera

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Untuk Menyiapkan Nasi Uduk Betawi:

1. beras 1 liter
1. Santan segar kental 600ml jika santan instan 2sacet  air 
1. Minyak kelapa aku barco untuk menumis 
1. sereh besar digeprek 4 batang
1. daun salam yang agak tua besar 6 lembar
1. Garam 1 1/2 sdt
1. bumbu halus 
1. bawang merah besar 8 siung
1. bawang putih besar 6 siung



<!--inarticleads2-->

## Cara Membuat Nasi Uduk Betawi:

1. Cuci bersih beras lalu diamkan sambil menunggu persiapan bumbu lainnya
1. Haluskan bawang merah dan bawang putih..
1. Tumis bumbu halus sampai berubah warna dan matang plus harum. Lanjut masukkan santan kental dan sereh dan daun salam. Masak sampai mendidih (ingat harus terus diaduk selama memasak santan jangan sampai pecah)
1. Setelah santan matang langsung masukan ke dalam beras yang sudah siap diwadah magic com. (Posisi air menutupi beras atau sesuai takaran beras masing-masing)
1. Maka on magic com sampai matang
1. Setelah nasi uduk dimagic com matang lalu pindahkan nasi uduk ke panci kukusan dan kukus sampai nasi uduk asat atau matang sempurna. (Kenapa harus dikukus lagi? Karena untuk menghasilkan nasi yang terasa enak, legit, lembut dan bagus) menurut saya. Selamat mencoba 😊🌹
1. Nikmati nasi uduk dengan pelengkap sesuai keinginan masing-masing.. ada ayang goreng, jengkol balado, tempe orek kecap, timun dan bawang goreng 😋




Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
