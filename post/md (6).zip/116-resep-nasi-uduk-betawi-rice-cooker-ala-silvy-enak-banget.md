---
description: "Resep Nasi Uduk Betawi rice cooker (ala silvy), Enak Banget"
title: "Resep Nasi Uduk Betawi rice cooker (ala silvy), Enak Banget"
slug: 116-resep-nasi-uduk-betawi-rice-cooker-ala-silvy-enak-banget
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-29T05:49:13.295Z 
thumbnail: https://img-global.cpcdn.com/recipes/612e7d0740ca3b0f/682x484cq65/nasi-uduk-betawi-rice-cooker-ala-silvy-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/612e7d0740ca3b0f/682x484cq65/nasi-uduk-betawi-rice-cooker-ala-silvy-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/612e7d0740ca3b0f/682x484cq65/nasi-uduk-betawi-rice-cooker-ala-silvy-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/612e7d0740ca3b0f/682x484cq65/nasi-uduk-betawi-rice-cooker-ala-silvy-foto-resep-utama.webp
author: Julia Floyd
ratingvalue: 4.1
reviewcount: 7
recipeingredient:
- "beras putih 3 gelas belimbing"
- "sereh 2 batang"
- "jahe 1 ruas ibu jari"
- "lengkuas 1/2 ruas ibu jari"
- "kencur 3 buah"
- "bawang merah 7 siung"
- "daun salam 3 lbr"
- "garam 1 sdm"
- "minyak bekas menggoreng bawang 1 sdk sayur"
- "Santan dengan kekentalan sedang secukupnya"
recipeinstructions:
- "Rendam beras semalaman atau paling tidak selama 2 jam.Cuci bersih semua bahan.geprek sereh,lengkuas,jahe,kencur.iris bawang merah."
- "Didihkan santan dalam panci,sisihkan dulu.lalu cuci beras yang sudah di rendam,lalu tiriskan taruh dalam rice cooker campur dengan semua bahan bumbu aduk rata menggunakan centong."
- "Tuang santan,aduk rata lagi.nyalakan rice cooker,biarkan matang.sajikan dengan pelengkap😊👌"
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 147 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT35M"
recipeyield: "4"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Betawi rice cooker (ala silvy)](https://img-global.cpcdn.com/recipes/612e7d0740ca3b0f/682x484cq65/nasi-uduk-betawi-rice-cooker-ala-silvy-foto-resep-utama.webp)

Ingin membuat Nasi Uduk Betawi rice cooker (ala silvy) ? Coba resep berikut ini. Cara memasaknya sangat praktis namun hasilnya gurih dan lezat yang musti ibu coba dirumah

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Dalam Menyiapkan Nasi Uduk Betawi rice cooker (ala silvy):

1. beras putih 3 gelas belimbing
1. sereh 2 batang
1. jahe 1 ruas ibu jari
1. lengkuas 1/2 ruas ibu jari
1. kencur 3 buah
1. bawang merah 7 siung
1. daun salam 3 lbr
1. garam 1 sdm
1. minyak bekas menggoreng bawang 1 sdk sayur
1. Santan dengan kekentalan sedang secukupnya



<!--inarticleads2-->

## Cara Menyiapkan Nasi Uduk Betawi rice cooker (ala silvy):

1. Rendam beras semalaman atau paling tidak selama 2 jam.Cuci bersih semua bahan.geprek sereh,lengkuas,jahe,kencur.iris bawang merah.
1. Didihkan santan dalam panci,sisihkan dulu.lalu cuci beras yang sudah di rendam,lalu tiriskan taruh dalam rice cooker campur dengan semua bahan bumbu aduk rata menggunakan centong.
1. Tuang santan,aduk rata lagi.nyalakan rice cooker,biarkan matang.sajikan dengan pelengkap😊👌




Daripada bunda beli  Nasi Uduk Betawi rice cooker (ala silvy)  diluar terus, ibu  bisa membuatnya sendiri dirumah. Resep  Nasi Uduk Betawi rice cooker (ala silvy)  sederhana ini cukup praktis dalam proses pembuatannya, cukup menggunakan bumbu sederhana  Nasi Uduk Betawi rice cooker (ala silvy)  yang enak, ibu nikmati di rumah.
