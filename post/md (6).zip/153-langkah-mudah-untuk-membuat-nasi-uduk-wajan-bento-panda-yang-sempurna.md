---
description: "Langkah Mudah untuk Membuat Nasi Uduk Wajan (Bento panda) yang Sempurna"
title: "Langkah Mudah untuk Membuat Nasi Uduk Wajan (Bento panda) yang Sempurna"
slug: 153-langkah-mudah-untuk-membuat-nasi-uduk-wajan-bento-panda-yang-sempurna
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-27T20:26:19.484Z 
thumbnail: https://img-global.cpcdn.com/recipes/56c6a677755abb0a/682x484cq65/nasi-uduk-wajan-bento-panda-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/56c6a677755abb0a/682x484cq65/nasi-uduk-wajan-bento-panda-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/56c6a677755abb0a/682x484cq65/nasi-uduk-wajan-bento-panda-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/56c6a677755abb0a/682x484cq65/nasi-uduk-wajan-bento-panda-foto-resep-utama.webp
author: Leona Rivera
ratingvalue: 4.2
reviewcount: 5
recipeingredient:
- "Beras 1 liter"
- "air perasan santan dari 1 kelapa tua 1 liter"
- "Bumbu halus  "
- "Bawang merah di parut halus 5"
- "Jahe di parut Halus 1 cm"
- "Garam halus 3 sdt"
- "Bumbu pelengkap  "
- "sereh geprek 6 Batang"
- "Daun salam 8 lembar"
- "lengkuas geprek 2 cm"
- "Kayu Manis 2 cm"
recipeinstructions:
- "Cuci beras tiriskan Air nya."
- "Peras santan ke dalam panci masukkan bumbu halus, bumbu pelengkap dan Beras"
- "Nyalakan api masak sampai air surut/jdi aron sambil sesekali di aduk"
- "Siapkan panci dandang didihkan air nya,kukus selama 30 menit sambil tutup panci di alasi kain bersih, siap di bentuk pakai cetakan, fyi : kalau mau di cetak pas nasi masih hangat ya."
categories:
- Resep
tags:
- nasi
- uduk
- wajan

katakunci: nasi uduk wajan 
nutrition: 158 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT41M"
recipeyield: "2"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Wajan (Bento panda)](https://img-global.cpcdn.com/recipes/56c6a677755abb0a/682x484cq65/nasi-uduk-wajan-bento-panda-foto-resep-utama.webp)

Resep dan cara memasak  Nasi Uduk Wajan (Bento panda) yang wajib ibu coba segera

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Untuk Menyiapkan Nasi Uduk Wajan (Bento panda):

1. Beras 1 liter
1. air perasan santan dari 1 kelapa tua 1 liter
1. Bumbu halus  
1. Bawang merah di parut halus 5
1. Jahe di parut Halus 1 cm
1. Garam halus 3 sdt
1. Bumbu pelengkap  
1. sereh geprek 6 Batang
1. Daun salam 8 lembar
1. lengkuas geprek 2 cm
1. Kayu Manis 2 cm



<!--inarticleads2-->

## Cara Membuat Nasi Uduk Wajan (Bento panda):

1. Cuci beras tiriskan Air nya.
1. Peras santan ke dalam panci masukkan bumbu halus, bumbu pelengkap dan Beras
1. Nyalakan api masak sampai air surut/jdi aron sambil sesekali di aduk
1. Siapkan panci dandang didihkan air nya,kukus selama 30 menit sambil tutup panci di alasi kain bersih, siap di bentuk pakai cetakan, fyi : kalau mau di cetak pas nasi masih hangat ya.




Terima kasih telah membaca resep yang tim kami tampilkan di halaman ini. Selamat mencoba!
