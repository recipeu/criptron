---
description: "Resep Nasi bakar ayam suwir, Sempurna"
title: "Resep Nasi bakar ayam suwir, Sempurna"
slug: 384-resep-nasi-bakar-ayam-suwir-sempurna
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-18T05:18:17.784Z 
thumbnail: https://img-global.cpcdn.com/recipes/8ebaa8eed939d53b/682x484cq65/nasi-bakar-ayam-suwir-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/8ebaa8eed939d53b/682x484cq65/nasi-bakar-ayam-suwir-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/8ebaa8eed939d53b/682x484cq65/nasi-bakar-ayam-suwir-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/8ebaa8eed939d53b/682x484cq65/nasi-bakar-ayam-suwir-foto-resep-utama.webp
author: Richard Park
ratingvalue: 3.3
reviewcount: 7
recipeingredient:
- "Nasi uduk harumnasi biasa 1 cup           lihat resep "
- "daun kemangi 1 ikat"
- "dada ayam 1/2"
- "daun salam 1"
- "garam Sejumput"
- "air Secukupnya"
- "daun pisang Secukupnya"
- "Bumbu halus "
- "bawang putih 3"
- "bawang merah 3"
- "kemiri sangrai 1 butir"
- "cabe merah 1"
- "cabai keriting 2"
- "Bumbu lainnya "
- "kunyit bubuk 1/2 sdt"
- "lada bubuk 1/2 sdt"
- "garam 1/4 sdt"
- "kaldu bubuk 1/4 sdt"
- "kecap manis 1 sdm"
- "air Secukupnya"
recipeinstructions:
- "Rebus dada ayam + daun salam + sejumput garam hingga matang. Angkat dan biarkan dingin kemudian disuwir-suwir, sisihkan."
- "Tumis bumbu halus hingga harum, tambahkan semua bumbu lainnya, aduk rata."
- "Tambahkan ayam suwir, aduk rata hingga bumbu meresap. Angkat dan sisihkan."
- "Siapkan dua lembar daun pisang yang kecil di atas, masukkan nasi uduk secukupnya. Tambahkan ayam suwir di atasnya + kemangi di samping, bungkus sesuai selera."
- "Panaskan kukusan, kukus nasi selama 30 menit. Angkat. Lalu bakar dgn teflon atau arang. Bolak² sampai daunnya kecoklatan."
categories:
- Resep
tags:
- nasi
- bakar
- ayam

katakunci: nasi bakar ayam 
nutrition: 240 calories
recipecuisine: Indonesian
preptime: "PT12M"
cooktime: "PT54M"
recipeyield: "1"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi bakar ayam suwir](https://img-global.cpcdn.com/recipes/8ebaa8eed939d53b/682x484cq65/nasi-bakar-ayam-suwir-foto-resep-utama.webp)

Resep rahasia dan cara memasak  Nasi bakar ayam suwir yang wajib bunda coba segera

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Dalam Menyiapkan Nasi bakar ayam suwir:

1. Nasi uduk harumnasi biasa 1 cup           lihat resep 
1. daun kemangi 1 ikat
1. dada ayam 1/2
1. daun salam 1
1. garam Sejumput
1. air Secukupnya
1. daun pisang Secukupnya
1. Bumbu halus 
1. bawang putih 3
1. bawang merah 3
1. kemiri sangrai 1 butir
1. cabe merah 1
1. cabai keriting 2
1. Bumbu lainnya 
1. kunyit bubuk 1/2 sdt
1. lada bubuk 1/2 sdt
1. garam 1/4 sdt
1. kaldu bubuk 1/4 sdt
1. kecap manis 1 sdm
1. air Secukupnya

Agar lebih spesial gunakan ayam kampung. Ini Resep mudah Membuat Nasi Bakar isi Ayam Suwir yang paling enak dan lezat. Berikut resep Membuat Nasi Bakar yang sedap dan gurih isi suwir ayam. Bahan dan bumbu  Tenang saja, cara membuat nasi bakar ayam suwir bali ini simpel. 

<!--inarticleads2-->

## Cara Menyiapkan Nasi bakar ayam suwir:

1. Rebus dada ayam + daun salam + sejumput garam hingga matang. Angkat dan biarkan dingin kemudian disuwir-suwir, sisihkan.
1. Tumis bumbu halus hingga harum, tambahkan semua bumbu lainnya, aduk rata.
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/cf3145fcdfec0575/160x128cq70/nasi-bakar-ayam-suwir-langkah-memasak-2-foto.webp" alt="Nasi bakar ayam suwir" width="340" height="340">
><img class="lazyload" data-src="https://img-global.cpcdn.com/steps/293f2e3c3427d0fd/160x128cq70/nasi-bakar-ayam-suwir-langkah-memasak-2-foto.webp" alt="Nasi bakar ayam suwir" width="340" height="340">
>1. Tambahkan ayam suwir, aduk rata hingga bumbu meresap. Angkat dan sisihkan.
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/c4754a68f4a3abc7/160x128cq70/nasi-bakar-ayam-suwir-langkah-memasak-3-foto.webp" alt="Nasi bakar ayam suwir" width="340" height="340">
><img class="lazyload" data-src="https://img-global.cpcdn.com/steps/a863ea9eefd382ec/160x128cq70/nasi-bakar-ayam-suwir-langkah-memasak-3-foto.webp" alt="Nasi bakar ayam suwir" width="340" height="340">
>1. Siapkan dua lembar daun pisang yang kecil di atas, masukkan nasi uduk secukupnya. Tambahkan ayam suwir di atasnya + kemangi di samping, bungkus sesuai selera.
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/ebc9d4f5c360c15f/160x128cq70/nasi-bakar-ayam-suwir-langkah-memasak-4-foto.webp" alt="Nasi bakar ayam suwir" width="340" height="340">
><img class="lazyload" data-src="https://img-global.cpcdn.com/steps/4f3f91abdd0376ef/160x128cq70/nasi-bakar-ayam-suwir-langkah-memasak-4-foto.webp" alt="Nasi bakar ayam suwir" width="340" height="340">
>1. Panaskan kukusan, kukus nasi selama 30 menit. Angkat. Lalu bakar dgn teflon atau arang. Bolak² sampai daunnya kecoklatan.


Cara membakarnya saja cukup menggunakan wajan teflon antilengket. Guling hingga tertutup bersama daun pisangnya. Rekatkan dengan stapler atau tusuk gigi. Nasi bakar ayam suwir is a dish of grilled rice with shredded chicken. Spiced chicken breast is enveloped with rice, which is then wrapped in banana leaves, and then grilled for a charred, smokey flavour. 

Daripada   beli  Nasi bakar ayam suwir  diluar terus, kamu  bisa membuatnya sendiri dirumah. Resep  Nasi bakar ayam suwir  sederhana ini cukup praktis pembuatannya, serta cukup menggunakan bumbu-bumbu sederhana yang ada di dapur  Nasi bakar ayam suwir  yang enak, kamu nikmati di rumah.
