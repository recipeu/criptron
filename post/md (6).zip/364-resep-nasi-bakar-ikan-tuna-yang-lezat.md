---
description: "Resep Nasi Bakar Ikan Tuna yang Lezat"
title: "Resep Nasi Bakar Ikan Tuna yang Lezat"
slug: 364-resep-nasi-bakar-ikan-tuna-yang-lezat
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-19T10:22:36.754Z 
thumbnail: https://img-global.cpcdn.com/recipes/5a869c61c9f736ae/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/5a869c61c9f736ae/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/5a869c61c9f736ae/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/5a869c61c9f736ae/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp
author: Lela Barnett
ratingvalue: 3.8
reviewcount: 8
recipeingredient:
- "Bumbu untuk nasi  "
- "beras 2 cup"
- "santan kara bungkus kotak kecil 12 nya aja 1/2 bgks"
- "air hangat Secukupnya"
- "garam 1 sdt"
- "daun salam 2 lbr"
- "serai keprek 1 btg"
- "Untuk isian  "
- "ikan tuna uk sedang 1 ekor"
- "cabai rawit aku mix iris 8 bh"
- "cabai merah besar iris serong buang biji 2 bh"
- "bwg putih cacah 2 siung"
- "bwg merah iris 6 siung"
- "daun salam 2 lbr"
- "garam gula lada bubuk penyedap rasa Secukupnya"
- "air 150 ml"
- "kecap manis 3 sdm"
- "daun kemangi 1 ikat"
- "daun pisang dicuci bersih lalu di lap Secukupnya"
recipeinstructions:
- "Untuk nasinya : cuci bersih beras lalu masukkan dlm wadah rice cooker,tuang air dan santan kara (sama banyaknya ya), masukkan daun salam, serai dan garam. Tutup rice cooker dan tekan tombol cook hehe (ud pd tau kali ya 😅) Sambil nunggu nasi matang, mari buat isiannya yaa"
- "Rebus ikan tuna (bisa kukus juga) sampai matang (aku kasih garam sedikit aja), suwir&#34;, sisihkan"
- "Tumis bawang merah, aduk sebentar masukkan bwg putih. Tumis hingga layu. Lalu masukkan cabai&#34;an, daun salam. Aduk sebentar lalu masukkan suwiran ikan tuna. Tambah garam, merica, penyedap rasa dan gula. Aduk sebentar tambahkan kecap manis. Aduh sekitar 1 menit. Lalu tambahkan air. Masak hingga air benar&#34; tiris, ikan tuna kering. Lalu masukkan daun kemangi (aduk sebentaaR aja) kalo aku apinya sudah dimatikan saat kemangi dimasukkan. Angkat"
- "Siapkan daun pisang, tata nasi + isian tuna + nasi, bungkus lalu sematkan di kedua ujungnya dengan lidi atau tusuk gigi. Lalu bakar deh di atas wajan. Angkat dan sajikaaan.. Enak lhooo ❤️ selamat mencoba buibu"
categories:
- Resep
tags:
- nasi
- bakar
- ikan

katakunci: nasi bakar ikan 
nutrition: 204 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT35M"
recipeyield: "4"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Bakar Ikan Tuna](https://img-global.cpcdn.com/recipes/5a869c61c9f736ae/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp)

4 langkah mudah dan cepat memasak  Nasi Bakar Ikan Tuna yang harus bunda coba dirumah

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Untuk Pembuatan Nasi Bakar Ikan Tuna:

1. Bumbu untuk nasi  
1. beras 2 cup
1. santan kara bungkus kotak kecil 12 nya aja 1/2 bgks
1. air hangat Secukupnya
1. garam 1 sdt
1. daun salam 2 lbr
1. serai keprek 1 btg
1. Untuk isian  
1. ikan tuna uk sedang 1 ekor
1. cabai rawit aku mix iris 8 bh
1. cabai merah besar iris serong buang biji 2 bh
1. bwg putih cacah 2 siung
1. bwg merah iris 6 siung
1. daun salam 2 lbr
1. garam gula lada bubuk penyedap rasa Secukupnya
1. air 150 ml
1. kecap manis 3 sdm
1. daun kemangi 1 ikat
1. daun pisang dicuci bersih lalu di lap Secukupnya



<!--inarticleads2-->

## Cara Menyiapkan Nasi Bakar Ikan Tuna:

1. Untuk nasinya : cuci bersih beras lalu masukkan dlm wadah rice cooker,tuang air dan santan kara (sama banyaknya ya), masukkan daun salam, serai dan garam. Tutup rice cooker dan tekan tombol cook hehe (ud pd tau kali ya 😅) Sambil nunggu nasi matang, mari buat isiannya yaa
1. Rebus ikan tuna (bisa kukus juga) sampai matang (aku kasih garam sedikit aja), suwir&#34;, sisihkan
1. Tumis bawang merah, aduk sebentar masukkan bwg putih. Tumis hingga layu. Lalu masukkan cabai&#34;an, daun salam. Aduk sebentar lalu masukkan suwiran ikan tuna. Tambah garam, merica, penyedap rasa dan gula. Aduk sebentar tambahkan kecap manis. Aduh sekitar 1 menit. Lalu tambahkan air. Masak hingga air benar&#34; tiris, ikan tuna kering. Lalu masukkan daun kemangi (aduk sebentaaR aja) kalo aku apinya sudah dimatikan saat kemangi dimasukkan. Angkat
1. Siapkan daun pisang, tata nasi + isian tuna + nasi, bungkus lalu sematkan di kedua ujungnya dengan lidi atau tusuk gigi. Lalu bakar deh di atas wajan. Angkat dan sajikaaan.. Enak lhooo ❤️ selamat mencoba buibu




Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
