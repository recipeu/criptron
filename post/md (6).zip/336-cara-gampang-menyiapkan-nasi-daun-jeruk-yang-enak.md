---
description: "Cara Gampang Menyiapkan Nasi Daun Jeruk yang Enak"
title: "Cara Gampang Menyiapkan Nasi Daun Jeruk yang Enak"
slug: 336-cara-gampang-menyiapkan-nasi-daun-jeruk-yang-enak
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-10T18:17:09.543Z 
thumbnail: https://img-global.cpcdn.com/recipes/124633342e457307/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/124633342e457307/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/124633342e457307/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/124633342e457307/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
author: Alex Fuller
ratingvalue: 3.4
reviewcount: 7
recipeingredient:
- "cup magicom beras putih 5"
- "santan karra 1 bungkus"
- "daun salam 2 lembar"
- "daun jeruk 6 lembar"
- "serehmemarkan 1 batang"
- "garam 2 sdt"
- "Air secukupnya"
recipeinstructions:
- "Cuci bersih beras kemudian letakkan pada wadah masak nasi magicom."
- "Lalu tambahkan santan kara,garam,3 lembar daun jeruk yang diremas remas,daun salam,sereh,lalu tambahkan air sesuai batas yang terlihat pada wadah."
- "Aduk rata lalu Colokkan pada listrik dan tunggu sampai matang."
- "Setelah matang,keluarkan semua daun n serehnya lalu iris tipis tipis 3 lembar daun jeruknya lalu taburkan pada nasi yang baru matang kemudian tutup kembali n biarkan sampai tanak."
- "Setelah tanak,nasi daun jeruk siap dihidangkan dengan lauk dan lalapan sambel😊"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 147 calories
recipecuisine: Indonesian
preptime: "PT12M"
cooktime: "PT53M"
recipeyield: "2"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk](https://img-global.cpcdn.com/recipes/124633342e457307/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp)

Resep dan cara memasak  Nasi Daun Jeruk cocok banget jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Untuk Menyiapkan Nasi Daun Jeruk:

1. cup magicom beras putih 5
1. santan karra 1 bungkus
1. daun salam 2 lembar
1. daun jeruk 6 lembar
1. serehmemarkan 1 batang
1. garam 2 sdt
1. Air secukupnya

Nasi daun jeruk siap dihidangkan dengan. Nasi daun jeruk ini memang sedang tren di kalangan masyarakat Indonesia, banyak sekali kaum muda mudi yang berlomba-lomba membuat makanan nasi putih spesial ini. Nasi daun jeruk ala geprek bensu rekomended buat di coba. Geprek bensu nasi daun jeruk anti mainst. 

<!--inarticleads2-->

## Cara Mudah Membuat Nasi Daun Jeruk:

1. Cuci bersih beras kemudian letakkan pada wadah masak nasi magicom.
1. Lalu tambahkan santan kara,garam,3 lembar daun jeruk yang diremas remas,daun salam,sereh,lalu tambahkan air sesuai batas yang terlihat pada wadah.
1. Aduk rata lalu Colokkan pada listrik dan tunggu sampai matang.
1. Setelah matang,keluarkan semua daun n serehnya lalu iris tipis tipis 3 lembar daun jeruknya lalu taburkan pada nasi yang baru matang kemudian tutup kembali n biarkan sampai tanak.
1. Setelah tanak,nasi daun jeruk siap dihidangkan dengan lauk dan lalapan sambel😊


Gurih dan wangi dari daun jeruk menambah kelezatan nasi daun jeruk. Nasi dengan campuran daun jeruk yang wangi sedang tren. Hai selamat pagi sahabat CWS, pagi ini saya share resep Nasi Daun Jeruk. Praktis banget karena saya gunakan rice cooker. Rasanya mirip nasi uduk tapi wangiiii. 

Daripada kamu beli  Nasi Daun Jeruk  diluar terus, ibu  bisa membuatnya sendiri dirumah. Resep  Nasi Daun Jeruk  sederhana ini cukup praktis pembuatannya, serta cukup menggunakan bumbu sederhana  Nasi Daun Jeruk  yang enak, ibu nikmati di rumah.
