---
description: "Resep Nasi Daun Jeruk yang Enak"
title: "Resep Nasi Daun Jeruk yang Enak"
slug: 319-resep-nasi-daun-jeruk-yang-enak
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-26T23:36:43.179Z 
thumbnail: https://img-global.cpcdn.com/recipes/d3cf6166dedf3ef2/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/d3cf6166dedf3ef2/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/d3cf6166dedf3ef2/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/d3cf6166dedf3ef2/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
author: Rachel Cruz
ratingvalue: 5
reviewcount: 14
recipeingredient:
- "Beras secukupnya"
- "Daun jeruk 1 genggam"
- "Garam "
- "Kaldu ayam "
- "Santan encer "
- "sere optional saya nga Batang"
recipeinstructions:
- "Cuci beras dan tiriskan"
- "Buang bagian tengah daun jeruk agar tdk pahit dan blender 3/4 bagian. Saring dan ambil airnya"
- "Masukkan jus air daun jeruk, daun jeruk yg sudah dibuang tengahnya, santan encer secukupnya, garam dan kaldu bubuk"
- "Masak dgn magic com sampe matang. Yummie"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 253 calories
recipecuisine: Indonesian
preptime: "PT16M"
cooktime: "PT39M"
recipeyield: "3"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk](https://img-global.cpcdn.com/recipes/d3cf6166dedf3ef2/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp)

4 langkah cepat memasak  Nasi Daun Jeruk cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Untuk Pembuatan Nasi Daun Jeruk:

1. Beras secukupnya
1. Daun jeruk 1 genggam
1. Garam 
1. Kaldu ayam 
1. Santan encer 
1. sere optional saya nga Batang

Nasi daun jeruk siap dihidangkan dengan. Nasi daun jeruk ini memang sedang tren di kalangan masyarakat Indonesia, banyak sekali kaum muda mudi yang berlomba-lomba membuat makanan nasi putih spesial ini. Nasi daun jeruk ala geprek bensu rekomended buat di coba. Geprek bensu nasi daun jeruk anti mainst. 

<!--inarticleads2-->

## Cara Menyiapkan Nasi Daun Jeruk:

1. Cuci beras dan tiriskan
1. Buang bagian tengah daun jeruk agar tdk pahit dan blender 3/4 bagian. Saring dan ambil airnya
1. Masukkan jus air daun jeruk, daun jeruk yg sudah dibuang tengahnya, santan encer secukupnya, garam dan kaldu bubuk
1. Masak dgn magic com sampe matang. Yummie


Gurih dan wangi dari daun jeruk menambah kelezatan nasi daun jeruk. Nasi dengan campuran daun jeruk yang wangi sedang tren. Hai selamat pagi sahabat CWS, pagi ini saya share resep Nasi Daun Jeruk. Praktis banget karena saya gunakan rice cooker. Rasanya mirip nasi uduk tapi wangiiii. 

Terima kasih telah menggunakan resep yang tim kami tampilkan di sini. Semoga bermanfaat dan selamat mencoba!
