---
description: "Bagaimana Menyiapkan Soto Semarang Simple (MPASI 21 BULAN) Anti Gagal"
title: "Bagaimana Menyiapkan Soto Semarang Simple (MPASI 21 BULAN) Anti Gagal"
slug: 499-bagaimana-menyiapkan-soto-semarang-simple-mpasi-21-bulan-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-22T23:46:15.781Z 
thumbnail: https://img-global.cpcdn.com/recipes/e15919bc7b6a2550/682x484cq65/soto-semarang-simple-mpasi-21-bulan-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/e15919bc7b6a2550/682x484cq65/soto-semarang-simple-mpasi-21-bulan-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/e15919bc7b6a2550/682x484cq65/soto-semarang-simple-mpasi-21-bulan-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/e15919bc7b6a2550/682x484cq65/soto-semarang-simple-mpasi-21-bulan-foto-resep-utama.webp
author: Matthew Pittman
ratingvalue: 4.7
reviewcount: 5
recipeingredient:
- "ayam kampung 1/2 kg"
- "daun salam 2 lembar"
- "daun jeruk 2 lembar"
- "serai memarkan 1 batang"
- "Air 2 L"
- "mentega 1 sdm"
- "garam 1/2 sdm"
- "gula 1 sdm"
- "gula merah 1 butir"
- "ketumbar bubuk saya pakai desaku 1/2 sdm"
- "lada bubuk saya pakai ladaku 1/2 sdt"
- "kaldu jamur 1/2 sdm"
- "Pala bubuk secukupnya"
- "jinten 1/2 sdt"
- "Bumbu halus  "
- "bawang merah 6 butir"
- "bawang putih 7 butir"
- "kunyit ambil yg besar 1 buah"
- "jahe 1 buah"
- "Pelengkap  "
- "bihun beras saya pakai Indomaret bihun beras 1/2 Bks"
- "tomat 1 buah"
- "daun kol 1/2"
- "tauge panjang Segenggam"
- "Jeruk nipis "
- "Telur rebus "
- "Bawang putih goreng "
- "Bawang merah goreng "
- "Sambal bawang mentah untuk mama dan papa "
- "Suwiran ayam "
recipeinstructions:
- "Rebus ayam yang sudah di cuci. Tunggu hingga mendidih."
- "Haluskan bawang merah, bawang putih bersama jahe dan kunyit yg sudah dibakar. (Saya pakai blender). Kemudian tumis dgn 1 sdm mentega sampai harum, masukan daun salam, daun jeruk yg sudah disobek ujungnya dan 1 batang serai yg sudah dimemarkan. Tumis sampai bumbu sedikit mengering."
- "Campur tumisan bumbu halus dengan 2 L air kaldu ayam. Tambahkan gula, garam, gula merah, lada bubuk,jinten, pala bubuk, kaldu jamur, ketumbar bubuk. Aduk, tunggu sampai mendidih. Cek rasa. Sembari menunggu kuah soto mendidih mom bisa merebus aneka bahan pelengkap soto."
- "Sajikan selagi hangat. Taburi bawang putih dan bawang merah goreng."
categories:
- Resep
tags:
- soto
- semarang
- simple

katakunci: soto semarang simple 
nutrition: 254 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT40M"
recipeyield: "1"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Soto Semarang Simple (MPASI 21 BULAN)](https://img-global.cpcdn.com/recipes/e15919bc7b6a2550/682x484cq65/soto-semarang-simple-mpasi-21-bulan-foto-resep-utama.webp)

Ingin membuat Soto Semarang Simple (MPASI 21 BULAN) ? Coba resep berikut ini. Cara memasaknya sangat praktis namun hasilnya gurih dan lezat yang wajib ibu coba dirumah

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Untuk Menyiapkan Soto Semarang Simple (MPASI 21 BULAN):

1. ayam kampung 1/2 kg
1. daun salam 2 lembar
1. daun jeruk 2 lembar
1. serai memarkan 1 batang
1. Air 2 L
1. mentega 1 sdm
1. garam 1/2 sdm
1. gula 1 sdm
1. gula merah 1 butir
1. ketumbar bubuk saya pakai desaku 1/2 sdm
1. lada bubuk saya pakai ladaku 1/2 sdt
1. kaldu jamur 1/2 sdm
1. Pala bubuk secukupnya
1. jinten 1/2 sdt
1. Bumbu halus  
1. bawang merah 6 butir
1. bawang putih 7 butir
1. kunyit ambil yg besar 1 buah
1. jahe 1 buah
1. Pelengkap  
1. bihun beras saya pakai Indomaret bihun beras 1/2 Bks
1. tomat 1 buah
1. daun kol 1/2
1. tauge panjang Segenggam
1. Jeruk nipis 
1. Telur rebus 
1. Bawang putih goreng 
1. Bawang merah goreng 
1. Sambal bawang mentah untuk mama dan papa 
1. Suwiran ayam 



<!--inarticleads2-->

## Tata Cara Menyiapkan Soto Semarang Simple (MPASI 21 BULAN):

1. Rebus ayam yang sudah di cuci. Tunggu hingga mendidih.
1. Haluskan bawang merah, bawang putih bersama jahe dan kunyit yg sudah dibakar. (Saya pakai blender). Kemudian tumis dgn 1 sdm mentega sampai harum, masukan daun salam, daun jeruk yg sudah disobek ujungnya dan 1 batang serai yg sudah dimemarkan. Tumis sampai bumbu sedikit mengering.
1. Campur tumisan bumbu halus dengan 2 L air kaldu ayam. Tambahkan gula, garam, gula merah, lada bubuk,jinten, pala bubuk, kaldu jamur, ketumbar bubuk. Aduk, tunggu sampai mendidih. Cek rasa. Sembari menunggu kuah soto mendidih mom bisa merebus aneka bahan pelengkap soto.
1. Sajikan selagi hangat. Taburi bawang putih dan bawang merah goreng.




Demikian informasi  resep Soto Semarang Simple (MPASI 21 BULAN)   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
