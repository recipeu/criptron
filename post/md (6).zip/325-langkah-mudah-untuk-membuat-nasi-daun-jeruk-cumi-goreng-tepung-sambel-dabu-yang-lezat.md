---
description: "Langkah Mudah untuk Membuat Nasi Daun Jeruk Cumi Goreng Tepung Sambel Dabu yang Lezat"
title: "Langkah Mudah untuk Membuat Nasi Daun Jeruk Cumi Goreng Tepung Sambel Dabu yang Lezat"
slug: 325-langkah-mudah-untuk-membuat-nasi-daun-jeruk-cumi-goreng-tepung-sambel-dabu-yang-lezat
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-12T10:12:44.503Z 
thumbnail: https://img-global.cpcdn.com/recipes/e88c0c7196933cbe/682x484cq65/nasi-daun-jeruk-cumi-goreng-tepung-sambel-dabu-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/e88c0c7196933cbe/682x484cq65/nasi-daun-jeruk-cumi-goreng-tepung-sambel-dabu-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/e88c0c7196933cbe/682x484cq65/nasi-daun-jeruk-cumi-goreng-tepung-sambel-dabu-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/e88c0c7196933cbe/682x484cq65/nasi-daun-jeruk-cumi-goreng-tepung-sambel-dabu-foto-resep-utama.webp
author: Estella Sparks
ratingvalue: 4.5
reviewcount: 10
recipeingredient:
- "beras 1/2 kg"
- "Air secukupnya"
- "bawang putih 7 pcs"
- "bawang merah 3 pcs"
- "serai 1 pcs"
- "daun jeruk iris tipistipis 7 lembar"
- "garam Secukupnya"
- "kaldu jamur Secukupnya"
- "Serai secukupnya"
- "Cumi goreng tepung "
- "Cumi 1 buah"
- "garam Secukupnya"
- "kunyit Secukupnya"
- "bawang putih 3 pcs"
- "telor 1 butir"
- "Tepung terigu secukupnya"
- "Tepung bumbu secukupnya"
- "Sambel dabu "
- "bawang merah 5 pcs"
- "serai yg muda 3"
- "Jeruk nipis secukupny "
- "cabe rawit 10 pcs"
- "Garam secukupnya"
recipeinstructions:
- "Pertama kita bikin nasi nya dulu ya..cuci beras smpai bersih taruh di rice cooker,cincang halus bawang putih lalu tumis dengan api kecil smpai warna kecoklatan,setelah matang masukan ke dalam rice cooker,tambahkan air seperti menanak nasi biasa..masukan pila bawang merah serai yg di geprek dan irisan daun jeruk,tambahkan garam dan kaldu jamur agar ada rasa"
- "Sambil menanak nasi kita goreng cumi siapkan tepung dan telor yg sudah di bumbui bawang kunyit dan garam kocok smpe rata jd adonan tepung basah,siapkan pula 1 adonan lagi tepung kering(saya pake tepung bumbu)"
- "Setelah dimasukan ke adonan basah dan kering guling2kan dah goreng dengan api kecil sampai matang"
- "Sekarang kita buat sambel dabu nya,iris tipis2 bawang merah serai dan cabe rawit oseng sebentar saja ga usah smpai matang masukan lemon garam dan kaldu,koreksi rasa"
- "Nasi sudah matang,cumi matang,dan sambel dabu matang,siap di sajikan"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 263 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT53M"
recipeyield: "3"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk Cumi Goreng Tepung Sambel Dabu](https://img-global.cpcdn.com/recipes/e88c0c7196933cbe/682x484cq65/nasi-daun-jeruk-cumi-goreng-tepung-sambel-dabu-foto-resep-utama.webp)

Ingin membuat Nasi Daun Jeruk Cumi Goreng Tepung Sambel Dabu ? Coba resep berikut ini. Cara memasaknya sangat praktis namun hasilnya gurih dan lezat yang bisa bunda coba segera

<!--inarticleads1-->

## Bahan-bahan Yang Dibutuhkan Dalam Pembuatan Nasi Daun Jeruk Cumi Goreng Tepung Sambel Dabu:

1. beras 1/2 kg
1. Air secukupnya
1. bawang putih 7 pcs
1. bawang merah 3 pcs
1. serai 1 pcs
1. daun jeruk iris tipistipis 7 lembar
1. garam Secukupnya
1. kaldu jamur Secukupnya
1. Serai secukupnya
1. Cumi goreng tepung 
1. Cumi 1 buah
1. garam Secukupnya
1. kunyit Secukupnya
1. bawang putih 3 pcs
1. telor 1 butir
1. Tepung terigu secukupnya
1. Tepung bumbu secukupnya
1. Sambel dabu 
1. bawang merah 5 pcs
1. serai yg muda 3
1. Jeruk nipis secukupny 
1. cabe rawit 10 pcs
1. Garam secukupnya



<!--inarticleads2-->

## Cara Mudah Membuat Nasi Daun Jeruk Cumi Goreng Tepung Sambel Dabu:

1. Pertama kita bikin nasi nya dulu ya..cuci beras smpai bersih taruh di rice cooker,cincang halus bawang putih lalu tumis dengan api kecil smpai warna kecoklatan,setelah matang masukan ke dalam rice cooker,tambahkan air seperti menanak nasi biasa..masukan pila bawang merah serai yg di geprek dan irisan daun jeruk,tambahkan garam dan kaldu jamur agar ada rasa
1. Sambil menanak nasi kita goreng cumi siapkan tepung dan telor yg sudah di bumbui bawang kunyit dan garam kocok smpe rata jd adonan tepung basah,siapkan pula 1 adonan lagi tepung kering(saya pake tepung bumbu)
1. Setelah dimasukan ke adonan basah dan kering guling2kan dah goreng dengan api kecil sampai matang
1. Sekarang kita buat sambel dabu nya,iris tipis2 bawang merah serai dan cabe rawit oseng sebentar saja ga usah smpai matang masukan lemon garam dan kaldu,koreksi rasa
1. Nasi sudah matang,cumi matang,dan sambel dabu matang,siap di sajikan




Terima kasih telah membaca resep yang tim kami tampilkan di sini. Selamat mencoba!
