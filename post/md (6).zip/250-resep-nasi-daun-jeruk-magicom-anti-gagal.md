---
description: "Resep Nasi Daun Jeruk Magicom Anti Gagal"
title: "Resep Nasi Daun Jeruk Magicom Anti Gagal"
slug: 250-resep-nasi-daun-jeruk-magicom-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-21T17:46:07.663Z 
thumbnail: https://img-global.cpcdn.com/recipes/e5772cb653b8b466/682x484cq65/nasi-daun-jeruk-magicom-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/e5772cb653b8b466/682x484cq65/nasi-daun-jeruk-magicom-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/e5772cb653b8b466/682x484cq65/nasi-daun-jeruk-magicom-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/e5772cb653b8b466/682x484cq65/nasi-daun-jeruk-magicom-foto-resep-utama.webp
author: Lottie Hicks
ratingvalue: 4.5
reviewcount: 3
recipeingredient:
- "beras 250 gr"
- "santan sangat encer 500-550 ml"
- "Bumbu Tumis "
- "bawang merah iris tipis 4 siung"
- "bawang putih iris tipis 3 siung"
- "lengkuas geprek 1 ruas"
- "daun salam potong2 1 lbr"
- "gr10 lbr daun jeruk buang tulang iris tipis 5"
- "minyak sayur Secukupnya"
- "Bumbu lain "
- "peres garam 1 sdt"
- "kaldu bubuk 1/2 sdt"
- "pasta pandansecukupnya 1/4 sdt"
recipeinstructions:
- "Siapkan bahan, cuci bersih beras. Sisihkan."
- "Tumis bawang putih, bawang merah, lengkuas dan daun salam, tumis hingga layu, masukkan daun jeruk tumis hingga harum."
- "Masukkan beras ke dalam panci magicom, tambahkan bumbu tumis, santan dan bumbu lain. Aduk rata. Cook. Takaran air bisa disesuain masing2 yaaa...."
- "Sajikan dengan pelengkap. Sedaappppp....."
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 212 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT34M"
recipeyield: "2"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk Magicom](https://img-global.cpcdn.com/recipes/e5772cb653b8b466/682x484cq65/nasi-daun-jeruk-magicom-foto-resep-utama.webp)

Resep dan cara mengolah  Nasi Daun Jeruk Magicom cocok sekali jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Dalam Pembuatan Nasi Daun Jeruk Magicom:

1. beras 250 gr
1. santan sangat encer 500-550 ml
1. Bumbu Tumis 
1. bawang merah iris tipis 4 siung
1. bawang putih iris tipis 3 siung
1. lengkuas geprek 1 ruas
1. daun salam potong2 1 lbr
1. gr10 lbr daun jeruk buang tulang iris tipis 5
1. minyak sayur Secukupnya
1. Bumbu lain 
1. peres garam 1 sdt
1. kaldu bubuk 1/2 sdt
1. pasta pandansecukupnya 1/4 sdt



<!--inarticleads2-->

## Langkah-langkah Untuk Menyiapkan Nasi Daun Jeruk Magicom:

1. Siapkan bahan, cuci bersih beras. Sisihkan.
1. Tumis bawang putih, bawang merah, lengkuas dan daun salam, tumis hingga layu, masukkan daun jeruk tumis hingga harum.
1. Masukkan beras ke dalam panci magicom, tambahkan bumbu tumis, santan dan bumbu lain. Aduk rata. Cook. Takaran air bisa disesuain masing2 yaaa....
1. Sajikan dengan pelengkap. Sedaappppp.....




Terima kasih telah menggunakan resep yang tim kami tampilkan di sini. Selamat mencoba!
