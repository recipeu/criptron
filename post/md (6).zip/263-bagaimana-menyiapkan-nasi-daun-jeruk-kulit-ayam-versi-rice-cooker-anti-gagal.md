---
description: "Bagaimana Menyiapkan Nasi Daun Jeruk Kulit Ayam (Versi Rice Cooker) Anti Gagal"
title: "Bagaimana Menyiapkan Nasi Daun Jeruk Kulit Ayam (Versi Rice Cooker) Anti Gagal"
slug: 263-bagaimana-menyiapkan-nasi-daun-jeruk-kulit-ayam-versi-rice-cooker-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-28T20:49:05.456Z 
thumbnail: https://img-global.cpcdn.com/recipes/880f529b5daf4e75/682x484cq65/nasi-daun-jeruk-kulit-ayam-versi-rice-cooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/880f529b5daf4e75/682x484cq65/nasi-daun-jeruk-kulit-ayam-versi-rice-cooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/880f529b5daf4e75/682x484cq65/nasi-daun-jeruk-kulit-ayam-versi-rice-cooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/880f529b5daf4e75/682x484cq65/nasi-daun-jeruk-kulit-ayam-versi-rice-cooker-foto-resep-utama.webp
author: Ruth Ramos
ratingvalue: 4.5
reviewcount: 3
recipeingredient:
- "beras 1 Cup"
- "bawang putih cincang 2 siung"
- "daun jeruk rajang halus 4 Lembar"
- "Kaldu bubuk 1 sdt"
- "garam Sejumput"
- "MargarinMentega 2 sdm"
- "Untuk Kulit Ayam  "
- "kulit Ayam cuci potong kecil2 300 gr"
- "bawang putih cincang 2 siung"
- "bubuk cabe 1 sdt"
- "Kaldu bubuk 1 sdt"
- "garam 1/2 sdt"
recipeinstructions:
- "Tumis bawang putih cincang sampai harum dan kecoklatan. Sisihkan"
- "Cuci bersih beras, beri air Sesuai takaran. Masukkan bawang putih yg sudah Di Tumis ke dalam ya. Tambahkan garam, Kaldu bubuk dan daun jeruk aduk rata. Masak spt nasi biasa. Setelah matang, tambahkan margarin/mentega aduk rata. Nasi siap disajikan"
- "Siapkan kulit Ayam, taruh diatas wajan anti lengket tanpa minyak. Masukkan bubuk cabe, bubuk Kaldu dan garam. Aduk2 dan masak. Stlh setengah matang Masukkan bawang putih cincang. Masak sampai Keluar minyak dan kulit crispy (gunakan api kecil dan aduk2 terus Selama masak kulit spy tdk gosong) matikan kompor, sajikan dg Nasi Daun jeruknya"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 285 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT42M"
recipeyield: "1"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk Kulit Ayam (Versi Rice Cooker)](https://img-global.cpcdn.com/recipes/880f529b5daf4e75/682x484cq65/nasi-daun-jeruk-kulit-ayam-versi-rice-cooker-foto-resep-utama.webp)

Ingin membuat Nasi Daun Jeruk Kulit Ayam (Versi Rice Cooker) ? Coba resep berikut ini. Cara memasaknya sangat praktis namun jangan kaget jika hasilnya gurih dan lezat yang wajib kamu coba segera

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Dalam Pembuatan Nasi Daun Jeruk Kulit Ayam (Versi Rice Cooker):

1. beras 1 Cup
1. bawang putih cincang 2 siung
1. daun jeruk rajang halus 4 Lembar
1. Kaldu bubuk 1 sdt
1. garam Sejumput
1. MargarinMentega 2 sdm
1. Untuk Kulit Ayam  
1. kulit Ayam cuci potong kecil2 300 gr
1. bawang putih cincang 2 siung
1. bubuk cabe 1 sdt
1. Kaldu bubuk 1 sdt
1. garam 1/2 sdt



<!--inarticleads2-->

## Cara Mudah Menyiapkan Nasi Daun Jeruk Kulit Ayam (Versi Rice Cooker):

1. Tumis bawang putih cincang sampai harum dan kecoklatan. Sisihkan
1. Cuci bersih beras, beri air Sesuai takaran. Masukkan bawang putih yg sudah Di Tumis ke dalam ya. Tambahkan garam, Kaldu bubuk dan daun jeruk aduk rata. Masak spt nasi biasa. Setelah matang, tambahkan margarin/mentega aduk rata. Nasi siap disajikan
1. Siapkan kulit Ayam, taruh diatas wajan anti lengket tanpa minyak. Masukkan bubuk cabe, bubuk Kaldu dan garam. Aduk2 dan masak. Stlh setengah matang Masukkan bawang putih cincang. Masak sampai Keluar minyak dan kulit crispy (gunakan api kecil dan aduk2 terus Selama masak kulit spy tdk gosong) matikan kompor, sajikan dg Nasi Daun jeruknya




Demikian informasi  resep Nasi Daun Jeruk Kulit Ayam (Versi Rice Cooker)   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
