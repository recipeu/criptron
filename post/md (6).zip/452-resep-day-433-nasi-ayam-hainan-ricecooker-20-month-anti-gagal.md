---
description: "Resep Day. 433 Nasi Ayam Hainan Ricecooker (20 month+) Anti Gagal"
title: "Resep Day. 433 Nasi Ayam Hainan Ricecooker (20 month+) Anti Gagal"
slug: 452-resep-day-433-nasi-ayam-hainan-ricecooker-20-month-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-16T04:28:56.487Z 
thumbnail: https://img-global.cpcdn.com/recipes/7cf9869da9921e00/682x484cq65/day-433-nasi-ayam-hainan-ricecooker-20-month-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/7cf9869da9921e00/682x484cq65/day-433-nasi-ayam-hainan-ricecooker-20-month-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/7cf9869da9921e00/682x484cq65/day-433-nasi-ayam-hainan-ricecooker-20-month-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/7cf9869da9921e00/682x484cq65/day-433-nasi-ayam-hainan-ricecooker-20-month-foto-resep-utama.webp
author: Ronnie Robinson
ratingvalue: 3.7
reviewcount: 7
recipeingredient:
- "daun bawang iris tipis 2 batang"
- " Nasi Ayam Hainan "
- "paha ayam 1 kg"
- "beras 850 gram"
- "bawang merah cincang halus 5 buah"
- "bawang putih cincang halus 8 siung"
- "jahe geprek 2 cm"
- "daun pandan simpul 1 lembar"
- "margarine 1 sdm"
- "minyak wijen 2 sdm"
- "air 850 ml"
- " Tumisan Bawang Putih "
- "bawang putih cincang halus 3 siung"
- "jahe cincang halus 3 cm"
- "minyak wijen 2 sdm"
- "minyak sayur 2 sdm"
- "kecap manis 1 sdm"
- "kecap asin 2 sdm"
- "saos tiram 1/2 sdt"
- " Pokcoy Kuah "
- "pokcoy 3 bonggol"
- "air 800 ml"
- "garam 1/4 sdt"
- "kaldu jamur 1/2 sdt"
recipeinstructions:
- "Cuci bersih ayam. Kerat dagingnya. Tiriskan."
- "🍛 Nasi Ayam Hainan: Lelehkan margarine dan minyak wijen. Tumis bawang putih dan bawang merah hingga kecokelatan. Kecilkan api. Masukkan beras, aduk rata. Tambahkan air, aduk rata. Gunakan api sedang. Masak hingga mulai mendidih. Matikan api."
- "Tuang beras ke dalam ricecooker. Susun daun pandan, jahe dan ayam. Masak hingga matang. Setelah matang, ambil daun pandan, jahe dan ayam. Lalu aduk nasinya."
- "Tumis bawang putih dan jahe dengan minyak sayur dan minyak wijen hingga kecokelatan. Tambahkan sisa bahan lainnya, aduk rata. Matikan api."
- "Rebus air hingga mendidih. Masukkan pokcoy. Masak hingga empuk. Tambahkan garam dan kaldu jamur. Matikan api. Koreksi rasa."
- "Tata nasi dan ayam di piring. Siram ayam dengan tulisan bawang putih. Taburi daun bawang. Sajikan dengan pokcoy kuah."
categories:
- Resep
tags:
- day
- 433
- nasi

katakunci: day 433 nasi 
nutrition: 115 calories
recipecuisine: Indonesian
preptime: "PT39M"
cooktime: "PT54M"
recipeyield: "4"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Day. 433 Nasi Ayam Hainan Ricecooker (20 month+)](https://img-global.cpcdn.com/recipes/7cf9869da9921e00/682x484cq65/day-433-nasi-ayam-hainan-ricecooker-20-month-foto-resep-utama.webp)

Resep rahasia Day. 433 Nasi Ayam Hainan Ricecooker (20 month+)  anti gagal dengan 6 langkahmudah yang musti ibu coba dirumah

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Untuk Menyiapkan Day. 433 Nasi Ayam Hainan Ricecooker (20 month+):

1. daun bawang iris tipis 2 batang
1.  Nasi Ayam Hainan 
1. paha ayam 1 kg
1. beras 850 gram
1. bawang merah cincang halus 5 buah
1. bawang putih cincang halus 8 siung
1. jahe geprek 2 cm
1. daun pandan simpul 1 lembar
1. margarine 1 sdm
1. minyak wijen 2 sdm
1. air 850 ml
1.  Tumisan Bawang Putih 
1. bawang putih cincang halus 3 siung
1. jahe cincang halus 3 cm
1. minyak wijen 2 sdm
1. minyak sayur 2 sdm
1. kecap manis 1 sdm
1. kecap asin 2 sdm
1. saos tiram 1/2 sdt
1.  Pokcoy Kuah 
1. pokcoy 3 bonggol
1. air 800 ml
1. garam 1/4 sdt
1. kaldu jamur 1/2 sdt



<!--inarticleads2-->

## Langkah-langkah Untuk Menyiapkan Day. 433 Nasi Ayam Hainan Ricecooker (20 month+):

1. Cuci bersih ayam. Kerat dagingnya. Tiriskan.
1. 🍛 Nasi Ayam Hainan: Lelehkan margarine dan minyak wijen. Tumis bawang putih dan bawang merah hingga kecokelatan. Kecilkan api. Masukkan beras, aduk rata. Tambahkan air, aduk rata. Gunakan api sedang. Masak hingga mulai mendidih. Matikan api.
1. Tuang beras ke dalam ricecooker. Susun daun pandan, jahe dan ayam. Masak hingga matang. Setelah matang, ambil daun pandan, jahe dan ayam. Lalu aduk nasinya.
1. Tumis bawang putih dan jahe dengan minyak sayur dan minyak wijen hingga kecokelatan. Tambahkan sisa bahan lainnya, aduk rata. Matikan api.
1. Rebus air hingga mendidih. Masukkan pokcoy. Masak hingga empuk. Tambahkan garam dan kaldu jamur. Matikan api. Koreksi rasa.
1. Tata nasi dan ayam di piring. Siram ayam dengan tulisan bawang putih. Taburi daun bawang. Sajikan dengan pokcoy kuah.




Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
