---
description: "Bagaimana Menyiapkan Nasi ayam semarang, Bisa Manjain Lidah"
title: "Bagaimana Menyiapkan Nasi ayam semarang, Bisa Manjain Lidah"
slug: 461-bagaimana-menyiapkan-nasi-ayam-semarang-bisa-manjain-lidah
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-16T18:40:53.300Z 
thumbnail: https://img-global.cpcdn.com/recipes/2f6f90803a744a56/682x484cq65/nasi-ayam-semarang-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/2f6f90803a744a56/682x484cq65/nasi-ayam-semarang-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/2f6f90803a744a56/682x484cq65/nasi-ayam-semarang-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/2f6f90803a744a56/682x484cq65/nasi-ayam-semarang-foto-resep-utama.webp
author: Adeline Baldwin
ratingvalue: 3.3
reviewcount: 11
recipeingredient:
- "ayam tanpa kepala dan jeroan 1 ekor"
- "telor rebus 10 butir"
- "tahu goreng 12 buah"
- "santan kental 100 ml"
- "santan cair 500 ml"
- "air 300 ml"
- "kaldu ayam bubuk saya pakai merk jays 1 sdm"
- "Garam dan gula secukupnya"
- "Gula jawa secukupnya"
- "Bumbu halus  "
- "bawang merah 6 buah"
- "bawang putih 4 buah"
- "kemiri sangrai 3 buah"
- "kunyit bakar 3 cm"
- "ketumbar sangrai 1 sdm"
- "jahe 1 ruas"
- "Bahan tumisan  "
- "laos dipotong2 5 cm"
- "daun jeruk 3 lembar"
- "daun salam 2 lembar"
- "sereh digeprek 2"
recipeinstructions:
- "Potong ayam menjadi beberapa bagian, sisihkan"
- "Blender bumbu dengan minyak agar dapat benar2 halus, tumis sampai benar2 wangi dan matang"
- "Masukan bumbu tambahan, lalu masukan ayam, tumis sebentar sekitar 5 menit"
- "Masukan air dan santan cair"
- "Masukan telor dan tahu"
- "Masak sampai matang dan meresap sambil sesekali diaduk agar santan tidak pecah"
- "Bumbui dengan garam, gula, gula jawa, kaldu ayam bubuk, koreksi rasa"
- "Masukan santan kental"
- "Siap disajikan"
categories:
- Resep
tags:
- nasi
- ayam
- semarang

katakunci: nasi ayam semarang 
nutrition: 124 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT58M"
recipeyield: "3"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi ayam semarang](https://img-global.cpcdn.com/recipes/2f6f90803a744a56/682x484cq65/nasi-ayam-semarang-foto-resep-utama.webp)

Ingin membuat Nasi ayam semarang ? Coba resep berikut ini. Cara memasaknya sangat praktis namun hasilnya gurih dan lezat cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Dibutuhkan Dalam Menyiapkan Nasi ayam semarang:

1. ayam tanpa kepala dan jeroan 1 ekor
1. telor rebus 10 butir
1. tahu goreng 12 buah
1. santan kental 100 ml
1. santan cair 500 ml
1. air 300 ml
1. kaldu ayam bubuk saya pakai merk jays 1 sdm
1. Garam dan gula secukupnya
1. Gula jawa secukupnya
1. Bumbu halus  
1. bawang merah 6 buah
1. bawang putih 4 buah
1. kemiri sangrai 3 buah
1. kunyit bakar 3 cm
1. ketumbar sangrai 1 sdm
1. jahe 1 ruas
1. Bahan tumisan  
1. laos dipotong2 5 cm
1. daun jeruk 3 lembar
1. daun salam 2 lembar
1. sereh digeprek 2

Semarang jangan lupa Baca juga Kumpulan Pin BB Artis Indonesia Terbaru. Jawa Tengah, Kota Magelang, Kota Pekalongan, Kota Salatiga, Kota Semarang, Kota Surakarta, Kota Tegal. Nasi ayam menyajikan citarasa gurih yang cukup pekat karena disiram kuah opor. Pasti rugi, deh kalau ke Semarang kalian gak icip kuliner nasi ayam ini. 

<!--inarticleads2-->

## Langkah-langkah Untuk Membuat Nasi ayam semarang:

1. Potong ayam menjadi beberapa bagian, sisihkan
1. Blender bumbu dengan minyak agar dapat benar2 halus, tumis sampai benar2 wangi dan matang
1. Masukan bumbu tambahan, lalu masukan ayam, tumis sebentar sekitar 5 menit
1. Masukan air dan santan cair
1. Masukan telor dan tahu
1. Masak sampai matang dan meresap sambil sesekali diaduk agar santan tidak pecah
1. Bumbui dengan garam, gula, gula jawa, kaldu ayam bubuk, koreksi rasa
1. Masukan santan kental
1. Siap disajikan


You can choose to buy it spicy or not. The skewers were also good This is a very good Nasi Ayam, the best in Semarang. The portion of vegetables and other ingredients are. Pagi semua, Ini aku posting lagi menu Nasi Ayam Semarang ya teman-teman, walau dulu udah pernah posting, tapi ini ada beberapa pelengkap yang baru. Tapi jangan di sama-samakan, karena baik orang semarang dan orang solo, suka tidak terima jika antara nasi liwet di samakan dengan nasi ayam. 

Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
