---
description: "Resep Nasi daun jeruk tampah Anti Gagal"
title: "Resep Nasi daun jeruk tampah Anti Gagal"
slug: 339-resep-nasi-daun-jeruk-tampah-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-12T02:14:39.670Z 
thumbnail: https://img-global.cpcdn.com/recipes/dea6011942541962/682x484cq65/nasi-daun-jeruk-tampah-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/dea6011942541962/682x484cq65/nasi-daun-jeruk-tampah-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/dea6011942541962/682x484cq65/nasi-daun-jeruk-tampah-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/dea6011942541962/682x484cq65/nasi-daun-jeruk-tampah-foto-resep-utama.webp
author: Edward Willis
ratingvalue: 3.8
reviewcount: 9
recipeingredient:
- "beras 2 kg"
- "sun kara 400 ml"
- "daun jeruk buang tulangiris tipis 1 ons"
- "lengkuas iris tipis 25 gr"
- "jahe iris tipis 15 gr"
- "daun salam 7 lembar"
- "sereh 5 btg"
- "bawang merah 20 gr"
- "bawang putih 20 gr"
- "royco 2 sdm"
- "garam 2 sdt"
recipeinstructions:
- "Cuci beras sampai bersih, masukkan ke panci/ rice cooker"
- "Masukkan sun kara"
- "Masukkan daun jeruk yg sudah diiris tipis, ratakan."
- "Masukkan bawang putih dan bawang merah yg sudah di haluskan dan ditumis"
- "Masukkan sereh yg sudah digeprek, daun salam, jahe, lengkuas, garam, dan royco."
- "Tambahkan air kurang lebih 2 liter"
- "Aduk2 dan cicipi. Masak sampe air larut."
- "Jika tdk matang dikukus, sajikan selagi hangat, tambahkan topping bawang goreng."
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 173 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT48M"
recipeyield: "1"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi daun jeruk tampah](https://img-global.cpcdn.com/recipes/dea6011942541962/682x484cq65/nasi-daun-jeruk-tampah-foto-resep-utama.webp)

Resep Nasi daun jeruk tampah    dengan 8 langkahcepat dan mudah cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Dibutuhkan Dalam Pembuatan Nasi daun jeruk tampah:

1. beras 2 kg
1. sun kara 400 ml
1. daun jeruk buang tulangiris tipis 1 ons
1. lengkuas iris tipis 25 gr
1. jahe iris tipis 15 gr
1. daun salam 7 lembar
1. sereh 5 btg
1. bawang merah 20 gr
1. bawang putih 20 gr
1. royco 2 sdm
1. garam 2 sdt

Aromanya yang khas memang bisa membuat siapa saja. Nasi Daun Jeruk, Sambal Goreng Kentang Udang, Ayam Goreng Lengkuas, Tumis Buncis, Bakwan Jagung, Lalapan, Sambal Bajak, Kerupuk. Nasi tumpeng komplit merupakan nasi tumpeng yang ada pada umumnya Bedanya, untuk nasi tumpeng komplit dari Kami ini Anda dapat memilih jenis nasi yang akan dibuat tumpeng, misal nasi kuning, atau nasi biasa, atau bisa juga nasi daun jeruk khas Kami. Sajian nasi jeruk tumis teri ini pasti sulit ditolak. 

<!--inarticleads2-->

## Cara Menyiapkan Nasi daun jeruk tampah:

1. Cuci beras sampai bersih, masukkan ke panci/ rice cooker
1. Masukkan sun kara
1. Masukkan daun jeruk yg sudah diiris tipis, ratakan.
1. Masukkan bawang putih dan bawang merah yg sudah di haluskan dan ditumis
1. Masukkan sereh yg sudah digeprek, daun salam, jahe, lengkuas, garam, dan royco.
1. Tambahkan air kurang lebih 2 liter
1. Aduk2 dan cicipi. Masak sampe air larut.
1. Jika tdk matang dikukus, sajikan selagi hangat, tambahkan topping bawang goreng.


Ikuti cara membuatnya berikut ini, dan hidangkan untuk keluarga tercinta di rumah! Kita hanya perlu menyiapkan nasi, daun jeruk, teri Medan, dan rempah seperti bawang putih, bawang merah, serai, dan cabai. Cara penyajian nasi ini khas Jawa atau masyarakat Betawi keturunan Jawa dan biasanya dibuat pada saat kenduri atau perayaan suatu kejadian penting. Tumpeng biasa disajikan di atas tampah (wadah bundar tradisional dari anyaman bambu) dan dialasi daun pisang. Nasi daun jeruk kini menjadi salah satu makanan hits yang digemari banyak orang. 

Terima kasih telah membaca resep yang kami tampilkan di halaman ini. Selamat mencoba!
