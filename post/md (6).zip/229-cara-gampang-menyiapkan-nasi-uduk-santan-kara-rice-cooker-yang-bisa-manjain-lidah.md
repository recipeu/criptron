---
description: "Cara Gampang Menyiapkan Nasi Uduk Santan Kara Rice Cooker yang Bisa Manjain Lidah"
title: "Cara Gampang Menyiapkan Nasi Uduk Santan Kara Rice Cooker yang Bisa Manjain Lidah"
slug: 229-cara-gampang-menyiapkan-nasi-uduk-santan-kara-rice-cooker-yang-bisa-manjain-lidah
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-05T22:18:45.888Z 
thumbnail: https://img-global.cpcdn.com/recipes/cb84b1bd0da6e640/682x484cq65/nasi-uduk-santan-kara-rice-cooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/cb84b1bd0da6e640/682x484cq65/nasi-uduk-santan-kara-rice-cooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/cb84b1bd0da6e640/682x484cq65/nasi-uduk-santan-kara-rice-cooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/cb84b1bd0da6e640/682x484cq65/nasi-uduk-santan-kara-rice-cooker-foto-resep-utama.webp
author: Estella Clayton
ratingvalue: 3.9
reviewcount: 10
recipeingredient:
- "Beras 3 Cup"
- "Santan Kara Santan Instan 1 Bungkus"
- "Sereh 1 Batang"
- "Daun Salam Kecil 2 Lembar"
- "Daun Jeruk 2 Lembar"
- "LengkuasLaos 1 Cm"
- "Garam Bisa di sesuaikan selera 1 1/2 Sdt"
- "Air Bisa di sesuaikan lebih suka pulen  tidak Secukupnya"
recipeinstructions:
- "Cuci beras sampai bersih  Lalu masukan Sereh,Lengkuas,Daun Salam,Daun Jeruk (Lengkuas dan Sereh di geprek)"
- "Lalu masukan Santan Instan beserta air bisa di sesuaikan seperti memasak nasi putih di ricecooker lalu aduk tambahkan garam aduk dan masukan di ricecooker"
- "Tunggu sampai mendidih buka ricecooker aduk supaya rasanya menyatu semua,bisa icip sedikit untuk koreksi rasa yg di mau tutup kembali diamkan hingga matang  Nasi uduk siap di sajikan"
categories:
- Resep
tags:
- nasi
- uduk
- santan

katakunci: nasi uduk santan 
nutrition: 208 calories
recipecuisine: Indonesian
preptime: "PT39M"
cooktime: "PT54M"
recipeyield: "4"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Santan Kara Rice Cooker](https://img-global.cpcdn.com/recipes/cb84b1bd0da6e640/682x484cq65/nasi-uduk-santan-kara-rice-cooker-foto-resep-utama.webp)

3 langkah mudah dan cepat memasak  Nasi Uduk Santan Kara Rice Cooker cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Untuk Pembuatan Nasi Uduk Santan Kara Rice Cooker:

1. Beras 3 Cup
1. Santan Kara Santan Instan 1 Bungkus
1. Sereh 1 Batang
1. Daun Salam Kecil 2 Lembar
1. Daun Jeruk 2 Lembar
1. LengkuasLaos 1 Cm
1. Garam Bisa di sesuaikan selera 1 1/2 Sdt
1. Air Bisa di sesuaikan lebih suka pulen  tidak Secukupnya



<!--inarticleads2-->

## Tata Cara Membuat Nasi Uduk Santan Kara Rice Cooker:

1. Cuci beras sampai bersih  - Lalu masukan Sereh,Lengkuas,Daun Salam,Daun Jeruk (Lengkuas dan Sereh di geprek)
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/0938d07ffaa60643/160x128cq70/nasi-uduk-santan-kara-rice-cooker-langkah-memasak-1-foto.webp" alt="Nasi Uduk Santan Kara Rice Cooker" width="340" height="340">
>1. Lalu masukan Santan Instan beserta air bisa di sesuaikan seperti memasak nasi putih di ricecooker lalu aduk tambahkan garam aduk dan masukan di ricecooker
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/e127e8ab0b057c94/160x128cq70/nasi-uduk-santan-kara-rice-cooker-langkah-memasak-2-foto.webp" alt="Nasi Uduk Santan Kara Rice Cooker" width="340" height="340">
>1. Tunggu sampai mendidih buka ricecooker aduk supaya rasanya menyatu semua,bisa icip sedikit untuk koreksi rasa yg di mau tutup kembali diamkan hingga matang  - Nasi uduk siap di sajikan




Terima kasih telah membaca resep yang tim kami tampilkan di sini. Selamat mencoba!
