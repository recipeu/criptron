---
description: "Bagaimana Membuat Nasi Bakar Ikan Tuna, Bisa Manjain Lidah"
title: "Bagaimana Membuat Nasi Bakar Ikan Tuna, Bisa Manjain Lidah"
slug: 347-bagaimana-membuat-nasi-bakar-ikan-tuna-bisa-manjain-lidah
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-24T10:43:37.492Z 
thumbnail: https://img-global.cpcdn.com/recipes/f38eb5b9a02c4827/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/f38eb5b9a02c4827/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/f38eb5b9a02c4827/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/f38eb5b9a02c4827/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp
author: Lettie Joseph
ratingvalue: 3.2
reviewcount: 9
recipeingredient:
- "daging tuna fillet 1 kg"
- "bwamg merah 5 siung"
- "bawang putih 8 siung"
- "cabe keriting 5"
- "cabe rawit cincang atau sesuai selera 15"
- "jeruk nipis untuk perasan 1 buah"
- "buncis 100 gr"
- "I sdt merica bubuk "
- "Garam secukupmyq "
- "Gula secukupnya"
- "Kaldu bubuk secukupnya"
- "berasmasak terlebih dahulu 500 gr"
- "Daun seredaun salamdaun jerukdaun kemangi secukupnya"
- "Daun pisang untuk membeungkus "
recipeinstructions:
- "Masak beras terlebih dahulu sperti biasa bunda masak namun tambahkan bawang putih 2 siung cincang halus,daun salam daun sere,tambahkan garam"
- "Perasi daging tuna dengan jeruk nipis diamkan 10 menit,setelahnya,kukus 15 menit.angkat,suir2"
- "Haluskan bawang putih cabe keriting merica gula garam bawang putih kaldu bubuk,tambahkan daun salam daun sere dan dauun jeruk tumis hingga harum dan masak..masukkan daging tuna dan buncis cabe cincang.koreksi rasa"
- "Ambil daun pisang,bersihkan dan lemaskan diatas dandang bbrp menit..lalu mskkan nasi dijabarkan dan isi dengan daging tuna yang telah masak beri kemmngi..bungkus rapi.Kukus 10 menit"
- "Setelah itu ambil bagian yg sudah terkukus..bakar sejenak..dan siap dinikmati"
categories:
- Resep
tags:
- nasi
- bakar
- ikan

katakunci: nasi bakar ikan 
nutrition: 281 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT51M"
recipeyield: "4"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Bakar Ikan Tuna](https://img-global.cpcdn.com/recipes/f38eb5b9a02c4827/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp)

Resep rahasia Nasi Bakar Ikan Tuna    dengan 5 langkahmudah cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Dibutuhkan Untuk Menyiapkan Nasi Bakar Ikan Tuna:

1. daging tuna fillet 1 kg
1. bwamg merah 5 siung
1. bawang putih 8 siung
1. cabe keriting 5
1. cabe rawit cincang atau sesuai selera 15
1. jeruk nipis untuk perasan 1 buah
1. buncis 100 gr
1. I sdt merica bubuk 
1. Garam secukupmyq 
1. Gula secukupnya
1. Kaldu bubuk secukupnya
1. berasmasak terlebih dahulu 500 gr
1. Daun seredaun salamdaun jerukdaun kemangi secukupnya
1. Daun pisang untuk membeungkus 



<!--inarticleads2-->

## Langkah-langkah Untuk Menyiapkan Nasi Bakar Ikan Tuna:

1. Masak beras terlebih dahulu sperti biasa bunda masak namun tambahkan bawang putih 2 siung cincang halus,daun salam daun sere,tambahkan garam
1. Perasi daging tuna dengan jeruk nipis diamkan 10 menit,setelahnya,kukus 15 menit.angkat,suir2
1. Haluskan bawang putih cabe keriting merica gula garam bawang putih kaldu bubuk,tambahkan daun salam daun sere dan dauun jeruk tumis hingga harum dan masak..masukkan daging tuna dan buncis cabe cincang.koreksi rasa
1. Ambil daun pisang,bersihkan dan lemaskan diatas dandang bbrp menit..lalu mskkan nasi dijabarkan dan isi dengan daging tuna yang telah masak beri kemmngi..bungkus rapi.Kukus 10 menit
1. Setelah itu ambil bagian yg sudah terkukus..bakar sejenak..dan siap dinikmati




Daripada bunda beli  Nasi Bakar Ikan Tuna  diluar terus, kamu  bisa membuatnya sendiri dirumah. Resep  Nasi Bakar Ikan Tuna  sederhana ini cukup praktis dalam proses pembuatannya, serta cukup menggunakan bumbu-bumbu sederhana yang ada di dapur  Nasi Bakar Ikan Tuna  yang enak, ibu nikmati di rumah.
