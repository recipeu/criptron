---
description: "Bagaimana Membuat Nasi Bakar Pampis Tuna Anti Gagal"
title: "Bagaimana Membuat Nasi Bakar Pampis Tuna Anti Gagal"
slug: 368-bagaimana-membuat-nasi-bakar-pampis-tuna-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-22T03:33:22.615Z 
thumbnail: https://img-global.cpcdn.com/recipes/89e2f10126fcb62b/682x484cq65/nasi-bakar-pampis-tuna-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/89e2f10126fcb62b/682x484cq65/nasi-bakar-pampis-tuna-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/89e2f10126fcb62b/682x484cq65/nasi-bakar-pampis-tuna-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/89e2f10126fcb62b/682x484cq65/nasi-bakar-pampis-tuna-foto-resep-utama.webp
author: Charlie Price
ratingvalue: 3
reviewcount: 10
recipeingredient:
- "Nasi putih "
- "Isian Nasi Bakar pampis tuna  "
- "ikan tuna kukus tanpa duri suwir2 250 gram"
- "daun kemangi 1 ikat"
- "daun bawang iris halus 2 batang"
- "daun jeruk iris halus 8 lembar"
- "Garam gula secukupnya"
- "Bumbu halus  "
- "cabe merah besar 2 buah"
- "cabe rawit 5 buah"
- "bawang merah 3 siung"
- "bawang putih 2 siung"
- "kunyit 1 ruas jari"
- "jahe 1 ruas jari"
- "serai ambil putihnya saja 1 batang"
- "Daun pisang dan tusuk gigi untuk membungkus "
recipeinstructions:
- "Isian pampis tuna : Tumis bumbu halus sampai matang, kemudian masukkan daun jeruk iris, tuna, garam dan gula. Aduk2, jika sudah hampir kering masukkan daun bawang dan kemangi. Aduk rata, angkat"
- "Letakkan 2 centong nasi keatas daun pisang, ratakan dan lebarkan. Taruh 5 sdm pampis ditengah nasi, lalu gulung daun pisang dan sematkan dengan tusuk gigi seperti membuat lontong."
- "Panggang sampai tercium wangi daun pisang. Sajikan hangat"
categories:
- Resep
tags:
- nasi
- bakar
- pampis

katakunci: nasi bakar pampis 
nutrition: 261 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT41M"
recipeyield: "4"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Bakar Pampis Tuna](https://img-global.cpcdn.com/recipes/89e2f10126fcb62b/682x484cq65/nasi-bakar-pampis-tuna-foto-resep-utama.webp)

Resep dan cara mengolah  Nasi Bakar Pampis Tuna cocok banget jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Untuk Pembuatan Nasi Bakar Pampis Tuna:

1. Nasi putih 
1. Isian Nasi Bakar pampis tuna  
1. ikan tuna kukus tanpa duri suwir2 250 gram
1. daun kemangi 1 ikat
1. daun bawang iris halus 2 batang
1. daun jeruk iris halus 8 lembar
1. Garam gula secukupnya
1. Bumbu halus  
1. cabe merah besar 2 buah
1. cabe rawit 5 buah
1. bawang merah 3 siung
1. bawang putih 2 siung
1. kunyit 1 ruas jari
1. jahe 1 ruas jari
1. serai ambil putihnya saja 1 batang
1. Daun pisang dan tusuk gigi untuk membungkus 



<!--inarticleads2-->

## Langkah-langkah Untuk Menyiapkan Nasi Bakar Pampis Tuna:

1. Isian pampis tuna : - Tumis bumbu halus sampai matang, kemudian masukkan daun jeruk iris, tuna, garam dan gula. Aduk2, jika sudah hampir kering masukkan daun bawang dan kemangi. Aduk rata, angkat
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/5275c445f4828826/160x128cq70/nasi-bakar-pampis-tuna-langkah-memasak-1-foto.webp" alt="Nasi Bakar Pampis Tuna" width="340" height="340">
><img class="lazyload" data-src="https://img-global.cpcdn.com/steps/da667847135fb1f9/160x128cq70/nasi-bakar-pampis-tuna-langkah-memasak-1-foto.webp" alt="Nasi Bakar Pampis Tuna" width="340" height="340">
>1. Letakkan 2 centong nasi keatas daun pisang, ratakan dan lebarkan. Taruh 5 sdm pampis ditengah nasi, lalu gulung daun pisang dan sematkan dengan tusuk gigi seperti membuat lontong.
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/202d7604b334f961/160x128cq70/nasi-bakar-pampis-tuna-langkah-memasak-2-foto.webp" alt="Nasi Bakar Pampis Tuna" width="340" height="340">
><img class="lazyload" data-src="https://img-global.cpcdn.com/steps/79844f09e6a3ec4e/160x128cq70/nasi-bakar-pampis-tuna-langkah-memasak-2-foto.webp" alt="Nasi Bakar Pampis Tuna" width="340" height="340">
><img class="lazyload" data-src="https://img-global.cpcdn.com/steps/0563e3242d041894/160x128cq70/nasi-bakar-pampis-tuna-langkah-memasak-2-foto.webp" alt="Nasi Bakar Pampis Tuna" width="340" height="340">
>1. Panggang sampai tercium wangi daun pisang. Sajikan hangat
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/852449cc3c8d2f87/160x128cq70/nasi-bakar-pampis-tuna-langkah-memasak-3-foto.webp" alt="Nasi Bakar Pampis Tuna" width="340" height="340">
>



Terima kasih telah menggunakan resep yang tim kami tampilkan di sini. Semoga bermanfaat dan selamat mencoba!
