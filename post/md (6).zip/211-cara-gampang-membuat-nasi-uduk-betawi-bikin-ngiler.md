---
description: "Cara Gampang Membuat 💓Nasi Uduk Betawi, Bikin Ngiler"
title: "Cara Gampang Membuat 💓Nasi Uduk Betawi, Bikin Ngiler"
slug: 211-cara-gampang-membuat-nasi-uduk-betawi-bikin-ngiler
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-03T18:42:15.754Z 
thumbnail: https://img-global.cpcdn.com/recipes/7c0fbe8888cf0f65/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/7c0fbe8888cf0f65/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/7c0fbe8888cf0f65/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/7c0fbe8888cf0f65/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
author: Lucile Page
ratingvalue: 4.5
reviewcount: 4
recipeingredient:
- "BAHAN NASI UDUK  "
- "beras cuci bersih 400 gr"
- "santan dengan kekentalan sedang 650 ml"
- "cengkeh 5 buah"
- "daun salam 5 buah"
- "serai dimemarkan 2 batang"
- "lengkuas dimemarkan 3 cm"
- "jahe dimemarkan 2 cm"
- "garam 2 sdt"
- "pala tidak dimemarkan 1/2 butir"
- "kayu manis 3 cm"
- "PELENGKAP  "
- "Bawang goreng "
- "Kerupuk emping "
- "Sambal goreng kentang "
- "Ayam goreng sambal tempe sambal telur "
- "Timun iris untuk lalapan "
- "Sayur campur  Mie sayur "
recipeinstructions:
- "Cuci bersih beras, isi wadah beras dengan air sebanyak air biasa kita memasak nasi, lalu ukur air cucian itu agar kita tahu berapa banyak santan yg dibutuhkan. Nanti santannya sebanyak air cucian kita itu. Masukkan dalam wajan semua bumbu, beras dan santan. Masak dengan api sedang sambil terus diaduk hingga menjadi kesat. Tidak ada air lagi di bagian bawah wajan (video ketiga). Matikan api."
- "Gambar 1 : hasil setelah dimasak di wajan, beras masih agak berair tapi tidak ada santan cair lagi di wajan atau di bawah wajan. Gambar 2 : dandang/kukusan saya alasi daun pandan, bisa diganti daun pisang, atau tidak pakai alas juga tidak apa. Gambar 3 : beras saya masukkan ke wajan."
- "Hitung 20-30 menit dari sejak kukusan mendidih. Lihat lagi apakah sudah jadi nasi. Bisa ditest dimakan, Jika dirasa kurang matang, bisa siram dengan air minum (air panas lebih baik) sedikit (sekitar ½ gelas) lalu didihkan lagi sekitar 10 menit. Cek lagi. Jika sudah matang, matikan api."
- "Jika sudah agak hangat, segera ambil semua bumbu dari nasi terutama lengkuas dan sereh agar tidak merubah warna nasi, lengkuas akan meninggalkan bekas warna pink di nasi jika lama didiamkan."
- "Sayur campur bisa lihat di resep ini ya 👇 https://cookpad.com/id/resep/3150052-sayur-campur?invite_token=LmXjscdLfTxcBQyk9NjuY6sc&amp;shared_at=1594221307"
- "Untuk sambal kering kentangnya bisa lihat di resep ini 👇 https://cookpad.com/id/resep/13100530-kering-kentang-mustofa?invite_token=Hb2PLCRX85kziC34wN4E3aYT&amp;shared_at=1594221705"
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 237 calories
recipecuisine: Indonesian
preptime: "PT15M"
cooktime: "PT58M"
recipeyield: "2"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![💓Nasi Uduk Betawi](https://img-global.cpcdn.com/recipes/7c0fbe8888cf0f65/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp)

Resep rahasia 💓Nasi Uduk Betawi  enak dengan 6 langkahmudah dan cepat cocok sekali jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Untuk Menyiapkan 💓Nasi Uduk Betawi:

1. BAHAN NASI UDUK  
1. beras cuci bersih 400 gr
1. santan dengan kekentalan sedang 650 ml
1. cengkeh 5 buah
1. daun salam 5 buah
1. serai dimemarkan 2 batang
1. lengkuas dimemarkan 3 cm
1. jahe dimemarkan 2 cm
1. garam 2 sdt
1. pala tidak dimemarkan 1/2 butir
1. kayu manis 3 cm
1. PELENGKAP  
1. Bawang goreng 
1. Kerupuk emping 
1. Sambal goreng kentang 
1. Ayam goreng sambal tempe sambal telur 
1. Timun iris untuk lalapan 
1. Sayur campur  Mie sayur 



<!--inarticleads2-->

## Cara Menyiapkan 💓Nasi Uduk Betawi:

1. Cuci bersih beras, isi wadah beras dengan air sebanyak air biasa kita memasak nasi, lalu ukur air cucian itu agar kita tahu berapa banyak santan yg dibutuhkan. Nanti santannya sebanyak air cucian kita itu. Masukkan dalam wajan semua bumbu, beras dan santan. Masak dengan api sedang sambil terus diaduk hingga menjadi kesat. Tidak ada air lagi di bagian bawah wajan (video ketiga). Matikan api.
<img class="lazyload" data-src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="💓Nasi Uduk Betawi" width="340" height="340">
><img class="lazyload" data-src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="💓Nasi Uduk Betawi" width="340" height="340">
>1. Gambar 1 : hasil setelah dimasak di wajan, beras masih agak berair tapi tidak ada santan cair lagi di wajan atau di bawah wajan. - Gambar 2 : dandang/kukusan saya alasi daun pandan, bisa diganti daun pisang, atau tidak pakai alas juga tidak apa. - Gambar 3 : beras saya masukkan ke wajan.
1. Hitung 20-30 menit dari sejak kukusan mendidih. Lihat lagi apakah sudah jadi nasi. Bisa ditest dimakan, Jika dirasa kurang matang, bisa siram dengan air minum (air panas lebih baik) sedikit (sekitar ½ gelas) lalu didihkan lagi sekitar 10 menit. Cek lagi. Jika sudah matang, matikan api.
1. Jika sudah agak hangat, segera ambil semua bumbu dari nasi terutama lengkuas dan sereh agar tidak merubah warna nasi, lengkuas akan meninggalkan bekas warna pink di nasi jika lama didiamkan.
1. Sayur campur bisa lihat di resep ini ya 👇 https://cookpad.com/id/resep/3150052-sayur-campur?invite_token=LmXjscdLfTxcBQyk9NjuY6sc&amp;shared_at=1594221307
1. Untuk sambal kering kentangnya bisa lihat di resep ini 👇 https://cookpad.com/id/resep/13100530-kering-kentang-mustofa?invite_token=Hb2PLCRX85kziC34wN4E3aYT&amp;shared_at=1594221705




Demikian informasi  resep 💓Nasi Uduk Betawi   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
