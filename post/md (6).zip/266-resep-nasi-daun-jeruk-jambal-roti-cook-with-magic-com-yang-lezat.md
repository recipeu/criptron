---
description: "Resep Nasi daun jeruk jambal roti (cook with magic com) yang Lezat"
title: "Resep Nasi daun jeruk jambal roti (cook with magic com) yang Lezat"
slug: 266-resep-nasi-daun-jeruk-jambal-roti-cook-with-magic-com-yang-lezat
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-30T02:34:41.019Z 
thumbnail: https://img-global.cpcdn.com/recipes/5b9453d9e6a12ca4/682x484cq65/nasi-daun-jeruk-jambal-roti-cook-with-magic-com-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/5b9453d9e6a12ca4/682x484cq65/nasi-daun-jeruk-jambal-roti-cook-with-magic-com-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/5b9453d9e6a12ca4/682x484cq65/nasi-daun-jeruk-jambal-roti-cook-with-magic-com-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/5b9453d9e6a12ca4/682x484cq65/nasi-daun-jeruk-jambal-roti-cook-with-magic-com-foto-resep-utama.webp
author: Florence Lynch
ratingvalue: 5
reviewcount: 4
recipeingredient:
- "beras 500 gram"
- "ikan asin jambal roti 200 gram"
- "serai geprek iris bagian putihnya 2 batang"
- "cabe rawit utuh 15 buah"
- "garam 1 sdm"
- "santan kental 100 ml"
- "daun jeruk rajang tipis 25 lembar"
- "ruas lengkuas geprek 5 cm"
- "Bumbu halus "
- "bawang putih 7 siung"
- "bawang merah 10 siung"
recipeinstructions:
- "Cuci bersih ikan jambal roti kemudian goreng sebentar jangan terlalu kering sisihkan"
- "Tumis bumbu halus sampai wangi tambahkan serai,garam,lengkuas dan terakhir masukkkan daun jeruk yang telah dirajang tumis sbntr sampai daun jeruk wangi lalu tambahkan 200 ml air kemudian matikan api"
- "Masukkan tumisan bumbu ke dalam beras yang telah dicuci masukkan ke dalam wadah magic com tambahkan 100 ml santan kental, masak menggunakan magic com 10 menit sebelum matang masukkan cabe rawit utuh dan ikan asin jambal roti yang telah digoreng tutup kembali biarkan sampai matang"
- "Nasi daun jeruk jambal roti siap dihidangkan"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 133 calories
recipecuisine: Indonesian
preptime: "PT38M"
cooktime: "PT52M"
recipeyield: "4"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi daun jeruk jambal roti (cook with magic com)](https://img-global.cpcdn.com/recipes/5b9453d9e6a12ca4/682x484cq65/nasi-daun-jeruk-jambal-roti-cook-with-magic-com-foto-resep-utama.webp)

Resep rahasia Nasi daun jeruk jambal roti (cook with magic com)    dengan 4 langkahcepat yang musti bunda coba dirumah

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Dalam Pembuatan Nasi daun jeruk jambal roti (cook with magic com):

1. beras 500 gram
1. ikan asin jambal roti 200 gram
1. serai geprek iris bagian putihnya 2 batang
1. cabe rawit utuh 15 buah
1. garam 1 sdm
1. santan kental 100 ml
1. daun jeruk rajang tipis 25 lembar
1. ruas lengkuas geprek 5 cm
1. Bumbu halus 
1. bawang putih 7 siung
1. bawang merah 10 siung

Roti can be stuffed with potatoes or lentils before it&#39;s cooked, used as a wrap, or simply served on the side of a plate of curry or dhal to help soak up all of the delicious sauce. Masukan beras ke rice cooker tambahkan tumisan bawang, tambahkan kekurangan air seperti memasak nasi biasanya. Tekan tombol cook pada rice cooker. Saat nasi mendidih di rice cooker, masukan ikan dan irisan cabe. 

<!--inarticleads2-->

## Cara Mudah Membuat Nasi daun jeruk jambal roti (cook with magic com):

1. Cuci bersih ikan jambal roti kemudian goreng sebentar jangan terlalu kering sisihkan
1. Tumis bumbu halus sampai wangi tambahkan serai,garam,lengkuas dan terakhir masukkkan daun jeruk yang telah dirajang tumis sbntr sampai daun jeruk wangi lalu tambahkan 200 ml air kemudian matikan api
1. Masukkan tumisan bumbu ke dalam beras yang telah dicuci masukkan ke dalam wadah magic com tambahkan 100 ml santan kental, masak menggunakan magic com 10 menit sebelum matang masukkan cabe rawit utuh dan ikan asin jambal roti yang telah digoreng tutup kembali biarkan sampai matang
1. Nasi daun jeruk jambal roti siap dihidangkan


But what happens when someone tries to market our humble roti as something else? Recently, when an Italian channel called &#34;Cookist&#34; shared a recipe of roti and called it &#34;Balloon bread,&#34; people on the internet were definitely left amused! This essential recipe was adapted from rasamalaysia.com and can serve as a base for any other type of nasi goreng. Accompanied by a fried egg and enhanced with fresh shrimp and leftover meat, this version of nasi goreng can be served as a hearty breakfast, lunch or dinner. Oseng Ikan Asin Jambal Roti Cabai Hijau. 

Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
