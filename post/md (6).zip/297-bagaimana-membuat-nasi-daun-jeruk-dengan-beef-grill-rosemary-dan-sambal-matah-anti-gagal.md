---
description: "Bagaimana Membuat Nasi daun jeruk dengan Beef grill rosemary dan sambal matah Anti Gagal"
title: "Bagaimana Membuat Nasi daun jeruk dengan Beef grill rosemary dan sambal matah Anti Gagal"
slug: 297-bagaimana-membuat-nasi-daun-jeruk-dengan-beef-grill-rosemary-dan-sambal-matah-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-13T02:39:22.298Z 
thumbnail: https://img-global.cpcdn.com/recipes/4ea6772c2b83156f/682x484cq65/nasi-daun-jeruk-dengan-beef-grill-rosemary-dan-sambal-matah-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/4ea6772c2b83156f/682x484cq65/nasi-daun-jeruk-dengan-beef-grill-rosemary-dan-sambal-matah-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/4ea6772c2b83156f/682x484cq65/nasi-daun-jeruk-dengan-beef-grill-rosemary-dan-sambal-matah-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/4ea6772c2b83156f/682x484cq65/nasi-daun-jeruk-dengan-beef-grill-rosemary-dan-sambal-matah-foto-resep-utama.webp
author: Barbara Chavez
ratingvalue: 3.2
reviewcount: 7
recipeingredient:
- "daging beef slice 250 gr"
- "bawang putihparut dengan parutan keju 1 siung"
- "Secuput garam "
- "Secuput lada "
- "Kaldu ayam "
- "rosemary kering 1 sdt"
- "Nasi daun jeruk "
- "beras cuci bersih 2 cup"
- "bawang putih cincang 2 siung"
- "cabe keriting buang bijinya potong2 1 buah"
- "daun jerukbuang tengahnya dan iris tipis2 10 lembar"
- "garam 1/2 sdt"
- "kaldu jamur 1/2 sdt"
- "kaldu ayam 1/2 sdt"
- "Minyak untuk menumis "
- "Air untuk masak "
- "Sambal matah "
- "bawang merah iris2 7 siung"
- "cabe merah iris2 10 buah"
- "cabe keriting iris2 1 buah"
- "sereh iris tipis bagian putihnya 1 btg"
- "daun jerukiris tipis buang tengahnya 3 lembar"
- "Secuput garam "
- "Minyak menumis "
- "jeruk nipis 1 buah"
recipeinstructions:
- "Cuci beras dan isi dengan air, tumis bawang putih, daun jeruk dan cabe hingga matang, lalu masukkan kedalam beras yg sudah ada airnya, tambahkan garam dan penyedap. Lalu masak di magic com."
- "Cuci bersih beef slice, lalu marinasi dengan masukkan bawang putih, lada, garam, penyedap dan rosemary diemkan selama 20 menit dalam kulkas."
- "Siapkan bahan sambal matah iris semua bahan, panas kan minyak, tumis semua bahan beri garam. Oseng2 sebentar sampai harum. Lalu angkat, dan beri perasan jeruk nipis."
- "Beef slice siap untuk digrill, panaskan grillan tanpa minyak yaa.. grill hingga berubah warna dan angkat."
- "Tata semua masakkan dan siap untuk dinikmati 😄😄"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 280 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT54M"
recipeyield: "1"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi daun jeruk dengan Beef grill rosemary dan sambal matah](https://img-global.cpcdn.com/recipes/4ea6772c2b83156f/682x484cq65/nasi-daun-jeruk-dengan-beef-grill-rosemary-dan-sambal-matah-foto-resep-utama.webp)

Ingin membuat Nasi daun jeruk dengan Beef grill rosemary dan sambal matah ? Coba resep berikut ini. Cara memasaknya sangat praktis namun hasilnya gurih dan lezat yang bisa kamu coba segera

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Dalam Menyiapkan Nasi daun jeruk dengan Beef grill rosemary dan sambal matah:

1. daging beef slice 250 gr
1. bawang putihparut dengan parutan keju 1 siung
1. Secuput garam 
1. Secuput lada 
1. Kaldu ayam 
1. rosemary kering 1 sdt
1. Nasi daun jeruk 
1. beras cuci bersih 2 cup
1. bawang putih cincang 2 siung
1. cabe keriting buang bijinya potong2 1 buah
1. daun jerukbuang tengahnya dan iris tipis2 10 lembar
1. garam 1/2 sdt
1. kaldu jamur 1/2 sdt
1. kaldu ayam 1/2 sdt
1. Minyak untuk menumis 
1. Air untuk masak 
1. Sambal matah 
1. bawang merah iris2 7 siung
1. cabe merah iris2 10 buah
1. cabe keriting iris2 1 buah
1. sereh iris tipis bagian putihnya 1 btg
1. daun jerukiris tipis buang tengahnya 3 lembar
1. Secuput garam 
1. Minyak menumis 
1. jeruk nipis 1 buah

Tata rapi Karage Fiesta yang sudah digoreng di atasnya, siram dengan sambal. A speciality sambal from Bali, sambal with a mixture of sweet, sour, and spicy flavours, made with bongkot or kecombrang flower stems Usually used as condiments for nasi uduk, ketan, or otak-otak. The simple version only employ cabe rawit chilli, crushed fried peanuts, and water. Cara membuat sambal matah ala Bali, mudah dibuat dan bahannya sederhana. 

<!--inarticleads2-->

## Cara Menyiapkan Nasi daun jeruk dengan Beef grill rosemary dan sambal matah:

1. Cuci beras dan isi dengan air, tumis bawang putih, daun jeruk dan cabe hingga matang, lalu masukkan kedalam beras yg sudah ada airnya, tambahkan garam dan penyedap. Lalu masak di magic com.
1. Cuci bersih beef slice, lalu marinasi dengan masukkan bawang putih, lada, garam, penyedap dan rosemary diemkan selama 20 menit dalam kulkas.
1. Siapkan bahan sambal matah iris semua bahan, panas kan minyak, tumis semua bahan beri garam. Oseng2 sebentar sampai harum. Lalu angkat, dan beri perasan jeruk nipis.
1. Beef slice siap untuk digrill, panaskan grillan tanpa minyak yaa.. grill hingga berubah warna dan angkat.
1. Tata semua masakkan dan siap untuk dinikmati 😄😄


Lewat siaran langsung Instagram @kompas.travel, Erwin memperagakan cara memasak Nasi Bali Uluwatu dan Kamu juga bisa menikmati sambal matah sebagai makanan pendamping ikan bakar, ayam. Nasi dengan campuran daun jeruk yang wangi sedang tren. Ditambah karage dan sambal matah, dijamin bikin nagih. Sambal Matah merupakan sambal yang berasal dari Bali. Sambal Matah sangat cocok dijadikan sebagai panganan pendamping untuk ikan bakar, ayam goreng atau lauk lainnya yang dimakan dengan nasi hangat. 

Salah satu masakan yang cukup praktis dalam pembuatannya adalah  Nasi daun jeruk dengan Beef grill rosemary dan sambal matah. Selain itu  Nasi daun jeruk dengan Beef grill rosemary dan sambal matah  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu lakukan 5 langkah, dan  Nasi daun jeruk dengan Beef grill rosemary dan sambal matah  pun siap di hidangkan. selamat mencoba !
