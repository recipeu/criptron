---
description: "Cara Gampang Membuat Nasi uduk betawi yang Menggugah Selera"
title: "Cara Gampang Membuat Nasi uduk betawi yang Menggugah Selera"
slug: 91-cara-gampang-membuat-nasi-uduk-betawi-yang-menggugah-selera
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-12T15:50:27.677Z 
thumbnail: https://img-global.cpcdn.com/recipes/f31e85fe42a1ddfb/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/f31e85fe42a1ddfb/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/f31e85fe42a1ddfb/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/f31e85fe42a1ddfb/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
author: Bobby James
ratingvalue: 3.2
reviewcount: 4
recipeingredient:
- "Nasi uduk "
- "Beras 2 Cup"
- "bawang merah sedang 4 siung"
- "daun salam 3 lembar"
- "sereh 2 batang"
- "kaldu jamur 1 sdt"
- "garam 1/2 sdt"
- "santan kara 35 ml"
- "Air Secukupnya"
- "minyak goreng 2 sdm"
- "Semur "
- "bawang putih sedang 2 siung"
- "bawang merah sedang 4 siung"
- "cabe rawit saya suka pedas 5"
- "kemiri 2 butir"
- "pala 1/2 biji"
- "ketumbar 1 sdt"
- "lada 1/2 sdt"
- "lengkuas 2 ruas"
- "daun salam 2 lembar"
- "Kapulaga 4 butir"
- "Cengkeh 5 pcs"
- "Bunga pekak 2 pcs"
- "telur ayam rebus 4 butir"
- "tahu coklat 10 buah"
- "kentang ukuran sedang 2 buah"
- "Kecap manis Secukupnya"
- "Minyak goreng 3 sdm"
- "kaldu jamur 1 sdt"
- "garam 1/2 sdt"
- "gula pasir 1 sdt"
- "santan kara 35 ml"
- "Air Secukupnya"
- "Sambal kacang "
- "kacang tanah 250 gr"
- "bawang merah sedang 3 siung"
- "bawang merah kecil 1 siung"
- "cabe rawit merah 7"
- "cabe merah 4"
- "kaldu jamur 1 sdt"
- "garam 1 sdt"
- "Minyak goreng Secukupnya"
- "Air Secukupnya"
- "Bihun goreng "
- "Bihun jagung 200 gr"
- "bawang merah sedang 2 siung"
- "bawang putih sedang 4 siung"
- "cabe rawit 3 buah"
- "kecap Secukupnya"
- "Minyak Secukupnya"
recipeinstructions:
- "Cara membuat nasi uduk: Iris bawang merah, tumis bawang merah bersama salam dan sereh. Masukkan tumisan ke beras yg telah di cuci dan di beri air secukupya. Beri santan dan kaldu jamur kemudian aduk dan masak hingga matang. Saya menggunakan magic com."
- "Cara membuat semur: haluskan bawang merah, bawang putih, kemiri, lada, ketumbar &amp; pala. Tumis bumbu halus bersama salam, sereh, dan lengkuas. Beri air secukupnya. Masukkan cengkeh, kapulaga, bunga pekak,kecap manis dan kentang. Beri kaldu jamur, garam dan gula. Masak hingga mendidih dan kentang setengah matang. Lalu masukkan telur &amp; tahu. Masak hingga telur berwarna coklat. Tuangkan santan. Koreksi rasa dan semur siap disajikan."
- "Cara membuat sambal: goreng kacang, bawang merah, bawang putih dan semua cabe hingga matang, tiriskan. Kemudian blender hingga halus. Beri air hingga kekentalan yg di inginkan, masukkan garam dan kaldu jamur. Koreksi rasa."
- "Cara membuat Bihun : rebus bihun hingga matang dan tiriskan. Iris bawang merah, bawang putih dan cabe lalu tumis dengan minyak. Masukkan garam dan kaldu jamur kemudian masukkan bihun yang sudah di rebus, beri kecap dan aduk rata. Koreksi rasa dan bihun siap disajikan"
- "Nasi uduk betawi komplit siap disajikan"
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 158 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT44M"
recipeyield: "1"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi uduk betawi](https://img-global.cpcdn.com/recipes/f31e85fe42a1ddfb/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp)

Resep rahasia Nasi uduk betawi    dengan 5 langkahmudah dan cepat yang bisa bunda coba segera

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Dalam Pembuatan Nasi uduk betawi:

1. Nasi uduk 
1. Beras 2 Cup
1. bawang merah sedang 4 siung
1. daun salam 3 lembar
1. sereh 2 batang
1. kaldu jamur 1 sdt
1. garam 1/2 sdt
1. santan kara 35 ml
1. Air Secukupnya
1. minyak goreng 2 sdm
1. Semur 
1. bawang putih sedang 2 siung
1. bawang merah sedang 4 siung
1. cabe rawit saya suka pedas 5
1. kemiri 2 butir
1. pala 1/2 biji
1. ketumbar 1 sdt
1. lada 1/2 sdt
1. lengkuas 2 ruas
1. daun salam 2 lembar
1. Kapulaga 4 butir
1. Cengkeh 5 pcs
1. Bunga pekak 2 pcs
1. telur ayam rebus 4 butir
1. tahu coklat 10 buah
1. kentang ukuran sedang 2 buah
1. Kecap manis Secukupnya
1. Minyak goreng 3 sdm
1. kaldu jamur 1 sdt
1. garam 1/2 sdt
1. gula pasir 1 sdt
1. santan kara 35 ml
1. Air Secukupnya
1. Sambal kacang 
1. kacang tanah 250 gr
1. bawang merah sedang 3 siung
1. bawang merah kecil 1 siung
1. cabe rawit merah 7
1. cabe merah 4
1. kaldu jamur 1 sdt
1. garam 1 sdt
1. Minyak goreng Secukupnya
1. Air Secukupnya
1. Bihun goreng 
1. Bihun jagung 200 gr
1. bawang merah sedang 2 siung
1. bawang putih sedang 4 siung
1. cabe rawit 3 buah
1. kecap Secukupnya
1. Minyak Secukupnya

Menu siap saji, tinggal goreng dan siap disantap dengan. There are no reviews for Nasi Uduk Betawi Bang Acim, Indonesia yet. Be the first to write a review! Cara membuat nasi uduk betawi bisa dibikin mudah, cukup gunakan magic com. 

<!--inarticleads2-->

## Cara Membuat Nasi uduk betawi:

1. Cara membuat nasi uduk: Iris bawang merah, tumis bawang merah bersama salam dan sereh. Masukkan tumisan ke beras yg telah di cuci dan di beri air secukupya. Beri santan dan kaldu jamur kemudian aduk dan masak hingga matang. Saya menggunakan magic com.
1. Cara membuat semur: haluskan bawang merah, bawang putih, kemiri, lada, ketumbar &amp; pala. Tumis bumbu halus bersama salam, sereh, dan lengkuas. Beri air secukupnya. Masukkan cengkeh, kapulaga, bunga pekak,kecap manis dan kentang. Beri kaldu jamur, garam dan gula. Masak hingga mendidih dan kentang setengah matang. Lalu masukkan telur &amp; tahu. Masak hingga telur berwarna coklat. Tuangkan santan. Koreksi rasa dan semur siap disajikan.
1. Cara membuat sambal: goreng kacang, bawang merah, bawang putih dan semua cabe hingga matang, tiriskan. Kemudian blender hingga halus. Beri air hingga kekentalan yg di inginkan, masukkan garam dan kaldu jamur. Koreksi rasa.
1. Cara membuat Bihun : rebus bihun hingga matang dan tiriskan. Iris bawang merah, bawang putih dan cabe lalu tumis dengan minyak. Masukkan garam dan kaldu jamur kemudian masukkan bihun yang sudah di rebus, beri kecap dan aduk rata. Koreksi rasa dan bihun siap disajikan
1. Nasi uduk betawi komplit siap disajikan


Berikut resep nasi uduk betawi sederhana yang bisa untuk dijual. Resep Nasi Uduk Betawi - Makanan khas Betawi ini cocok sekali dijadikan menu sarapan. Uhh, sajian nasi uduk betawi ini akan semakin lezat dan komplit. Baca Juga : Resep Mie Aceh Tumis. Nasi uduk Betawi memiliki kekhasannya sendiri dan sudah memiliki citra tersendiri. 

Demikian informasi  resep Nasi uduk betawi   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
