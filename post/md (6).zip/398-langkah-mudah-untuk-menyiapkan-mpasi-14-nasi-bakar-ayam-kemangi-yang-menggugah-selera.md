---
description: "Langkah Mudah untuk Menyiapkan MPASI 14+ Nasi Bakar Ayam Kemangi yang Menggugah Selera"
title: "Langkah Mudah untuk Menyiapkan MPASI 14+ Nasi Bakar Ayam Kemangi yang Menggugah Selera"
slug: 398-langkah-mudah-untuk-menyiapkan-mpasi-14-nasi-bakar-ayam-kemangi-yang-menggugah-selera
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-29T16:56:25.607Z 
thumbnail: https://img-global.cpcdn.com/recipes/4bab3ded03902844/682x484cq65/mpasi-14-nasi-bakar-ayam-kemangi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/4bab3ded03902844/682x484cq65/mpasi-14-nasi-bakar-ayam-kemangi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/4bab3ded03902844/682x484cq65/mpasi-14-nasi-bakar-ayam-kemangi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/4bab3ded03902844/682x484cq65/mpasi-14-nasi-bakar-ayam-kemangi-foto-resep-utama.webp
author: Chester Carson
ratingvalue: 5
reviewcount: 3
recipeingredient:
- "Bahan nasi "
- "beras 1 cup"
- "santan instan 1 bungkus"
- "air 240 ml"
- "sereh 1 lembar salam 1 lembar daun pandan 1 batang"
- "Kaldu jamur dan kaldu ayam "
- "Ayam kemangi "
- "Bumbu halus kunyit bawang putih bawang merah jahe cabe merah tanpa biji "
- "ayam fillet rebus 200 gram"
- "Kemangi secukupnya"
- "Salam sereh daun jeruk "
- "Daun pisang untuk membungkus "
recipeinstructions:
- "Campurkan bahan nasi dirice cooker lalu masak seperti biasa"
- "Tumis bumbu halus bersama salam, sereh dan daun jeruk"
- "Setelah bumbu sedikit asat. Masukan ayam yg sudah direbus dan disuwir"
- "Berikan kaldu bubuk, garam, gula kemudian cek rasa"
- "Setelah bumbu meresap dan tercampur rata kecilkan api dan masukan kemangi. Kemudian tumis sebentar sampai sedikit layu"
- "Siapkan daun pisang yg sudah digarang diatas api kecil"
- "Tata nasi lalu masukan isian ayam, kemudia digulung."
- "Setelah digulung bisa langsung dibakar diatas panggangan atau teflon. Bisa juga disimpan didalam lemari es untuk keesokan hari. Selamat mencoba moms !"
categories:
- Resep
tags:
- mpasi
- 14
- nasi

katakunci: mpasi 14 nasi 
nutrition: 185 calories
recipecuisine: Indonesian
preptime: "PT36M"
cooktime: "PT38M"
recipeyield: "2"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![MPASI 14+ Nasi Bakar Ayam Kemangi](https://img-global.cpcdn.com/recipes/4bab3ded03902844/682x484cq65/mpasi-14-nasi-bakar-ayam-kemangi-foto-resep-utama.webp)

Resep rahasia MPASI 14+ Nasi Bakar Ayam Kemangi  sederhana dengan 8 langkahmudah dan cepat cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Dibutuhkan Dalam Pembuatan MPASI 14+ Nasi Bakar Ayam Kemangi:

1. Bahan nasi 
1. beras 1 cup
1. santan instan 1 bungkus
1. air 240 ml
1. sereh 1 lembar salam 1 lembar daun pandan 1 batang
1. Kaldu jamur dan kaldu ayam 
1. Ayam kemangi 
1. Bumbu halus kunyit bawang putih bawang merah jahe cabe merah tanpa biji 
1. ayam fillet rebus 200 gram
1. Kemangi secukupnya
1. Salam sereh daun jeruk 
1. Daun pisang untuk membungkus 



<!--inarticleads2-->

## Cara Mudah Membuat MPASI 14+ Nasi Bakar Ayam Kemangi:

1. Campurkan bahan nasi dirice cooker lalu masak seperti biasa
1. Tumis bumbu halus bersama salam, sereh dan daun jeruk
1. Setelah bumbu sedikit asat. Masukan ayam yg sudah direbus dan disuwir
1. Berikan kaldu bubuk, garam, gula kemudian cek rasa
1. Setelah bumbu meresap dan tercampur rata kecilkan api dan masukan kemangi. Kemudian tumis sebentar sampai sedikit layu
1. Siapkan daun pisang yg sudah digarang diatas api kecil
1. Tata nasi lalu masukan isian ayam, kemudia digulung.
1. Setelah digulung bisa langsung dibakar diatas panggangan atau teflon. Bisa juga disimpan didalam lemari es untuk keesokan hari. Selamat mencoba moms !




Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
