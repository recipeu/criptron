---
description: "Langkah Mudah untuk Membuat Nasi Bakar Ikan Tuna Anti Gagal"
title: "Langkah Mudah untuk Membuat Nasi Bakar Ikan Tuna Anti Gagal"
slug: 365-langkah-mudah-untuk-membuat-nasi-bakar-ikan-tuna-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-31T14:28:10.476Z 
thumbnail: https://img-global.cpcdn.com/recipes/08c0e38fd5cbf070/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/08c0e38fd5cbf070/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/08c0e38fd5cbf070/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/08c0e38fd5cbf070/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp
author: Beulah Strickland
ratingvalue: 3.9
reviewcount: 10
recipeingredient:
- "nasi putih 4 porsi"
- "Ikan tuna Filet 250 gr"
- " 50 gr Jamur Merang "
- "bawang putih keprek dan iris tipis 5 siung"
- "bawang merah iris tipis 2 siung"
- "bawang bombay cincang kasar 1/2 butir"
- "daun bawang iris 1 batang"
- "jahe kupas memarkan 1 ruas"
- "lengkuas kupas memarkan 1 ruas"
- "sereh ambil bagian putih nya lalu memarkan 1 batang"
- "pucuk daun kemangi 1 genggam"
- "kecap asin dpt ditambah sesuai selera 1 sdt"
- "saus tiram dpt ditambah sesuai selera 1 sdt"
- "minyak wijen 1 sdm"
- "merica bubuk 1 sdt"
- "cabe merah iris apabila suka pedas dapat ditambah cabe rawit merah "
- "minyak untuk menumis 5 sdm"
- "air secukupnya"
- "daun salam 2 lembar"
- "daun jeruk 2 lembar"
- "garam secukupnya"
- "daun pisang "
- "gigi tusuk"
recipeinstructions:
- "Didihkan air, masukan ikan tuna rebus sampai berubah warna, angkat lalu tiriskan, setelah dingin suir suir"
- "Panaskan minyak, tumis bawang merah, bawang putih, bawang bombai sampai harum"
- "Tambahkan cabe, tumis sebentar, masukan sereh, daun salam, daun jeruk, jahe, dan lengkuas"
- "Masukan potongan ikan tuna, dan jamur merang, kemudian tambahkan kecap asin, saus tiram, minyak wijen dan merica bubuk, dan garam"
- "Tuang sedikit air, aduk sampai air mendidih, kemudian masukan daun bawang dan daun kemangi, masak sebentar, tes rasa"
- "Apabila rasa sudah pas, matikan api"
- "Siapkan wadah, masukan nasi dan tumisan, aduk rata, buang sereh, daun salam, daun jeruk, jahe, dan lengkuas"
- "Bersihkan daun pisang, potong sesuai selera, kukus sebentar agar daun pisang lemas dan mudah dibentuk"
- "Ambil 2 lembar daun pisang, isi dengan campuran nasi, gulung lalu lipat ujungnya dan sematkan tusuk gigi (seperti membuat lontong)"
- "Kukus gulungan nasi +/- 15 menit, kemudian angkat"
- "Panggang nasi, bolak balik sampai semua bagian kecoklatan, matikan api, nasi bakar siap dihidangkan"
categories:
- Resep
tags:
- nasi
- bakar
- ikan

katakunci: nasi bakar ikan 
nutrition: 246 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT60M"
recipeyield: "4"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Bakar Ikan Tuna](https://img-global.cpcdn.com/recipes/08c0e38fd5cbf070/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp)

11 langkah cepat membuat  Nasi Bakar Ikan Tuna cocok sekali jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Dalam Pembuatan Nasi Bakar Ikan Tuna:

1. nasi putih 4 porsi
1. Ikan tuna Filet 250 gr
1.  50 gr Jamur Merang 
1. bawang putih keprek dan iris tipis 5 siung
1. bawang merah iris tipis 2 siung
1. bawang bombay cincang kasar 1/2 butir
1. daun bawang iris 1 batang
1. jahe kupas memarkan 1 ruas
1. lengkuas kupas memarkan 1 ruas
1. sereh ambil bagian putih nya lalu memarkan 1 batang
1. pucuk daun kemangi 1 genggam
1. kecap asin dpt ditambah sesuai selera 1 sdt
1. saus tiram dpt ditambah sesuai selera 1 sdt
1. minyak wijen 1 sdm
1. merica bubuk 1 sdt
1. cabe merah iris apabila suka pedas dapat ditambah cabe rawit merah 
1. minyak untuk menumis 5 sdm
1. air secukupnya
1. daun salam 2 lembar
1. daun jeruk 2 lembar
1. garam secukupnya
1. daun pisang 
1. gigi tusuk



<!--inarticleads2-->

## Tata Cara Membuat Nasi Bakar Ikan Tuna:

1. Didihkan air, masukan ikan tuna rebus sampai berubah warna, angkat lalu tiriskan, setelah dingin suir suir
1. Panaskan minyak, tumis bawang merah, bawang putih, bawang bombai sampai harum
1. Tambahkan cabe, tumis sebentar, masukan sereh, daun salam, daun jeruk, jahe, dan lengkuas
1. Masukan potongan ikan tuna, dan jamur merang, kemudian tambahkan kecap asin, saus tiram, minyak wijen dan merica bubuk, dan garam
1. Tuang sedikit air, aduk sampai air mendidih, kemudian masukan daun bawang dan daun kemangi, masak sebentar, tes rasa
1. Apabila rasa sudah pas, matikan api
1. Siapkan wadah, masukan nasi dan tumisan, aduk rata, buang sereh, daun salam, daun jeruk, jahe, dan lengkuas
1. Bersihkan daun pisang, potong sesuai selera, kukus sebentar agar daun pisang lemas dan mudah dibentuk
1. Ambil 2 lembar daun pisang, isi dengan campuran nasi, gulung lalu lipat ujungnya dan sematkan tusuk gigi (seperti membuat lontong)
1. Kukus gulungan nasi +/- 15 menit, kemudian angkat
1. Panggang nasi, bolak balik sampai semua bagian kecoklatan, matikan api, nasi bakar siap dihidangkan




Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
