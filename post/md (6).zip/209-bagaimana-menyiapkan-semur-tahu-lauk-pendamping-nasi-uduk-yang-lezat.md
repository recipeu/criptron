---
description: "Bagaimana Menyiapkan Semur Tahu (Lauk Pendamping Nasi Uduk) yang Lezat"
title: "Bagaimana Menyiapkan Semur Tahu (Lauk Pendamping Nasi Uduk) yang Lezat"
slug: 209-bagaimana-menyiapkan-semur-tahu-lauk-pendamping-nasi-uduk-yang-lezat
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-03T01:31:38.050Z 
thumbnail: https://img-global.cpcdn.com/recipes/2f4ee8b0ffa792e7/682x484cq65/semur-tahu-lauk-pendamping-nasi-uduk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/2f4ee8b0ffa792e7/682x484cq65/semur-tahu-lauk-pendamping-nasi-uduk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/2f4ee8b0ffa792e7/682x484cq65/semur-tahu-lauk-pendamping-nasi-uduk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/2f4ee8b0ffa792e7/682x484cq65/semur-tahu-lauk-pendamping-nasi-uduk-foto-resep-utama.webp
author: Emilie Jimenez
ratingvalue: 4.1
reviewcount: 4
recipeingredient:
- "tahu putih potong segitiga goreng hingga berkulit 6 kotak"
- "bumbu dasar putih           lihat resep 2 sdm"
- "kecap manis 5 sdm"
- "sereh geprek 2 batang"
- "daun salam sobek2 3 lembar"
- "daun jeruk sobek2 2 lembar"
- "garam 3 sdt"
- "kaldu jamur 2 sdt"
- "merica bubuk 1 sdt"
- "bubuk kayu manis 1 sdt"
- "pala bubuk 1 sdt"
- "air 300 ml"
- "minyak goreng 2 sdm"
recipeinstructions:
- "Tumis bumbu dasar putih, daun salam, daun jeruk, sereh, bubuk kayu manis dan pala bubuk hingga harum dan matang."
- "Tuangkan air, masak hingga mendidih, masukan tahu goreng. Tuang kecap manis. Beri garam, kaldu jamur, merica bubuk. Aduk rata, koreksi rasanya."
- "Angkat dan siap disajikan."
categories:
- Resep
tags:
- semur
- tahu
- lauk

katakunci: semur tahu lauk 
nutrition: 209 calories
recipecuisine: Indonesian
preptime: "PT39M"
cooktime: "PT34M"
recipeyield: "3"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Semur Tahu (Lauk Pendamping Nasi Uduk)](https://img-global.cpcdn.com/recipes/2f4ee8b0ffa792e7/682x484cq65/semur-tahu-lauk-pendamping-nasi-uduk-foto-resep-utama.webp)

Resep Semur Tahu (Lauk Pendamping Nasi Uduk)  enak dengan 3 langkahmudah cocok sekali jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Dalam Pembuatan Semur Tahu (Lauk Pendamping Nasi Uduk):

1. tahu putih potong segitiga goreng hingga berkulit 6 kotak
1. bumbu dasar putih           lihat resep 2 sdm
1. kecap manis 5 sdm
1. sereh geprek 2 batang
1. daun salam sobek2 3 lembar
1. daun jeruk sobek2 2 lembar
1. garam 3 sdt
1. kaldu jamur 2 sdt
1. merica bubuk 1 sdt
1. bubuk kayu manis 1 sdt
1. pala bubuk 1 sdt
1. air 300 ml
1. minyak goreng 2 sdm



<!--inarticleads2-->

## Cara Menyiapkan Semur Tahu (Lauk Pendamping Nasi Uduk):

1. Tumis bumbu dasar putih, daun salam, daun jeruk, sereh, bubuk kayu manis dan pala bubuk hingga harum dan matang.
1. Tuangkan air, masak hingga mendidih, masukan tahu goreng. Tuang kecap manis. Beri garam, kaldu jamur, merica bubuk. Aduk rata, koreksi rasanya.
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/0ead52fabeb0ee43/160x128cq70/semur-tahu-lauk-pendamping-nasi-uduk-langkah-memasak-2-foto.webp" alt="Semur Tahu (Lauk Pendamping Nasi Uduk)" width="340" height="340">
>1. Angkat dan siap disajikan.
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/b742db136c795e4b/160x128cq70/semur-tahu-lauk-pendamping-nasi-uduk-langkah-memasak-3-foto.webp" alt="Semur Tahu (Lauk Pendamping Nasi Uduk)" width="340" height="340">
>



Daripada bunda beli  Semur Tahu (Lauk Pendamping Nasi Uduk)  diluar terus, bunda  bisa membuatnya sendiri dirumah. Resep  Semur Tahu (Lauk Pendamping Nasi Uduk)  sederhana ini cukup praktis dalam proses pembuatannya, cukup menggunakan bumbu sederhana  Semur Tahu (Lauk Pendamping Nasi Uduk)  yang enak, ibu nikmati di rumah.
