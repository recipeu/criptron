---
description: "Langkah Mudah untuk Membuat Nasi Bakar Ayam Kemangi, Bikin Ngiler"
title: "Langkah Mudah untuk Membuat Nasi Bakar Ayam Kemangi, Bikin Ngiler"
slug: 400-langkah-mudah-untuk-membuat-nasi-bakar-ayam-kemangi-bikin-ngiler
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-11T21:57:19.412Z 
thumbnail: https://img-global.cpcdn.com/recipes/4034378e10f0ab35/682x484cq65/nasi-bakar-ayam-kemangi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/4034378e10f0ab35/682x484cq65/nasi-bakar-ayam-kemangi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/4034378e10f0ab35/682x484cq65/nasi-bakar-ayam-kemangi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/4034378e10f0ab35/682x484cq65/nasi-bakar-ayam-kemangi-foto-resep-utama.webp
author: Bertie Reyes
ratingvalue: 4.4
reviewcount: 4
recipeingredient:
- "Nasi Uduk "
- "beras 2 cangkir"
- "santan instan 1 bks"
- "serai 1 btg"
- "daun salam 2 lembar"
- "garam Secukupnya"
- "Bahan Isian "
- "dada ayam 100 gr"
- "daun kemangi 1 ikat"
- "Rawit 4 bh"
- "Bumbu Halus "
- "cabe keriting merah 7 bh"
- "bawang merah 5 butir"
- "bawang putih 4 siung"
- "serai 1 btg"
- "garam kaldu dan gula Secukupnya"
- "Daun pisang utk membungkus "
recipeinstructions:
- "Pertama saya membuat Nasi uduk nya: campur semua bahan nasi uduk, masak di rice cooker seperti menanak nasi biasa."
- "Utk isian: rebus dada ayam sampai matang, tiriskan.  Stelah dingin suir&#34;, haluskan semua bumbu kecuali serai dan daun salam"
- "Tumis bumbu sampai harum, masukan ayam suir dan beri sedikit air. Tambahkan garam, kaldu dan gula sesuai selera. Tes rasa. Terakhir masukan daun kemangi, aduk sebentar."
- "Tata nasi diatas daun pisang, beri isian kemudian bungkus dengan cara gulung daun dan semat menggunakan lidi/tusuk gigi. Bakar Nasi diatas teflon dengan api sedang kecil sampai daun pisang berwarna sdkit gosong. Sajikan."
categories:
- Resep
tags:
- nasi
- bakar
- ayam

katakunci: nasi bakar ayam 
nutrition: 106 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT56M"
recipeyield: "1"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Bakar Ayam Kemangi](https://img-global.cpcdn.com/recipes/4034378e10f0ab35/682x484cq65/nasi-bakar-ayam-kemangi-foto-resep-utama.webp)

Ingin membuat Nasi Bakar Ayam Kemangi ? Coba resep berikut ini. Cara memasaknya sangat praktis namun jangan kaget jika hasilnya gurih dan lezat cocok sekali jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Untuk Menyiapkan Nasi Bakar Ayam Kemangi:

1. Nasi Uduk 
1. beras 2 cangkir
1. santan instan 1 bks
1. serai 1 btg
1. daun salam 2 lembar
1. garam Secukupnya
1. Bahan Isian 
1. dada ayam 100 gr
1. daun kemangi 1 ikat
1. Rawit 4 bh
1. Bumbu Halus 
1. cabe keriting merah 7 bh
1. bawang merah 5 butir
1. bawang putih 4 siung
1. serai 1 btg
1. garam kaldu dan gula Secukupnya
1. Daun pisang utk membungkus 

Resep dan cara memasak nasi bakar. Nasi Bakar Ayam Suwir Kemangi. beras•Santan•daun pandan•daun serai•garam•Isian nasi bakarnya di resep sebelumnya•daun kemangi. Kemudian tata daun pisang, nasi liwet serta tambahkan kemangi kemudian tambahkan suwiran ayam, tembahkan lagi kemangi di atas ayam dan dapat pula tambahkan irisan cabe rawit apabila anda menyukai pedas, setelah itu bakar di atas grill pan, bolak - balik hingga matang, angkat dan hidangkan. Biasa ditemukan di Pulau Jawa, nasi bakar berisi beragam protein. 

<!--inarticleads2-->

## Cara Membuat Nasi Bakar Ayam Kemangi:

1. Pertama saya membuat Nasi uduk nya: campur semua bahan nasi uduk, masak di rice cooker seperti menanak nasi biasa.
1. Utk isian: rebus dada ayam sampai matang, tiriskan.  - Stelah dingin suir&#34;, haluskan semua bumbu kecuali serai dan daun salam
1. Tumis bumbu sampai harum, masukan ayam suir dan beri sedikit air. Tambahkan garam, kaldu dan gula sesuai selera. Tes rasa. Terakhir masukan daun kemangi, aduk sebentar.
1. Tata nasi diatas daun pisang, beri isian kemudian bungkus dengan cara gulung daun dan semat menggunakan lidi/tusuk gigi. Bakar Nasi diatas teflon dengan api sedang kecil sampai daun pisang berwarna sdkit gosong. Sajikan.


Salah satu yang paling disukai adalah daging ayam dengan sentuhan daun kemangi. Bisa untuk ide menu makan siang bersama keluarga, berikut resep membuat nasi bakar ayam kemangi yang enak dan mudah. Nasi bakar ayam kemangi adalah salah satu inovasi masakan Nusantara yang sangat terkenal di seluruh Indonesia terutama di pulau Jawa. Aroma harum muncul dari daun kemangi yang ada dan dipadukan dengan daging ayam, sungguh menambah nikmatnya nasi goreng bakar kemangi ini. There are so many versions of nasi bakar out there and honestly, there aren&#39;t really any right or wrong recipes if you ask me. 

Terima kasih telah membaca resep yang kami tampilkan di sini. Selamat mencoba!
