---
description: "Resep Nasi Uduk Betawi Anti Gagal"
title: "Resep Nasi Uduk Betawi Anti Gagal"
slug: 18-resep-nasi-uduk-betawi-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-23T11:03:53.305Z 
thumbnail: https://img-global.cpcdn.com/recipes/244c0d6843ff98d9/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/244c0d6843ff98d9/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/244c0d6843ff98d9/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/244c0d6843ff98d9/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
author: Winnie Barber
ratingvalue: 3
reviewcount: 6
recipeingredient:
- "beras 500 gram"
- "air santan me 65 ml santan kara dicampur air 600 ml"
- "garam 7 gram"
- "Bumbu "
- "daun salam 3 lembar"
- "sereh 1 batang"
- "kayu manis ukuran kecil 1 batang"
- "cengkeh 3 butir"
- "jahe Sejempol"
- "lengkuas Sejempol"
recipeinstructions:
- "Cuci bersih beras, masukkan santan ke beras, beri garam, dan bumbu. Aduk rata, masak di rice cooker, masak sampai masak"
- "Setelah pindah ke tombol warm, aduk aduk nasi uduk dan pindahkan kembali ke tombol &#34;cook&#34;,dan diamkan kembali sampai tombol pindah ke warm"
- "Sajikan dengan lauk pilihan ditambah dengan sambal kacang"
- "Saya lampirkan resep bihun gorengnya           (lihat resep)"
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 123 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT57M"
recipeyield: "2"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Betawi](https://img-global.cpcdn.com/recipes/244c0d6843ff98d9/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp)

4 langkah cepat dan mudah mengolah  Nasi Uduk Betawi yang wajib ibu coba segera

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Dalam Menyiapkan Nasi Uduk Betawi:

1. beras 500 gram
1. air santan me 65 ml santan kara dicampur air 600 ml
1. garam 7 gram
1. Bumbu 
1. daun salam 3 lembar
1. sereh 1 batang
1. kayu manis ukuran kecil 1 batang
1. cengkeh 3 butir
1. jahe Sejempol
1. lengkuas Sejempol



<!--inarticleads2-->

## Cara Membuat Nasi Uduk Betawi:

1. Cuci bersih beras, masukkan santan ke beras, beri garam, dan bumbu. Aduk rata, masak di rice cooker, masak sampai masak
1. Setelah pindah ke tombol warm, aduk aduk nasi uduk dan pindahkan kembali ke tombol &#34;cook&#34;,dan diamkan kembali sampai tombol pindah ke warm
1. Sajikan dengan lauk pilihan ditambah dengan sambal kacang
1. Saya lampirkan resep bihun gorengnya -           (lihat resep)




Terima kasih telah menggunakan resep yang kami tampilkan di sini. Semoga bermanfaat dan selamat mencoba!
