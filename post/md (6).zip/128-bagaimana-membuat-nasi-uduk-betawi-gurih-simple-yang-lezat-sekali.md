---
description: "Bagaimana Membuat Nasi Uduk Betawi Gurih Simple yang Lezat Sekali"
title: "Bagaimana Membuat Nasi Uduk Betawi Gurih Simple yang Lezat Sekali"
slug: 128-bagaimana-membuat-nasi-uduk-betawi-gurih-simple-yang-lezat-sekali
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-15T08:53:25.701Z 
thumbnail: https://img-global.cpcdn.com/recipes/31a4141d02f677bb/682x484cq65/nasi-uduk-betawi-gurih-simple-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/31a4141d02f677bb/682x484cq65/nasi-uduk-betawi-gurih-simple-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/31a4141d02f677bb/682x484cq65/nasi-uduk-betawi-gurih-simple-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/31a4141d02f677bb/682x484cq65/nasi-uduk-betawi-gurih-simple-foto-resep-utama.webp
author: Estelle Brooks
ratingvalue: 5
reviewcount: 11
recipeingredient:
- "Beras cuci bersih 1 liter"
- "kara besar  1 liter santan sedang 1 kotak"
- "Serai Memarkan 2 Batang"
- "Jahe Memarkan 5 cm"
- "Lengkuas Memarkan 5 cm"
- "Kayu Manis 10 cm"
- "bawang putih cincang halus 2 siung"
- "daun pandan 2 lembar"
- "Garam secukupnya"
- "Air  aku ukurannya 1 12 ruas jari dari atas beras secukupnya"
- "Pelengkap "
- "Telur balado "
- "Bihun Goreng "
- "Gorengan "
- "Bawang merah goreng "
recipeinstructions:
- "Campur semua bahan didalam panci. Aduk hingga santan habis."
- "Panaskan dandang, aku tambahan 2 lembar daun pandan di air bawah dandang. Agar nasi lebih harum. Masak hingga nasi masak."
- "Bila menggunakan rice cook, masukan semua bahan kedalam rice cooker. Masak seperti biasa. Namun sesekali harus diaduk."
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 199 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT36M"
recipeyield: "2"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Betawi Gurih Simple](https://img-global.cpcdn.com/recipes/31a4141d02f677bb/682x484cq65/nasi-uduk-betawi-gurih-simple-foto-resep-utama.webp)

3 langkah mudah dan cepat mengolah  Nasi Uduk Betawi Gurih Simple cocok banget jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Dalam Menyiapkan Nasi Uduk Betawi Gurih Simple:

1. Beras cuci bersih 1 liter
1. kara besar  1 liter santan sedang 1 kotak
1. Serai Memarkan 2 Batang
1. Jahe Memarkan 5 cm
1. Lengkuas Memarkan 5 cm
1. Kayu Manis 10 cm
1. bawang putih cincang halus 2 siung
1. daun pandan 2 lembar
1. Garam secukupnya
1. Air  aku ukurannya 1 12 ruas jari dari atas beras secukupnya
1. Pelengkap 
1. Telur balado 
1. Bihun Goreng 
1. Gorengan 
1. Bawang merah goreng 



<!--inarticleads2-->

## Langkah-langkah Untuk Menyiapkan Nasi Uduk Betawi Gurih Simple:

1. Campur semua bahan didalam panci. Aduk hingga santan habis.
1. Panaskan dandang, aku tambahan 2 lembar daun pandan di air bawah dandang. Agar nasi lebih harum. Masak hingga nasi masak.
1. Bila menggunakan rice cook, masukan semua bahan kedalam rice cooker. Masak seperti biasa. Namun sesekali harus diaduk.




Terima kasih telah membaca resep yang kami tampilkan di sini. Selamat mencoba!
