---
description: "Cara Gampang Menyiapkan Nasi Daun Jeruk yang Enak"
title: "Cara Gampang Menyiapkan Nasi Daun Jeruk yang Enak"
slug: 294-cara-gampang-menyiapkan-nasi-daun-jeruk-yang-enak
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-02T18:56:33.129Z 
thumbnail: https://img-global.cpcdn.com/recipes/e631cd30c177318f/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/e631cd30c177318f/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/e631cd30c177318f/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/e631cd30c177318f/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
author: Christopher Knight
ratingvalue: 3.5
reviewcount: 13
recipeingredient:
- "beras 2 cup"
- "sereh 2"
- "daun salam 4"
- "daun jeruk di bejek 10"
- "daun jeruk iris tipis 15"
- "santan kara boleh pake santan yg fresh sesuai selera aja 2"
- "mujung garam 1 sdt"
recipeinstructions:
- "Bersihkan beras..."
- "Masukan sereh, daun jeruk, daun salam, santan, garam dan tambahkan air. adukk terlebih dahulu. masukan ke rice cooker"
- "Jangan lupa sesekali dilihat dan diaduk nasi dalam ricecooker. agar matangnya merata."
- "Jika sudah matang masukan potongan daun jeruk. siap hidangkan"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 239 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT59M"
recipeyield: "2"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk](https://img-global.cpcdn.com/recipes/e631cd30c177318f/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp)

Resep rahasia Nasi Daun Jeruk  enak dengan 4 langkahmudah dan cepat cocok sekali jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Bahan-bahan Yang Dibutuhkan Dalam Pembuatan Nasi Daun Jeruk:

1. beras 2 cup
1. sereh 2
1. daun salam 4
1. daun jeruk di bejek 10
1. daun jeruk iris tipis 15
1. santan kara boleh pake santan yg fresh sesuai selera aja 2
1. mujung garam 1 sdt



<!--inarticleads2-->

## Langkah-langkah Untuk Membuat Nasi Daun Jeruk:

1. Bersihkan beras...
1. Masukan sereh, daun jeruk, daun salam, santan, garam dan tambahkan air. adukk terlebih dahulu. masukan ke rice cooker
1. Jangan lupa sesekali dilihat dan diaduk nasi dalam ricecooker. agar matangnya merata.
1. Jika sudah matang masukan potongan daun jeruk. siap hidangkan




Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
