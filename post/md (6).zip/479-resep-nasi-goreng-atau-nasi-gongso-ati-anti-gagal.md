---
description: "Resep Nasi Goreng atau Nasi Gongso Ati Anti Gagal"
title: "Resep Nasi Goreng atau Nasi Gongso Ati Anti Gagal"
slug: 479-resep-nasi-goreng-atau-nasi-gongso-ati-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-23T09:39:52.172Z 
thumbnail: https://img-global.cpcdn.com/recipes/46140085c6403e4d/682x484cq65/nasi-goreng-atau-nasi-gongso-ati-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/46140085c6403e4d/682x484cq65/nasi-goreng-atau-nasi-gongso-ati-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/46140085c6403e4d/682x484cq65/nasi-goreng-atau-nasi-gongso-ati-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/46140085c6403e4d/682x484cq65/nasi-goreng-atau-nasi-gongso-ati-foto-resep-utama.webp
author: Alta Fox
ratingvalue: 4.3
reviewcount: 7
recipeingredient:
- "nasi Putih Sepiring"
- "wortel 1 buah"
- "kembang kol 1/2 buah"
- "ati ampela ayam dipotong kecil 1"
- "telur ayam 1"
- "saos sambal 2 sendok"
- "cabai rawit 5 buah"
- "kecap bango 1 sachet"
- "bawang bombay diiris kotak 1/2 siung"
- "bawang putih cincang halus 1 siung"
- "Garam dan merica secukupnya"
- "cabai merah besar 3 buah"
recipeinstructions:
- "Tumis bawang putih, bawang bombay dan cabai rawit sampai harum lalu masukkan sayuran. Masak sampai layu setelah itu masukkan ati ampela ayam masak sampai matang"
- "Masukkan saos sambal, kecap, garam dan merica tumis sampai harum beri sedikit air biar gak gosong. Tunggu sedikit mengental lalu masukkan nasi putih. Aduk sampai merata lalu cicip rasa"
- "Kocok telur beri sedikit garam lalu goreng"
- "Setelah nasi matang merata, sajikan dipiring saji dengan hiasan telur dadar diatasnya"
categories:
- Resep
tags:
- nasi
- goreng
- atau

katakunci: nasi goreng atau 
nutrition: 174 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT50M"
recipeyield: "1"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Goreng atau Nasi Gongso Ati](https://img-global.cpcdn.com/recipes/46140085c6403e4d/682x484cq65/nasi-goreng-atau-nasi-gongso-ati-foto-resep-utama.webp)

Resep rahasia dan cara mengolah  Nasi Goreng atau Nasi Gongso Ati cocok sekali jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Untuk Pembuatan Nasi Goreng atau Nasi Gongso Ati:

1. nasi Putih Sepiring
1. wortel 1 buah
1. kembang kol 1/2 buah
1. ati ampela ayam dipotong kecil 1
1. telur ayam 1
1. saos sambal 2 sendok
1. cabai rawit 5 buah
1. kecap bango 1 sachet
1. bawang bombay diiris kotak 1/2 siung
1. bawang putih cincang halus 1 siung
1. Garam dan merica secukupnya
1. cabai merah besar 3 buah



<!--inarticleads2-->

## Langkah-langkah Untuk Menyiapkan Nasi Goreng atau Nasi Gongso Ati:

1. Tumis bawang putih, bawang bombay dan cabai rawit sampai harum lalu masukkan sayuran. Masak sampai layu setelah itu masukkan ati ampela ayam masak sampai matang
1. Masukkan saos sambal, kecap, garam dan merica tumis sampai harum beri sedikit air biar gak gosong. Tunggu sedikit mengental lalu masukkan nasi putih. Aduk sampai merata lalu cicip rasa
1. Kocok telur beri sedikit garam lalu goreng
1. Setelah nasi matang merata, sajikan dipiring saji dengan hiasan telur dadar diatasnya




Demikian informasi  resep Nasi Goreng atau Nasi Gongso Ati   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
