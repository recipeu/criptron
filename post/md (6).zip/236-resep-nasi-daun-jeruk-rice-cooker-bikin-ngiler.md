---
description: "Resep Nasi daun jeruk rice cooker, Bikin Ngiler"
title: "Resep Nasi daun jeruk rice cooker, Bikin Ngiler"
slug: 236-resep-nasi-daun-jeruk-rice-cooker-bikin-ngiler
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-10T19:33:02.978Z 
thumbnail: https://img-global.cpcdn.com/recipes/9cc0b9a283880682/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/9cc0b9a283880682/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/9cc0b9a283880682/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/9cc0b9a283880682/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
author: Minerva Hudson
ratingvalue: 3.8
reviewcount: 8
recipeingredient:
- "beras 2 cup"
- "Santan kekentalan sesuai selera banyaknya spt masak nasi biasa "
- "sereh 1 batang"
- "daun salam 2 lembar"
- "daun jeruk guntingiris tipis 7 lembar"
- "garam Secukupnya"
recipeinstructions:
- "Masukkan beras dan semua bahan di rice cooker, masak spt memasak nasi biasa"
- "Jika sudah bunyi&#39; klek&#39;aduk2 lalu tutup dan tunggu sampai nasi tanak"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 278 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT55M"
recipeyield: "4"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi daun jeruk rice cooker](https://img-global.cpcdn.com/recipes/9cc0b9a283880682/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp)

Resep rahasia dan cara mengolah  Nasi daun jeruk rice cooker cocok sekali jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Untuk Menyiapkan Nasi daun jeruk rice cooker:

1. beras 2 cup
1. Santan kekentalan sesuai selera banyaknya spt masak nasi biasa 
1. sereh 1 batang
1. daun salam 2 lembar
1. daun jeruk guntingiris tipis 7 lembar
1. garam Secukupnya

Hai selamat pagi sahabat CWS, pagi ini saya share resep Nasi Daun Jeruk. Praktis banget karena saya gunakan rice cooker. Rasanya mirip nasi uduk tapi wangiiii. Yukkk mari dipantengin dan dipraktekin yah. 

<!--inarticleads2-->

## Cara Mudah Membuat Nasi daun jeruk rice cooker:

1. Masukkan beras dan semua bahan di rice cooker, masak spt memasak nasi biasa
1. Jika sudah bunyi&#39; klek&#39;aduk2 lalu tutup dan tunggu sampai nasi tanak


Berikut nih tips dari saya supaya nasi nya matang. Gurih dan wangi dari daun jeruk menambah kelezatan nasi daun jeruk. Setelah tombol menyatakan matang, masukkan daun jeruk. Jangan buka rice cooker sampai uap hilang. Sajikan nasi bersama lauk pelengkap seperti dadar rawis atau bakwan jagung. 

Terima kasih telah membaca resep yang kami tampilkan di halaman ini. Semoga bermanfaat dan selamat mencoba!
