---
description: "Resep Nasi Daun Jeruk Ricecooker ala #buayu Anti Gagal"
title: "Resep Nasi Daun Jeruk Ricecooker ala #buayu Anti Gagal"
slug: 240-resep-nasi-daun-jeruk-ricecooker-ala-buayu-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-08T21:16:38.515Z 
thumbnail: https://img-global.cpcdn.com/recipes/7d81cb0e433ecc70/682x484cq65/nasi-daun-jeruk-ricecooker-ala-buayu-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/7d81cb0e433ecc70/682x484cq65/nasi-daun-jeruk-ricecooker-ala-buayu-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/7d81cb0e433ecc70/682x484cq65/nasi-daun-jeruk-ricecooker-ala-buayu-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/7d81cb0e433ecc70/682x484cq65/nasi-daun-jeruk-ricecooker-ala-buayu-foto-resep-utama.webp
author: Calvin Garza
ratingvalue: 4.2
reviewcount: 8
recipeingredient:
- "beras cuci bersih 3 cup"
- "daun salam 3 lembar"
- "daun jeruk buang tulang potong tipis 10 lembar"
- "bawang putih 3siung cincang 1 sdt"
- "garam 1/2 sdt"
- "minyak goreng 1 sdm"
- "Air secukupnya"
recipeinstructions:
- "Masukkan minyak goreng ke teflon kecil, tumis bawang putih + irisan daun jeruk sampai harum. Sisihkan"
- "Masukkan beras yang sudah dicuci ke dalam ricecooker. Masukkan daun salam dan tumisan tadi. Tambahkan air secukupnya (seperti memasak nasi biasanya)."
- "Masukkan garam. Aduk sebentar dan nyalakan ricecooker mode memasak."
- "Pas setangah matang, buka ricecooker dan aduk perlahan nasi. Tutup kembali sampai matang."
- "Selamat mencoba 🤗 ini aku tambahin dori butter panggang teflon aja udah enak dan wangi banget 😊 selamat mencoba 😘"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 191 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT50M"
recipeyield: "4"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk Ricecooker ala #buayu](https://img-global.cpcdn.com/recipes/7d81cb0e433ecc70/682x484cq65/nasi-daun-jeruk-ricecooker-ala-buayu-foto-resep-utama.webp)

Resep rahasia dan cara mengolah  Nasi Daun Jeruk Ricecooker ala #buayu yang harus ibu coba dirumah

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Dalam Menyiapkan Nasi Daun Jeruk Ricecooker ala #buayu:

1. beras cuci bersih 3 cup
1. daun salam 3 lembar
1. daun jeruk buang tulang potong tipis 10 lembar
1. bawang putih 3siung cincang 1 sdt
1. garam 1/2 sdt
1. minyak goreng 1 sdm
1. Air secukupnya



<!--inarticleads2-->

## Langkah-langkah Untuk Membuat Nasi Daun Jeruk Ricecooker ala #buayu:

1. Masukkan minyak goreng ke teflon kecil, tumis bawang putih + irisan daun jeruk sampai harum. Sisihkan
1. Masukkan beras yang sudah dicuci ke dalam ricecooker. Masukkan daun salam dan tumisan tadi. Tambahkan air secukupnya (seperti memasak nasi biasanya).
1. Masukkan garam. Aduk sebentar dan nyalakan ricecooker mode memasak.
1. Pas setangah matang, buka ricecooker dan aduk perlahan nasi. Tutup kembali sampai matang.
1. Selamat mencoba 🤗 ini aku tambahin dori butter panggang teflon aja udah enak dan wangi banget 😊 selamat mencoba 😘




Salah satu masakan yang cukup praktis dalam pembuatannya adalah  Nasi Daun Jeruk Ricecooker ala #buayu. Selain itu  Nasi Daun Jeruk Ricecooker ala #buayu  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu ikuti 5 langkah, dan  Nasi Daun Jeruk Ricecooker ala #buayu  pun siap di hidangkan. selamat mencoba !
