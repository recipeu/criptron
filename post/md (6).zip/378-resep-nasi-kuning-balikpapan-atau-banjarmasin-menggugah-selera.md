---
description: "Resep Nasi kuning Balikpapan atau Banjarmasin, Menggugah Selera"
title: "Resep Nasi kuning Balikpapan atau Banjarmasin, Menggugah Selera"
slug: 378-resep-nasi-kuning-balikpapan-atau-banjarmasin-menggugah-selera
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-21T06:55:23.303Z 
thumbnail: https://img-global.cpcdn.com/recipes/6c21701ec22e6c6c/682x484cq65/nasi-kuning-balikpapan-atau-banjarmasin-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/6c21701ec22e6c6c/682x484cq65/nasi-kuning-balikpapan-atau-banjarmasin-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/6c21701ec22e6c6c/682x484cq65/nasi-kuning-balikpapan-atau-banjarmasin-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/6c21701ec22e6c6c/682x484cq65/nasi-kuning-balikpapan-atau-banjarmasin-foto-resep-utama.webp
author: Russell Davis
ratingvalue: 4.8
reviewcount: 7
recipeingredient:
- "nasi kuning "
- "Beras putih 750 gr"
- "daun salam 4 lembar"
- "daun jeruk 5 lembar"
- "daun pandan 4 lembar"
- "kunyit 10cm haluskan 1 ruas"
- "2 bungkus Santan kental 1.1"
- "santan encer 1 bungkus"
- "masak habang "
- "Cabai merah kering hilangkan bijinya 25 Buah"
- "bawang merah 20 Buah"
- "bawang putih 15 Buah"
- "Kemiri 8 Buah"
- "santan kental 1/2 Bungkus"
- "air asam jawa 2 Sdm"
- "Sereh 1 Ruas"
- "terasi bakar 1 Sdt"
- "kelingking ruas kayu manis 1/2"
- "kelingking kunyit 1/2"
- "kelingking kencur 1/2"
- "gula merah 2 Sdm"
- "daging sapi 1 kg"
- "ikan tuna goreng 500 gram"
- "telur bebek rebus 10 butir"
recipeinstructions:
- "Masak habang"
- "Rebus sebentar saja cabai kering, jangan direndam/dibiarkan lama karena warna gelap cabe akan larut di air dan akan pengaruhi warna masakan"
- "Blender : Cabai kering yg telah direbus, Bawang putih, Bawang merah, Kencur, Kemiri, kunyit menggunakan air"
- "Tumis semua bumbu yang telah diblender, tambahkan minyak, masukkan terasi, sereh, gula merah, tumis hingga berwarna gelap, tambahkan air 1.5liter, air asam jawa, santan."
- "Masukkan daging sapi dan telur ayam terlebih dahulu agar daging empuk dan telur menyerap bumbu merah, dan terakhir masukkan ikan yang telah digoreng. Atur rasa. Siap dihidangkan"
- "Nasi kuning"
- "Rebus santan, setelah mendidih masukkan kunyit (jika tidak direbus maka akan bau kunyit), daun salam, daun jeruk, daun pandan, masukkan beras tambahkan santan, air, beri garam dan vetcin, nasi diaron sampai air meresap"
- "Kukus selama 30-40 menit"
- "Sajikan dengan taburan bawang goreng"
categories:
- Resep
tags:
- nasi
- kuning
- balikpapan

katakunci: nasi kuning balikpapan 
nutrition: 213 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT38M"
recipeyield: "1"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi kuning Balikpapan atau Banjarmasin](https://img-global.cpcdn.com/recipes/6c21701ec22e6c6c/682x484cq65/nasi-kuning-balikpapan-atau-banjarmasin-foto-resep-utama.webp)

9 langkah cepat dan mudah mengolah  Nasi kuning Balikpapan atau Banjarmasin yang bisa ibu coba segera

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Untuk Menyiapkan Nasi kuning Balikpapan atau Banjarmasin:

1. nasi kuning 
1. Beras putih 750 gr
1. daun salam 4 lembar
1. daun jeruk 5 lembar
1. daun pandan 4 lembar
1. kunyit 10cm haluskan 1 ruas
1. 2 bungkus Santan kental 1.1
1. santan encer 1 bungkus
1. masak habang 
1. Cabai merah kering hilangkan bijinya 25 Buah
1. bawang merah 20 Buah
1. bawang putih 15 Buah
1. Kemiri 8 Buah
1. santan kental 1/2 Bungkus
1. air asam jawa 2 Sdm
1. Sereh 1 Ruas
1. terasi bakar 1 Sdt
1. kelingking ruas kayu manis 1/2
1. kelingking kunyit 1/2
1. kelingking kencur 1/2
1. gula merah 2 Sdm
1. daging sapi 1 kg
1. ikan tuna goreng 500 gram
1. telur bebek rebus 10 butir

Saya ambil nasi putih sebungkus, dengan lauk ikan Haruan masak Habang. Untuk via udara melalui bandara balikpapan. Naskun Begitu Sebagian Besar Orang Balikpapan Menyebut Kuliner Nasi Kuning Makanan Ini Merupakan Menu Sarapan Favori Resep Makanan Sehat Makanan Resep Makanan. To drink it, you can enjoy the typical Banjarmasi iced tea which is famous for its delicious aroma. (Original) Soto khas banjar tersedia disini. 

<!--inarticleads2-->

## Cara Menyiapkan Nasi kuning Balikpapan atau Banjarmasin:

1. Masak habang
1. Rebus sebentar saja cabai kering, jangan direndam/dibiarkan lama karena warna gelap cabe akan larut di air dan akan pengaruhi warna masakan
1. Blender : Cabai kering yg telah direbus, Bawang putih, Bawang merah, Kencur, Kemiri, kunyit menggunakan air
1. Tumis semua bumbu yang telah diblender, tambahkan minyak, masukkan terasi, sereh, gula merah, tumis hingga berwarna gelap, tambahkan air 1.5liter, air asam jawa, santan.
1. Masukkan daging sapi dan telur ayam terlebih dahulu agar daging empuk dan telur menyerap bumbu merah, dan terakhir masukkan ikan yang telah digoreng. Atur rasa. Siap dihidangkan
1. Nasi kuning
1. Rebus santan, setelah mendidih masukkan kunyit (jika tidak direbus maka akan bau kunyit), daun salam, daun jeruk, daun pandan, masukkan beras tambahkan santan, air, beri garam dan vetcin, nasi diaron sampai air meresap
1. Kukus selama 30-40 menit
1. Sajikan dengan taburan bawang goreng


Dengan kuah yg bening dan sedap, lalu bisa menggunakan ketupat atau nasi, serta terdapat suiran ayam, telur, perkedel juga. Ada juga nasi kuning khas banjar. Nasi Kuning H Daud berada di kawasan Kota Lama Balikpapan. COM - Sarapan menjadi kebutuhan wajib untuk dipenuhi oleh Bagi traveler yang berkunjung ke Balikpapan, Kalimantan Timur, bisa mampir ke beberapa warung makan enak yang cocok untuk sarapan pagi ini. Misalnya nasi kuning dan lontong sayur khas Banjarmasin yang jadi menu sarapan favorit warga. 

Demikian informasi  resep Nasi kuning Balikpapan atau Banjarmasin   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
