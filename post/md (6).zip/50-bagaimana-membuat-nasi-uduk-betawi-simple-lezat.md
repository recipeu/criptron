---
description: "Bagaimana Membuat Nasi Uduk betawi simple, Lezat"
title: "Bagaimana Membuat Nasi Uduk betawi simple, Lezat"
slug: 50-bagaimana-membuat-nasi-uduk-betawi-simple-lezat
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-28T06:59:07.044Z 
thumbnail: https://img-global.cpcdn.com/recipes/f93115740e428efd/682x484cq65/nasi-uduk-betawi-simple-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/f93115740e428efd/682x484cq65/nasi-uduk-betawi-simple-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/f93115740e428efd/682x484cq65/nasi-uduk-betawi-simple-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/f93115740e428efd/682x484cq65/nasi-uduk-betawi-simple-foto-resep-utama.webp
author: Erik Santos
ratingvalue: 3.7
reviewcount: 7
recipeingredient:
- "beras 2 cup"
- "santan kara 1 pcs"
- "sereh 2 ruas"
- "daun salam 4 lembar"
- "dauh jeruk 1 lembar"
- "garam 1 sdt"
- "penyedap rasa 1/2 sdt"
- "Bahan Topping tempe orek "
- "tempe 1 papan"
- "bawang putih 3 siung"
- "garam 1/2 sdt"
- "gula 1/2 sdt"
- "gula merah 1/2 sdt"
- "kecap 1/2 sdt"
- "air 1/4"
recipeinstructions:
- "Cuci beras di air mengalir lalu tiriskan kemudian rendam beras selama 1/2 sampai 1 jam"
- "Setelah waktu rendaman selesai kukus beras 15menit"
- "Selagi nunggu beras jadi siapkan rebusan santan sereh daun salam daun jeruk garam penyedap rasa aduk aduk sampai mendidih *selalu diaduk agar tidak pecah santannya"
- "Setelah beras cukup tanak angkat beras ke baskom tuangkan santan sedikit demi sedikit sampai menjadi aronan jangan terlalu banyak ya moms nanti kelembekan org betawi ga doyan beras lembek gehehhe..."
- "Setelah diaduk dan seperti aronan masukan kembali ke dalam dandang lalu kukus selama 30 menit lalu angkat dinginkan"
- "Membuat orek potong tempe lalu goreng kering ya moms"
- "Bumbunya tumis bawang putih sampai harum masukan air 1/4 gelas lalu tambahkan garam gula pasir gula merah penyedap rasa dan kecap setelah mendidih masukan. Tempe sampai air susut siap di sajikan lalu buat dadar telurnya ya moms dan dipotong seperti ini 😁"
- "Tata nasi uduk tambahkan bawang goreng tempe orek telur dadar dan kerupuk untuk sambar bebas ya mom kalau aku pakai sambal kacang dijamin endess deh jangan lupa di reecook ya momz selamat mencoba😁😁🙏🙏🤗🤗🤤🤤"
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 230 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT40M"
recipeyield: "3"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk betawi simple](https://img-global.cpcdn.com/recipes/f93115740e428efd/682x484cq65/nasi-uduk-betawi-simple-foto-resep-utama.webp)

Resep Nasi Uduk betawi simple    dengan 8 langkahmudah dan cepat yang wajib kamu coba segera

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Dalam Menyiapkan Nasi Uduk betawi simple:

1. beras 2 cup
1. santan kara 1 pcs
1. sereh 2 ruas
1. daun salam 4 lembar
1. dauh jeruk 1 lembar
1. garam 1 sdt
1. penyedap rasa 1/2 sdt
1. Bahan Topping tempe orek 
1. tempe 1 papan
1. bawang putih 3 siung
1. garam 1/2 sdt
1. gula 1/2 sdt
1. gula merah 1/2 sdt
1. kecap 1/2 sdt
1. air 1/4



<!--inarticleads2-->

## Tata Cara Menyiapkan Nasi Uduk betawi simple:

1. Cuci beras di air mengalir lalu tiriskan kemudian rendam beras selama 1/2 sampai 1 jam
1. Setelah waktu rendaman selesai kukus beras 15menit
1. Selagi nunggu beras jadi siapkan rebusan santan sereh daun salam daun jeruk garam penyedap rasa aduk aduk sampai mendidih *selalu diaduk agar tidak pecah santannya
1. Setelah beras cukup tanak angkat beras ke baskom tuangkan santan sedikit demi sedikit sampai menjadi aronan jangan terlalu banyak ya moms nanti kelembekan org betawi ga doyan beras lembek gehehhe...
1. Setelah diaduk dan seperti aronan masukan kembali ke dalam dandang lalu kukus selama 30 menit lalu angkat dinginkan
1. Membuat orek potong tempe lalu goreng kering ya moms
1. Bumbunya tumis bawang putih sampai harum masukan air 1/4 gelas lalu tambahkan garam gula pasir gula merah penyedap rasa dan kecap setelah mendidih masukan. Tempe sampai air susut siap di sajikan lalu buat dadar telurnya ya moms dan dipotong seperti ini 😁
1. Tata nasi uduk tambahkan bawang goreng tempe orek telur dadar dan kerupuk untuk sambar bebas ya mom kalau aku pakai sambal kacang dijamin endess deh jangan lupa di reecook ya momz selamat mencoba😁😁🙏🙏🤗🤗🤤🤤




Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
