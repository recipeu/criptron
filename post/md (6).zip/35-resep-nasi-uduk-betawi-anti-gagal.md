---
description: "Resep Nasi Uduk Betawi Anti Gagal"
title: "Resep Nasi Uduk Betawi Anti Gagal"
slug: 35-resep-nasi-uduk-betawi-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-15T01:51:29.203Z 
thumbnail: https://img-global.cpcdn.com/recipes/6bee1e77fdc9d64c/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/6bee1e77fdc9d64c/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/6bee1e77fdc9d64c/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/6bee1e77fdc9d64c/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
author: Jay Gonzalez
ratingvalue: 3.6
reviewcount: 5
recipeingredient:
- "beras 2 1/2 cup"
- "santan dari 65ml santan kara instan  2 gelas"
- "daun salam 2 lembar"
- "serai geprek 2 batang"
- "daun pandan aku skip krn lagi gak punya  Secukupnya"
- "lengkoas potong2 1 cm"
- "jahe potong2 1 cm"
recipeinstructions:
- "Cuci bersih beras, lalu rendam dg air bersih -+1 jam, biarkan. Masak santan dan dedaunannya, aduk2 jangan sampai pecah, aduk hingga mendidih, biarkan dingin"
- "Tiriskan beras yg sudah direndam, lalu tambahkan air santannya secukupnya, menyesuaikan kebiasaan masak nasi, daun yg ikut masuk ke sini daun salam, daun pandan, &amp; serai, klik cook di rice cookernya, biarkan matang, ketika sdh matang, aduk2 biar merata, dan biarkan tanak -+15menit"
- "Sajikan dengan bihun goreng, tempe orek, dan sambel goreng,, :) semoga bermanfaat :)"
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 139 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT53M"
recipeyield: "2"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Betawi](https://img-global.cpcdn.com/recipes/6bee1e77fdc9d64c/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp)

3 langkah cepat dan mudah memasak  Nasi Uduk Betawi cocok sekali jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Untuk Menyiapkan Nasi Uduk Betawi:

1. beras 2 1/2 cup
1. santan dari 65ml santan kara instan  2 gelas
1. daun salam 2 lembar
1. serai geprek 2 batang
1. daun pandan aku skip krn lagi gak punya  Secukupnya
1. lengkoas potong2 1 cm
1. jahe potong2 1 cm



<!--inarticleads2-->

## Langkah-langkah Untuk Menyiapkan Nasi Uduk Betawi:

1. Cuci bersih beras, lalu rendam dg air bersih -+1 jam, biarkan. Masak santan dan dedaunannya, aduk2 jangan sampai pecah, aduk hingga mendidih, biarkan dingin
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/40bf4bf33e117684/160x128cq70/nasi-uduk-betawi-langkah-memasak-1-foto.webp" alt="Nasi Uduk Betawi" width="340" height="340">
>1. Tiriskan beras yg sudah direndam, lalu tambahkan air santannya secukupnya, menyesuaikan kebiasaan masak nasi, daun yg ikut masuk ke sini daun salam, daun pandan, &amp; serai, klik cook di rice cookernya, biarkan matang, ketika sdh matang, aduk2 biar merata, dan biarkan tanak -+15menit
1. Sajikan dengan bihun goreng, tempe orek, dan sambel goreng,, :) semoga bermanfaat :)




Terima kasih telah menggunakan resep yang kami tampilkan di sini. Selamat mencoba!
