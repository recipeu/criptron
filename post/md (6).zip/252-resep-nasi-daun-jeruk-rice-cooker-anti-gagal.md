---
description: "Resep Nasi Daun Jeruk Rice Cooker Anti Gagal"
title: "Resep Nasi Daun Jeruk Rice Cooker Anti Gagal"
slug: 252-resep-nasi-daun-jeruk-rice-cooker-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-18T13:41:54.274Z 
thumbnail: https://img-global.cpcdn.com/recipes/e8c5985384cdc585/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/e8c5985384cdc585/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/e8c5985384cdc585/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/e8c5985384cdc585/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
author: Emily Hardy
ratingvalue: 3.5
reviewcount: 14
recipeingredient:
- "beras 2 cup"
- "air 2 cup"
- "santan instan 65 ml"
- "daun jeruk cincang halus 5-6 lembar"
- "bawang putih parut 3 siung"
- "sereh digeprek 1 batang"
- "Garam gula sesuai selera"
- "Kaldu jamur optional "
recipeinstructions:
- "Cuci bersih beras dan tiriskan."
- "Masukkan bawang putih, daun jeruk dan santan."
- "Tambahkan air. Jumlah air bisa disesuaikan jenis beras masing-masing. Masukkan sereh dan bumbui dengan garam dan gula (boleh dikasih kaldu jamur juga). Aduk rata dan masak hingga matang. Sajikan dengan lauk favorite Anda."
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 286 calories
recipecuisine: Indonesian
preptime: "PT20M"
cooktime: "PT31M"
recipeyield: "1"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk Rice Cooker](https://img-global.cpcdn.com/recipes/e8c5985384cdc585/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp)

3 langkah mudah dan cepat memasak  Nasi Daun Jeruk Rice Cooker yang bisa bunda coba dirumah

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Untuk Pembuatan Nasi Daun Jeruk Rice Cooker:

1. beras 2 cup
1. air 2 cup
1. santan instan 65 ml
1. daun jeruk cincang halus 5-6 lembar
1. bawang putih parut 3 siung
1. sereh digeprek 1 batang
1. Garam gula sesuai selera
1. Kaldu jamur optional 



<!--inarticleads2-->

## Cara Menyiapkan Nasi Daun Jeruk Rice Cooker:

1. Cuci bersih beras dan tiriskan.
1. Masukkan bawang putih, daun jeruk dan santan.
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/0ca6c856555b52b2/160x128cq70/nasi-daun-jeruk-rice-cooker-langkah-memasak-2-foto.webp" alt="Nasi Daun Jeruk Rice Cooker" width="340" height="340">
>1. Tambahkan air. Jumlah air bisa disesuaikan jenis beras masing-masing. Masukkan sereh dan bumbui dengan garam dan gula (boleh dikasih kaldu jamur juga). Aduk rata dan masak hingga matang. Sajikan dengan lauk favorite Anda.
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/98c8260985a1b3aa/160x128cq70/nasi-daun-jeruk-rice-cooker-langkah-memasak-3-foto.webp" alt="Nasi Daun Jeruk Rice Cooker" width="340" height="340">
>



Salah satu masakan yang cukup praktis dalam pembuatannya adalah  Nasi Daun Jeruk Rice Cooker. Selain itu  Nasi Daun Jeruk Rice Cooker  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu lakukan 3 langkah, dan  Nasi Daun Jeruk Rice Cooker  pun siap di hidangkan. selamat mencoba !
