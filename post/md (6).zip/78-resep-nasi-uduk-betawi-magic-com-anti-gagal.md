---
description: "Resep Nasi Uduk Betawi (magic com) Anti Gagal"
title: "Resep Nasi Uduk Betawi (magic com) Anti Gagal"
slug: 78-resep-nasi-uduk-betawi-magic-com-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-01T13:57:59.010Z 
thumbnail: https://img-global.cpcdn.com/recipes/64336d408b669abd/682x484cq65/nasi-uduk-betawi-magic-com-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/64336d408b669abd/682x484cq65/nasi-uduk-betawi-magic-com-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/64336d408b669abd/682x484cq65/nasi-uduk-betawi-magic-com-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/64336d408b669abd/682x484cq65/nasi-uduk-betawi-magic-com-foto-resep-utama.webp
author: Dora McDonald
ratingvalue: 3.3
reviewcount: 12
recipeingredient:
- "Bahan Nasi Uduk "
- "beras pulen cuci bersih tiriskan 1 ltr"
- "air 1 1/4 liter"
- "garam 1 sdt"
- "daun pandan diikat 1 lbr"
- "serai memarkan 2 btg"
- "jahe memarkan 1 cm"
- "daun salam 2 lbr"
- "santan kara 65 ml"
- "Bahan Telur Balado "
- "telur rebus 5 btr"
- "cabe merah keriting 8 bh"
- "cabe rawit merah 3 bh"
- "bawang merah 5 bh"
- "tomat besar 1 bh"
- "Gula dan garam secukupnya"
- "Bahan Pelengkap "
- "Bihun goreng "
- "Perkedel kentang "
- "Telur dadar iris halus "
- "Orek tempe "
- "Bawang goreng "
recipeinstructions:
- "Masukkan beras, garam, serai, jahe, daun saka, daun pandan, dalam panci magic com, lalu tuangi air."
- "Masak beras dalam magic com. Setelah 10 mnt, buka magic, aduk rata koreksi rasa, lalu masukkan santan kara, aduk2 rata lagi. Lakukan pengadukan setiap 10 mnt hingga nasi matang"
- "Telur balado: haluskan semua bahan sambal balado, kecuali telur"
- "Tumis bahan sambal balado hingga minyak naik, bumbui garam dan gula, koreksi rasa"
- "Sajikan nasi uduk bersama perkedel kentang, bihun goreng, telur balado, telur dadar iris dan orek tempe"
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 156 calories
recipecuisine: Indonesian
preptime: "PT13M"
cooktime: "PT46M"
recipeyield: "3"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Betawi (magic com)](https://img-global.cpcdn.com/recipes/64336d408b669abd/682x484cq65/nasi-uduk-betawi-magic-com-foto-resep-utama.webp)

Resep dan cara memasak  Nasi Uduk Betawi (magic com) cocok banget jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Dalam Pembuatan Nasi Uduk Betawi (magic com):

1. Bahan Nasi Uduk 
1. beras pulen cuci bersih tiriskan 1 ltr
1. air 1 1/4 liter
1. garam 1 sdt
1. daun pandan diikat 1 lbr
1. serai memarkan 2 btg
1. jahe memarkan 1 cm
1. daun salam 2 lbr
1. santan kara 65 ml
1. Bahan Telur Balado 
1. telur rebus 5 btr
1. cabe merah keriting 8 bh
1. cabe rawit merah 3 bh
1. bawang merah 5 bh
1. tomat besar 1 bh
1. Gula dan garam secukupnya
1. Bahan Pelengkap 
1. Bihun goreng 
1. Perkedel kentang 
1. Telur dadar iris halus 
1. Orek tempe 
1. Bawang goreng 



<!--inarticleads2-->

## Langkah-langkah Untuk Menyiapkan Nasi Uduk Betawi (magic com):

1. Masukkan beras, garam, serai, jahe, daun saka, daun pandan, dalam panci magic com, lalu tuangi air.
1. Masak beras dalam magic com. Setelah 10 mnt, buka magic, aduk rata koreksi rasa, lalu masukkan santan kara, aduk2 rata lagi. Lakukan pengadukan setiap 10 mnt hingga nasi matang
1. Telur balado: haluskan semua bahan sambal balado, kecuali telur
1. Tumis bahan sambal balado hingga minyak naik, bumbui garam dan gula, koreksi rasa
1. Sajikan nasi uduk bersama perkedel kentang, bihun goreng, telur balado, telur dadar iris dan orek tempe




Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
