---
description: "Resep Nasi uduk yang Enak"
title: "Resep Nasi uduk yang Enak"
slug: 157-resep-nasi-uduk-yang-enak
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-01T21:41:06.902Z 
thumbnail: https://img-global.cpcdn.com/recipes/437fa5256d8aed65/682x484cq65/nasi-uduk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/437fa5256d8aed65/682x484cq65/nasi-uduk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/437fa5256d8aed65/682x484cq65/nasi-uduk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/437fa5256d8aed65/682x484cq65/nasi-uduk-foto-resep-utama.webp
author: Alfred Bailey
ratingvalue: 3
reviewcount: 13
recipeingredient:
- "beras 500 gr"
- "santan cair dari 12 butir kelapa 700 ml"
- "garam 1/4 sdt"
- "daun salam 3 lbr"
- "daun pandan 2 lbr"
- "sereh 2 btg"
- "lengkuas 1 ruas"
- "cengkeh 3 butir"
- "Bumbu halus "
- "bawang merah 5 siung"
- "bawang putih 4 siung"
- "garam 1/4 sdt"
recipeinstructions:
- "Haluskan bumbu dengan cara diulek."
- "Tumis bumbu tambahkan daun salam, sereh, pandan, lengkuas, cengkeh."
- "Masukkan beras dan santan. Masak dg cara diaron. Masak sampai air menyusut. Matikan kompor."
- "Kukus nasi aron sampai matang kurleb 25 menit. Sajikan dengan pelengkap. Aku bikin bihun goreng, bakwan goreng, semur kentang telur, telur balado, minumnya teh tawar hangat. Ah mantap!"
categories:
- Resep
tags:
- nasi
- uduk

katakunci: nasi uduk 
nutrition: 224 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT45M"
recipeyield: "4"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi uduk](https://img-global.cpcdn.com/recipes/437fa5256d8aed65/682x484cq65/nasi-uduk-foto-resep-utama.webp)

Ingin membuat Nasi uduk ? Coba resep berikut ini. Cara memasaknya sangat praktis namun hasilnya gurih dan lezat cocok banget jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Untuk Pembuatan Nasi uduk:

1. beras 500 gr
1. santan cair dari 12 butir kelapa 700 ml
1. garam 1/4 sdt
1. daun salam 3 lbr
1. daun pandan 2 lbr
1. sereh 2 btg
1. lengkuas 1 ruas
1. cengkeh 3 butir
1. Bumbu halus 
1. bawang merah 5 siung
1. bawang putih 4 siung
1. garam 1/4 sdt

My favorite way of cooking nasi uduk is with a rice cooker or Instant Pot. It&#39;s a no brainer because I just need to put. Nasi uduk literally means mixed rice in Indonesian. The name describes the dish preparation itself which requires more ingredients than common rice cooking and also varieties additional side dishes. 

<!--inarticleads2-->

## Tata Cara Menyiapkan Nasi uduk:

1. Haluskan bumbu dengan cara diulek.
1. Tumis bumbu tambahkan daun salam, sereh, pandan, lengkuas, cengkeh.
1. Masukkan beras dan santan. Masak dg cara diaron. Masak sampai air menyusut. Matikan kompor.
1. Kukus nasi aron sampai matang kurleb 25 menit. Sajikan dengan pelengkap. Aku bikin bihun goreng, bakwan goreng, semur kentang telur, telur balado, minumnya teh tawar hangat. Ah mantap!


Nasi uduk merupakan hidanga utama khas di Indonesia. Nasi uduk memiliki cita rasa yang enak, dilengkapi dengan lauk-pauk yang komplit dan juga membuatnya cukup mudah dengan. Resep nasi uduk - Makanan merupakan salah satu kebutuhan pokok manusia yang harus dipenuhi. Terdapat banyak sekali jenis makanan yang baik dan menyehatkan, salah satunya yaitu nasi uduk. Namun, nasi uduk juga bisa dibuat dengan tampilan berbeda, misalnya jadi berwarna hijau. 

Terima kasih telah membaca resep yang kami tampilkan di halaman ini. Semoga bermanfaat dan selamat mencoba!
