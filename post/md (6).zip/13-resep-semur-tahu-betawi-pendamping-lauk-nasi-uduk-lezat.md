---
description: "Resep Semur Tahu Betawi (Pendamping Lauk Nasi Uduk), Lezat"
title: "Resep Semur Tahu Betawi (Pendamping Lauk Nasi Uduk), Lezat"
slug: 13-resep-semur-tahu-betawi-pendamping-lauk-nasi-uduk-lezat
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-25T17:45:56.529Z 
thumbnail: https://img-global.cpcdn.com/recipes/da75febfc034d304/682x484cq65/semur-tahu-betawi-pendamping-lauk-nasi-uduk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/da75febfc034d304/682x484cq65/semur-tahu-betawi-pendamping-lauk-nasi-uduk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/da75febfc034d304/682x484cq65/semur-tahu-betawi-pendamping-lauk-nasi-uduk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/da75febfc034d304/682x484cq65/semur-tahu-betawi-pendamping-lauk-nasi-uduk-foto-resep-utama.webp
author: Birdie Osborne
ratingvalue: 4.9
reviewcount: 4
recipeingredient:
- "tahu kulit segitiga 10 buah"
- "air 300 ml"
- "Bumbu cemplung "
- "lengkuas geprek 1 ruas"
- "sereh geprek 2 batang"
- "daun salam sobek2 3 lembar"
- "daun jeruk sobek2 2 lembar"
- "kayu manis 1 batang"
- "pala bubuk 1 sdt"
- "Bumbu masak "
- "kecap manis 5 sdm"
- "Garam kaldu bubuk merica bubuk secukupnya"
- "Bumbu halus "
- "bawang putih 3 siung"
- "bawang merah 4 siung"
- "kemiri sangrai 2 butir"
recipeinstructions:
- "Tumis bumbu halus, daun salam, daun jeruk, sereh, bubuk kayu manis dan pala bubuk hingga harum dan matang. Tambahkan air."
- "Masak hingga air mendidih, masukan tahu. Tuang kecap manis. Beri garam, kaldu jamur, merica bubuk. Aduk rata, koreksi rasanya."
- "Masak hingga bumbu meresap. Sajikan."
categories:
- Resep
tags:
- semur
- tahu
- betawi

katakunci: semur tahu betawi 
nutrition: 217 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT40M"
recipeyield: "4"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Semur Tahu Betawi (Pendamping Lauk Nasi Uduk)](https://img-global.cpcdn.com/recipes/da75febfc034d304/682x484cq65/semur-tahu-betawi-pendamping-lauk-nasi-uduk-foto-resep-utama.webp)

3 langkah cepat mengolah  Semur Tahu Betawi (Pendamping Lauk Nasi Uduk) cocok sekali jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Dalam Pembuatan Semur Tahu Betawi (Pendamping Lauk Nasi Uduk):

1. tahu kulit segitiga 10 buah
1. air 300 ml
1. Bumbu cemplung 
1. lengkuas geprek 1 ruas
1. sereh geprek 2 batang
1. daun salam sobek2 3 lembar
1. daun jeruk sobek2 2 lembar
1. kayu manis 1 batang
1. pala bubuk 1 sdt
1. Bumbu masak 
1. kecap manis 5 sdm
1. Garam kaldu bubuk merica bubuk secukupnya
1. Bumbu halus 
1. bawang putih 3 siung
1. bawang merah 4 siung
1. kemiri sangrai 2 butir



<!--inarticleads2-->

## Cara Mudah Menyiapkan Semur Tahu Betawi (Pendamping Lauk Nasi Uduk):

1. Tumis bumbu halus, daun salam, daun jeruk, sereh, bubuk kayu manis dan pala bubuk hingga harum dan matang. Tambahkan air.
1. Masak hingga air mendidih, masukan tahu. Tuang kecap manis. Beri garam, kaldu jamur, merica bubuk. Aduk rata, koreksi rasanya.
1. Masak hingga bumbu meresap. Sajikan.




Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
