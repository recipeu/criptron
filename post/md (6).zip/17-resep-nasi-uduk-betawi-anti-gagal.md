---
description: "Resep Nasi Uduk Betawi Anti Gagal"
title: "Resep Nasi Uduk Betawi Anti Gagal"
slug: 17-resep-nasi-uduk-betawi-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-01T13:37:44.912Z 
thumbnail: https://img-global.cpcdn.com/recipes/2d4a7bfcc0f211d2/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/2d4a7bfcc0f211d2/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/2d4a7bfcc0f211d2/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/2d4a7bfcc0f211d2/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
author: Lizzie Cross
ratingvalue: 4.8
reviewcount: 5
recipeingredient:
- "beras yg agak perak 1 liter"
- "santan 12 butir kelapa sy 2 sachet santan instan 1200 ml"
- "Bumbu aromatic  "
- "daun salam 6 lembar"
- "serai geprek 2 btg"
- "jahe geprek Sejempol"
- "lengkuas geprek Sejempol"
- "pala ukuran kecil geprek sy skip 1 btr"
- "kayu manis 1 btg"
- "cengkih 6 btr"
- "garam dan kaldu jamur Secukupnya"
recipeinstructions:
- "Tuang santan ke dalam wajan, masukkan semua bumbu. Masak sambil diaduk2 hingga mendidih, jangan sampai santan nya pecah ya"
- "Setelah santan mendidih masukkan beras. Masak sambil diaduk / di aron hingga santan terserap habis. Api nya jangan besar2 ya"
- "Panaskan kukusan. Pindahkan beras aron ke kukusan. Kukus sampai matang. Sy kukus 45 menit."
- "Sajikan nasi uduk hangat2 ditabur bawang goreng dan dilengkapi sambal kacang.. MaasyaaAllah mari makannnn😋😍"
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 127 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT60M"
recipeyield: "3"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Betawi](https://img-global.cpcdn.com/recipes/2d4a7bfcc0f211d2/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp)

Resep Nasi Uduk Betawi    dengan 4 langkahcepat dan mudah cocok sekali jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Dalam Menyiapkan Nasi Uduk Betawi:

1. beras yg agak perak 1 liter
1. santan 12 butir kelapa sy 2 sachet santan instan 1200 ml
1. Bumbu aromatic  
1. daun salam 6 lembar
1. serai geprek 2 btg
1. jahe geprek Sejempol
1. lengkuas geprek Sejempol
1. pala ukuran kecil geprek sy skip 1 btr
1. kayu manis 1 btg
1. cengkih 6 btr
1. garam dan kaldu jamur Secukupnya



<!--inarticleads2-->

## Cara Membuat Nasi Uduk Betawi:

1. Tuang santan ke dalam wajan, masukkan semua bumbu. Masak sambil diaduk2 hingga mendidih, jangan sampai santan nya pecah ya
1. Setelah santan mendidih masukkan beras. Masak sambil diaduk / di aron hingga santan terserap habis. Api nya jangan besar2 ya
<img class="lazyload" data-src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Nasi Uduk Betawi" width="340" height="340">
>1. Panaskan kukusan. Pindahkan beras aron ke kukusan. Kukus sampai matang. Sy kukus 45 menit.
1. Sajikan nasi uduk hangat2 ditabur bawang goreng dan dilengkapi sambal kacang.. - MaasyaaAllah mari makannnn😋😍




Salah satu masakan yang cukup praktis pembuatannya adalah  Nasi Uduk Betawi. Selain itu  Nasi Uduk Betawi  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu lakukan 4 langkah, dan  Nasi Uduk Betawi  pun siap di hidangkan. selamat mencoba !
