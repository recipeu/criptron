---
description: "Resep Nasi Daun Jeruk yang Lezat"
title: "Resep Nasi Daun Jeruk yang Lezat"
slug: 332-resep-nasi-daun-jeruk-yang-lezat
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-24T14:28:06.929Z 
thumbnail: https://img-global.cpcdn.com/recipes/304a4f346e5d9aa9/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/304a4f346e5d9aa9/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/304a4f346e5d9aa9/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/304a4f346e5d9aa9/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
author: Steven Lowe
ratingvalue: 4.8
reviewcount: 14
recipeingredient:
- "Beras 500 gram"
- "Bawang putih 5 Siung"
- "Sereh 2 buah"
- "daun jeruk 10 lembar"
- "garam 1 sdt"
- "kaldu ayam 1 sdt"
- "minyak 2 sdm"
- "Air secukupnya"
recipeinstructions:
- "Cuci beras sampai bersih sisihkan"
- "Potong kecil&#34;bawang putih lalu tumis sampai kuning sisihkan"
- "Daun jeruk hilangkan batang tengahnya lalu potong&#34;panjang tipis..Geprek Sereh"
- "Masak Nasi (Aku pakai rice cooker) Dan Masukan bawang putih yang sudah digoreng,daun jeruk,sereh,garam dan kaldu,Air Secukupnya Seperti Masak Nasi Biasa"
- "Masak Sampai mateng,Dan Siap Dihidangkan *Saya Makan Sama Eseng pete ikan bilis😋"
- "SELAMAT MENCOBA*"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 171 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT31M"
recipeyield: "2"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk](https://img-global.cpcdn.com/recipes/304a4f346e5d9aa9/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp)

6 langkah mudah membuat  Nasi Daun Jeruk cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Dibutuhkan Untuk Pembuatan Nasi Daun Jeruk:

1. Beras 500 gram
1. Bawang putih 5 Siung
1. Sereh 2 buah
1. daun jeruk 10 lembar
1. garam 1 sdt
1. kaldu ayam 1 sdt
1. minyak 2 sdm
1. Air secukupnya

Nasi daun jeruk siap dihidangkan dengan. Nasi daun jeruk ini memang sedang tren di kalangan masyarakat Indonesia, banyak sekali kaum muda mudi yang berlomba-lomba membuat makanan nasi putih spesial ini. Nasi daun jeruk ala geprek bensu rekomended buat di coba. Geprek bensu nasi daun jeruk anti mainst. 

<!--inarticleads2-->

## Cara Mudah Menyiapkan Nasi Daun Jeruk:

1. Cuci beras sampai bersih sisihkan
1. Potong kecil&#34;bawang putih lalu tumis sampai kuning sisihkan
1. Daun jeruk hilangkan batang tengahnya lalu potong&#34;panjang tipis..Geprek Sereh
1. Masak Nasi (Aku pakai rice cooker) Dan Masukan bawang putih yang sudah digoreng,daun jeruk,sereh,garam dan kaldu,Air Secukupnya Seperti Masak Nasi Biasa
1. Masak Sampai mateng,Dan Siap Dihidangkan *Saya Makan Sama Eseng pete ikan bilis😋
1. SELAMAT MENCOBA*


Gurih dan wangi dari daun jeruk menambah kelezatan nasi daun jeruk. Nasi dengan campuran daun jeruk yang wangi sedang tren. Hai selamat pagi sahabat CWS, pagi ini saya share resep Nasi Daun Jeruk. Praktis banget karena saya gunakan rice cooker. Rasanya mirip nasi uduk tapi wangiiii. 

Daripada ibu beli  Nasi Daun Jeruk  diluar terus, kamu  bisa membuatnya sendiri dirumah. Resep  Nasi Daun Jeruk  sederhana ini cukup praktis pembuatannya, serta cukup menggunakan bumbu-bumbu sederhana yang ada di dapur  Nasi Daun Jeruk  yang enak, ibu nikmati di rumah.
