---
description: "Resep Nasi Daun Jeruk (Magicom), Enak"
title: "Resep Nasi Daun Jeruk (Magicom), Enak"
slug: 251-resep-nasi-daun-jeruk-magicom-enak
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-16T12:43:06.384Z 
thumbnail: https://img-global.cpcdn.com/recipes/f0ac461afc74741a/682x484cq65/nasi-daun-jeruk-magicom-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/f0ac461afc74741a/682x484cq65/nasi-daun-jeruk-magicom-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/f0ac461afc74741a/682x484cq65/nasi-daun-jeruk-magicom-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/f0ac461afc74741a/682x484cq65/nasi-daun-jeruk-magicom-foto-resep-utama.webp
author: Cole Ellis
ratingvalue: 3.3
reviewcount: 11
recipeingredient:
- "bawang putih cincangbaceman bawang 1 sdm 3 siung"
- "daun jeruk iris kecil buang tulang daunnya 15-20 lembar"
- "beras 2 gelas belimbing"
- "sereh 1 batang"
- "minyak untuk menumis Secukupnya"
- "garam dan kaldu ayam bubuk Secukupnya"
- "air Secukupnya"
recipeinstructions:
- "Cuci beras hingga bersih dan masukkan ke dalam wadah magicom"
- "Tumis bawang hingga harum dan masukkan daun jeruk yg sudah dipotong. Aduk aduk hingga kecoklatan kemudian tuang ke atas beras"
- "Tambahkan sereh yg sudah digeprek, garam dan kaldu bubuk"
- "Tambahkan air seperti memasak nasi pada umunya dan masak dengan magicom"
- "Setelah mendidih aduk aduk sesekali dan cek rasa."
- "Nasi daun jeruk sudah matang dan siap untuk disajikan"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 110 calories
recipecuisine: Indonesian
preptime: "PT15M"
cooktime: "PT31M"
recipeyield: "2"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk (Magicom)](https://img-global.cpcdn.com/recipes/f0ac461afc74741a/682x484cq65/nasi-daun-jeruk-magicom-foto-resep-utama.webp)

Resep Nasi Daun Jeruk (Magicom)    dengan 6 langkahcepat dan mudah cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Dibutuhkan Untuk Pembuatan Nasi Daun Jeruk (Magicom):

1. bawang putih cincangbaceman bawang 1 sdm 3 siung
1. daun jeruk iris kecil buang tulang daunnya 15-20 lembar
1. beras 2 gelas belimbing
1. sereh 1 batang
1. minyak untuk menumis Secukupnya
1. garam dan kaldu ayam bubuk Secukupnya
1. air Secukupnya



<!--inarticleads2-->

## Cara Mudah Membuat Nasi Daun Jeruk (Magicom):

1. Cuci beras hingga bersih dan masukkan ke dalam wadah magicom
1. Tumis bawang hingga harum dan masukkan daun jeruk yg sudah dipotong. Aduk aduk hingga kecoklatan kemudian tuang ke atas beras
1. Tambahkan sereh yg sudah digeprek, garam dan kaldu bubuk
1. Tambahkan air seperti memasak nasi pada umunya dan masak dengan magicom
1. Setelah mendidih aduk aduk sesekali dan cek rasa.
1. Nasi daun jeruk sudah matang dan siap untuk disajikan




Selamat memasak dan menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
