---
description: "Langkah Mudah untuk Menyiapkan Nasi Bakar AYAM KEMANGI Anti Gagal"
title: "Langkah Mudah untuk Menyiapkan Nasi Bakar AYAM KEMANGI Anti Gagal"
slug: 389-langkah-mudah-untuk-menyiapkan-nasi-bakar-ayam-kemangi-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-11T02:22:32.231Z 
thumbnail: https://img-global.cpcdn.com/recipes/171abcb60e8253b4/682x484cq65/nasi-bakar-ayam-kemangi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/171abcb60e8253b4/682x484cq65/nasi-bakar-ayam-kemangi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/171abcb60e8253b4/682x484cq65/nasi-bakar-ayam-kemangi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/171abcb60e8253b4/682x484cq65/nasi-bakar-ayam-kemangi-foto-resep-utama.webp
author: Adeline Walker
ratingvalue: 3.2
reviewcount: 7
recipeingredient:
- "Bahan Nasi  "
- "Beras 2 cup"
- "Santan instan 1 bungkus"
- "Serei 1 batang"
- "daun Salam 2 lembar"
- "daun Jeruk 2 lembar"
- "daun Pandan simpulkan 1"
- "Garam Secukupnya"
- "Air Secukupnya"
- "Bahan Ayam Kemangi  "
- "Ayam 250 gram"
- "Serei geprek 1 batang"
- "Lengkuas geprek 1 ruas"
- "daun Salam 2 lembar"
- "daun Jeruk 2 lembar"
- "daun Kemangi 2 ikat"
- "Gula Garam dan Lada Secukupnya"
- "Kaldu bubuk Secukupnya"
- "Air Secukupnya"
- "Bumbu halus  "
- "bawang Merah 6 siung"
- "bawang Putih 3 siung"
- "Cabe merah besar 5 buah"
- "Kemiri 2 buah"
- "Kunyit 1 ruas"
- "Jahe 1/2 ruas"
- "Gula jawa sisir 1 sdm"
- "air Asam jawa 2 sdm"
- "Bahan Pelengkap  "
- "daun Pisang Secukupnya"
recipeinstructions:
- "Cuci beras, lalu campur semua bahan nasi dan masak menggunakan ricecooker."
- "Rebus ayam hingga empuk, lalu suwir-suwir ayam dan sisihkan."
- "Haluskan bumbu, tumis beserta daun salam, daun jeruk, serei dan lengkuas hingga harum. Lalu masukan ayam suwir."
- "Aduk rata lalu tambahkan gula, garam, lada dan kaldu bubuk. Beri sedikit air. Masak hingga bumbu meresap dan air menyusut."
- "Sebelum diangkat, masukan daun kemangi dan aduk sebentar."
- "Siapkan nasi dan daun pisang yang sudah dibakar (agar tidak mudah sobek). Gulung dan bungkus nasi lalu panggang sebentar."
- "Selamat Mencoba 🤗"
- "Ambil nasi dan tambahkan ayam kemangi secukupnya pada bagian atas."
categories:
- Resep
tags:
- nasi
- bakar
- ayam

katakunci: nasi bakar ayam 
nutrition: 116 calories
recipecuisine: Indonesian
preptime: "PT38M"
cooktime: "PT50M"
recipeyield: "2"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Bakar AYAM KEMANGI](https://img-global.cpcdn.com/recipes/171abcb60e8253b4/682x484cq65/nasi-bakar-ayam-kemangi-foto-resep-utama.webp)

Resep rahasia dan cara mengolah  Nasi Bakar AYAM KEMANGI cocok sekali jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Dalam Menyiapkan Nasi Bakar AYAM KEMANGI:

1. Bahan Nasi  
1. Beras 2 cup
1. Santan instan 1 bungkus
1. Serei 1 batang
1. daun Salam 2 lembar
1. daun Jeruk 2 lembar
1. daun Pandan simpulkan 1
1. Garam Secukupnya
1. Air Secukupnya
1. Bahan Ayam Kemangi  
1. Ayam 250 gram
1. Serei geprek 1 batang
1. Lengkuas geprek 1 ruas
1. daun Salam 2 lembar
1. daun Jeruk 2 lembar
1. daun Kemangi 2 ikat
1. Gula Garam dan Lada Secukupnya
1. Kaldu bubuk Secukupnya
1. Air Secukupnya
1. Bumbu halus  
1. bawang Merah 6 siung
1. bawang Putih 3 siung
1. Cabe merah besar 5 buah
1. Kemiri 2 buah
1. Kunyit 1 ruas
1. Jahe 1/2 ruas
1. Gula jawa sisir 1 sdm
1. air Asam jawa 2 sdm
1. Bahan Pelengkap  
1. daun Pisang Secukupnya



<!--inarticleads2-->

## Langkah-langkah Untuk Membuat Nasi Bakar AYAM KEMANGI:

1. Cuci beras, lalu campur semua bahan nasi dan masak menggunakan ricecooker.
1. Rebus ayam hingga empuk, lalu suwir-suwir ayam dan sisihkan.
1. Haluskan bumbu, tumis beserta daun salam, daun jeruk, serei dan lengkuas hingga harum. Lalu masukan ayam suwir.
1. Aduk rata lalu tambahkan gula, garam, lada dan kaldu bubuk. Beri sedikit air. Masak hingga bumbu meresap dan air menyusut.
1. Sebelum diangkat, masukan daun kemangi dan aduk sebentar.
1. Siapkan nasi dan daun pisang yang sudah dibakar (agar tidak mudah sobek). Gulung dan bungkus nasi lalu panggang sebentar.
1. Selamat Mencoba 🤗
1. Ambil nasi dan tambahkan ayam kemangi secukupnya pada bagian atas.




Demikian informasi  resep Nasi Bakar AYAM KEMANGI   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
