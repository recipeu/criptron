---
description: "Resep Nasi bakar ikan tuna (kaleng) yang Bisa Manjain Lidah"
title: "Resep Nasi bakar ikan tuna (kaleng) yang Bisa Manjain Lidah"
slug: 358-resep-nasi-bakar-ikan-tuna-kaleng-yang-bisa-manjain-lidah
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-22T05:42:45.306Z 
thumbnail: https://img-global.cpcdn.com/recipes/3d777c334903ec49/682x484cq65/nasi-bakar-ikan-tuna-kaleng-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/3d777c334903ec49/682x484cq65/nasi-bakar-ikan-tuna-kaleng-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/3d777c334903ec49/682x484cq65/nasi-bakar-ikan-tuna-kaleng-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/3d777c334903ec49/682x484cq65/nasi-bakar-ikan-tuna-kaleng-foto-resep-utama.webp
author: Sarah Lindsey
ratingvalue: 3.6
reviewcount: 15
recipeingredient:
- "ikan tuna 1 kaleng"
- "nasi 1 piring"
- "bawang putih 5 siung"
- "bawang merah 5 siung"
- "cabe merah besar 2 biji"
- "cabe rawit 5 biji"
- "serai 1 biji"
- "daun salam 1 lembar"
recipeinstructions:
- "Tumis bumbu lalu masukan ikan tuna aduk 10 menit lalu angkat"
- "Ambil daun pisang secukupnya."
- "Taruh nasi matang di atas daun."
- "Lalu tambahkan ikan. Tuna diatasnya."
- "Tambahkan kemangi bawang goreng. Lalu bungkus seperti pepes"
- "Ambil panggangan untuk membakar nasi bolak balik"
- "Angkat dan sajikan selagi hangat rasanya enak banget"
categories:
- Resep
tags:
- nasi
- bakar
- ikan

katakunci: nasi bakar ikan 
nutrition: 274 calories
recipecuisine: Indonesian
preptime: "PT38M"
cooktime: "PT51M"
recipeyield: "4"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi bakar ikan tuna (kaleng)](https://img-global.cpcdn.com/recipes/3d777c334903ec49/682x484cq65/nasi-bakar-ikan-tuna-kaleng-foto-resep-utama.webp)

Resep Nasi bakar ikan tuna (kaleng)  sederhana dengan 7 langkahmudah dan cepat yang musti ibu coba dirumah

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Untuk Menyiapkan Nasi bakar ikan tuna (kaleng):

1. ikan tuna 1 kaleng
1. nasi 1 piring
1. bawang putih 5 siung
1. bawang merah 5 siung
1. cabe merah besar 2 biji
1. cabe rawit 5 biji
1. serai 1 biji
1. daun salam 1 lembar

Tuna merupakan salah satu jenis ikan yang mengandung banyak nutrisi. Ikan memang adalah salah satu lauk yang banyak digemari masyarakat. Ikan Tuna banyak diburu hingga saat ini, karena rasanya yang lezat dan memiliki banyak gizi, maka tak heran jika harga ikan tuna mahal. Karakteristik daging ikan tuna bertekstur lembut dan berwarna merah darah. 

<!--inarticleads2-->

## Cara Membuat Nasi bakar ikan tuna (kaleng):

1. Tumis bumbu lalu masukan ikan tuna aduk 10 menit lalu angkat
1. Ambil daun pisang secukupnya.
1. Taruh nasi matang di atas daun.
1. Lalu tambahkan ikan. Tuna diatasnya.
1. Tambahkan kemangi bawang goreng. Lalu bungkus seperti pepes
1. Ambil panggangan untuk membakar nasi bolak balik
1. Angkat dan sajikan selagi hangat rasanya enak banget


Semakin merah warna dagingnya, akan membuat harga ikan tuna menjadi semakin. Manfaat Ikan Tuna yang Tak Boleh Dilewatkan. Ini Olahan Ikan Tuna yang Dijamin Menggoyang Lidah. Masukkan kemangi lalu aduk rata dan sajikan dengan nasi hangat. Tambahkan tuna kaleng ke dalam tumisan bumbu dan aduk merata. 

Terima kasih telah menggunakan resep yang kami tampilkan di halaman ini. Selamat mencoba!
