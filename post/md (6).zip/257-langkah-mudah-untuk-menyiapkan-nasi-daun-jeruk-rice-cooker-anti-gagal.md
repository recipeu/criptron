---
description: "Langkah Mudah untuk Menyiapkan Nasi daun jeruk rice cooker Anti Gagal"
title: "Langkah Mudah untuk Menyiapkan Nasi daun jeruk rice cooker Anti Gagal"
slug: 257-langkah-mudah-untuk-menyiapkan-nasi-daun-jeruk-rice-cooker-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2022-01-04T14:53:24.687Z 
thumbnail: https://img-global.cpcdn.com/recipes/7738575fdbc211bc/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/7738575fdbc211bc/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/7738575fdbc211bc/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/7738575fdbc211bc/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
author: Emilie Briggs
ratingvalue: 4.6
reviewcount: 9
recipeingredient:
- "beras 2 cup"
- "margarin 1 sdm"
- "daun salam 2 lembar"
- "daun jeruk iris 15 lembar"
- "sereh geprek 1 batang"
- "Garam kaldu jamur dan merica bubuk "
recipeinstructions:
- "Cuci beras. Masukkan semua bahan yg disiapkan diatas. Masak seperti biasa"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 212 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT44M"
recipeyield: "4"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi daun jeruk rice cooker](https://img-global.cpcdn.com/recipes/7738575fdbc211bc/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp)

Ingin membuat Nasi daun jeruk rice cooker ? Coba resep berikut ini. Cara memasaknya sangat praktis namun hasilnya gurih dan lezat yang wajib kamu coba dirumah

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Untuk Menyiapkan Nasi daun jeruk rice cooker:

1. beras 2 cup
1. margarin 1 sdm
1. daun salam 2 lembar
1. daun jeruk iris 15 lembar
1. sereh geprek 1 batang
1. Garam kaldu jamur dan merica bubuk 

Hai selamat pagi sahabat CWS, pagi ini saya share resep Nasi Daun Jeruk. Praktis banget karena saya gunakan rice cooker. Rasanya mirip nasi uduk tapi wangiiii. Yukkk mari dipantengin dan dipraktekin yah. 

<!--inarticleads2-->

## Tata Cara Menyiapkan Nasi daun jeruk rice cooker:

1. Cuci beras. Masukkan semua bahan yg disiapkan diatas. Masak seperti biasa


Berikut nih tips dari saya supaya nasi nya matang. Gurih dan wangi dari daun jeruk menambah kelezatan nasi daun jeruk. Setelah tombol menyatakan matang, masukkan daun jeruk. Jangan buka rice cooker sampai uap hilang. Sajikan nasi bersama lauk pelengkap seperti dadar rawis atau bakwan jagung. 

Demikian informasi  resep Nasi daun jeruk rice cooker   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
