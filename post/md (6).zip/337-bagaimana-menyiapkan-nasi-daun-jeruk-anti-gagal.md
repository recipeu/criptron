---
description: "Bagaimana Menyiapkan Nasi Daun Jeruk Anti Gagal"
title: "Bagaimana Menyiapkan Nasi Daun Jeruk Anti Gagal"
slug: 337-bagaimana-menyiapkan-nasi-daun-jeruk-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-21T16:45:43.022Z 
thumbnail: https://img-global.cpcdn.com/recipes/b4bbcdcc0e9bc75c/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/b4bbcdcc0e9bc75c/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/b4bbcdcc0e9bc75c/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/b4bbcdcc0e9bc75c/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
author: Erik Doyle
ratingvalue: 5
reviewcount: 12
recipeingredient:
- "beras pake cup bawaan magiccom 3 Cup"
- "santan instan aku pake kara 65 gr"
- "daun jeruk 3 lembar"
- "daun salam 4 lembar"
- "serai 2 batang"
- "air untuk memasak nasi seperti biasa Secukupnya"
- "garam dan penyedap rasa Secukupnya"
- "Taburan  "
- "daun jeruk buang tulangnya iris tipis 4 lembar"
- "Pelengkap lauk  "
- "Lalapan tahu tempe sambal dan ayam goreng "
recipeinstructions:
- "Aduk rata semua bahan dalam magiccom (kecuali bahan taburan). Masak hingga matang."
- "Setelah matang aduk nasi dalam magiccom ambil daun rempahnya, kemudian berikan taburan daun jeruk, aduk rata kembali."
- "Nasi daun jeruk siap dihidangkan dengan pelengkap lainnya."
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 111 calories
recipecuisine: Indonesian
preptime: "PT11M"
cooktime: "PT52M"
recipeyield: "2"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk](https://img-global.cpcdn.com/recipes/b4bbcdcc0e9bc75c/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp)

Resep dan cara mengolah  Nasi Daun Jeruk cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Untuk Menyiapkan Nasi Daun Jeruk:

1. beras pake cup bawaan magiccom 3 Cup
1. santan instan aku pake kara 65 gr
1. daun jeruk 3 lembar
1. daun salam 4 lembar
1. serai 2 batang
1. air untuk memasak nasi seperti biasa Secukupnya
1. garam dan penyedap rasa Secukupnya
1. Taburan  
1. daun jeruk buang tulangnya iris tipis 4 lembar
1. Pelengkap lauk  
1. Lalapan tahu tempe sambal dan ayam goreng 

Nasi daun jeruk siap dihidangkan dengan. Nasi daun jeruk ini memang sedang tren di kalangan masyarakat Indonesia, banyak sekali kaum muda mudi yang berlomba-lomba membuat makanan nasi putih spesial ini. Nasi daun jeruk ala geprek bensu rekomended buat di coba. Geprek bensu nasi daun jeruk anti mainst. 

<!--inarticleads2-->

## Tata Cara Membuat Nasi Daun Jeruk:

1. Aduk rata semua bahan dalam magiccom (kecuali bahan taburan). Masak hingga matang.
1. Setelah matang aduk nasi dalam magiccom ambil daun rempahnya, kemudian berikan taburan daun jeruk, aduk rata kembali.
1. Nasi daun jeruk siap dihidangkan dengan pelengkap lainnya.


Gurih dan wangi dari daun jeruk menambah kelezatan nasi daun jeruk. Nasi dengan campuran daun jeruk yang wangi sedang tren. Hai selamat pagi sahabat CWS, pagi ini saya share resep Nasi Daun Jeruk. Praktis banget karena saya gunakan rice cooker. Rasanya mirip nasi uduk tapi wangiiii. 

Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
