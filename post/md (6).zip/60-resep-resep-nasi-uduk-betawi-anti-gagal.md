---
description: "Resep Resep Nasi Uduk Betawi Anti Gagal"
title: "Resep Resep Nasi Uduk Betawi Anti Gagal"
slug: 60-resep-resep-nasi-uduk-betawi-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-12T05:26:12.362Z 
thumbnail: https://img-global.cpcdn.com/recipes/437e00747ff5e41b/682x484cq65/resep-nasi-uduk-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/437e00747ff5e41b/682x484cq65/resep-nasi-uduk-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/437e00747ff5e41b/682x484cq65/resep-nasi-uduk-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/437e00747ff5e41b/682x484cq65/resep-nasi-uduk-betawi-foto-resep-utama.webp
author: Dennis Greene
ratingvalue: 3.9
reviewcount: 10
recipeingredient:
- "Beras 1 l"
- "Santan kara uk kecil 1 bks"
- "Geprek sereh langkoas dan jahe "
- "Kayu manis biji pala lada "
- "Daun salam dan 2 daun jeruk 4"
- "Garam secukupnya"
- "Air putih secukupnya"
recipeinstructions:
- "Rebus air bersamaan dengan lengkoas, jahe, sereh, biji pala, kayu manis, dan lada, setelah itu angkat dan saring"
- "Masak kembali air rebusan yg sudah disaring, Lalu tambahkan kembali geprek lengkuas, jahe dan sereh kemudian masukkan beras yang sudah dicuci bersih, aduk rata"
- "Tambahkan santan dan garam, lalu aduk-aduk rata sampai air menyusut, jangan sampai kering airnya agar tidak hangus bagian bawahnya"
- "Lalu matikan kompor, dan diamkan sekitar 5menit"
- "Selanjutnya kukus nasi seperti biasa sekitar 40menit"
categories:
- Resep
tags:
- resep
- nasi
- uduk

katakunci: resep nasi uduk 
nutrition: 244 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT31M"
recipeyield: "1"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Resep Nasi Uduk Betawi](https://img-global.cpcdn.com/recipes/437e00747ff5e41b/682x484cq65/resep-nasi-uduk-betawi-foto-resep-utama.webp)

5 langkah cepat dan mudah membuat  Resep Nasi Uduk Betawi cocok sekali jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Bahan-bahan Yang Dibutuhkan Dalam Menyiapkan Resep Nasi Uduk Betawi:

1. Beras 1 l
1. Santan kara uk kecil 1 bks
1. Geprek sereh langkoas dan jahe 
1. Kayu manis biji pala lada 
1. Daun salam dan 2 daun jeruk 4
1. Garam secukupnya
1. Air putih secukupnya



<!--inarticleads2-->

## Cara Membuat Resep Nasi Uduk Betawi:

1. Rebus air bersamaan dengan lengkoas, jahe, sereh, biji pala, kayu manis, dan lada, setelah itu angkat dan saring
1. Masak kembali air rebusan yg sudah disaring, Lalu tambahkan kembali geprek lengkuas, jahe dan sereh kemudian masukkan beras yang sudah dicuci bersih, aduk rata
1. Tambahkan santan dan garam, lalu aduk-aduk rata sampai air menyusut, jangan sampai kering airnya agar tidak hangus bagian bawahnya
1. Lalu matikan kompor, dan diamkan sekitar 5menit
1. Selanjutnya kukus nasi seperti biasa sekitar 40menit




Daripada ibu beli  Resep Nasi Uduk Betawi  diluar terus, bunda  bisa membuatnya sendiri dirumah. Resep  Resep Nasi Uduk Betawi  sederhana ini cukup praktis pembuatannya, serta cukup menggunakan bumbu-bumbu sederhana yang ada di dapur  Resep Nasi Uduk Betawi  yang enak, bunda nikmati di rumah.
