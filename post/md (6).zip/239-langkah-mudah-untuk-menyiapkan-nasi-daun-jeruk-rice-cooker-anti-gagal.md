---
description: "Langkah Mudah untuk Menyiapkan Nasi daun jeruk (rice cooker) Anti Gagal"
title: "Langkah Mudah untuk Menyiapkan Nasi daun jeruk (rice cooker) Anti Gagal"
slug: 239-langkah-mudah-untuk-menyiapkan-nasi-daun-jeruk-rice-cooker-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-03T05:20:26.864Z 
thumbnail: https://img-global.cpcdn.com/recipes/cb27733e35146def/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/cb27733e35146def/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/cb27733e35146def/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/cb27733e35146def/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
author: Ruby Ortiz
ratingvalue: 4
reviewcount: 9
recipeingredient:
- "Beras 3 cup"
- "Air untuk masak nasi "
- "Santan kara 1 kecil "
- "Daun jeruk 6 lembar iris halus "
- "Bawang putih 4"
- "Sereh 1 batang geprek "
- "Garam 1,5 sdt"
- "Gula 2 sdm"
- "Kaldu jamur 1 sdt non msg "
recipeinstructions:
- "Cuci bersih beras masukkan dalam wadah rice cooker, parut bawah putih, masukkan irisan daun jeruk (buang tulang dsunnya baru iris tipis biar gak pait), masukkan sereh geprek, air, santan, gula garem, kaldu jamur"
- "Jangan lupa colok kabelnya ke stop kontak, dan celkekkan rice cooker ke bawah"
- "Tinggu sampai matang dan sajikan dengan lauk favorit keluarga"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 235 calories
recipecuisine: Indonesian
preptime: "PT39M"
cooktime: "PT57M"
recipeyield: "4"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi daun jeruk (rice cooker)](https://img-global.cpcdn.com/recipes/cb27733e35146def/682x484cq65/nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp)

3 langkah mudah dan cepat membuat  Nasi daun jeruk (rice cooker) cocok sekali jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Untuk Pembuatan Nasi daun jeruk (rice cooker):

1. Beras 3 cup
1. Air untuk masak nasi 
1. Santan kara 1 kecil 
1. Daun jeruk 6 lembar iris halus 
1. Bawang putih 4
1. Sereh 1 batang geprek 
1. Garam 1,5 sdt
1. Gula 2 sdm
1. Kaldu jamur 1 sdt non msg 

Penanak nasi (rice cooker) adalah pilihan yang mudah dan efektif digunakan untuk memasak nasi. Saat ini, ada banyak penanak nasi yang dilengkapi fitur penghangat sehingga tetap bisa menjaga nasi tetap hangat setelah matang. Anda tidak perlu mengawasi penanak nasi setiap saat hingga nasi. Gurih dan wangi dari daun jeruk menambah kelezatan nasi daun jeruk. 

<!--inarticleads2-->

## Cara Mudah Menyiapkan Nasi daun jeruk (rice cooker):

1. Cuci bersih beras masukkan dalam wadah rice cooker, parut bawah putih, masukkan irisan daun jeruk (buang tulang dsunnya baru iris tipis biar gak pait), masukkan sereh geprek, air, santan, gula garem, kaldu jamur
1. Jangan lupa colok kabelnya ke stop kontak, dan celkekkan rice cooker ke bawah
1. Tinggu sampai matang dan sajikan dengan lauk favorit keluarga


Dash Mini Rice Cooker Steamer With Removable Nonstick Pot Nasi dengan aroma yang khas ini memang cocok dinikmati bersama Ketika bosan mengonsumsi nasi putih biasa, kamu bisa menggantinya dengan nasi daun jeruk. Siapkan rice cooker, lalu masukkan tiga cangkir gelas. Setelah itu, cuci beras hingga bersih atau. Nasi putih daun jeruk rice cooker. 

Salah satu kuliner yang cukup praktis pembuatannya adalah  Nasi daun jeruk (rice cooker). Selain itu  Nasi daun jeruk (rice cooker)  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu lakukan 3 langkah, dan  Nasi daun jeruk (rice cooker)  pun siap di hidangkan. selamat mencoba !
