---
description: "Resep Nasi bakar ikan tuna pedas Anti Gagal"
title: "Resep Nasi bakar ikan tuna pedas Anti Gagal"
slug: 349-resep-nasi-bakar-ikan-tuna-pedas-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-31T01:30:52.129Z 
thumbnail: https://img-global.cpcdn.com/recipes/90b16304395e059a/682x484cq65/nasi-bakar-ikan-tuna-pedas-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/90b16304395e059a/682x484cq65/nasi-bakar-ikan-tuna-pedas-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/90b16304395e059a/682x484cq65/nasi-bakar-ikan-tuna-pedas-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/90b16304395e059a/682x484cq65/nasi-bakar-ikan-tuna-pedas-foto-resep-utama.webp
author: Allen Singleton
ratingvalue: 4.1
reviewcount: 10
recipeingredient:
- "Beras 2 cup"
- "Santan kental 2 gelas"
- "Daun salam "
- "Garam Sejumput"
- "ikan tuna 1 ekor"
- "bumbu kuning bawang putihmerah kemiri kunyit laos 2 sdm"
- "Garam secukupnya"
- "Kaldu jamur secukupnya"
- "cabe hijau  cabe merah 5 buah"
- "serai geprek 2 batang"
- "tomat 1 buah"
- "Daun kemangi "
- "Daun pisang untuk membungkus "
- "Telor dadar "
- "Kerupuk "
recipeinstructions:
- "Buat nasi gurih, saya pakai magiccom. Cuci beras, lalu masukkan dalam panci, beri garam dan daun salam, tambahkan santan. Tekan tombol cook."
- "Bersihkan ikan tuna, lumuri dengan jeruk nipis jika ada, agar tidak amis. Goreng sejenak, iriskan. Lalu Suwir2."
- "Untuk isian : tumis bumbu kuning, serai, cabe, sampai harum. Masukkan irisan tomat, aduk, lalu masukkan suwiran tuna, garam, kaldu jamur. Tes rasa."
- "Ambil daun pisang, 2 centong nasi, ratakan, beri isian dan daun kemangi, lalu gulung seperti lontong/arem-arem."
- "Bakar di atas kompor, sampai daun terlihat matang. Bolak-balik agar merata."
- "Sajikan dengan telur dadar atau kerupuk."
categories:
- Resep
tags:
- nasi
- bakar
- ikan

katakunci: nasi bakar ikan 
nutrition: 112 calories
recipecuisine: Indonesian
preptime: "PT16M"
cooktime: "PT44M"
recipeyield: "3"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi bakar ikan tuna pedas](https://img-global.cpcdn.com/recipes/90b16304395e059a/682x484cq65/nasi-bakar-ikan-tuna-pedas-foto-resep-utama.webp)

Resep Nasi bakar ikan tuna pedas  anti gagal dengan 6 langkahcepat yang harus bunda coba segera

<!--inarticleads1-->

## Bahan-bahan Yang Dibutuhkan Untuk Pembuatan Nasi bakar ikan tuna pedas:

1. Beras 2 cup
1. Santan kental 2 gelas
1. Daun salam 
1. Garam Sejumput
1. ikan tuna 1 ekor
1. bumbu kuning bawang putihmerah kemiri kunyit laos 2 sdm
1. Garam secukupnya
1. Kaldu jamur secukupnya
1. cabe hijau  cabe merah 5 buah
1. serai geprek 2 batang
1. tomat 1 buah
1. Daun kemangi 
1. Daun pisang untuk membungkus 
1. Telor dadar 
1. Kerupuk 

Tuna bakar pedas asam manis. tuna sesuai selera•Jeruk nipis•Bawang merah•Bawang putih•cabai besar•cabai rawit•tomat•Gula merah,garam,vetsin,kecap. Ikan Bakar Pedas Manis. ikan tuna•jeruk nipis•Gula, garam, lada•Bumbu halus:•cabe keriting•bawang putih•kunyit•jahe. Maka jadilah saya masak Nasi Bakar Tuna Pedas yang ternyata rasanya enak dan sesuai yang saya harapkan. Masukkan tuna, aduk hingga rata dan agak kering. 

<!--inarticleads2-->

## Langkah-langkah Untuk Membuat Nasi bakar ikan tuna pedas:

1. Buat nasi gurih, saya pakai magiccom. Cuci beras, lalu masukkan dalam panci, beri garam dan daun salam, tambahkan santan. Tekan tombol cook.
1. Bersihkan ikan tuna, lumuri dengan jeruk nipis jika ada, agar tidak amis. Goreng sejenak, iriskan. Lalu Suwir2.
1. Untuk isian : tumis bumbu kuning, serai, cabe, sampai harum. Masukkan irisan tomat, aduk, lalu masukkan suwiran tuna, garam, kaldu jamur. Tes rasa.
1. Ambil daun pisang, 2 centong nasi, ratakan, beri isian dan daun kemangi, lalu gulung seperti lontong/arem-arem.
1. Bakar di atas kompor, sampai daun terlihat matang. Bolak-balik agar merata.
1. Sajikan dengan telur dadar atau kerupuk.


Berikut resep Nasi Bakar Tuna Pedas racikan Food Blogger, Susie Agung. Nasi Bakar Tuna Kecombrang. foto: Instagram/@amakigai. Resep ikan tuna bakar oleh yuniati wijaya ikan tuna bakar enak resep easy healthy. Salah satunya adalah tumis tuna pedas. Sea food bakar udang bakar madu udang bakar simple cumi bakar teflon kepiting. 

Selamat memasak dan menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
