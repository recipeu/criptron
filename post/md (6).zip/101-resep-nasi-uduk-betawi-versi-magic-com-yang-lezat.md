---
description: "Resep Nasi Uduk Betawi Versi Magic Com yang Lezat"
title: "Resep Nasi Uduk Betawi Versi Magic Com yang Lezat"
slug: 101-resep-nasi-uduk-betawi-versi-magic-com-yang-lezat
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-11T14:54:13.323Z 
thumbnail: https://img-global.cpcdn.com/recipes/d0a2bb0952f56dea/682x484cq65/nasi-uduk-betawi-versi-magic-com-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/d0a2bb0952f56dea/682x484cq65/nasi-uduk-betawi-versi-magic-com-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/d0a2bb0952f56dea/682x484cq65/nasi-uduk-betawi-versi-magic-com-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/d0a2bb0952f56dea/682x484cq65/nasi-uduk-betawi-versi-magic-com-foto-resep-utama.webp
author: Juan Estrada
ratingvalue: 4.1
reviewcount: 4
recipeingredient:
- "beras 1 liter"
- "125 ml santan kental "
- "air takaran seperti biasa memasak secukupnya"
- "garam 1 sdt"
- "kaldu bubuk 2 sdt"
- "Bumbu Rempah  "
- "sereh geprek 3 batang"
- "daun salam 3 lembar"
- "lengkuas geprekiris 3 ruas jari"
- "jahe geprekiris 2 ruas jari"
- "kencur geprekiris sejempol"
recipeinstructions:
- "Cuci bersih beras, didihkan air santan beserta bumbu dan rempah setelah mendidih masukkan beras dan masak di magic com dengan tekan cook"
- "Setelah matang aduk nasi dan siap disajikan dengan pelengkap sambel bawang kerupuk dan ayam goreng lengkuas"
- ""
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 211 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT48M"
recipeyield: "4"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Betawi Versi Magic Com](https://img-global.cpcdn.com/recipes/d0a2bb0952f56dea/682x484cq65/nasi-uduk-betawi-versi-magic-com-foto-resep-utama.webp)

Ingin membuat Nasi Uduk Betawi Versi Magic Com ? Coba resep berikut ini. Cara memasaknya sangat praktis namun jangan kaget jika hasilnya gurih dan lezat cocok sekali jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Bahan-bahan Yang Dibutuhkan Untuk Pembuatan Nasi Uduk Betawi Versi Magic Com:

1. beras 1 liter
1. 125 ml santan kental 
1. air takaran seperti biasa memasak secukupnya
1. garam 1 sdt
1. kaldu bubuk 2 sdt
1. Bumbu Rempah  
1. sereh geprek 3 batang
1. daun salam 3 lembar
1. lengkuas geprekiris 3 ruas jari
1. jahe geprekiris 2 ruas jari
1. kencur geprekiris sejempol



<!--inarticleads2-->

## Langkah-langkah Untuk Membuat Nasi Uduk Betawi Versi Magic Com:

1. Cuci bersih beras, didihkan air santan beserta bumbu dan rempah setelah mendidih masukkan beras dan masak di magic com dengan tekan cook
1. Setelah matang aduk nasi dan siap disajikan dengan pelengkap sambel bawang kerupuk dan ayam goreng lengkuas
1. 




Terima kasih telah membaca resep yang kami tampilkan di sini. Semoga bermanfaat dan selamat mencoba!
