---
description: "Bagaimana Membuat Nasi Goreng Tuna, Sempurna"
title: "Bagaimana Membuat Nasi Goreng Tuna, Sempurna"
slug: 375-bagaimana-membuat-nasi-goreng-tuna-sempurna
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-12T23:39:55.416Z 
thumbnail: https://img-global.cpcdn.com/recipes/c2b7019195d94a32/682x484cq65/nasi-goreng-tuna-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/c2b7019195d94a32/682x484cq65/nasi-goreng-tuna-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/c2b7019195d94a32/682x484cq65/nasi-goreng-tuna-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/c2b7019195d94a32/682x484cq65/nasi-goreng-tuna-foto-resep-utama.webp
author: Catherine Townsend
ratingvalue: 3.1
reviewcount: 9
recipeingredient:
- "Nasi Putih 300 gr"
- "Ikan Tuna buang airnya 1 kaleng"
- "Bawang Merah haluskan 5 btr"
- "Bawang Putih haluskan 2 siung"
- "Daun Bawang iris halus 1 tangkai"
- "Kunyit Bakar haluskan 1/2 ruas"
- "Cabai Merah haluskan 2 bh"
- "Terasi Bakar haluskan 1 sdt"
- "Kecap Manis 2 sdm"
- "Garam dan Merica secukupnya"
recipeinstructions:
- "Campurkan minyak sayur dan daun bawang. Nyalakan api sedang. Proses ini adalah cara untuk membuat minyak daun bawang. Setelah daun bawang layu, tumis semua bumbu halus hingga harum."
- "Tambahkan gading ikan tuna. Aduk2 sampai ikan stengah masak."
- "Masukan nasi putih. Aduk rata."
- "Tambahkan kecap manis, garam dan merica. Aduk rata hingga nasi tidak lengket satu sama lain. Sajikan."
categories:
- Resep
tags:
- nasi
- goreng
- tuna

katakunci: nasi goreng tuna 
nutrition: 110 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT38M"
recipeyield: "4"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Goreng Tuna](https://img-global.cpcdn.com/recipes/c2b7019195d94a32/682x484cq65/nasi-goreng-tuna-foto-resep-utama.webp)

4 langkah cepat membuat  Nasi Goreng Tuna cocok banget jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Bahan-bahan Yang Dibutuhkan Dalam Menyiapkan Nasi Goreng Tuna:

1. Nasi Putih 300 gr
1. Ikan Tuna buang airnya 1 kaleng
1. Bawang Merah haluskan 5 btr
1. Bawang Putih haluskan 2 siung
1. Daun Bawang iris halus 1 tangkai
1. Kunyit Bakar haluskan 1/2 ruas
1. Cabai Merah haluskan 2 bh
1. Terasi Bakar haluskan 1 sdt
1. Kecap Manis 2 sdm
1. Garam dan Merica secukupnya



<!--inarticleads2-->

## Cara Membuat Nasi Goreng Tuna:

1. Campurkan minyak sayur dan daun bawang. Nyalakan api sedang. Proses ini adalah cara untuk membuat minyak daun bawang. Setelah daun bawang layu, tumis semua bumbu halus hingga harum.
1. Tambahkan gading ikan tuna. Aduk2 sampai ikan stengah masak.
1. Masukan nasi putih. Aduk rata.
1. Tambahkan kecap manis, garam dan merica. Aduk rata hingga nasi tidak lengket satu sama lain. Sajikan.




Salah satu masakan yang cukup praktis dalam pembuatannya adalah  Nasi Goreng Tuna. Selain itu  Nasi Goreng Tuna  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu ikuti 4 langkah, dan  Nasi Goreng Tuna  pun siap di hidangkan. selamat mencoba !
