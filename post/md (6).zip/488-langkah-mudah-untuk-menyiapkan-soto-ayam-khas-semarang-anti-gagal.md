---
description: "Langkah Mudah untuk Menyiapkan Soto Ayam Khas Semarang Anti Gagal"
title: "Langkah Mudah untuk Menyiapkan Soto Ayam Khas Semarang Anti Gagal"
slug: 488-langkah-mudah-untuk-menyiapkan-soto-ayam-khas-semarang-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-22T23:44:31.983Z 
thumbnail: https://img-global.cpcdn.com/recipes/1e934c14c0a6ede1/682x484cq65/soto-ayam-khas-semarang-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/1e934c14c0a6ede1/682x484cq65/soto-ayam-khas-semarang-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/1e934c14c0a6ede1/682x484cq65/soto-ayam-khas-semarang-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/1e934c14c0a6ede1/682x484cq65/soto-ayam-khas-semarang-foto-resep-utama.webp
author: Joel Goodwin
ratingvalue: 3.8
reviewcount: 7
recipeingredient:
- "Bahan Utama "
- "Ayam kampung 1 ekor"
- "Air 2 ltr"
- "Daun salam 2 lbr"
- "Sereh geprek 2 btg"
- "Garam 1,5 sdm"
- "Lada bubuk 1/2 sdt"
- "Gula pasir 1 sdt"
- "Minyak goreng 2 sdm"
- "Bumbu Halus "
- "Bawang putih 6 buah"
- "Ketumbar 1 sdt"
- "Jahe 2 cm"
- "Kunyit 1 cm"
- "Pelengkap "
- "Nasi putih "
- "Soun yg sudah diseduh 50 gr"
- "Jeruk nipis belah 2 1 buah"
- "Kecap manis 4 sdm"
- "Sate kerang saya lebih suka telur  "
- "Bawang putih goreng 2 sdm"
- "Daun bawang cincang 1 btg"
- "Seledri cincang 1 btg"
- "Bawang goreng 2 sdm"
recipeinstructions:
- "Didihkan air, kemudian masukkan ayam dan masak hingga ayam matang. Angkat ayam dan sisakan air kuah ayam 1,5liter (untuj kuah soto)"
- "Goreng ayam hingga bagian luar agar kecoklatan, angkat tiriskan lalu suwir-suwir ayam"
- "Panaskan minyak dan tumis bumbu halus, sereh dan daun salam sampai harum. Lalu tambahkan garam, lada dan gula pasir. Koreksi rasa dan masak sampai mendidih."
- "Siapkan mangkok, isi dengan nasi, soun, daun bawang, daun seledri, kecap manis. Kemudian siram dengan kuah soto"
- "Beri taburan bawang putih dan merah goreng, dan kucuran air jeruk nipis"
- "Sajikan dengan sate kerang"
categories:
- Resep
tags:
- soto
- ayam
- khas

katakunci: soto ayam khas 
nutrition: 249 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT45M"
recipeyield: "2"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Soto Ayam Khas Semarang](https://img-global.cpcdn.com/recipes/1e934c14c0a6ede1/682x484cq65/soto-ayam-khas-semarang-foto-resep-utama.webp)

Resep rahasia Soto Ayam Khas Semarang  anti gagal dengan 6 langkahcepat dan mudah cocok sekali jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Dibutuhkan Untuk Pembuatan Soto Ayam Khas Semarang:

1. Bahan Utama 
1. Ayam kampung 1 ekor
1. Air 2 ltr
1. Daun salam 2 lbr
1. Sereh geprek 2 btg
1. Garam 1,5 sdm
1. Lada bubuk 1/2 sdt
1. Gula pasir 1 sdt
1. Minyak goreng 2 sdm
1. Bumbu Halus 
1. Bawang putih 6 buah
1. Ketumbar 1 sdt
1. Jahe 2 cm
1. Kunyit 1 cm
1. Pelengkap 
1. Nasi putih 
1. Soun yg sudah diseduh 50 gr
1. Jeruk nipis belah 2 1 buah
1. Kecap manis 4 sdm
1. Sate kerang saya lebih suka telur  
1. Bawang putih goreng 2 sdm
1. Daun bawang cincang 1 btg
1. Seledri cincang 1 btg
1. Bawang goreng 2 sdm



<!--inarticleads2-->

## Cara Membuat Soto Ayam Khas Semarang:

1. Didihkan air, kemudian masukkan ayam dan masak hingga ayam matang. Angkat ayam dan sisakan air kuah ayam 1,5liter (untuj kuah soto)
1. Goreng ayam hingga bagian luar agar kecoklatan, angkat tiriskan lalu suwir-suwir ayam
1. Panaskan minyak dan tumis bumbu halus, sereh dan daun salam sampai harum. Lalu tambahkan garam, lada dan gula pasir. Koreksi rasa dan masak sampai mendidih.
1. Siapkan mangkok, isi dengan nasi, soun, daun bawang, daun seledri, kecap manis. Kemudian siram dengan kuah soto
1. Beri taburan bawang putih dan merah goreng, dan kucuran air jeruk nipis
1. Sajikan dengan sate kerang




Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
