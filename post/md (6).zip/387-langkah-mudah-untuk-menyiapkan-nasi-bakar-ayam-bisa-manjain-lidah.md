---
description: "Langkah Mudah untuk Menyiapkan Nasi Bakar Ayam, Bisa Manjain Lidah"
title: "Langkah Mudah untuk Menyiapkan Nasi Bakar Ayam, Bisa Manjain Lidah"
slug: 387-langkah-mudah-untuk-menyiapkan-nasi-bakar-ayam-bisa-manjain-lidah
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-13T15:30:34.271Z 
thumbnail: https://img-global.cpcdn.com/recipes/9ba323a91394f72d/682x484cq65/nasi-bakar-ayam-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/9ba323a91394f72d/682x484cq65/nasi-bakar-ayam-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/9ba323a91394f72d/682x484cq65/nasi-bakar-ayam-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/9ba323a91394f72d/682x484cq65/nasi-bakar-ayam-foto-resep-utama.webp
author: Eddie Adams
ratingvalue: 4.1
reviewcount: 14
recipeingredient:
- "Nasi Uduk "
- "beras cuci bersih 1 gelas"
- "air santan 400 ml"
- "sereh di geprek 2 tangkai"
- "bawang merah iris tipis 2 siung"
- "Garam sejumput"
- "Ayam Suwir "
- "dada ayam 1/2"
- "daun kemangi 3 ikat"
- "cabai merah keriting 4 buah"
- "cabai rawit merah 4 buah"
- "bawang merah 3 siung"
- "sereh iris tipis 1 tangkai"
- "minyak untuk menumis 3 sdm"
- "Bumbu Halus "
- "cabai merah keriting 8 buah"
- "cabai rawit merah 4 buah"
- "bawang merah 5 siung"
- "bawang putih 5 siung"
- "kemiri 2 biji"
- "kunyit 1 ruas jari"
- "air putih 150 ml"
- "gula pasir 1/2 sdt"
- "garam 1/2 sdt"
- "penyedap rasa 1/4 sdt"
- "Daun Pisang "
recipeinstructions:
- "Masukkan beras, air santan, sereh, bawang merah dan sejumput garam ke dalam magic com. Masak sampai matang"
- "Rebus dada ayam sampai empuk. Lalu suwir-suwir"
- "Panaskan minyak, tumis bawang merah, cabai merah keriting, cabai rawit merah, dan sereh, tumis sampai tercium harumnya"
- "Masukkan bumbu halus. Tumis sampai harum. Kemudian masukkan 150 ml air. Beri gula pasir, garam, penyedap rasa. Masak sampai mendidih"
- "Masukkan ayam suwir dan daun kemangi. Aduk rata. Masak sampai air asat"
- "Panaskan daun pisang di atas api kompor, bolak balik, sampai daun lentur"
- "Siapkan daun pisang (ukuran besar) dan daun pisang (ukuran kecil). Tata nasi uduk di atas daun pisang. Lalu tata ayam suwir di tengahnya. Lalu tutup kembali dengan nasi di atasnya"
- "Gulung nasi. Rapihkan. Beri tusuk gigi sebagai penjepit di ujung daun. Lalu dibakar/dipanggang sampai daun pisang berwarna kecoklatan. Angkat dan sajikan"
- "Nasi bakar ayam siap di nikmati"
categories:
- Resep
tags:
- nasi
- bakar
- ayam

katakunci: nasi bakar ayam 
nutrition: 194 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT53M"
recipeyield: "1"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Bakar Ayam](https://img-global.cpcdn.com/recipes/9ba323a91394f72d/682x484cq65/nasi-bakar-ayam-foto-resep-utama.webp)

9 langkah cepat dan mudah memasak  Nasi Bakar Ayam yang wajib bunda coba segera

<!--inarticleads1-->

## Bahan-bahan Yang Dibutuhkan Dalam Menyiapkan Nasi Bakar Ayam:

1. Nasi Uduk 
1. beras cuci bersih 1 gelas
1. air santan 400 ml
1. sereh di geprek 2 tangkai
1. bawang merah iris tipis 2 siung
1. Garam sejumput
1. Ayam Suwir 
1. dada ayam 1/2
1. daun kemangi 3 ikat
1. cabai merah keriting 4 buah
1. cabai rawit merah 4 buah
1. bawang merah 3 siung
1. sereh iris tipis 1 tangkai
1. minyak untuk menumis 3 sdm
1. Bumbu Halus 
1. cabai merah keriting 8 buah
1. cabai rawit merah 4 buah
1. bawang merah 5 siung
1. bawang putih 5 siung
1. kemiri 2 biji
1. kunyit 1 ruas jari
1. air putih 150 ml
1. gula pasir 1/2 sdt
1. garam 1/2 sdt
1. penyedap rasa 1/4 sdt
1. Daun Pisang 



<!--inarticleads2-->

## Cara Mudah Membuat Nasi Bakar Ayam:

1. Masukkan beras, air santan, sereh, bawang merah dan sejumput garam ke dalam magic com. Masak sampai matang
1. Rebus dada ayam sampai empuk. Lalu suwir-suwir
1. Panaskan minyak, tumis bawang merah, cabai merah keriting, cabai rawit merah, dan sereh, tumis sampai tercium harumnya
1. Masukkan bumbu halus. Tumis sampai harum. Kemudian masukkan 150 ml air. Beri gula pasir, garam, penyedap rasa. Masak sampai mendidih
1. Masukkan ayam suwir dan daun kemangi. Aduk rata. Masak sampai air asat
1. Panaskan daun pisang di atas api kompor, bolak balik, sampai daun lentur
1. Siapkan daun pisang (ukuran besar) dan daun pisang (ukuran kecil). Tata nasi uduk di atas daun pisang. Lalu tata ayam suwir di tengahnya. Lalu tutup kembali dengan nasi di atasnya
1. Gulung nasi. Rapihkan. Beri tusuk gigi sebagai penjepit di ujung daun. Lalu dibakar/dipanggang sampai daun pisang berwarna kecoklatan. Angkat dan sajikan
1. Nasi bakar ayam siap di nikmati




Salah satu masakan yang cukup praktis pembuatannya adalah  Nasi Bakar Ayam. Selain itu  Nasi Bakar Ayam  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu lakukan 9 langkah, dan  Nasi Bakar Ayam  pun siap di hidangkan. selamat mencoba !
