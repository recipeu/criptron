---
description: "Langkah Mudah untuk Membuat Nasi Uduk Betawi yang Menggugah Selera"
title: "Langkah Mudah untuk Membuat Nasi Uduk Betawi yang Menggugah Selera"
slug: 55-langkah-mudah-untuk-membuat-nasi-uduk-betawi-yang-menggugah-selera
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-20T07:48:26.223Z 
thumbnail: https://img-global.cpcdn.com/recipes/ec4c3312aabf5d4e/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/ec4c3312aabf5d4e/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/ec4c3312aabf5d4e/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/ec4c3312aabf5d4e/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
author: Lou Murray
ratingvalue: 5
reviewcount: 11
recipeingredient:
- "Bahan Utama "
- "Beras 3 Cup"
- "Santan Siap saji 1 1/2 Box"
- "Air 600-700 ml"
- "Bahan Bumbu "
- "Bawang Merah Parut 5 Siung"
- "Jahe geprek 2 Ruas"
- "Lengkuas Geprek 2 Ruas"
- "Kayu manis ukuran kecil 1 Batang"
- "daun pandan ikat 1 lembar"
- "daun salam 6 lembar"
- "Sereh ukuran besar geprek 2 Batang"
- "Garam 1 Sdt"
recipeinstructions:
- "Campur Santan kedalam air, dan panaskan dalam magic jar sembari masukan semua bumbu, aduk hingga rata dan mendidih."
- "Setelah itu, masukan 3 cup beras, aduk-aduk sebentar, tutup rice cooker."
- "Apabila ditengah-tengah rice cooker menunjukan tanda-tanda sudah matang padahal belum matang, aduk sebentar. Lalu nyalakan kembali rice cookernya untuk menanak nasi, dan tunggu hingga matang sempurna."
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 119 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT36M"
recipeyield: "3"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Betawi](https://img-global.cpcdn.com/recipes/ec4c3312aabf5d4e/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp)

Ingin membuat Nasi Uduk Betawi ? Coba resep berikut ini. Cara memasaknya sangat praktis namun jangan kaget jika hasilnya gurih dan lezat yang harus kamu coba segera

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Untuk Pembuatan Nasi Uduk Betawi:

1. Bahan Utama 
1. Beras 3 Cup
1. Santan Siap saji 1 1/2 Box
1. Air 600-700 ml
1. Bahan Bumbu 
1. Bawang Merah Parut 5 Siung
1. Jahe geprek 2 Ruas
1. Lengkuas Geprek 2 Ruas
1. Kayu manis ukuran kecil 1 Batang
1. daun pandan ikat 1 lembar
1. daun salam 6 lembar
1. Sereh ukuran besar geprek 2 Batang
1. Garam 1 Sdt



<!--inarticleads2-->

## Cara Membuat Nasi Uduk Betawi:

1. Campur Santan kedalam air, dan panaskan dalam magic jar sembari masukan semua bumbu, aduk hingga rata dan mendidih.
1. Setelah itu, masukan 3 cup beras, aduk-aduk sebentar, tutup rice cooker.
1. Apabila ditengah-tengah rice cooker menunjukan tanda-tanda sudah matang padahal belum matang, aduk sebentar. Lalu nyalakan kembali rice cookernya untuk menanak nasi, dan tunggu hingga matang sempurna.




Salah satu kuliner yang cukup praktis pembuatannya adalah  Nasi Uduk Betawi. Selain itu  Nasi Uduk Betawi  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu lakukan 3 langkah, dan  Nasi Uduk Betawi  pun siap di hidangkan. selamat mencoba !
