---
description: "Resep Nasi liwet ricecooker Anti Gagal"
title: "Resep Nasi liwet ricecooker Anti Gagal"
slug: 408-resep-nasi-liwet-ricecooker-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-05T17:01:43.514Z 
thumbnail: https://img-global.cpcdn.com/recipes/80dafe0354b22344/682x484cq65/nasi-liwet-ricecooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/80dafe0354b22344/682x484cq65/nasi-liwet-ricecooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/80dafe0354b22344/682x484cq65/nasi-liwet-ricecooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/80dafe0354b22344/682x484cq65/nasi-liwet-ricecooker-foto-resep-utama.webp
author: Hattie Turner
ratingvalue: 4.6
reviewcount: 7
recipeingredient:
- "beras 330 gr"
- "minyak 2 sdm"
- "teri kering goreng 20 gr"
- "Bumbu iris  "
- "bawang putih rajang  cincang 2 siung"
- "bawang merah 5 siung"
- "cabe merah besar 1 buah"
- "Bumbu cemplung  "
- "rawit utuh opsional 5 buah"
- "daun salam 2 lembar"
- "daun jeruk sobek2 4 lembar"
- "serai memarkan 1 batang"
- "daun pandan ikat simpul 1 lembar"
- "royco ayam 1/2 sdt"
- "garam 1 sd 15 sdt Secukupnya"
- "minyak untuk menumis bumbu 2 sdm"
- "Pelengkap  "
- "Ayam suwir mercon           lihat resep "
- "Sate puyuh bacem           lihat resep "
- "Sambal goreng kentang tahu           lihat resep "
- "Sambal petir pete           lihat resep "
- "Kerupuk "
recipeinstructions:
- "Cuci bersih beras."
- "Goreng teri hingga matang. Sisihkan."
- "Siapkan bumbu2, rajang &amp; geprek"
- "Tumis bumbu liwet dg 2 sdm minyak goreng hingga matang, lalu masukkan ke dalam beras yg sudah ditaruh dalam magic com. Beri teri goreng, garam, royco, &amp; 2 sdm minyak goreng. Tuang air seperti memasak nasi biasanya, aduk rata. Lalu nyalakan mode masak."
- "Tunggu nasi hingga matang, biarkan tanak dulu.  Setelah tanak, sisihkan daun salam, serai &amp; pandan, lalu aduk nasinya. Cicip rasanya. Jika dirasa kurang asin boleh ditambah garam / kaldu bubuk, lalu diaduk lagi."
- "Nasi liwet siap disajikan.  Gurih &amp; wanginya kemana mana, bikin nafsu makan meningkat 1000%😁"
categories:
- Resep
tags:
- nasi
- liwet
- ricecooker

katakunci: nasi liwet ricecooker 
nutrition: 263 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT51M"
recipeyield: "3"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi liwet ricecooker](https://img-global.cpcdn.com/recipes/80dafe0354b22344/682x484cq65/nasi-liwet-ricecooker-foto-resep-utama.webp)

Resep rahasia dan cara memasak  Nasi liwet ricecooker cocok banget jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Untuk Pembuatan Nasi liwet ricecooker:

1. beras 330 gr
1. minyak 2 sdm
1. teri kering goreng 20 gr
1. Bumbu iris  
1. bawang putih rajang  cincang 2 siung
1. bawang merah 5 siung
1. cabe merah besar 1 buah
1. Bumbu cemplung  
1. rawit utuh opsional 5 buah
1. daun salam 2 lembar
1. daun jeruk sobek2 4 lembar
1. serai memarkan 1 batang
1. daun pandan ikat simpul 1 lembar
1. royco ayam 1/2 sdt
1. garam 1 sd 15 sdt Secukupnya
1. minyak untuk menumis bumbu 2 sdm
1. Pelengkap  
1. Ayam suwir mercon           lihat resep 
1. Sate puyuh bacem           lihat resep 
1. Sambal goreng kentang tahu           lihat resep 
1. Sambal petir pete           lihat resep 
1. Kerupuk 

Nasi Liwet Sunda is one of my favorite rice dishes. There are many rice dishes in Indonesia that use coconut milk and spices and they This nasi liwet Sunda can be made on stove-top, rice cooker or instant pot. My favorite ways are rice cooker and instant pot. Nasi liwet identik dengan aroma yang wangi dan tekstur yang pulen. 

<!--inarticleads2-->

## Langkah-langkah Untuk Membuat Nasi liwet ricecooker:

1. Cuci bersih beras.
1. Goreng teri hingga matang. Sisihkan.
1. Siapkan bumbu2, rajang &amp; geprek
1. Tumis bumbu liwet dg 2 sdm minyak goreng hingga matang, lalu masukkan ke dalam beras yg sudah ditaruh dalam magic com. - Beri teri goreng, garam, royco, &amp; 2 sdm minyak goreng. - Tuang air seperti memasak nasi biasanya, aduk rata. - Lalu nyalakan mode masak.
1. Tunggu nasi hingga matang, biarkan tanak dulu.  - Setelah tanak, sisihkan daun salam, serai &amp; pandan, lalu aduk nasinya. - Cicip rasanya. Jika dirasa kurang asin boleh ditambah garam / kaldu bubuk, lalu diaduk lagi.
1. Nasi liwet siap disajikan.  - Gurih &amp; wanginya kemana mana, bikin nafsu makan meningkat 1000%😁


Jika menggunakan rice cooker berkerak, akan timbul bau gosong dari dasar nasi. Selain itu, nasi jadi tidak matang merata alias keras. Akhirnya, nasi liwet yang dihasilkan pun tidak sesuai harapan. Resep Nasi Liwet Sunda - Nasi liwet merupakan salah satu hidangan berupa nasi gurih yang khas dari Jawa Barat. Namun nasi liwet juga bisa dimasak dengan rice cooker / magic com untuk proses yang lebih mudah dan praktis. 

Terima kasih telah membaca resep yang tim kami tampilkan di sini. Semoga bermanfaat dan selamat mencoba!
