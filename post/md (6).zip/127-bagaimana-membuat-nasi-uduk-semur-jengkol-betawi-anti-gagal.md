---
description: "Bagaimana Membuat Nasi Uduk Semur Jengkol betawi Anti Gagal"
title: "Bagaimana Membuat Nasi Uduk Semur Jengkol betawi Anti Gagal"
slug: 127-bagaimana-membuat-nasi-uduk-semur-jengkol-betawi-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-29T02:14:06.204Z 
thumbnail: https://img-global.cpcdn.com/recipes/192ecef711aba1c8/682x484cq65/nasi-uduk-semur-jengkol-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/192ecef711aba1c8/682x484cq65/nasi-uduk-semur-jengkol-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/192ecef711aba1c8/682x484cq65/nasi-uduk-semur-jengkol-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/192ecef711aba1c8/682x484cq65/nasi-uduk-semur-jengkol-betawi-foto-resep-utama.webp
author: Hettie Wells
ratingvalue: 4
reviewcount: 13
recipeingredient:
- "Semur Jengkol "
- "jengkol tua 1/4 kg"
- "bawang putih 3 siung"
- "bawang merah 5 siung"
- "cabe keriting 5 bh"
- "tomat merah besar 1 buah"
- "pala 1 biji"
- "merica butir 1 sdt"
- "garam "
- "daun salam daun sereh geprek "
- "kecap bango "
- "Nasi uduk  "
- "beras "
- "santan kara "
- "jahe potong tipis2 saya suka agak banyak biar wangi 1 ruas"
- "garam "
- "daun salam daun sereh daun jeruk "
recipeinstructions:
- "# Nasi uduk : cuci beras, lgsg masukan santan, potongan jahe, daun salam, sereh, jeruk dan garam (klo ada yg mw nambahin royco boleh)jumlah air seperti masak nasi biasanya ya, nyalakan rice cooker hingga nasi matang"
- "#Semur jengkol : Rebus jengkol (klo saya pake daun salam utk menghilangkan bau)klo sdh agak empuk angkat, buang kulitnya,bagi 2 trus geprek, lalu tumis semua bumbu yg sdh dihaluskan hingga harum ya biar ga bau langu masukan juga daun salam dan sereh lalu masukan jengkol, aduk bentar lalu masukan air, kecap manis dan garam secukupnya, masak hingga air menyusut dan bumbu sdh menyerap kejengkol"
- "Hidangkan nasi uduk dgn tambahan bawang goreng, emping, sambel kacang..yummiii jengkolnya legit n bikin nagiiih😂"
categories:
- Resep
tags:
- nasi
- uduk
- semur

katakunci: nasi uduk semur 
nutrition: 234 calories
recipecuisine: Indonesian
preptime: "PT16M"
cooktime: "PT56M"
recipeyield: "2"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Semur Jengkol betawi](https://img-global.cpcdn.com/recipes/192ecef711aba1c8/682x484cq65/nasi-uduk-semur-jengkol-betawi-foto-resep-utama.webp)

3 langkah cepat memasak  Nasi Uduk Semur Jengkol betawi cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Dibutuhkan Dalam Menyiapkan Nasi Uduk Semur Jengkol betawi:

1. Semur Jengkol 
1. jengkol tua 1/4 kg
1. bawang putih 3 siung
1. bawang merah 5 siung
1. cabe keriting 5 bh
1. tomat merah besar 1 buah
1. pala 1 biji
1. merica butir 1 sdt
1. garam 
1. daun salam daun sereh geprek 
1. kecap bango 
1. Nasi uduk  
1. beras 
1. santan kara 
1. jahe potong tipis2 saya suka agak banyak biar wangi 1 ruas
1. garam 
1. daun salam daun sereh daun jeruk 



<!--inarticleads2-->

## Tata Cara Membuat Nasi Uduk Semur Jengkol betawi:

1. # Nasi uduk : cuci beras, lgsg masukan santan, potongan jahe, daun salam, sereh, jeruk dan garam (klo ada yg mw nambahin royco boleh)jumlah air seperti masak nasi biasanya ya, nyalakan rice cooker hingga nasi matang
1. #Semur jengkol : Rebus jengkol (klo saya pake daun salam utk menghilangkan bau)klo sdh agak empuk angkat, buang kulitnya,bagi 2 trus geprek, lalu tumis semua bumbu yg sdh dihaluskan hingga harum ya biar ga bau langu masukan juga daun salam dan sereh lalu masukan jengkol, aduk bentar lalu masukan air, kecap manis dan garam secukupnya, masak hingga air menyusut dan bumbu sdh menyerap kejengkol
1. Hidangkan nasi uduk dgn tambahan bawang goreng, emping, sambel kacang..yummiii jengkolnya legit n bikin nagiiih😂




Daripada   beli  Nasi Uduk Semur Jengkol betawi  diluar terus, kamu  bisa membuatnya sendiri dirumah. Resep  Nasi Uduk Semur Jengkol betawi  sederhana ini cukup praktis pembuatannya, cukup menggunakan bumbu-bumbu sederhana yang ada di dapur  Nasi Uduk Semur Jengkol betawi  yang enak, ibu nikmati di rumah.
