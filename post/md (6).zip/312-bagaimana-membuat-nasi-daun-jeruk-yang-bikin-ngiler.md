---
description: "Bagaimana Membuat Nasi Daun Jeruk yang Bikin Ngiler"
title: "Bagaimana Membuat Nasi Daun Jeruk yang Bikin Ngiler"
slug: 312-bagaimana-membuat-nasi-daun-jeruk-yang-bikin-ngiler
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-12T01:30:09.916Z 
thumbnail: https://img-global.cpcdn.com/recipes/66ae0ff5aad518fb/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/66ae0ff5aad518fb/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/66ae0ff5aad518fb/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/66ae0ff5aad518fb/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
author: Gilbert Alvarez
ratingvalue: 3.5
reviewcount: 12
recipeingredient:
- "beras 500 gr"
- "daun jeruk buang tulangnya itis tipis 20 lembar"
- "daun pandan cuci ikat simpul 3 lbr"
- "serai geprek 3 btg"
- "garam 1 sdm"
- "kaldu jamur 1/2 sdm"
- "fiber creme  air hingga 650 ml sesuaikan jenis beras 5 sdm"
- "Bahan tambahan "
- "Ayam geprek "
- "Lalapan "
recipeinstructions:
- "Campur semua bahan di panci magic com. Aduk rata."
- "Nyalakan magiccom dan masak hingga matang. Jangan lupa diaduk supaya bumbu merata."
- "Sajikan dengan lauk ayam geprek &amp; lalapan lebih sedappp 👍👍"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 244 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT31M"
recipeyield: "1"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk](https://img-global.cpcdn.com/recipes/66ae0ff5aad518fb/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp)

Resep rahasia dan cara mengolah  Nasi Daun Jeruk yang musti kamu coba dirumah

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Dalam Menyiapkan Nasi Daun Jeruk:

1. beras 500 gr
1. daun jeruk buang tulangnya itis tipis 20 lembar
1. daun pandan cuci ikat simpul 3 lbr
1. serai geprek 3 btg
1. garam 1 sdm
1. kaldu jamur 1/2 sdm
1. fiber creme  air hingga 650 ml sesuaikan jenis beras 5 sdm
1. Bahan tambahan 
1. Ayam geprek 
1. Lalapan 

Nasi daun jeruk siap dihidangkan dengan. Nasi daun jeruk ini memang sedang tren di kalangan masyarakat Indonesia, banyak sekali kaum muda mudi yang berlomba-lomba membuat makanan nasi putih spesial ini. Nasi daun jeruk ala geprek bensu rekomended buat di coba. Geprek bensu nasi daun jeruk anti mainst. 

<!--inarticleads2-->

## Cara Mudah Membuat Nasi Daun Jeruk:

1. Campur semua bahan di panci magic com. Aduk rata.
1. Nyalakan magiccom dan masak hingga matang. Jangan lupa diaduk supaya bumbu merata.
1. Sajikan dengan lauk ayam geprek &amp; lalapan lebih sedappp 👍👍


Gurih dan wangi dari daun jeruk menambah kelezatan nasi daun jeruk. Nasi dengan campuran daun jeruk yang wangi sedang tren. Hai selamat pagi sahabat CWS, pagi ini saya share resep Nasi Daun Jeruk. Praktis banget karena saya gunakan rice cooker. Rasanya mirip nasi uduk tapi wangiiii. 

Terima kasih telah membaca resep yang tim kami tampilkan di halaman ini. Selamat mencoba!
