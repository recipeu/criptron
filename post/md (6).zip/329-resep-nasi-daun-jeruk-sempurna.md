---
description: "Resep Nasi daun jeruk, Sempurna"
title: "Resep Nasi daun jeruk, Sempurna"
slug: 329-resep-nasi-daun-jeruk-sempurna
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-14T00:21:37.131Z 
thumbnail: https://img-global.cpcdn.com/recipes/248995eab97a2ef3/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/248995eab97a2ef3/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/248995eab97a2ef3/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/248995eab97a2ef3/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
author: Verna Moody
ratingvalue: 4
reviewcount: 14
recipeingredient:
- "bawang merah brebes 3 siung"
- "bawang putih 5 siung"
- "cabe caplak hijau boleh lebih 3"
- "cabe kriting hijau boleh lebih 3"
- "daun jeruk uk sedang 4-5 lembar"
- "Bahan lain  "
- "Minyak sayur "
- "Nasi "
- "Garam "
- "Gula "
- "Kaldu jamur "
recipeinstructions:
- "Haluskan bawang merah, bawang putih, cabe &amp; daun jeruk"
- "Kemudian tumis bumbu halus sampai matang, masukkan garam, gula &amp; kaldu jamur hingga rasanya sesuai"
- "Masukkan nasi, aduk sampai rata. Siap disajikan ✨"
- "Jika ingin mengurangi jumlah minyak, bumbu halus yg ditumis tadi dimasukkan ke dalam ricecooker yg sudah diisi beras, kemudian diaduk rata dan beras di masak. (Seperti membuat nasi liwet ricecooker). Selamat mencoba moms 🥰"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 229 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT47M"
recipeyield: "4"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi daun jeruk](https://img-global.cpcdn.com/recipes/248995eab97a2ef3/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp)

Resep dan cara memasak  Nasi daun jeruk cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Dalam Pembuatan Nasi daun jeruk:

1. bawang merah brebes 3 siung
1. bawang putih 5 siung
1. cabe caplak hijau boleh lebih 3
1. cabe kriting hijau boleh lebih 3
1. daun jeruk uk sedang 4-5 lembar
1. Bahan lain  
1. Minyak sayur 
1. Nasi 
1. Garam 
1. Gula 
1. Kaldu jamur 

Nasi daun jeruk siap dihidangkan dengan. Nasi daun jeruk ini memang sedang tren di kalangan masyarakat Indonesia, banyak sekali kaum muda mudi yang berlomba-lomba membuat makanan nasi putih spesial ini. Nasi daun jeruk ala geprek bensu rekomended buat di coba. Geprek bensu nasi daun jeruk anti mainst. 

<!--inarticleads2-->

## Langkah-langkah Untuk Membuat Nasi daun jeruk:

1. Haluskan bawang merah, bawang putih, cabe &amp; daun jeruk
1. Kemudian tumis bumbu halus sampai matang, masukkan garam, gula &amp; kaldu jamur hingga rasanya sesuai
1. Masukkan nasi, aduk sampai rata. Siap disajikan ✨
1. Jika ingin mengurangi jumlah minyak, bumbu halus yg ditumis tadi dimasukkan ke dalam ricecooker yg sudah diisi beras, kemudian diaduk rata dan beras di masak. (Seperti membuat nasi liwet ricecooker). Selamat mencoba moms 🥰


Gurih dan wangi dari daun jeruk menambah kelezatan nasi daun jeruk. Nasi dengan campuran daun jeruk yang wangi sedang tren. Hai selamat pagi sahabat CWS, pagi ini saya share resep Nasi Daun Jeruk. Praktis banget karena saya gunakan rice cooker. Rasanya mirip nasi uduk tapi wangiiii. 

Terima kasih telah membaca resep yang kami tampilkan di sini. Semoga bermanfaat dan selamat mencoba!
