---
description: "Resep Nasi Uduk (rice cooker) Anti Gagal"
title: "Resep Nasi Uduk (rice cooker) Anti Gagal"
slug: 173-resep-nasi-uduk-rice-cooker-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-26T23:42:48.884Z 
thumbnail: https://img-global.cpcdn.com/recipes/ea9cb015a9d6fec4/682x484cq65/nasi-uduk-rice-cooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/ea9cb015a9d6fec4/682x484cq65/nasi-uduk-rice-cooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/ea9cb015a9d6fec4/682x484cq65/nasi-uduk-rice-cooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/ea9cb015a9d6fec4/682x484cq65/nasi-uduk-rice-cooker-foto-resep-utama.webp
author: Fannie Cummings
ratingvalue: 3.3
reviewcount: 12
recipeingredient:
- "beras cuci satu kali 2 cup"
- "serai geprek 2-3 batang"
- "daun pandan ikat 2 lembar"
- "daun salam 2-3 lembar"
- "daun jeruk 2-3 lembar"
- "Lengkuas "
- "santan cair 400 ml"
- "santan kental 50-100 mL"
- "Garam "
recipeinstructions:
- "Masak santan cair, serai, daun pandan, daun salam, jeruk, lengkuas, garam. Api sedang, aduk, sampai mengeluarkan minyak. Dinginkan"
- "Masak santal kental sampai keluar minyak, sisihkan."
- "Setelah santan cair dingin, tuang ke dalam rice cooker yg sudah berisi beras. Aduk2."
- "Memasak dgn rice cooker: takaran air sesuai petunjuk dr ricecooker. Biasanya satu cup beras, ditambah dgn 1.5 cup santan."
- "Setelah matang, tambahkan santan kental, setelahnya tekan tombol masak. Masak lagi, sampai otomatis selesai"
categories:
- Resep
tags:
- nasi
- uduk
- rice

katakunci: nasi uduk rice 
nutrition: 227 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT42M"
recipeyield: "3"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk (rice cooker)](https://img-global.cpcdn.com/recipes/ea9cb015a9d6fec4/682x484cq65/nasi-uduk-rice-cooker-foto-resep-utama.webp)

Ingin membuat Nasi Uduk (rice cooker) ? Coba resep berikut ini. Cara memasaknya sangat praktis namun jangan kaget jika hasilnya gurih dan lezat yang bisa bunda coba segera

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Untuk Pembuatan Nasi Uduk (rice cooker):

1. beras cuci satu kali 2 cup
1. serai geprek 2-3 batang
1. daun pandan ikat 2 lembar
1. daun salam 2-3 lembar
1. daun jeruk 2-3 lembar
1. Lengkuas 
1. santan cair 400 ml
1. santan kental 50-100 mL
1. Garam 



<!--inarticleads2-->

## Langkah-langkah Untuk Menyiapkan Nasi Uduk (rice cooker):

1. Masak santan cair, serai, daun pandan, daun salam, jeruk, lengkuas, garam. Api sedang, aduk, sampai mengeluarkan minyak. Dinginkan
1. Masak santal kental sampai keluar minyak, sisihkan.
1. Setelah santan cair dingin, tuang ke dalam rice cooker yg sudah berisi beras. Aduk2.
1. Memasak dgn rice cooker: takaran air sesuai petunjuk dr ricecooker. Biasanya satu cup beras, ditambah dgn 1.5 cup santan.
1. Setelah matang, tambahkan santan kental, setelahnya tekan tombol masak. Masak lagi, sampai otomatis selesai




Salah satu masakan yang cukup praktis dalam pembuatannya adalah  Nasi Uduk (rice cooker). Selain itu  Nasi Uduk (rice cooker)  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu ikuti 5 langkah, dan  Nasi Uduk (rice cooker)  pun siap di hidangkan. selamat mencoba !
