---
description: "Resep [121] Nasi Daun Jeruk Rice Cooker, Lezat Sekali"
title: "Resep [121] Nasi Daun Jeruk Rice Cooker, Lezat Sekali"
slug: 249-resep-121-nasi-daun-jeruk-rice-cooker-lezat-sekali
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-11T07:51:42.495Z 
thumbnail: https://img-global.cpcdn.com/recipes/da16b83b6a978e55/682x484cq65/121-nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/da16b83b6a978e55/682x484cq65/121-nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/da16b83b6a978e55/682x484cq65/121-nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/da16b83b6a978e55/682x484cq65/121-nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp
author: Caroline Figueroa
ratingvalue: 3.6
reviewcount: 3
recipeingredient:
- "beras 4 cup"
- "Air secukupnya"
- "daun jeruk 5 lembar"
- "daun salam 2 lembar"
- "sereh 1 batang"
- "bawang merah 3 siung"
- "bawang putih 1 siung"
- "garam 1/2 sdt"
recipeinstructions:
- "Siapkan bahan, cuci bersih. Iris bawang merah dan bawang putih. Untuk daun jeruknya juga di iris kecil-kecil. Sereh di geprek."
- "Tumis sebentar hingga harum."
- "Cuci beras dan masukan tumisan tadi. Masak dengan rice cooker hingga matang."
- "Nasi daun jeruk siap disajikan dengan lauk, seperti ayam goreng, ikan goreng atau lainnya, sesuai selera."
categories:
- Resep
tags:
- 121
- nasi
- daun

katakunci: 121 nasi daun 
nutrition: 164 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT38M"
recipeyield: "1"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![[121] Nasi Daun Jeruk Rice Cooker](https://img-global.cpcdn.com/recipes/da16b83b6a978e55/682x484cq65/121-nasi-daun-jeruk-rice-cooker-foto-resep-utama.webp)

4 langkah mudah dan cepat mengolah  [121] Nasi Daun Jeruk Rice Cooker cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Dibutuhkan Untuk Pembuatan [121] Nasi Daun Jeruk Rice Cooker:

1. beras 4 cup
1. Air secukupnya
1. daun jeruk 5 lembar
1. daun salam 2 lembar
1. sereh 1 batang
1. bawang merah 3 siung
1. bawang putih 1 siung
1. garam 1/2 sdt



<!--inarticleads2-->

## Tata Cara Membuat [121] Nasi Daun Jeruk Rice Cooker:

1. Siapkan bahan, cuci bersih. Iris bawang merah dan bawang putih. Untuk daun jeruknya juga di iris kecil-kecil. Sereh di geprek.
1. Tumis sebentar hingga harum.
1. Cuci beras dan masukan tumisan tadi. Masak dengan rice cooker hingga matang.
1. Nasi daun jeruk siap disajikan dengan lauk, seperti ayam goreng, ikan goreng atau lainnya, sesuai selera.




Salah satu masakan yang cukup praktis dalam pembuatannya adalah  [121] Nasi Daun Jeruk Rice Cooker. Selain itu  [121] Nasi Daun Jeruk Rice Cooker  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu lakukan 4 langkah, dan  [121] Nasi Daun Jeruk Rice Cooker  pun siap di hidangkan. selamat mencoba !
