---
description: "Cara Gampang Membuat Bubur ayam kuah coklat khas semarang Anti Gagal"
title: "Cara Gampang Membuat Bubur ayam kuah coklat khas semarang Anti Gagal"
slug: 483-cara-gampang-membuat-bubur-ayam-kuah-coklat-khas-semarang-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-01T13:16:34.598Z 
thumbnail: https://img-global.cpcdn.com/recipes/85db1c02fd18a3d5/682x484cq65/bubur-ayam-kuah-coklat-khas-semarang-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/85db1c02fd18a3d5/682x484cq65/bubur-ayam-kuah-coklat-khas-semarang-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/85db1c02fd18a3d5/682x484cq65/bubur-ayam-kuah-coklat-khas-semarang-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/85db1c02fd18a3d5/682x484cq65/bubur-ayam-kuah-coklat-khas-semarang-foto-resep-utama.webp
author: Isabelle Schmidt
ratingvalue: 3.2
reviewcount: 15
recipeingredient:
- "bahan bubur "
- "centong nasi 4"
- "air secukupnya"
- "royco secukupnya"
- "garam secukupnya"
- "lada secukupnya"
- "bahan ayam dan telur "
- "telur direbus 1/2 kg"
- "ayam 1 kg"
- "laos 3 ruas"
- "daun salam 4"
- "sereh geprek 2"
- "jahe 2 ruas"
- "kunyit 1 ruas"
- "daun jeruk 5 lembar"
- "daun bawang potong2 1"
- "bawang merah 6"
- "bawang putih 4"
- "royco ayam secukupnya"
- "garam secukupnya"
- "gula jawa secukupnya"
- "kecap secukupnya"
- "bahan tambahan "
- "cakue saya beli 5rb dpt banyak secukupnya"
- "kedelai goreng "
- "daun bawang di potong tipis2 "
- "kerupuk "
- "bawang goreng "
recipeinstructions:
- "Htc bubur : ambil nasi (saya pakai nasi baru jd masih lembek. masukan ke panci. tambahkan air (sekitar 2 gelas air) sampai nasi terendam. masukan royco, garam, lada. masak hingga menjadi bubur."
- "Htc kuah ayam : rebus ayam stgh matang. buang rebusan pertama (utk menghilangkan kotoran2nya). kemudian bumbui dengan royco, garam,lada). tambahkan air. rebus lagi"
- "Masukan laos,daun salam,kunyit,sereh,daun jeruk,jahe, bawang merah, bawang putih. (bisa dioseng atau dimasukan ke air rebusan ayam lgsg) kemudian masukan kecap, gula jawa. masukan rebusan telur juga. tunggu hingga mendidih dan empuk. jangan lupa koreksi rasa"
- "Bubur ayam kuah coklat khas semarang bisa dinikmati"
categories:
- Resep
tags:
- bubur
- ayam
- kuah

katakunci: bubur ayam kuah 
nutrition: 283 calories
recipecuisine: Indonesian
preptime: "PT19M"
cooktime: "PT54M"
recipeyield: "1"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Bubur ayam kuah coklat khas semarang](https://img-global.cpcdn.com/recipes/85db1c02fd18a3d5/682x484cq65/bubur-ayam-kuah-coklat-khas-semarang-foto-resep-utama.webp)

4 langkah mudah dan cepat mengolah  Bubur ayam kuah coklat khas semarang cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Untuk Pembuatan Bubur ayam kuah coklat khas semarang:

1. bahan bubur 
1. centong nasi 4
1. air secukupnya
1. royco secukupnya
1. garam secukupnya
1. lada secukupnya
1. bahan ayam dan telur 
1. telur direbus 1/2 kg
1. ayam 1 kg
1. laos 3 ruas
1. daun salam 4
1. sereh geprek 2
1. jahe 2 ruas
1. kunyit 1 ruas
1. daun jeruk 5 lembar
1. daun bawang potong2 1
1. bawang merah 6
1. bawang putih 4
1. royco ayam secukupnya
1. garam secukupnya
1. gula jawa secukupnya
1. kecap secukupnya
1. bahan tambahan 
1. cakue saya beli 5rb dpt banyak secukupnya
1. kedelai goreng 
1. daun bawang di potong tipis2 
1. kerupuk 
1. bawang goreng 

Rebus ayam dan air diberi daun salam, masak hingga mendidih dan keluarkan ayam (kemudian ayam Saat kalian mencoba bubur ayam Cianjur, kalian akan merasakan sensasi rasa yang sedikit berbeda. Ya, itu semua karena kuah bubur yang satu ini. Coba resep bubur ayam sederhana kuah kuning yang rasa kaldunya gurih mantap. Catatan: apabila menggunakan nasi untuk membuat bubur, proses memasak pada langkah pertama akan lebih cepat. 

<!--inarticleads2-->

## Tata Cara Menyiapkan Bubur ayam kuah coklat khas semarang:

1. Htc bubur : ambil nasi (saya pakai nasi baru jd masih lembek. masukan ke panci. tambahkan air (sekitar 2 gelas air) sampai nasi terendam. masukan royco, garam, lada. masak hingga menjadi bubur.
1. Htc kuah ayam : rebus ayam stgh matang. buang rebusan pertama (utk menghilangkan kotoran2nya). kemudian bumbui dengan royco, garam,lada). tambahkan air. rebus lagi
1. Masukan laos,daun salam,kunyit,sereh,daun jeruk,jahe, bawang merah, bawang putih. (bisa dioseng atau dimasukan ke air rebusan ayam lgsg) kemudian masukan kecap, gula jawa. masukan rebusan telur juga. tunggu hingga mendidih dan empuk. jangan lupa koreksi rasa
1. Bubur ayam kuah coklat khas semarang bisa dinikmati


Bubur ayam (Indonesian for &#34;chicken congee&#34;) is a Chinese Indonesian chicken congee. It is rice congee with shredded chicken meat served with some condiments, such as chopped scallion, crispy fried shallot, celery, tongcay (preserved salted vegetables), fried soybean, Chinese crullers. Bubur ayam dari jakarta identik dengan kuah kuning dan aroma yang menggoda selera. Tidak heran banyak orang berbondong-bondong mengantri Seperti halnya bubur ayam khas Bandung yang dapat ditemukan diseluruh penjuru nusantara. Kini tidak perlu repot lagi membelinya karena dapat. 

Terima kasih telah membaca resep yang kami tampilkan di halaman ini. Semoga bermanfaat dan selamat mencoba!
