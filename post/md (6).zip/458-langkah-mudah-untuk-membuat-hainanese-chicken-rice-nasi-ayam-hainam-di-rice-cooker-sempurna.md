---
description: "Langkah Mudah untuk Membuat Hainanese Chicken Rice (nasi ayam Hainam) di rice cooker, Sempurna"
title: "Langkah Mudah untuk Membuat Hainanese Chicken Rice (nasi ayam Hainam) di rice cooker, Sempurna"
slug: 458-langkah-mudah-untuk-membuat-hainanese-chicken-rice-nasi-ayam-hainam-di-rice-cooker-sempurna
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-14T17:25:30.420Z 
thumbnail: https://img-global.cpcdn.com/recipes/d4cb4ebd0a4ea8d7/682x484cq65/hainanese-chicken-rice-nasi-ayam-hainam-di-rice-cooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/d4cb4ebd0a4ea8d7/682x484cq65/hainanese-chicken-rice-nasi-ayam-hainam-di-rice-cooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/d4cb4ebd0a4ea8d7/682x484cq65/hainanese-chicken-rice-nasi-ayam-hainam-di-rice-cooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/d4cb4ebd0a4ea8d7/682x484cq65/hainanese-chicken-rice-nasi-ayam-hainam-di-rice-cooker-foto-resep-utama.webp
author: Zachary Colon
ratingvalue: 4.7
reviewcount: 11
recipeingredient:
- "Kuah kaldu ayam "
- "dada ayam bisa ganti paha 1 1/2 ekor"
- "jahe 2 ruas"
- "daun bawang 2 batang"
- "bawang putih utuh dengan kulit 2 siung"
- "kaldu ayam 1 sdm"
- "garam 1 sdt"
- "Kuah nasi Hainam di rice cooker "
- "beras 500 gr (2 cup)"
- "air kuah kaldu ayam 550-600 ml"
- "jahe diparut 2 ruas"
- "bawang putih cincang halus 5-7 siung"
- "minyak wijen 1 sdm"
- "saos tiram 1 sdm"
- "kecap asin 1 sdm"
- "garam 2 sdt"
- "gula pasir 1/2 sdm"
- "merica 1/2 sdt"
- "Scallion Oil "
- "daun bawang cincang 5 batang"
- "jahe parut 1 ruas"
- "bawang putih cincang 2 siung"
- "minyak wijen 1 sdm"
- "saos tiram 1 sdm"
- "garam 1/2 sdt"
- "gula 1 sdt"
- "merica 1/2 sdt"
- "Siraman diatas ayam "
- "saos tiram 2 sdm"
- "daun bawang 1 batang"
- "air 50 ml"
- "gula 1 sdm"
- "kecap asin 2 sdm"
- "Sambal nasi Hainam "
- "cabe merah keriting 8"
- "cabe rawit merah 8"
- "bawang putih 6 siung"
- "garam 1 sdt"
- "air 80-100 ml"
- "cuka 2 sdt"
recipeinstructions:
- "Rebus ayam dan semua bahan kuah kaldu ayam dengan api kecil, cek daging apakah sudah matang. Jangan overcooked, spy dagingnya tetap lembut dan juicy. Angkat segera dan potong2 daging ayam susun diatas piring."
- "Tumis bawang putih cincang dan jahe parut. Jangan terlalu kering"
- "Beras yang sudah dicuci bersih, rendam dulu kurleb 30 menit, masukin beras bersih kedalam rice cooker, masukkan kuah kaldu ayam, tumisan bawang putih+jahe, dan semua bahan kuah nasi Hainam di rice cooker. Aduk rata.   Masak nasi seperti biasa"
- "Campur semua bahan Scallion Oil dalam mangkok"
- "Panaskan minyak, siram minyak panas ke bahan scallion oil. Aduk rata. Scallion oil ini nanti disiram di susunan ayam yg sudah matang dan dipotong"
- "Campur semua bahan siraman dan masak sampai matang. setelah matang siram diatas potongan ayam."
- "Jadi ada 3 siraman di atas potongan ayam yg sudah matang ya.. Tumisan bawang putih+jahe saya sisakan sedikit, scallion oil, dan siraman saos tiram."
- "Blender bahan sambal dan masak bahan sambal sampai matang, ayam dicocol dgn sambal ini."
categories:
- Resep
tags:
- hainanese
- chicken
- rice

katakunci: hainanese chicken rice 
nutrition: 293 calories
recipecuisine: Indonesian
preptime: "PT29M"
cooktime: "PT54M"
recipeyield: "1"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Hainanese Chicken Rice (nasi ayam Hainam) di rice cooker](https://img-global.cpcdn.com/recipes/d4cb4ebd0a4ea8d7/682x484cq65/hainanese-chicken-rice-nasi-ayam-hainam-di-rice-cooker-foto-resep-utama.webp)

Resep Hainanese Chicken Rice (nasi ayam Hainam) di rice cooker  enak dengan 8 langkahcepat dan mudah yang wajib bunda coba segera

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Untuk Menyiapkan Hainanese Chicken Rice (nasi ayam Hainam) di rice cooker:

1. Kuah kaldu ayam 
1. dada ayam bisa ganti paha 1 1/2 ekor
1. jahe 2 ruas
1. daun bawang 2 batang
1. bawang putih utuh dengan kulit 2 siung
1. kaldu ayam 1 sdm
1. garam 1 sdt
1. Kuah nasi Hainam di rice cooker 
1. beras 500 gr (2 cup)
1. air kuah kaldu ayam 550-600 ml
1. jahe diparut 2 ruas
1. bawang putih cincang halus 5-7 siung
1. minyak wijen 1 sdm
1. saos tiram 1 sdm
1. kecap asin 1 sdm
1. garam 2 sdt
1. gula pasir 1/2 sdm
1. merica 1/2 sdt
1. Scallion Oil 
1. daun bawang cincang 5 batang
1. jahe parut 1 ruas
1. bawang putih cincang 2 siung
1. minyak wijen 1 sdm
1. saos tiram 1 sdm
1. garam 1/2 sdt
1. gula 1 sdt
1. merica 1/2 sdt
1. Siraman diatas ayam 
1. saos tiram 2 sdm
1. daun bawang 1 batang
1. air 50 ml
1. gula 1 sdm
1. kecap asin 2 sdm
1. Sambal nasi Hainam 
1. cabe merah keriting 8
1. cabe rawit merah 8
1. bawang putih 6 siung
1. garam 1 sdt
1. air 80-100 ml
1. cuka 2 sdt



<!--inarticleads2-->

## Cara Membuat Hainanese Chicken Rice (nasi ayam Hainam) di rice cooker:

1. Rebus ayam dan semua bahan kuah kaldu ayam dengan api kecil, cek daging apakah sudah matang. Jangan overcooked, spy dagingnya tetap lembut dan juicy. Angkat segera dan potong2 daging ayam susun diatas piring.
1. Tumis bawang putih cincang dan jahe parut. Jangan terlalu kering
1. Beras yang sudah dicuci bersih, rendam dulu kurleb 30 menit, masukin beras bersih kedalam rice cooker, masukkan kuah kaldu ayam, tumisan bawang putih+jahe, dan semua bahan kuah nasi Hainam di rice cooker. Aduk rata.  -  - Masak nasi seperti biasa
1. Campur semua bahan Scallion Oil dalam mangkok
1. Panaskan minyak, siram minyak panas ke bahan scallion oil. Aduk rata. Scallion oil ini nanti disiram di susunan ayam yg sudah matang dan dipotong
1. Campur semua bahan siraman dan masak sampai matang. setelah matang siram diatas potongan ayam.
1. Jadi ada 3 siraman di atas potongan ayam yg sudah matang ya.. Tumisan bawang putih+jahe saya sisakan sedikit, scallion oil, dan siraman saos tiram.
1. Blender bahan sambal dan masak bahan sambal sampai matang, ayam dicocol dgn sambal ini.




Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
