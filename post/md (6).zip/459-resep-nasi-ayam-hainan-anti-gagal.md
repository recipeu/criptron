---
description: "Resep Nasi Ayam Hainan Anti Gagal"
title: "Resep Nasi Ayam Hainan Anti Gagal"
slug: 459-resep-nasi-ayam-hainan-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-11T22:16:04.049Z 
thumbnail: https://img-global.cpcdn.com/recipes/2973217f8662ce3e/682x484cq65/nasi-ayam-hainan-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/2973217f8662ce3e/682x484cq65/nasi-ayam-hainan-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/2973217f8662ce3e/682x484cq65/nasi-ayam-hainan-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/2973217f8662ce3e/682x484cq65/nasi-ayam-hainan-foto-resep-utama.webp
author: Brent Johnson
ratingvalue: 3.4
reviewcount: 3
recipeingredient:
- "ayam kampung potong bersihkansisihkan 1 ekor"
- "beras 4 cup"
- "bawang putih Chopper 15 siung"
- "saus tiram 1 sachet"
- "Minyak wijen secukupnya"
- "Merica bubuk secukupnya"
- "Garam dan kaldu bubuk secukupnya"
- "Minyak goreng secukupnya"
recipeinstructions:
- "Tambahkan minyak goreng dengan minyak wijen secukupnya"
- "Tumis bawang putih hingga kekuningan"
- "Ambil 2 sendok sayur bawang putih (untuk taburan) sisihkan"
- "Masukkan ayam aduh hingga berubah warna"
- "Tambahkan saus tiram merica bubuk garam dan kaldu bubuk secukupnya"
- "Tambahkan air secukupnya"
- "Koreksi air"
- "Masak hingga setengah empuk"
- "Angkat ayam,sisakan air rebusan"
- "Masukkan beras kedalam bekas air rebusan"
- "Masak hingga air menyusut sambil aduk terus"
- "Matikan kompor"
- "Taruh beras kedalam kukusan bersama ayam"
- "Kukus hingga ayam dan nasi matang"
- "Taburi dengan minyak bawang putih"
- "Siap disajikan"
categories:
- Resep
tags:
- nasi
- ayam
- hainan

katakunci: nasi ayam hainan 
nutrition: 217 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT59M"
recipeyield: "4"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Ayam Hainan](https://img-global.cpcdn.com/recipes/2973217f8662ce3e/682x484cq65/nasi-ayam-hainan-foto-resep-utama.webp)

16 langkah cepat dan mudah membuat  Nasi Ayam Hainan cocok sekali jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Bahan-bahan Yang Dibutuhkan Dalam Pembuatan Nasi Ayam Hainan:

1. ayam kampung potong bersihkansisihkan 1 ekor
1. beras 4 cup
1. bawang putih Chopper 15 siung
1. saus tiram 1 sachet
1. Minyak wijen secukupnya
1. Merica bubuk secukupnya
1. Garam dan kaldu bubuk secukupnya
1. Minyak goreng secukupnya



<!--inarticleads2-->

## Cara Mudah Menyiapkan Nasi Ayam Hainan:

1. Tambahkan minyak goreng dengan minyak wijen secukupnya
1. Tumis bawang putih hingga kekuningan
1. Ambil 2 sendok sayur bawang putih (untuk taburan) sisihkan
1. Masukkan ayam aduh hingga berubah warna
1. Tambahkan saus tiram merica bubuk garam dan kaldu bubuk secukupnya
1. Tambahkan air secukupnya
1. Koreksi air
1. Masak hingga setengah empuk
1. Angkat ayam,sisakan air rebusan
1. Masukkan beras kedalam bekas air rebusan
1. Masak hingga air menyusut sambil aduk terus
1. Matikan kompor
1. Taruh beras kedalam kukusan bersama ayam
1. Kukus hingga ayam dan nasi matang
1. Taburi dengan minyak bawang putih
1. Siap disajikan




Daripada   beli  Nasi Ayam Hainan  diluar terus, kamu  bisa membuatnya sendiri dirumah. Resep  Nasi Ayam Hainan  sederhana ini cukup praktis dalam proses pembuatannya, serta cukup menggunakan bumbu sederhana  Nasi Ayam Hainan  yang enak, bunda nikmati di rumah.
