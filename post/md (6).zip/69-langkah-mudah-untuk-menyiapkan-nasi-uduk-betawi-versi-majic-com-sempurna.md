---
description: "Langkah Mudah untuk Menyiapkan Nasi uduk betawi versi majic com, Sempurna"
title: "Langkah Mudah untuk Menyiapkan Nasi uduk betawi versi majic com, Sempurna"
slug: 69-langkah-mudah-untuk-menyiapkan-nasi-uduk-betawi-versi-majic-com-sempurna
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-07T18:20:16.940Z 
thumbnail: https://img-global.cpcdn.com/recipes/af4400f4ebca1af8/682x484cq65/nasi-uduk-betawi-versi-majic-com-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/af4400f4ebca1af8/682x484cq65/nasi-uduk-betawi-versi-majic-com-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/af4400f4ebca1af8/682x484cq65/nasi-uduk-betawi-versi-majic-com-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/af4400f4ebca1af8/682x484cq65/nasi-uduk-betawi-versi-majic-com-foto-resep-utama.webp
author: Jim Thornton
ratingvalue: 3.8
reviewcount: 9
recipeingredient:
- "beras 250 gram"
- "santan sedang saya pake 65 ml santan  195 ml air 260"
- "daun salam 2 lembar"
- "sereh 1 batang"
- "jahe 1 cm"
- "lengkoas 1 cm"
- "bumbu masak bubuk masako 1 sdt"
- "garam 1/2 sdt"
- "daun jeruk 2 lembar"
recipeinstructions:
- "Masukkan santan pada wadah dan masukkan salam, sereh, jahe, dan lengkoas, masak sampai mendidih"
- "Setelah mendidih, matikan api lalu masukkan beras, garam, lada dan masako. Saya tambahkan daun jeruk, aduk sebentar, lalu masak pada majigcom. Ketika hampir matang, buka tutup majigcom dan aduk2. Kemudian lanjutkan memasaknya"
- "Nasi uduk betawi majic com sudah matang.sajikan dengan bawang goreng dan irisan telur dadar"
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 178 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT47M"
recipeyield: "2"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi uduk betawi versi majic com](https://img-global.cpcdn.com/recipes/af4400f4ebca1af8/682x484cq65/nasi-uduk-betawi-versi-majic-com-foto-resep-utama.webp)

Resep dan cara memasak  Nasi uduk betawi versi majic com cocok sekali jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Dalam Pembuatan Nasi uduk betawi versi majic com:

1. beras 250 gram
1. santan sedang saya pake 65 ml santan  195 ml air 260
1. daun salam 2 lembar
1. sereh 1 batang
1. jahe 1 cm
1. lengkoas 1 cm
1. bumbu masak bubuk masako 1 sdt
1. garam 1/2 sdt
1. daun jeruk 2 lembar

Anda akan berfoto di depan Monas. Membuat panas yang melihat foto narsis anda sudah Rasanya sedikit berbeda. Bagi saya nasi uduk Betawi tiada duanya. Bahkan ada loh nasi uduk tiga ribuan! 

<!--inarticleads2-->

## Cara Menyiapkan Nasi uduk betawi versi majic com:

1. Masukkan santan pada wadah dan masukkan salam, sereh, jahe, dan lengkoas, masak sampai mendidih
1. Setelah mendidih, matikan api lalu masukkan beras, garam, lada dan masako. Saya tambahkan daun jeruk, aduk sebentar, lalu masak pada majigcom. Ketika hampir matang, buka tutup majigcom dan aduk2. Kemudian lanjutkan memasaknya
1. Nasi uduk betawi majic com sudah matang.sajikan dengan bawang goreng dan irisan telur dadar


KOMPAS.com - Nasi uduk umumnya berwarna putih, dari warna asli beras dan santan kelapa. Namun, nasi uduk juga bisa dibuat dengan tampilan berbeda, misalnya jadi berwarna hijau. Umumnya pada masakan tradisional menggunakan daun suji sebagai pewarna hijau. Memang banyak nasi uduk dimana mana, nasi uduk ini juga nggak terlalu spesial, tapi yang jelas nggak mahal. makanan khas betawi ini makin lengkap kalau ada jengkolnya. Untuk membuat nasi uduk sebetulnya nggak repot, bagi yang uda sering masak pasti bisa buatnya. 

Terima kasih telah membaca resep yang kami tampilkan di sini. Semoga bermanfaat dan selamat mencoba!
