---
description: "Resep Nasi Bakar ikan tuna jamur tiram pedas yang Lezat"
title: "Resep Nasi Bakar ikan tuna jamur tiram pedas yang Lezat"
slug: 360-resep-nasi-bakar-ikan-tuna-jamur-tiram-pedas-yang-lezat
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-20T09:41:31.527Z 
thumbnail: https://img-global.cpcdn.com/recipes/c103ff7bdb53af37/682x484cq65/nasi-bakar-ikan-tuna-jamur-tiram-pedas-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/c103ff7bdb53af37/682x484cq65/nasi-bakar-ikan-tuna-jamur-tiram-pedas-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/c103ff7bdb53af37/682x484cq65/nasi-bakar-ikan-tuna-jamur-tiram-pedas-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/c103ff7bdb53af37/682x484cq65/nasi-bakar-ikan-tuna-jamur-tiram-pedas-foto-resep-utama.webp
author: Chris Christensen
ratingvalue: 4.8
reviewcount: 7
recipeingredient:
- "beras 1 liter"
- "santan kental 200 ml"
- "air secukupnya"
- "garam 1 sdm"
- "penyedap rasa saya pake royco 2 sachet"
- "sereh 1 batang"
- "daun salam 2 lbr"
- "daun jeruk 3 lbr"
- "kapulaga 4 butir"
- "jinten 1 sdt"
- "cengkeh 10 butir"
- "Bahan isi "
- "daun kemangi 1 ikat sedang"
- "ikan tuna filet 250 gram"
- "jamur tiram 250 grm"
- "bawang putih 2 siung"
- "bawang merah 4 siung"
- "cabe merah   ya bun sesuai selera"
- "garam secukupnya"
- "gula pasir secukupnya"
- "penyedap rasa sedikit"
- "minyak sayur untuk menumis secukupnya"
- "Bahan untuk pembungkus "
- "daun pisang "
- "tusuk gigi "
recipeinstructions:
- "Masak beras campur semua bahan seperti masak nasi biasa...bisa menggunakan langseng atau macig com..kalau pake macig com jangan lupa ya bu kalau udah asapnya ngebul jangan lupa di aduk kalau gak di aduk nanti gak mateng."
- "Selagi nunggu nasi matang...kita buat isian.."
- "Haluskan cabe.bawang merah.bawang putih."
- "Tumis bumbu yg sudah di haluskan sampai harum..masukan ikan tuna yg sudah di potong dadu.. tunggu hingga setengah matang kemudian masukan jamur tiram yg sudah di suwir2...gak usah di kasih air ya bun karna jamur akan me geluarkan air.."
- "Tambah garam.gula dan penyedap rasa...test rasa jika kurang mantap tambah lagi bumbunya...setelah matang angkat sisihkan"
- "Siapkan daun kemangi yg sudah di preteli dari batangnya.dan daun pisang untuk pembungkusnya"
- "Setelah nasi matang siap di bungkus di isi dengan daun kemangi kemudian diberi tumisan ikan dan jamur.bungkus seperti bungkus lontong ya bun"
- "Biasanya bun beras 1 liter bisa jadi 10 - 12 bungkus ya bun"
- "Setelah terbungkus semua bakar di atas kompor dengan pembakar ikan atau bisa juga di bakar dgn areng..kalau terpaksanya gak punya areng pake teflon juga gpp bun."
- "Jadi deh nasi bakar ikan tuna jamur tiram.sajiakan bisa di tambah dgn lalapan dan sambal terasi lebih mantap"
categories:
- Resep
tags:
- nasi
- bakar
- ikan

katakunci: nasi bakar ikan 
nutrition: 212 calories
recipecuisine: Indonesian
preptime: "PT36M"
cooktime: "PT38M"
recipeyield: "3"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Bakar ikan tuna jamur tiram pedas](https://img-global.cpcdn.com/recipes/c103ff7bdb53af37/682x484cq65/nasi-bakar-ikan-tuna-jamur-tiram-pedas-foto-resep-utama.webp)

Resep rahasia Nasi Bakar ikan tuna jamur tiram pedas  enak dengan 10 langkahcepat dan mudah cocok sekali jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Beberapa Bahan Yang Digunakan Dalam Menyiapkan Nasi Bakar ikan tuna jamur tiram pedas:

1. beras 1 liter
1. santan kental 200 ml
1. air secukupnya
1. garam 1 sdm
1. penyedap rasa saya pake royco 2 sachet
1. sereh 1 batang
1. daun salam 2 lbr
1. daun jeruk 3 lbr
1. kapulaga 4 butir
1. jinten 1 sdt
1. cengkeh 10 butir
1. Bahan isi 
1. daun kemangi 1 ikat sedang
1. ikan tuna filet 250 gram
1. jamur tiram 250 grm
1. bawang putih 2 siung
1. bawang merah 4 siung
1. cabe merah   ya bun sesuai selera
1. garam secukupnya
1. gula pasir secukupnya
1. penyedap rasa sedikit
1. minyak sayur untuk menumis secukupnya
1. Bahan untuk pembungkus 
1. daun pisang 
1. tusuk gigi 



<!--inarticleads2-->

## Cara Mudah Menyiapkan Nasi Bakar ikan tuna jamur tiram pedas:

1. Masak beras campur semua bahan seperti masak nasi biasa...bisa menggunakan langseng atau macig com..kalau pake macig com jangan lupa ya bu kalau udah asapnya ngebul jangan lupa di aduk kalau gak di aduk nanti gak mateng.
1. Selagi nunggu nasi matang...kita buat isian..
1. Haluskan cabe.bawang merah.bawang putih.
1. Tumis bumbu yg sudah di haluskan sampai harum..masukan ikan tuna yg sudah di potong dadu.. tunggu hingga setengah matang kemudian masukan jamur tiram yg sudah di suwir2...gak usah di kasih air ya bun karna jamur akan me geluarkan air..
1. Tambah garam.gula dan penyedap rasa...test rasa jika kurang mantap tambah lagi bumbunya...setelah matang angkat sisihkan
1. Siapkan daun kemangi yg sudah di preteli dari batangnya.dan daun pisang untuk pembungkusnya
1. Setelah nasi matang siap di bungkus di isi dengan daun kemangi kemudian diberi tumisan ikan dan jamur.bungkus seperti bungkus lontong ya bun
1. Biasanya bun beras 1 liter bisa jadi 10 - 12 bungkus ya bun
1. Setelah terbungkus semua bakar di atas kompor dengan pembakar ikan atau bisa juga di bakar dgn areng..kalau terpaksanya gak punya areng pake teflon juga gpp bun.
1. Jadi deh nasi bakar ikan tuna jamur tiram.sajiakan bisa di tambah dgn lalapan dan sambal terasi lebih mantap




Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
