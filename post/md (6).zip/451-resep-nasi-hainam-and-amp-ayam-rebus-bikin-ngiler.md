---
description: "Resep Nasi Hainam &amp;amp; Ayam rebus, Bikin Ngiler"
title: "Resep Nasi Hainam &amp;amp; Ayam rebus, Bikin Ngiler"
slug: 451-resep-nasi-hainam-and-amp-ayam-rebus-bikin-ngiler
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-22T01:03:28.733Z 
thumbnail: https://img-global.cpcdn.com/recipes/426b4aaa7f9c25c5/682x484cq65/nasi-hainam-ayam-rebus-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/426b4aaa7f9c25c5/682x484cq65/nasi-hainam-ayam-rebus-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/426b4aaa7f9c25c5/682x484cq65/nasi-hainam-ayam-rebus-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/426b4aaa7f9c25c5/682x484cq65/nasi-hainam-ayam-rebus-foto-resep-utama.webp
author: Kyle Austin
ratingvalue: 4.5
reviewcount: 12
recipeingredient:
- "Bahan Ayam Rebus "
- "ayam kampung  broiler 1/2 ekor"
- "air 3/4 panci"
- "bawang putih di geprek isi halus 2 siung"
- "daun bawang iris kasar 5 cm"
- "jahe di geprek 4 cm"
- "daun bawang bagian putihnya diiris kotak kecilkecil 5 cm"
- "gula pasir 1 sdm"
- "Garam  lada secukupnya"
- "Saos siraman ayam "
- "bawang putih diiris kotak kecilkecil 5 siung"
- "jahe diiris kotak kecilkecil 2 ruas"
- "margarin utk menumis 1 sdm"
- "minyak wijen 1 sdm"
- "kecap asin 2 sdm"
- "saus tiram 1 sdm"
- "Garam secukupnya"
- "Nasi Hainam "
- "rice cooker beras dicuci 2x 2 mug"
- "bawang putih di geprek iris halus 2 siung"
- "jahe diiris kotak kecilkecil 1 ruas"
- "margarine 1 sdm"
- "minyak wijen 1 sdm"
- "air kaldu ambil dari rebusan ayam 500 ml"
- "Kuah nasi Hainam "
- "air kaldu ayam 500 ml"
- "sayur pokcoy dipotong 5 cm 3 btg"
- "Garam lada secukupnya"
- "Sambal Ayam Hainam "
- "cabe merah di blender 2 sdm"
- "bawang putih 1 siung"
- "jahe 1 ruas"
- "cuka putih 1 sdm"
- "air kaldu  air biasa 2 sdm"
- "gula pasir 1 sdm"
- "margarin utk menumis 1 sdm"
- "Garam secukupnya"
recipeinstructions:
- "Pertama, rebus ayam.  Cuci bersih ayam, gosok kulitnya dengan garam, bilas lagi, rebus ayam di panci dengan air 3/4 panci, masukkan bawang putih, daun bawang, jahe, lada, gula, garam slama 45 mnt sampai ayam empuk. Tiriskan. Potong ayam 2 cm pindahkan ke wadah."
- "Panaskan margarin, tumis bawang putih &amp; jahe sampai agak kering &amp; wangi (sebagian ada yg coklat) matikan api, sambil diaduk-aduk di wajan supaya bawang ga gosong, tuang yang rata ke atas ayam, di wadah lain siapkan kecap asin, saos tiram, minyak wijen aduk sampai rata, tuang rata diatas ayam. Ayam rebus siap disajikan"
- "Kedua, bikin nasi hainam. Masukkan 1 sdm margarin tumis bawang putih &amp; jahe sampai wangi, masukkan beras yang sudah dicuci, aduk-aduk, masukkan air kaldu, aduk-aduk tunggu sampai beras nya bengkak (berwarna putih susu) sampai airnya agak mengering, matikan api, panaskan air di kukusan, kukus beras yang 1/2 matang tadi sampai matang.  Nasi hainam siap disajikan"
- "Ketiga, bikin kuah Masak air kaldu (ambil dari rebusan ayam) masukkan batang sayur pokcoy ke dalam air yang belum mendidih karna bagian ini keras lama matangnya, masukkan garam &amp; lada, klo sudah mendidih masukkan sayur pokcoy, aduk- aduk sampai sayur smuanya layu, matikan api. Kuah siapkan dihidangkan"
- "Keempat, bikin sambel ayam hainam. Masukkan margarin, tumis bawang putih &amp; jahe sampai wangi, masukkan cabe, cuka, air, gula, garam aduk-aduk sampai mendidih &amp; air mulai berkurang, matikan api. Sambal siap disajikan."
categories:
- Resep
tags:
- nasi
- hainam
- 

katakunci: nasi hainam  
nutrition: 128 calories
recipecuisine: Indonesian
preptime: "PT26M"
cooktime: "PT51M"
recipeyield: "1"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Hainam &amp; Ayam rebus](https://img-global.cpcdn.com/recipes/426b4aaa7f9c25c5/682x484cq65/nasi-hainam-ayam-rebus-foto-resep-utama.webp)

Resep dan cara mengolah  Nasi Hainam &amp; Ayam rebus yang musti bunda coba segera

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Dalam Pembuatan Nasi Hainam &amp; Ayam rebus:

1. Bahan Ayam Rebus 
1. ayam kampung  broiler 1/2 ekor
1. air 3/4 panci
1. bawang putih di geprek isi halus 2 siung
1. daun bawang iris kasar 5 cm
1. jahe di geprek 4 cm
1. daun bawang bagian putihnya diiris kotak kecilkecil 5 cm
1. gula pasir 1 sdm
1. Garam  lada secukupnya
1. Saos siraman ayam 
1. bawang putih diiris kotak kecilkecil 5 siung
1. jahe diiris kotak kecilkecil 2 ruas
1. margarin utk menumis 1 sdm
1. minyak wijen 1 sdm
1. kecap asin 2 sdm
1. saus tiram 1 sdm
1. Garam secukupnya
1. Nasi Hainam 
1. rice cooker beras dicuci 2x 2 mug
1. bawang putih di geprek iris halus 2 siung
1. jahe diiris kotak kecilkecil 1 ruas
1. margarine 1 sdm
1. minyak wijen 1 sdm
1. air kaldu ambil dari rebusan ayam 500 ml
1. Kuah nasi Hainam 
1. air kaldu ayam 500 ml
1. sayur pokcoy dipotong 5 cm 3 btg
1. Garam lada secukupnya
1. Sambal Ayam Hainam 
1. cabe merah di blender 2 sdm
1. bawang putih 1 siung
1. jahe 1 ruas
1. cuka putih 1 sdm
1. air kaldu  air biasa 2 sdm
1. gula pasir 1 sdm
1. margarin utk menumis 1 sdm
1. Garam secukupnya



<!--inarticleads2-->

## Langkah-langkah Untuk Membuat Nasi Hainam &amp; Ayam rebus:

1. Pertama, rebus ayam. -  Cuci bersih ayam, gosok kulitnya dengan garam, bilas lagi, rebus ayam di panci dengan air 3/4 panci, masukkan bawang putih, daun bawang, jahe, lada, gula, garam slama 45 mnt sampai ayam empuk. Tiriskan. Potong ayam 2 cm pindahkan ke wadah.
1. Panaskan margarin, tumis bawang putih &amp; jahe sampai agak kering &amp; wangi (sebagian ada yg coklat) matikan api, sambil diaduk-aduk di wajan supaya bawang ga gosong, tuang yang rata ke atas ayam, di wadah lain siapkan kecap asin, saos tiram, minyak wijen aduk sampai rata, tuang rata diatas ayam. - Ayam rebus siap disajikan
1. Kedua, bikin nasi hainam. - Masukkan 1 sdm margarin tumis bawang putih &amp; jahe sampai wangi, masukkan beras yang sudah dicuci, aduk-aduk, masukkan air kaldu, aduk-aduk tunggu sampai beras nya bengkak (berwarna putih susu) sampai airnya agak mengering, matikan api, panaskan air di kukusan, kukus beras yang 1/2 matang tadi sampai matang.  - Nasi hainam siap disajikan
1. Ketiga, bikin kuah - Masak air kaldu (ambil dari rebusan ayam) masukkan batang sayur pokcoy ke dalam air yang belum mendidih karna bagian ini keras lama matangnya, masukkan garam &amp; lada, klo sudah mendidih masukkan sayur pokcoy, aduk- aduk sampai sayur smuanya layu, matikan api. Kuah siapkan dihidangkan
1. Keempat, bikin sambel ayam hainam. Masukkan margarin, tumis bawang putih &amp; jahe sampai wangi, masukkan cabe, cuka, air, gula, garam aduk-aduk sampai mendidih &amp; air mulai berkurang, matikan api. Sambal siap disajikan.




Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
