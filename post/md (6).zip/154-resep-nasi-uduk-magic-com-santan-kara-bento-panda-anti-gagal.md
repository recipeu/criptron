---
description: "Resep Nasi uduk Magic com santan kara (bento panda) Anti Gagal"
title: "Resep Nasi uduk Magic com santan kara (bento panda) Anti Gagal"
slug: 154-resep-nasi-uduk-magic-com-santan-kara-bento-panda-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-19T09:16:26.773Z 
thumbnail: https://img-global.cpcdn.com/recipes/e24842442e9d7697/682x484cq65/nasi-uduk-magic-com-santan-kara-bento-panda-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/e24842442e9d7697/682x484cq65/nasi-uduk-magic-com-santan-kara-bento-panda-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/e24842442e9d7697/682x484cq65/nasi-uduk-magic-com-santan-kara-bento-panda-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/e24842442e9d7697/682x484cq65/nasi-uduk-magic-com-santan-kara-bento-panda-foto-resep-utama.webp
author: Mildred Love
ratingvalue: 3.4
reviewcount: 15
recipeingredient:
- "beras 1 liter"
- "santan instan kara 65 ml 1"
- "beras Air 3 kaleng"
- "garam  1 sdm Kaldu ayam bubuk 3 sdt"
- "Daun Jeruk sobek pinggir nya 3"
- "Daun salam sobek pinggir nya 3"
- "serai geprek 2 Batang"
- "bawang merah geprek 2"
- "bawang putih geprek 2"
- "lengkuas geprek 3 cm"
recipeinstructions:
- "Cuci beras, masukkan semua bumbu, beras, santan,air aduk rata)"
- "Masukkan kedalam rice cooker masak sampai matang."
- "Jika udah turun setelan rice cooker nya diamkan 5 menit, keluar kan nasi nya mulai deh di cetay hangat&#34; agar saat di cetak nasi tidak buyar.."
categories:
- Resep
tags:
- nasi
- uduk
- magic

katakunci: nasi uduk magic 
nutrition: 206 calories
recipecuisine: Indonesian
preptime: "PT29M"
cooktime: "PT56M"
recipeyield: "2"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi uduk Magic com santan kara (bento panda)](https://img-global.cpcdn.com/recipes/e24842442e9d7697/682x484cq65/nasi-uduk-magic-com-santan-kara-bento-panda-foto-resep-utama.webp)

Resep rahasia dan cara mengolah  Nasi uduk Magic com santan kara (bento panda) cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Dibutuhkan Untuk Pembuatan Nasi uduk Magic com santan kara (bento panda):

1. beras 1 liter
1. santan instan kara 65 ml 1
1. beras Air 3 kaleng
1. garam  1 sdm Kaldu ayam bubuk 3 sdt
1. Daun Jeruk sobek pinggir nya 3
1. Daun salam sobek pinggir nya 3
1. serai geprek 2 Batang
1. bawang merah geprek 2
1. bawang putih geprek 2
1. lengkuas geprek 3 cm

Untuk takaran bumbu-bumbu sudah lengkap dan enak banget gurih rasanya. The site owner hides the web page description. Resep Nasi Uduk Betawi - Nasi uduk sudah menjadi kuliner khas yang eksistensinya seperti tak pernah memudar. Cara Membuat Resep Nasi Uduk Betawi Bumbu Komplit Bisa Dikukus Atau Menggunakan Rice Cooker atau Magic Com. 

<!--inarticleads2-->

## Langkah-langkah Untuk Membuat Nasi uduk Magic com santan kara (bento panda):

1. Cuci beras, masukkan semua bumbu, beras, santan,air aduk rata)
1. Masukkan kedalam rice cooker masak sampai matang.
1. Jika udah turun setelan rice cooker nya diamkan 5 menit, keluar kan nasi nya mulai deh di cetay hangat&#34; agar saat di cetak nasi tidak buyar..


Pagi ini saya sarapan nasi uduk. Rasanya tak kalah dengan nasi uduk kebun kacang Jakarta. Saya tidak tahu siapa yang memberi nama nasi uduk. Setiap daerah punya menunya masing-masing dan ada yang diaduk. Tuang santan panas ke dalam panci rice cooker berisi beras yg sudah dicuci,direndam dan di tiriskan,aduk rata. 

Terima kasih telah menggunakan resep yang tim kami tampilkan di sini. Semoga bermanfaat dan selamat mencoba!
