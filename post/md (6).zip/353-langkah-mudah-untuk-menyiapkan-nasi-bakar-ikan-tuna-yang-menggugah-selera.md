---
description: "Langkah Mudah untuk Menyiapkan Nasi Bakar (Ikan Tuna) yang Menggugah Selera"
title: "Langkah Mudah untuk Menyiapkan Nasi Bakar (Ikan Tuna) yang Menggugah Selera"
slug: 353-langkah-mudah-untuk-menyiapkan-nasi-bakar-ikan-tuna-yang-menggugah-selera
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-10T17:33:11.710Z 
thumbnail: https://img-global.cpcdn.com/recipes/9b1c8bd51d41b38b/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/9b1c8bd51d41b38b/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/9b1c8bd51d41b38b/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/9b1c8bd51d41b38b/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp
author: Marvin Marshall
ratingvalue: 4
reviewcount: 8
recipeingredient:
- "Nasi putih secukupnya"
- "Daun pisang secukupnya"
- "Sambal Tuna pete "
- "Ikan tuna 1 kaleng"
- "Pete kupas 3 Papan"
- "bawang putih 2 siung"
- "bawang merah 5 siung"
- "Cabe kriting secukupnya"
- "Cabe rawit merah secukupnya"
- "Sereh secukupnya"
- "Lengkuas secukupnya"
- "Daun salam 2 lembar"
- "Kaldu bubuk secukupnya"
- "Garam secukupnya"
- "Gula pasir secukupnya"
- "kecap manis 1 SDT"
recipeinstructions:
- "Haluskan (cabe, kunyit, bawang merah putih) lalu tumis dengan minyak goreng tambah lengkuas, Daun salam &amp; sereh masak sampai harum, beri sedikit air, masukin ikan tunanya, garam, kaldu bubuk, gula, &amp; kecap manis, tunggu sampai airnya asat biar hasilnya nyemek2 aja. Jangan terlalu kering."
- "Tata nasi, lauk di atas daun pisang bungkus lalu bakar di atas teflon. (Tips sebelum nya jemur dulu daun pisangnya biar agak layu jadi pas di bungkus si daun gak mudah robek)"
categories:
- Resep
tags:
- nasi
- bakar
- ikan

katakunci: nasi bakar ikan 
nutrition: 228 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT51M"
recipeyield: "4"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Bakar (Ikan Tuna)](https://img-global.cpcdn.com/recipes/9b1c8bd51d41b38b/682x484cq65/nasi-bakar-ikan-tuna-foto-resep-utama.webp)

Resep rahasia dan cara mengolah  Nasi Bakar (Ikan Tuna) yang wajib kamu coba dirumah

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Untuk Menyiapkan Nasi Bakar (Ikan Tuna):

1. Nasi putih secukupnya
1. Daun pisang secukupnya
1. Sambal Tuna pete 
1. Ikan tuna 1 kaleng
1. Pete kupas 3 Papan
1. bawang putih 2 siung
1. bawang merah 5 siung
1. Cabe kriting secukupnya
1. Cabe rawit merah secukupnya
1. Sereh secukupnya
1. Lengkuas secukupnya
1. Daun salam 2 lembar
1. Kaldu bubuk secukupnya
1. Garam secukupnya
1. Gula pasir secukupnya
1. kecap manis 1 SDT



<!--inarticleads2-->

## Langkah-langkah Untuk Menyiapkan Nasi Bakar (Ikan Tuna):

1. Haluskan (cabe, kunyit, bawang merah putih) lalu tumis dengan minyak goreng tambah lengkuas, Daun salam &amp; sereh masak sampai harum, beri sedikit air, masukin ikan tunanya, garam, kaldu bubuk, gula, &amp; kecap manis, tunggu sampai airnya asat biar hasilnya nyemek2 aja. Jangan terlalu kering.
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/0e274a819ec0792c/160x128cq70/nasi-bakar-ikan-tuna-langkah-memasak-1-foto.webp" alt="Nasi Bakar (Ikan Tuna)" width="340" height="340">
><img class="lazyload" data-src="https://img-global.cpcdn.com/steps/7f48c5d3349a8b1b/160x128cq70/nasi-bakar-ikan-tuna-langkah-memasak-1-foto.webp" alt="Nasi Bakar (Ikan Tuna)" width="340" height="340">
>1. Tata nasi, lauk di atas daun pisang bungkus lalu bakar di atas teflon. (Tips sebelum nya jemur dulu daun pisangnya biar agak layu jadi pas di bungkus si daun gak mudah robek)




Selamat memasak dan menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
