---
description: "Resep Nasi Uduk Betawi, Enak"
title: "Resep Nasi Uduk Betawi, Enak"
slug: 45-resep-nasi-uduk-betawi-enak
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-12T10:53:36.303Z 
thumbnail: https://img-global.cpcdn.com/recipes/2e4bae1c78e01324/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/2e4bae1c78e01324/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/2e4bae1c78e01324/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/2e4bae1c78e01324/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
author: Charles Dixon
ratingvalue: 3.9
reviewcount: 9
recipeingredient:
- "beras cuci bersih 1 1/2 Cup"
- "bawang merah rajang 6 siung"
- "sereh geprek 1 batang"
- "daun salam 2 Lembar"
- "daun pandan 1 Lembar"
- "cengkeh 3 butir"
- "kayu manis 1/2 bagian"
- "Lengkuas geprek 3 cm"
- "Garam secukup nya "
- "Merica bubuk secukupnya"
- "santan 250 ml"
recipeinstructions:
- "Cuci bersih beras, panaskan wajan dg 1 sdm minyak Tumis semua bumbu kecuali daun pandan. Masak sampai layu dan harum (bawang merah sampai kecoklatan ya bund)"
- "Tambahkan Santan, garam, merica. Aduk2 sampai sedikit mendidih (Santan harum) matikan kompor. Masukkan Tumisan bumbu dan Santan ke dlm beras, tambahkan daun pandan. Masak spt masak nasi biasa. Setelah matang taburi dg bawang goreng"
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 144 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT47M"
recipeyield: "3"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Betawi](https://img-global.cpcdn.com/recipes/2e4bae1c78e01324/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp)

Resep Nasi Uduk Betawi    dengan 2 langkahmudah dan cepat yang bisa bunda coba segera

<!--inarticleads1-->

## Bahan-bahan Yang Dibutuhkan Dalam Menyiapkan Nasi Uduk Betawi:

1. beras cuci bersih 1 1/2 Cup
1. bawang merah rajang 6 siung
1. sereh geprek 1 batang
1. daun salam 2 Lembar
1. daun pandan 1 Lembar
1. cengkeh 3 butir
1. kayu manis 1/2 bagian
1. Lengkuas geprek 3 cm
1. Garam secukup nya 
1. Merica bubuk secukupnya
1. santan 250 ml



<!--inarticleads2-->

## Cara Mudah Membuat Nasi Uduk Betawi:

1. Cuci bersih beras, panaskan wajan dg 1 sdm minyak Tumis semua bumbu kecuali daun pandan. Masak sampai layu dan harum (bawang merah sampai kecoklatan ya bund)
1. Tambahkan Santan, garam, merica. Aduk2 sampai sedikit mendidih (Santan harum) matikan kompor. Masukkan Tumisan bumbu dan Santan ke dlm beras, tambahkan daun pandan. Masak spt masak nasi biasa. Setelah matang taburi dg bawang goreng




Salah satu kuliner yang cukup praktis dalam pembuatannya adalah  Nasi Uduk Betawi. Selain itu  Nasi Uduk Betawi  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu lakukan 2 langkah, dan  Nasi Uduk Betawi  pun siap di hidangkan. selamat mencoba !
