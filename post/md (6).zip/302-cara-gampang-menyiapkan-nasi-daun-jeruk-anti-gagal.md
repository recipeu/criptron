---
description: "Cara Gampang Menyiapkan Nasi Daun Jeruk Anti Gagal"
title: "Cara Gampang Menyiapkan Nasi Daun Jeruk Anti Gagal"
slug: 302-cara-gampang-menyiapkan-nasi-daun-jeruk-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-10-31T00:53:02.619Z 
thumbnail: https://img-global.cpcdn.com/recipes/065f8525f6757054/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/065f8525f6757054/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/065f8525f6757054/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/065f8525f6757054/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
author: Aiden Hudson
ratingvalue: 4.3
reviewcount: 15
recipeingredient:
- "beras putih 300 gram"
- "daun jeruk purut kalau dipotong jd 8 lembar 4 tangkai"
- "santan instan 65 ml"
- "air putih 250"
- "minyak goreng 1 SDM"
- "bawang merah 4 siung"
- "serai 1 batang"
- "garam 1 SDM"
recipeinstructions:
- "Cuci bersih semua bahan"
- "Iris tipis bawang merah, daun jeruk dan sereh"
- "Cuci bersih beras, rendam 15 menit. Cuci kembali dan tiriskan"
- "Siapkan 1 SDM minyak, panaskan. Kemudian tambahkan irisan bawang dan serei tumis sampai harum. kemudian tambahkan daun jeruk, tumis kembali sampai harum. Matikan api"
- "Tambahkan semua bumbu tumisan ke dalam beras, kemudian tambahkan garam dan beri air"
- "Tambahkan santan, aduk2 rata sampai garam larut"
- "Masak beras di magic com sampai matang."
- "Setelah matang jgn langsung dibuka biarkan 5 menit sampai uap hilang dan buka. Aduk2 tes rasa"
- "Sajikan dengan pendamping lainnya. Selamat menikmati"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 220 calories
recipecuisine: Indonesian
preptime: "PT29M"
cooktime: "PT55M"
recipeyield: "1"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk](https://img-global.cpcdn.com/recipes/065f8525f6757054/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp)

Ingin membuat Nasi Daun Jeruk ? Coba resep berikut ini. Cara memasaknya sangat praktis namun hasilnya gurih dan lezat yang musti bunda coba segera

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Dalam Menyiapkan Nasi Daun Jeruk:

1. beras putih 300 gram
1. daun jeruk purut kalau dipotong jd 8 lembar 4 tangkai
1. santan instan 65 ml
1. air putih 250
1. minyak goreng 1 SDM
1. bawang merah 4 siung
1. serai 1 batang
1. garam 1 SDM



<!--inarticleads2-->

## Langkah-langkah Untuk Membuat Nasi Daun Jeruk:

1. Cuci bersih semua bahan
1. Iris tipis bawang merah, daun jeruk dan sereh
1. Cuci bersih beras, rendam 15 menit. Cuci kembali dan tiriskan
1. Siapkan 1 SDM minyak, panaskan. Kemudian tambahkan irisan bawang dan serei tumis sampai harum. kemudian tambahkan daun jeruk, tumis kembali sampai harum. Matikan api
1. Tambahkan semua bumbu tumisan ke dalam beras, kemudian tambahkan garam dan beri air
1. Tambahkan santan, aduk2 rata sampai garam larut
1. Masak beras di magic com sampai matang.
1. Setelah matang jgn langsung dibuka biarkan 5 menit sampai uap hilang dan buka. Aduk2 tes rasa
1. Sajikan dengan pendamping lainnya. Selamat menikmati




Demikian informasi  resep Nasi Daun Jeruk   yang bisa Anda coba di rumah. Semoga informasi ini bisa bermanfaat bagi Anda. Terima kasih telah berkujung ke web kami
