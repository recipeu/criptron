---
description: "Resep Nasi daun jeruk ricecooker Anti Gagal"
title: "Resep Nasi daun jeruk ricecooker Anti Gagal"
slug: 276-resep-nasi-daun-jeruk-ricecooker-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-18T23:48:12.847Z 
thumbnail: https://img-global.cpcdn.com/recipes/942840adbdaeb56e/682x484cq65/nasi-daun-jeruk-ricecooker-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/942840adbdaeb56e/682x484cq65/nasi-daun-jeruk-ricecooker-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/942840adbdaeb56e/682x484cq65/nasi-daun-jeruk-ricecooker-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/942840adbdaeb56e/682x484cq65/nasi-daun-jeruk-ricecooker-foto-resep-utama.webp
author: Clara Gilbert
ratingvalue: 3.4
reviewcount: 6
recipeingredient:
- "beras300gr 2 cup"
- "santan kara kecil 1 bungkus"
- "Air 2 cup"
- "daun jeruk iris tipis 10 lembar"
- "Bumbu "
- "jahe 3 iris"
- "lengkuang 2 iris"
- "garam Sejumput"
- "bubuk kaldu 1 sdt"
- "serai 1 batang"
- "daun salam 2 lembar"
- "daun jeruk 3 lembar"
recipeinstructions:
- "Cuci bersih bumbu"
- "Masukkan semua bahan kecuali daun jeruk yg di iris masak hingga matang"
- "Setelah matang masukkan irisan daun jeruk"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 109 calories
recipecuisine: Indonesian
preptime: "PT11M"
cooktime: "PT41M"
recipeyield: "4"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi daun jeruk ricecooker](https://img-global.cpcdn.com/recipes/942840adbdaeb56e/682x484cq65/nasi-daun-jeruk-ricecooker-foto-resep-utama.webp)

Ingin membuat Nasi daun jeruk ricecooker ? Coba resep berikut ini. Cara memasaknya sangat praktis namun jangan kaget jika hasilnya gurih dan lezat yang wajib kamu coba dirumah

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Dalam Menyiapkan Nasi daun jeruk ricecooker:

1. beras300gr 2 cup
1. santan kara kecil 1 bungkus
1. Air 2 cup
1. daun jeruk iris tipis 10 lembar
1. Bumbu 
1. jahe 3 iris
1. lengkuang 2 iris
1. garam Sejumput
1. bubuk kaldu 1 sdt
1. serai 1 batang
1. daun salam 2 lembar
1. daun jeruk 3 lembar

Praktis banget karena saya gunakan rice cooker. Rasanya mirip nasi uduk tapi wangiiii. Yukkk mari dipantengin dan dipraktekin yah. Berikut nih tips dari saya supaya. 

<!--inarticleads2-->

## Cara Mudah Menyiapkan Nasi daun jeruk ricecooker:

1. Cuci bersih bumbu
1. Masukkan semua bahan kecuali daun jeruk yg di iris masak hingga matang
1. Setelah matang masukkan irisan daun jeruk


Gurih dan wangi dari daun jeruk menambah kelezatan nasi daun jeruk. Aroma daun jeruk yang menguar harum pasti mengundang selera siapa pun yang menghirupnya. Saat dicicipi, cita rasa teri dan santan yang gurih membuatnya makin menggoda. Yang paling penting, Cookiners bisa membuatnya dengan praktis menggunakan rice cooker andalan. Dash Mini Rice Cooker Steamer With Removable Nonstick Pot 

Terima kasih telah membaca resep yang tim kami tampilkan di halaman ini. Semoga bermanfaat dan selamat mencoba!
