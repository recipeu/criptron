---
description: "Bagaimana Menyiapkan Nasi Ayam Semarang yang Enak Banget"
title: "Bagaimana Menyiapkan Nasi Ayam Semarang yang Enak Banget"
slug: 468-bagaimana-menyiapkan-nasi-ayam-semarang-yang-enak-banget
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-05T05:38:36.796Z 
thumbnail: https://img-global.cpcdn.com/recipes/f9a0c22bd2ee65ce/682x484cq65/nasi-ayam-semarang-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/f9a0c22bd2ee65ce/682x484cq65/nasi-ayam-semarang-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/f9a0c22bd2ee65ce/682x484cq65/nasi-ayam-semarang-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/f9a0c22bd2ee65ce/682x484cq65/nasi-ayam-semarang-foto-resep-utama.webp
author: Carrie McBride
ratingvalue: 4.3
reviewcount: 11
recipeingredient:
- "Nasi gurih  "
- "Beras 3 cup"
- "Santan encer 4 cup"
- "serai 1 btg"
- "daun salam 2 lbr"
- "Garam secukup rasa "
- "Opor ayam suwir  tahu  "
- "ayam pejantankampung 1 ekor"
- "santan dr 1 butir kelapa 1,5 ltr"
- "tahu putih potong2 goreng 2 buah"
- "Bumbu cemplung  "
- "laos 1 ruas jari"
- "serai 1 btg"
- "daun salam 2 lbr"
- "Bumbu halus  "
- "bawang merah 5 siung"
- "bawang putih 3 siung"
- "kemiri 3 butir"
- "jahe 1/2 ruas jari"
- "ketumbar 1 sdt"
- "lada bubuk 1/2 sdt"
- "Garam dan gula secukup rasa "
- "Pelengkap lain  "
- "Sambal goreng labu dan kerecek  lihat di resep sy berikut "
- "Telur pindang  lihat di resep sy berikut "
- "Sambal "
recipeinstructions:
- "Membuat nasi gurih : masak beras spt biasa, tambahkan serai, salam dan garam. (Sy masak di rice cooker)"
- "Membuat opor : tumis bumbu halus dan bumbu cemplung dlm 2 sdm minyak goreng hingga bumbu matang, tuangkan santan. Aduk2, jgn sampai santan pecah. Masukan ayam, masak hingga ayam matang. Seblm diangkat, masukan tahu goreng. Penyajian : pisahkan ayam dan tahu dr kuah, suwir2 ayam. Siramkan dgn kuah."
categories:
- Resep
tags:
- nasi
- ayam
- semarang

katakunci: nasi ayam semarang 
nutrition: 175 calories
recipecuisine: Indonesian
preptime: "PT19M"
cooktime: "PT30M"
recipeyield: "2"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Ayam Semarang](https://img-global.cpcdn.com/recipes/f9a0c22bd2ee65ce/682x484cq65/nasi-ayam-semarang-foto-resep-utama.webp)

Resep rahasia dan cara memasak  Nasi Ayam Semarang yang musti kamu coba segera

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Dalam Menyiapkan Nasi Ayam Semarang:

1. Nasi gurih  
1. Beras 3 cup
1. Santan encer 4 cup
1. serai 1 btg
1. daun salam 2 lbr
1. Garam secukup rasa 
1. Opor ayam suwir  tahu  
1. ayam pejantankampung 1 ekor
1. santan dr 1 butir kelapa 1,5 ltr
1. tahu putih potong2 goreng 2 buah
1. Bumbu cemplung  
1. laos 1 ruas jari
1. serai 1 btg
1. daun salam 2 lbr
1. Bumbu halus  
1. bawang merah 5 siung
1. bawang putih 3 siung
1. kemiri 3 butir
1. jahe 1/2 ruas jari
1. ketumbar 1 sdt
1. lada bubuk 1/2 sdt
1. Garam dan gula secukup rasa 
1. Pelengkap lain  
1. Sambal goreng labu dan kerecek  lihat di resep sy berikut 
1. Telur pindang  lihat di resep sy berikut 
1. Sambal 



<!--inarticleads2-->

## Cara Menyiapkan Nasi Ayam Semarang:

1. Membuat nasi gurih : masak beras spt biasa, tambahkan serai, salam dan garam. (Sy masak di rice cooker)
1. Membuat opor : tumis bumbu halus dan bumbu cemplung dlm 2 sdm minyak goreng hingga bumbu matang, tuangkan santan. Aduk2, jgn sampai santan pecah. Masukan ayam, masak hingga ayam matang. Seblm diangkat, masukan tahu goreng. Penyajian : pisahkan ayam dan tahu dr kuah, suwir2 ayam. Siramkan dgn kuah.




Daripada   beli  Nasi Ayam Semarang  diluar terus, ibu  bisa membuatnya sendiri dirumah. Resep  Nasi Ayam Semarang  sederhana ini cukup praktis dalam proses pembuatannya, cukup menggunakan bumbu-bumbu sederhana yang ada di dapur  Nasi Ayam Semarang  yang enak, ibu nikmati di rumah.
