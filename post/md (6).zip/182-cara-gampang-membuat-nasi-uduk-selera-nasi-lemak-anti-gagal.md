---
description: "Cara Gampang Membuat Nasi uduk selera / nasi lemak Anti Gagal"
title: "Cara Gampang Membuat Nasi uduk selera / nasi lemak Anti Gagal"
slug: 182-cara-gampang-membuat-nasi-uduk-selera-nasi-lemak-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-07T09:18:51.442Z 
thumbnail: https://img-global.cpcdn.com/recipes/375ea34cc2b0badf/682x484cq65/nasi-uduk-selera-nasi-lemak-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/375ea34cc2b0badf/682x484cq65/nasi-uduk-selera-nasi-lemak-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/375ea34cc2b0badf/682x484cq65/nasi-uduk-selera-nasi-lemak-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/375ea34cc2b0badf/682x484cq65/nasi-uduk-selera-nasi-lemak-foto-resep-utama.webp
author: Lura Brown
ratingvalue: 5
reviewcount: 6
recipeingredient:
- "Tahu goreng "
- "Petai goreng "
- "Telur dadar iris"
- "Kerupuk ikan "
- "Bahan nasi "
- "Beras 2 cup"
- "Bawang merah goreng saya buat sendiri "
- "Santan kara 200 ml"
- "Sereh 1 btg"
- "garam 1/2 sdt"
- "Air sesuaikan takaran "
- "Bahan sambal terasi "
- "bawang merah 7 bh"
- "bawang putih 1 bh"
- "cabe keriting 5"
- "cabe rawit 5"
- "Terasi bubuk boleh batang "
- "Gula merah "
- "Garam "
- "Minyak goreng "
recipeinstructions:
- "Masak nasi terlebih dahulu sebelum, campurkan semua bahan menjadi 1 ya bun, tambahkan air sesuai takaran dam jangan lupa koreksi rasa"
- "Masak terasi : goreng dulu bahan bahan secara bertahap, masukan dulu bawang putih, kemudian bawang merah, cabe cabeaan pake jeda ya bun, stelah layu, pindahkan bahan2 yg sudah goreng kemudian ditumbuk menjadi satu, jangam lupa tambahkan terasi bubuk (terasi yg sudah disangrai) dan gula merah. Jangan lupa garam, dan kasi minyak panas siappp deh"
- "Hidangkan semua bahan bahan.. jadilah nasi lemak yang nikmat.. sederhana.."
categories:
- Resep
tags:
- nasi
- uduk
- selera

katakunci: nasi uduk selera 
nutrition: 293 calories
recipecuisine: Indonesian
preptime: "PT20M"
cooktime: "PT59M"
recipeyield: "3"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi uduk selera / nasi lemak](https://img-global.cpcdn.com/recipes/375ea34cc2b0badf/682x484cq65/nasi-uduk-selera-nasi-lemak-foto-resep-utama.webp)

3 langkah cepat dan mudah membuat  Nasi uduk selera / nasi lemak cocok sekali jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Dalam Pembuatan Nasi uduk selera / nasi lemak:

1. Tahu goreng 
1. Petai goreng 
1. Telur dadar iris
1. Kerupuk ikan 
1. Bahan nasi 
1. Beras 2 cup
1. Bawang merah goreng saya buat sendiri 
1. Santan kara 200 ml
1. Sereh 1 btg
1. garam 1/2 sdt
1. Air sesuaikan takaran 
1. Bahan sambal terasi 
1. bawang merah 7 bh
1. bawang putih 1 bh
1. cabe keriting 5
1. cabe rawit 5
1. Terasi bubuk boleh batang 
1. Gula merah 
1. Garam 
1. Minyak goreng 

Nasi lemak is a dish sold in Malaysia, Brunei, Singapore and Southern Thailand. In Kuala Lumpur, it is called the national dish, a national heritage of Malaysia. There is a similar dish in Indonesia called nasi uduk. Its name is a Malay word that literally means &#39;rice in cream&#39;. 

<!--inarticleads2-->

## Cara Mudah Membuat Nasi uduk selera / nasi lemak:

1. Masak nasi terlebih dahulu sebelum, campurkan semua bahan menjadi 1 ya bun, tambahkan air sesuai takaran dam jangan lupa koreksi rasa
1. Masak terasi : goreng dulu bahan bahan secara bertahap, masukan dulu bawang putih, kemudian bawang merah, cabe cabeaan pake jeda ya bun, stelah layu, pindahkan bahan2 yg sudah goreng kemudian ditumbuk menjadi satu, jangam lupa tambahkan terasi bubuk (terasi yg sudah disangrai) dan gula merah. Jangan lupa garam, dan kasi minyak panas siappp deh
1. Hidangkan semua bahan bahan.. jadilah nasi lemak yang nikmat.. sederhana..


The name is derived from the. Malaysian nasi lemak is the definitely of heavenly food. Coconut infused steamed rice and a variety of toppings For local Malaysians that leave their home country, nasi lemak is THE MEAL they crave, the comfort food Aha! Nasi Lemak is very similar with what we have in Indonesia, called Nasi Uduk. Resep nasi uduk : nasi uduk kerap kali di jadikan menu sarapan pagi, kita juga dapat dengan mudah untuk menemukannya. nasi bakar sayur dan masih banyak lagi lainnya. 

Daripada ibu beli  Nasi uduk selera / nasi lemak  diluar terus, kamu  bisa membuatnya sendiri dirumah. Resep  Nasi uduk selera / nasi lemak  sederhana ini cukup praktis dalam proses pembuatannya, cukup menggunakan bumbu-bumbu sederhana yang ada di dapur  Nasi uduk selera / nasi lemak  yang enak, kamu nikmati di rumah.
