---
description: "Langkah Mudah untuk Membuat Nasi Uduk yang Bisa Manjain Lidah"
title: "Langkah Mudah untuk Membuat Nasi Uduk yang Bisa Manjain Lidah"
slug: 184-langkah-mudah-untuk-membuat-nasi-uduk-yang-bisa-manjain-lidah
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-06T13:32:04.728Z 
thumbnail: https://img-global.cpcdn.com/recipes/f25e62bca6594253/682x484cq65/nasi-uduk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/f25e62bca6594253/682x484cq65/nasi-uduk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/f25e62bca6594253/682x484cq65/nasi-uduk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/f25e62bca6594253/682x484cq65/nasi-uduk-foto-resep-utama.webp
author: Minerva Howell
ratingvalue: 3.5
reviewcount: 13
recipeingredient:
- "beras 3 cup"
- "Serai 1 batang"
- "Daun Jeruk 2 lembar"
- "Daun Salam 2 lembar"
- "Santan kara kecil 1 bungkus"
- "Garam Sedikit"
recipeinstructions:
- "Cuci bersih sampai bersih. Kemudian tarok serai, daun heruk, daun salam, dan garam."
- "Kemudian tambahkan santan kedalamnya sebanyak ketika kita memasak nasi."
- "Masukkan kedalam ricecooker. Ketika mendidih, aduk nasi hingga merata. Tunggu hingga matang kemudian sajikan dengan pelengkap lainnya."
categories:
- Resep
tags:
- nasi
- uduk

katakunci: nasi uduk 
nutrition: 298 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT39M"
recipeyield: "2"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk](https://img-global.cpcdn.com/recipes/f25e62bca6594253/682x484cq65/nasi-uduk-foto-resep-utama.webp)

Ingin membuat Nasi Uduk ? Coba resep berikut ini. Cara memasaknya sangat praktis namun jangan kaget jika hasilnya gurih dan lezat yang harus bunda coba segera

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Dalam Menyiapkan Nasi Uduk:

1. beras 3 cup
1. Serai 1 batang
1. Daun Jeruk 2 lembar
1. Daun Salam 2 lembar
1. Santan kara kecil 1 bungkus
1. Garam Sedikit



<!--inarticleads2-->

## Tata Cara Menyiapkan Nasi Uduk:

1. Cuci bersih sampai bersih. Kemudian tarok serai, daun heruk, daun salam, dan garam.
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/7362005db8b21391/160x128cq70/nasi-uduk-langkah-memasak-1-foto.webp" alt="Nasi Uduk" width="340" height="340">
>1. Kemudian tambahkan santan kedalamnya sebanyak ketika kita memasak nasi.
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/1a4e282220c8213b/160x128cq70/nasi-uduk-langkah-memasak-2-foto.webp" alt="Nasi Uduk" width="340" height="340">
><img class="lazyload" data-src="https://img-global.cpcdn.com/steps/c8aab3fa042b79f2/160x128cq70/nasi-uduk-langkah-memasak-2-foto.webp" alt="Nasi Uduk" width="340" height="340">
>1. Masukkan kedalam ricecooker. Ketika mendidih, aduk nasi hingga merata. Tunggu hingga matang kemudian sajikan dengan pelengkap lainnya.




Daripada ibu beli  Nasi Uduk  diluar terus, bunda  bisa membuatnya sendiri dirumah. Resep  Nasi Uduk  sederhana ini cukup praktis dalam proses pembuatannya, serta cukup menggunakan bumbu-bumbu sederhana yang ada di dapur  Nasi Uduk  yang enak, ibu nikmati di rumah.
