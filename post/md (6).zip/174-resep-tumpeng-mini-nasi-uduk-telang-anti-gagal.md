---
description: "Resep Tumpeng Mini - Nasi Uduk Telang Anti Gagal"
title: "Resep Tumpeng Mini - Nasi Uduk Telang Anti Gagal"
slug: 174-resep-tumpeng-mini-nasi-uduk-telang-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-21T01:37:51.167Z 
thumbnail: https://img-global.cpcdn.com/recipes/b1b06bf1ee207af5/682x484cq65/tumpeng-mini-nasi-uduk-telang-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/b1b06bf1ee207af5/682x484cq65/tumpeng-mini-nasi-uduk-telang-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/b1b06bf1ee207af5/682x484cq65/tumpeng-mini-nasi-uduk-telang-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/b1b06bf1ee207af5/682x484cq65/tumpeng-mini-nasi-uduk-telang-foto-resep-utama.webp
author: Bertha Yates
ratingvalue: 4
reviewcount: 6
recipeingredient:
- "beras 1 1/2 cup"
- "santan kental 1 sachet 65 ml"
- "Air bunga telang dari 10 kuntum bunga yang diseduh "
- "bawang merah haluskan 2 siung"
- "bawang putih haluskan 1 siung"
- "garam 1/2-1 sdt"
- "daun salam 1 lembar"
- "serehgeprek 1 batang"
recipeinstructions:
- "Cuci beras hingga bersih. Masukan panci magic com. Tambahkan bumbu halus, Salam, sereh, garam, santan, air bunga telang sampai 1 ruas jari diatas beras."
- "Aduk rata. Dan masak seperti viasa dalam magic com. Saat nasi mendidih, aduk- aduk agar semua beras menyerap Santan dan bumbu. Tunggu hingga nasi matang."
- "Siapkan Cetakan tumpeng mini/ daun pisang yang dibentuk kerucut. Masukan nasi panas yang sudah matang, padatkan Dan keluarkan. Tata di piring Dan sajikan dengan lauk pelengkap."
categories:
- Resep
tags:
- tumpeng
- mini
- 

katakunci: tumpeng mini  
nutrition: 249 calories
recipecuisine: Indonesian
preptime: "PT38M"
cooktime: "PT45M"
recipeyield: "3"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Tumpeng Mini - Nasi Uduk Telang](https://img-global.cpcdn.com/recipes/b1b06bf1ee207af5/682x484cq65/tumpeng-mini-nasi-uduk-telang-foto-resep-utama.webp)

Resep dan cara memasak  Tumpeng Mini - Nasi Uduk Telang yang bisa ibu coba dirumah

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Untuk Pembuatan Tumpeng Mini - Nasi Uduk Telang:

1. beras 1 1/2 cup
1. santan kental 1 sachet 65 ml
1. Air bunga telang dari 10 kuntum bunga yang diseduh 
1. bawang merah haluskan 2 siung
1. bawang putih haluskan 1 siung
1. garam 1/2-1 sdt
1. daun salam 1 lembar
1. serehgeprek 1 batang



<!--inarticleads2-->

## Cara Mudah Membuat Tumpeng Mini - Nasi Uduk Telang:

1. Cuci beras hingga bersih. Masukan panci magic com. Tambahkan bumbu halus, Salam, sereh, garam, santan, air bunga telang sampai 1 ruas jari diatas beras.
1. Aduk rata. Dan masak seperti viasa dalam magic com. Saat nasi mendidih, aduk- aduk agar semua beras menyerap Santan dan bumbu. Tunggu hingga nasi matang.
1. Siapkan Cetakan tumpeng mini/ daun pisang yang dibentuk kerucut. Masukan nasi panas yang sudah matang, padatkan Dan keluarkan. Tata di piring Dan sajikan dengan lauk pelengkap.




Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
