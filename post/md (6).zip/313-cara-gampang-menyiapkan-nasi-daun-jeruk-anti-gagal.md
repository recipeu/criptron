---
description: "Cara Gampang Menyiapkan Nasi daun jeruk Anti Gagal"
title: "Cara Gampang Menyiapkan Nasi daun jeruk Anti Gagal"
slug: 313-cara-gampang-menyiapkan-nasi-daun-jeruk-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-08T21:57:35.656Z 
thumbnail: https://img-global.cpcdn.com/recipes/68d9a9abb0866901/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/68d9a9abb0866901/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/68d9a9abb0866901/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/68d9a9abb0866901/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
author: Tom Hayes
ratingvalue: 4.8
reviewcount: 9
recipeingredient:
- "beras 2.5 cup"
- "air Secukupnya"
- "daun jeruk iris tipis 8 lembar"
- "bawang putih 3 siung"
- "mentega 4 sdm"
- "lada bubuk 1 sdt"
recipeinstructions:
- "Masak beras di rice cooker seperti biasa. Setelah matang diamkan hingga tanak"
- "Sambil menunggu, panaskan wajan. Lelehkan mentega, tumis bawang putih, daun jeruk dan lada bubuk hingga harum"
- "Tuangkan tumisan mentega, bawang &amp; daun jeruk ke dalam nasi yang sudah matang. Aduk rata, diamkan di dalam rice cooker sekitar 10 menit agar meresap sempurna"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 155 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT38M"
recipeyield: "4"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi daun jeruk](https://img-global.cpcdn.com/recipes/68d9a9abb0866901/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp)

Resep rahasia dan cara mengolah  Nasi daun jeruk cocok sekali jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Dalam Menyiapkan Nasi daun jeruk:

1. beras 2.5 cup
1. air Secukupnya
1. daun jeruk iris tipis 8 lembar
1. bawang putih 3 siung
1. mentega 4 sdm
1. lada bubuk 1 sdt

Nasi daun jeruk siap dihidangkan dengan. Nasi daun jeruk ini memang sedang tren di kalangan masyarakat Indonesia, banyak sekali kaum muda mudi yang berlomba-lomba membuat makanan nasi putih spesial ini. Nasi daun jeruk ala geprek bensu rekomended buat di coba. Geprek bensu nasi daun jeruk anti mainst. 

<!--inarticleads2-->

## Tata Cara Membuat Nasi daun jeruk:

1. Masak beras di rice cooker seperti biasa. Setelah matang diamkan hingga tanak
1. Sambil menunggu, panaskan wajan. Lelehkan mentega, tumis bawang putih, daun jeruk dan lada bubuk hingga harum
1. Tuangkan tumisan mentega, bawang &amp; daun jeruk ke dalam nasi yang sudah matang. Aduk rata, diamkan di dalam rice cooker sekitar 10 menit agar meresap sempurna


Gurih dan wangi dari daun jeruk menambah kelezatan nasi daun jeruk. Nasi dengan campuran daun jeruk yang wangi sedang tren. Hai selamat pagi sahabat CWS, pagi ini saya share resep Nasi Daun Jeruk. Praktis banget karena saya gunakan rice cooker. Rasanya mirip nasi uduk tapi wangiiii. 

Daripada kamu beli  Nasi daun jeruk  diluar terus, ibu  bisa membuatnya sendiri dirumah. Resep  Nasi daun jeruk  sederhana ini cukup praktis dalam proses pembuatannya, serta cukup menggunakan bumbu sederhana  Nasi daun jeruk  yang enak, ibu nikmati di rumah.
