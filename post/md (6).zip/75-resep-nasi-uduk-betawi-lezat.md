---
description: "Resep Nasi uduk betawi, Lezat"
title: "Resep Nasi uduk betawi, Lezat"
slug: 75-resep-nasi-uduk-betawi-lezat
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-29T23:50:18.313Z 
thumbnail: https://img-global.cpcdn.com/recipes/9f38377a2477ebb0/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/9f38377a2477ebb0/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/9f38377a2477ebb0/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/9f38377a2477ebb0/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
author: Edith Williamson
ratingvalue: 4.1
reviewcount: 9
recipeingredient:
- "Bumbu halus  "
- " Bawang merah  4 siung 1"
- " Bawang putih  2 siung 2"
- " Ketumbar  12 sendok teh 3"
- " Lada  12 sendok teh 4"
- " Jahe  kurang lebih 4cm 5"
- " Kencur   2cm 6"
- "Bahan yang digeprek  "
- " Sereh  2 1"
- " Lengkuas  kurang lebih 4cm 2"
- "Bahan lain2  "
- " Beras 25 takaran magicom 1"
- " Santan kara yg bentuk segitiga  1 buah 2"
- " Daun salam  2 lembar 3"
- " Air  600cc 4"
- " Garam  2sdm 5"
- " Minyak goreng  3 sendok makan 6"
recipeinstructions:
- "Haluskan bahan-bahan bumbu halus denham blander (bisa di ulek)."
- "Cuci beras sebanyak 2x ganti air, jangan di remas-remas nanti kandungan vitaminnya hilang. Setelah di cuci tuang air +/- 600cc. Diamkan sebentar, agar nasi nanti jadi empuk. Lanjutkan menumis bumbu halus."
- "Tuangkan minyak sebanyak 3 sendok panaskan, lalu masukan bumbu halus, mulai menumis. Masukan daun salam, daun sereh, lengkuas yang sudah di geprek. Tumis sampai harum dan warna agak keemasan. Setelah matang, diamkan agar suhu berkurang panasnya."
- "Mulai mengaronkan beras, masukan bumbu yang telah di tumis beserta sisa minyaknya. Aduk-aduk sampai rata. Masukan garam 2 sdm, aduk kembali sampai rata, lalu masukan santan kara aduk kembali sampai air tiris. Setelah itu kukus nasi kurang lebih 45 menit."
- "Setelah 45 menit pastikan nasi sudah matang, lalu pindahkan ke megiciom untuk tetap hangat."
- "Nasi dapat di hidangkan, lebih mantap menggunakan bawang goreng 😊."
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 256 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT34M"
recipeyield: "2"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi uduk betawi](https://img-global.cpcdn.com/recipes/9f38377a2477ebb0/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp)

6 langkah cepat dan mudah mengolah  Nasi uduk betawi cocok sekali jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Untuk Menyiapkan Nasi uduk betawi:

1. Bumbu halus  
1.  Bawang merah  4 siung 1
1.  Bawang putih  2 siung 2
1.  Ketumbar  12 sendok teh 3
1.  Lada  12 sendok teh 4
1.  Jahe  kurang lebih 4cm 5
1.  Kencur   2cm 6
1. Bahan yang digeprek  
1.  Sereh  2 1
1.  Lengkuas  kurang lebih 4cm 2
1. Bahan lain2  
1.  Beras 25 takaran magicom 1
1.  Santan kara yg bentuk segitiga  1 buah 2
1.  Daun salam  2 lembar 3
1.  Air  600cc 4
1.  Garam  2sdm 5
1.  Minyak goreng  3 sendok makan 6

Menu siap saji, tinggal goreng dan siap disantap dengan. There are no reviews for Nasi Uduk Betawi Bang Acim, Indonesia yet. Be the first to write a review! Cara membuat nasi uduk betawi bisa dibikin mudah, cukup gunakan magic com. 

<!--inarticleads2-->

## Cara Menyiapkan Nasi uduk betawi:

1. Haluskan bahan-bahan bumbu halus denham blander (bisa di ulek).
1. Cuci beras sebanyak 2x ganti air, jangan di remas-remas nanti kandungan vitaminnya hilang. Setelah di cuci tuang air +/- 600cc. Diamkan sebentar, agar nasi nanti jadi empuk. Lanjutkan menumis bumbu halus.
1. Tuangkan minyak sebanyak 3 sendok panaskan, lalu masukan bumbu halus, mulai menumis. Masukan daun salam, daun sereh, lengkuas yang sudah di geprek. Tumis sampai harum dan warna agak keemasan. Setelah matang, diamkan agar suhu berkurang panasnya.
1. Mulai mengaronkan beras, masukan bumbu yang telah di tumis beserta sisa minyaknya. Aduk-aduk sampai rata. Masukan garam 2 sdm, aduk kembali sampai rata, lalu masukan santan kara aduk kembali sampai air tiris. Setelah itu kukus nasi kurang lebih 45 menit.
1. Setelah 45 menit pastikan nasi sudah matang, lalu pindahkan ke megiciom untuk tetap hangat.
1. Nasi dapat di hidangkan, lebih mantap menggunakan bawang goreng 😊.


Berikut resep nasi uduk betawi sederhana yang bisa untuk dijual. Resep Nasi Uduk Betawi - Makanan khas Betawi ini cocok sekali dijadikan menu sarapan. Uhh, sajian nasi uduk betawi ini akan semakin lezat dan komplit. Baca Juga : Resep Mie Aceh Tumis. Nasi uduk Betawi memiliki kekhasannya sendiri dan sudah memiliki citra tersendiri. 

Selamat memasak dan menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
