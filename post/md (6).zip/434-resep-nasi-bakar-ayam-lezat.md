---
description: "Resep Nasi Bakar Ayam, Lezat"
title: "Resep Nasi Bakar Ayam, Lezat"
slug: 434-resep-nasi-bakar-ayam-lezat
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-11-29T08:09:56.421Z 
thumbnail: https://img-global.cpcdn.com/recipes/eb51669546d4afd7/682x484cq65/nasi-bakar-ayam-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/eb51669546d4afd7/682x484cq65/nasi-bakar-ayam-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/eb51669546d4afd7/682x484cq65/nasi-bakar-ayam-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/eb51669546d4afd7/682x484cq65/nasi-bakar-ayam-foto-resep-utama.webp
author: Alfred Hall
ratingvalue: 3.9
reviewcount: 15
recipeingredient:
- "Ayam fillet sisa soto 14 suirsuir "
- "Nasi 12 kg lebih "
- "Daun kemangi ambil daunnya 2 ikat"
- "Daun salam 5 lembar"
- "Sereh sedang geprek putihnya 3"
- "Lengkuas potong tipis 2 ruas"
- "Bumbu Halus  "
- "Bawang putih 8 biji"
- "Bawang merah 10 biji"
- "Garam 1/2 sdt"
- "Kaldu jamur 1 sdt"
- "Merica bubuk 1/2 sdt"
- "Kencur 2 ruas"
- "Kunyit 3 ruas"
- "Daun pisang di jemur kemudian potongpotong "
- "gigi Tusuk"
recipeinstructions:
- "Tumis bumbu halus sampai harum kemudian masukkan sereh, lengkuas, daun salam. Tumis hingga harum."
- "Kemudian masukkan ayam yg sudah di suir-suir, aduk rata. Dicicipi terlebih dahulu."
- "Lalu masukkan nasi, aduk sampai rata, kemudian masukkan daun kemangi, tumis hingga layu. Angkat."
- "Bungkus nasi dengan daun pisang, lalu kukus selama 20 menit. Kemudian bakar menggunakan teflon/bakaran sampai harum. Angkat."
categories:
- Resep
tags:
- nasi
- bakar
- ayam

katakunci: nasi bakar ayam 
nutrition: 148 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT33M"
recipeyield: "1"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Bakar Ayam](https://img-global.cpcdn.com/recipes/eb51669546d4afd7/682x484cq65/nasi-bakar-ayam-foto-resep-utama.webp)

Resep Nasi Bakar Ayam  sederhana dengan 4 langkahmudah yang harus kamu coba dirumah

<!--inarticleads1-->

## Beberapa Bahan Yang Dibutuhkan Untuk Menyiapkan Nasi Bakar Ayam:

1. Ayam fillet sisa soto 14 suirsuir 
1. Nasi 12 kg lebih 
1. Daun kemangi ambil daunnya 2 ikat
1. Daun salam 5 lembar
1. Sereh sedang geprek putihnya 3
1. Lengkuas potong tipis 2 ruas
1. Bumbu Halus  
1. Bawang putih 8 biji
1. Bawang merah 10 biji
1. Garam 1/2 sdt
1. Kaldu jamur 1 sdt
1. Merica bubuk 1/2 sdt
1. Kencur 2 ruas
1. Kunyit 3 ruas
1. Daun pisang di jemur kemudian potongpotong 
1. gigi Tusuk



<!--inarticleads2-->

## Cara Membuat Nasi Bakar Ayam:

1. Tumis bumbu halus sampai harum kemudian masukkan sereh, lengkuas, daun salam. Tumis hingga harum.
1. Kemudian masukkan ayam yg sudah di suir-suir, aduk rata. Dicicipi terlebih dahulu.
1. Lalu masukkan nasi, aduk sampai rata, kemudian masukkan daun kemangi, tumis hingga layu. Angkat.
1. Bungkus nasi dengan daun pisang, lalu kukus selama 20 menit. Kemudian bakar menggunakan teflon/bakaran sampai harum. Angkat.




Salah satu masakan yang cukup praktis dalam pembuatannya adalah  Nasi Bakar Ayam. Selain itu  Nasi Bakar Ayam  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu ikuti 4 langkah, dan  Nasi Bakar Ayam  pun siap di hidangkan. selamat mencoba !
