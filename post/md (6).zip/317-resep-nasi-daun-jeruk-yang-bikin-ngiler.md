---
description: "Resep Nasi Daun Jeruk yang Bikin Ngiler"
title: "Resep Nasi Daun Jeruk yang Bikin Ngiler"
slug: 317-resep-nasi-daun-jeruk-yang-bikin-ngiler
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-08T21:42:16.360Z 
thumbnail: https://img-global.cpcdn.com/recipes/f50cea590f02c468/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/f50cea590f02c468/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/f50cea590f02c468/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/f50cea590f02c468/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
author: Alberta Boone
ratingvalue: 3.1
reviewcount: 8
recipeingredient:
- "serai 2 Batang"
- "bawang merah iris tipis 3 siung"
- "bawang putih cincang 3 siung"
- "daun jeruk buang tulangnya 3 lembar"
- "cabe rawit merah 4"
- "Garam dan lada "
- "Beras secukupnya aku untuk 4x makan "
- "Olive oil "
recipeinstructions:
- "Tumis semua bahan dengan olive oil hingga harum"
- "Cuci bersih beras dan masukkan ke dalam wadah rice cooker"
- "Letakkan bahan yang sudah di tumis di atas beras. Tidak perlu diaduk. Beri air sesuai selera pada beras. Kalo aku setinggi satu ruas jari"
- "Masak beras seperti menanak biasa. Setelah matang, aduk agar bumbu merata. Nasi daun jeruk siap dimakan menggunakan ayam goreng atau telor ceplok🤗"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 129 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT47M"
recipeyield: "1"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk](https://img-global.cpcdn.com/recipes/f50cea590f02c468/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp)

Resep rahasia Nasi Daun Jeruk    dengan 4 langkahcepat dan mudah cocok banget jika digunakan untuk menjamu tamu

<!--inarticleads1-->

## Bahan-bahan Yang Digunakan Dalam Menyiapkan Nasi Daun Jeruk:

1. serai 2 Batang
1. bawang merah iris tipis 3 siung
1. bawang putih cincang 3 siung
1. daun jeruk buang tulangnya 3 lembar
1. cabe rawit merah 4
1. Garam dan lada 
1. Beras secukupnya aku untuk 4x makan 
1. Olive oil 

Nasi daun jeruk siap dihidangkan dengan. Nasi daun jeruk ini memang sedang tren di kalangan masyarakat Indonesia, banyak sekali kaum muda mudi yang berlomba-lomba membuat makanan nasi putih spesial ini. Nasi daun jeruk ala geprek bensu rekomended buat di coba. Geprek bensu nasi daun jeruk anti mainst. 

<!--inarticleads2-->

## Tata Cara Menyiapkan Nasi Daun Jeruk:

1. Tumis semua bahan dengan olive oil hingga harum
1. Cuci bersih beras dan masukkan ke dalam wadah rice cooker
1. Letakkan bahan yang sudah di tumis di atas beras. Tidak perlu diaduk. Beri air sesuai selera pada beras. Kalo aku setinggi satu ruas jari
1. Masak beras seperti menanak biasa. Setelah matang, aduk agar bumbu merata. Nasi daun jeruk siap dimakan menggunakan ayam goreng atau telor ceplok🤗


Gurih dan wangi dari daun jeruk menambah kelezatan nasi daun jeruk. Nasi dengan campuran daun jeruk yang wangi sedang tren. Hai selamat pagi sahabat CWS, pagi ini saya share resep Nasi Daun Jeruk. Praktis banget karena saya gunakan rice cooker. Rasanya mirip nasi uduk tapi wangiiii. 

Terima kasih telah membaca resep yang tim kami tampilkan di halaman ini. Semoga bermanfaat dan selamat mencoba!
