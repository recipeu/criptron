---
description: "Resep Nasi Uduk Betawi (Tips nasi tidak cepat basi) yang Sempurna"
title: "Resep Nasi Uduk Betawi (Tips nasi tidak cepat basi) yang Sempurna"
slug: 0-resep-nasi-uduk-betawi-tips-nasi-tidak-cepat-basi-yang-sempurna
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-22T12:14:46.843Z 
thumbnail: https://img-global.cpcdn.com/recipes/09255912eba8675c/682x484cq65/nasi-uduk-betawi-tips-nasi-tidak-cepat-basi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/09255912eba8675c/682x484cq65/nasi-uduk-betawi-tips-nasi-tidak-cepat-basi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/09255912eba8675c/682x484cq65/nasi-uduk-betawi-tips-nasi-tidak-cepat-basi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/09255912eba8675c/682x484cq65/nasi-uduk-betawi-tips-nasi-tidak-cepat-basi-foto-resep-utama.webp
author: Edwin Hubbard
ratingvalue: 4.9
reviewcount: 13
recipeingredient:
- "beras 500 gr"
- "santan encer bisa di sesuaikan berasnya 750 ml"
- "Bahan Bumbu "
- "daun salam 3"
- "sereh geprek 2 batang"
- "kayu manis uk kecil atau 14 sdt kayumanis bubuk 1 batang"
- "cengkeh 5 buah"
- "daun pandan simpulkan 1"
- "jahe geprek 2 ruas"
- "lengkuas 2 ruas"
- "pala bubuk 1/4 sdt"
- "garam sesuaikan selera 1/2 sdm"
recipeinstructions:
- "Siapkan semua bahan lalu rebus bahan santan dan bumbu hingga mendidih. Jika sudah tambahkan garam dan air lemon. Fungsinya supaya nasi tidak cepat basi"
- "Cuci beras lalu tambahkan bahan santan. Masak dengan mode masak nasi hingga matang. Jika sudah bunyi biarkan dulu 10 menit baru dibuka dan diaduk. Biar nasi tanak atau matang sempurna"
- "Sajikan dengan pelengkapnya           (lihat resep)"
- "Yummy           (lihat resep)"
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 122 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT47M"
recipeyield: "4"
recipecategory: Lunch


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Betawi (Tips nasi tidak cepat basi)](https://img-global.cpcdn.com/recipes/09255912eba8675c/682x484cq65/nasi-uduk-betawi-tips-nasi-tidak-cepat-basi-foto-resep-utama.webp)

Resep dan cara memasak  Nasi Uduk Betawi (Tips nasi tidak cepat basi) cocok banget jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Bahan-bahan Yang Diperlukan Dalam Menyiapkan Nasi Uduk Betawi (Tips nasi tidak cepat basi):

1. beras 500 gr
1. santan encer bisa di sesuaikan berasnya 750 ml
1. Bahan Bumbu 
1. daun salam 3
1. sereh geprek 2 batang
1. kayu manis uk kecil atau 14 sdt kayumanis bubuk 1 batang
1. cengkeh 5 buah
1. daun pandan simpulkan 1
1. jahe geprek 2 ruas
1. lengkuas 2 ruas
1. pala bubuk 1/4 sdt
1. garam sesuaikan selera 1/2 sdm

Ini karena nasi uduk dimasak setengah matang (diaron) dulu dengan santan dan berbagai bumbu lain seperti daun jeruk, lengkuas, serai, dan. Nasi yang cepat basi, membuat anda kerepotan karena harus memasak nasi berulang- ulang. Untuk itu, ada baiknya bagi anda untuk menghindari hal-hal yang dapat menyebabkan nasi menjadi lebih cepat basi dengan tips serta cara di atas. Make this easy and aromatic Betawi-style nasi uduk that goes with many main and side dishes. 

<!--inarticleads2-->

## Tata Cara Membuat Nasi Uduk Betawi (Tips nasi tidak cepat basi):

1. Siapkan semua bahan lalu rebus bahan santan dan bumbu hingga mendidih. Jika sudah tambahkan garam dan air lemon. Fungsinya supaya nasi tidak cepat basi
1. Cuci beras lalu tambahkan bahan santan. Masak dengan mode masak nasi hingga matang. Jika sudah bunyi biarkan dulu 10 menit baru dibuka dan diaduk. Biar nasi tanak atau matang sempurna
1. Sajikan dengan pelengkapnya -           (lihat resep)
1. Yummy -           (lihat resep)


I&#39;m sharing how you can make it easily with a rice My favorite way of cooking nasi uduk is with a rice cooker or Instant Pot. It&#39;s a no brainer because I just need to put everything in there without having to. Memang nasi uduk Betawi memiliki rasa yang dapat membuat siapa saja ketagihan, tapi alangkah baiknya Anda, tetap makan nasi uduk Betawi sesuai dengan porsi yang mamang pas dengan kebutuhan isi perut Anda. Makan makanan yang berlebihan jelas tidak baik untuk kesehatan tubuh. Coba resep nasi uduk betawi klasik untuk sarapan. 

Selamat menikmati hidangan spesial ini bersama keluarga. Salam Istimewa.
