---
description: "Resep Nasi Daun Jeruk Anti Gagal"
title: "Resep Nasi Daun Jeruk Anti Gagal"
slug: 307-resep-nasi-daun-jeruk-anti-gagal
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-02T08:55:14.208Z 
thumbnail: https://img-global.cpcdn.com/recipes/533d948022fa6002/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/533d948022fa6002/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/533d948022fa6002/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/533d948022fa6002/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp
author: Lucille Wise
ratingvalue: 4.2
reviewcount: 8
recipeingredient:
- "beras 2 cup"
- "daun jeruk 15 lembar"
- "sereh 1 batang"
- "daun salam 3 lembar"
- "mentega margarin 2 sdm"
- "merica garam dan kaldu bubuk secukupnya"
recipeinstructions:
- "Cuci beras, dan berikan air seperti menanak nasi biasa"
- "Iris daun jeruk tipis², masukan kedalam panci/ricecooker di susul daun salam, sereh,margarin/mentega,garam,merica dan kaldu bubuk (saya pakai panci biar lebih mudah mengaduknya)"
- "Sesekali aduk beras, tunggu hingga matang, aduk2 kembali dan siap di sajikan"
categories:
- Resep
tags:
- nasi
- daun
- jeruk

katakunci: nasi daun jeruk 
nutrition: 195 calories
recipecuisine: Indonesian
preptime: "PT16M"
cooktime: "PT54M"
recipeyield: "4"
recipecategory: Dessert


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Daun Jeruk](https://img-global.cpcdn.com/recipes/533d948022fa6002/682x484cq65/nasi-daun-jeruk-foto-resep-utama.webp)

Ingin membuat Nasi Daun Jeruk ? Coba resep berikut ini. Cara memasaknya sangat praktis namun jangan kaget jika hasilnya gurih dan lezat yang bisa bunda coba dirumah

<!--inarticleads1-->

## Bahan-bahan Yang Dibutuhkan Dalam Pembuatan Nasi Daun Jeruk:

1. beras 2 cup
1. daun jeruk 15 lembar
1. sereh 1 batang
1. daun salam 3 lembar
1. mentega margarin 2 sdm
1. merica garam dan kaldu bubuk secukupnya

Nasi daun jeruk siap dihidangkan dengan. Nasi daun jeruk ini memang sedang tren di kalangan masyarakat Indonesia, banyak sekali kaum muda mudi yang berlomba-lomba membuat makanan nasi putih spesial ini. Nasi daun jeruk ala geprek bensu rekomended buat di coba. Geprek bensu nasi daun jeruk anti mainst. 

<!--inarticleads2-->

## Cara Mudah Menyiapkan Nasi Daun Jeruk:

1. Cuci beras, dan berikan air seperti menanak nasi biasa
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/f9570fd74c299076/160x128cq70/nasi-daun-jeruk-langkah-memasak-1-foto.webp" alt="Nasi Daun Jeruk" width="340" height="340">
>1. Iris daun jeruk tipis², masukan kedalam panci/ricecooker di susul daun salam, sereh,margarin/mentega,garam,merica dan kaldu bubuk (saya pakai panci biar lebih mudah mengaduknya)
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/e28177860f6f3430/160x128cq70/nasi-daun-jeruk-langkah-memasak-2-foto.webp" alt="Nasi Daun Jeruk" width="340" height="340">
>1. Sesekali aduk beras, tunggu hingga matang, aduk2 kembali dan siap di sajikan
<img class="lazyload" data-src="https://img-global.cpcdn.com/steps/f17134d4ab53441d/160x128cq70/nasi-daun-jeruk-langkah-memasak-3-foto.webp" alt="Nasi Daun Jeruk" width="340" height="340">
>

Gurih dan wangi dari daun jeruk menambah kelezatan nasi daun jeruk. Nasi dengan campuran daun jeruk yang wangi sedang tren. Hai selamat pagi sahabat CWS, pagi ini saya share resep Nasi Daun Jeruk. Praktis banget karena saya gunakan rice cooker. Rasanya mirip nasi uduk tapi wangiiii. 

Salah satu masakan yang cukup praktis pembuatannya adalah  Nasi Daun Jeruk. Selain itu  Nasi Daun Jeruk  juga cukup banyak digemari oleh semua kalangan, Cara penyajiannya juga cukup mudah, cukup sediakan bahan-bahan diatas lalu ikuti 3 langkah, dan  Nasi Daun Jeruk  pun siap di hidangkan. selamat mencoba !
