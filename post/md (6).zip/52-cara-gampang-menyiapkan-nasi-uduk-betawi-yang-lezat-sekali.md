---
description: "Cara Gampang Menyiapkan Nasi Uduk Betawi yang Lezat Sekali"
title: "Cara Gampang Menyiapkan Nasi Uduk Betawi yang Lezat Sekali"
slug: 52-cara-gampang-menyiapkan-nasi-uduk-betawi-yang-lezat-sekali
future: true
lang: id
language: id
languageCode: id
publishDate: 2021-12-02T09:32:27.310Z 
thumbnail: https://img-global.cpcdn.com/recipes/3ce51fc6f3090f92/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
images:
- https://img-global.cpcdn.com/recipes/3ce51fc6f3090f92/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
image: https://img-global.cpcdn.com/recipes/3ce51fc6f3090f92/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
cover: https://img-global.cpcdn.com/recipes/3ce51fc6f3090f92/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp
author: Cornelia Lowe
ratingvalue: 4.8
reviewcount: 6
recipeingredient:
- "Beras 4 cup"
- "Santan atau secukupnya sesuai dengan takaran masak nasi biasa 500 ml"
- "Lengkuas parut halus 1 ruas"
- "Jahe parut halus 1 ruas"
- "Bawah merah parut halus 5 siung"
- "Garam 1 sdm"
- "kayu manis kira2 2 cm"
- "kembang lawang 3"
- "sereh 5 batang"
- "daun salam 8"
recipeinstructions:
- "Siapkan bahan2 jahe, lengkuas, bawang merah yg sudah di parut. Siapkan panci kemudian Cuci beras &amp; masukkan santan ke beras."
- "Masukkan bahan parutan ke dalam panci beras yg sudah di campur dengan santan. Aduk rata. Kemudian masukkan daun salam dan sereh serta masukkan garam. Aduk rata &amp; nyalakan kompor dengan api sedang."
- "Masak beras sampai air santan menyusut. Sesekali di aduk supaya tidak gosong bawahnya. Siapkan kukusan."
- "Setelah air menyusut &amp; agak kering, pindahkan beras ke kukusan yang sudah di siapkan sebelumnya. Kukus beras kira2 30 menit. Sesekali di aduk supaya merata matangnya. Setelah 30 menit cek tekstur nasinya, kalau di rasa kurang matang bisa di lanjut kukusnya sampai sesuai tekstur yg di inginkan (jgn lupa cek airnya jgn sampai kering). Nasi uduk siap di hidangkan."
categories:
- Resep
tags:
- nasi
- uduk
- betawi

katakunci: nasi uduk betawi 
nutrition: 169 calories
recipecuisine: Indonesian
preptime: "PT16M"
cooktime: "PT47M"
recipeyield: "4"
recipecategory: Dinner


     
    
    
    
    
    
    
    
    
    
    
      
    
---


![Nasi Uduk Betawi](https://img-global.cpcdn.com/recipes/3ce51fc6f3090f92/682x484cq65/nasi-uduk-betawi-foto-resep-utama.webp)

Resep dan cara memasak  Nasi Uduk Betawi cocok sekali jika digunakan untuk menjamu teman

<!--inarticleads1-->

## Beberapa Bahan Yang Diperlukan Untuk Menyiapkan Nasi Uduk Betawi:

1. Beras 4 cup
1. Santan atau secukupnya sesuai dengan takaran masak nasi biasa 500 ml
1. Lengkuas parut halus 1 ruas
1. Jahe parut halus 1 ruas
1. Bawah merah parut halus 5 siung
1. Garam 1 sdm
1. kayu manis kira2 2 cm
1. kembang lawang 3
1. sereh 5 batang
1. daun salam 8



<!--inarticleads2-->

## Langkah-langkah Untuk Menyiapkan Nasi Uduk Betawi:

1. Siapkan bahan2 jahe, lengkuas, bawang merah yg sudah di parut. Siapkan panci kemudian Cuci beras &amp; masukkan santan ke beras.
1. Masukkan bahan parutan ke dalam panci beras yg sudah di campur dengan santan. Aduk rata. Kemudian masukkan daun salam dan sereh serta masukkan garam. Aduk rata &amp; nyalakan kompor dengan api sedang.
1. Masak beras sampai air santan menyusut. Sesekali di aduk supaya tidak gosong bawahnya. Siapkan kukusan.
1. Setelah air menyusut &amp; agak kering, pindahkan beras ke kukusan yang sudah di siapkan sebelumnya. Kukus beras kira2 30 menit. Sesekali di aduk supaya merata matangnya. Setelah 30 menit cek tekstur nasinya, kalau di rasa kurang matang bisa di lanjut kukusnya sampai sesuai tekstur yg di inginkan (jgn lupa cek airnya jgn sampai kering). Nasi uduk siap di hidangkan.




Daripada   beli  Nasi Uduk Betawi  diluar terus, kamu  bisa membuatnya sendiri dirumah. Resep  Nasi Uduk Betawi  sederhana ini cukup praktis dalam proses pembuatannya, serta cukup menggunakan bumbu-bumbu sederhana yang ada di dapur  Nasi Uduk Betawi  yang enak, kamu nikmati di rumah.
